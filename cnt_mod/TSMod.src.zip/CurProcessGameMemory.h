#pragma once


void setCurProcessGameMemory();

void copyAllBushouSoldiersOriginToCopy();
