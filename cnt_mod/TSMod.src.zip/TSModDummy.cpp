#include "WinTarget.h"

void WINAPI DummyFunc() {;}