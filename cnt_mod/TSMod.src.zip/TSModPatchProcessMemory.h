#pragma once

namespace TSModReadMode {
	enum { MAIN=1, WINMM=2 };
}
void TDModPatchProcessMemory(int iMode); 
