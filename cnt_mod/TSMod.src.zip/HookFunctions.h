#pragma once


void HookFunctions(); 
