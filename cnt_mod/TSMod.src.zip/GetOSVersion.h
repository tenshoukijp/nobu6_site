#pragma once

#include "WinTarget.h"

double getOSVersion();