#pragma once

#include "WinTarget.h"
#include <vector>
#include "GameDataStruct.h"

using namespace std;

#define SCENARIODATASTRUCT_NUM 6




extern vector<vector<byte>> vSnDataN6P;
