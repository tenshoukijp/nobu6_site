##
# TypeError ISO Test

assert('TypeError', '15.2.29') do
  assert_equal Class, TypeError.class
end
