/*
** print.c - Kernel.#p
**
** See Copyright Notice in mruby.h
*/

#include "mruby.h"
#include "mruby/string.h"
#include "mruby/variable.h"

static void
printstr(mrb_state *mrb, mrb_value obj)
{
#ifdef ENABLE_STDIO
  char *s;
  int len;

  if (mrb_string_p(obj)) {
    s = RSTRING_PTR(obj);
    len = RSTRING_LEN(obj);
    ODSfwrite(s, len, 1, stdout);
  }
#endif
}

MRB_API void
mrb_p(mrb_state *mrb, mrb_value obj)
{
#ifdef ENABLE_STDIO
  obj = mrb_funcall(mrb, obj, "inspect", 0);
  printstr(mrb, obj);
  ODSputc('\n', stdout);
#endif
}

MRB_API void
mrb_print_error(mrb_state *mrb)
{
#ifdef ENABLE_STDIO
  mrb_value s;

  mrb_print_backtrace(mrb);
  s = mrb_funcall(mrb, mrb_obj_value(mrb->exc), "inspect", 0);
  if (mrb_string_p(s)) {
    ODSfwrite(RSTRING_PTR(s), RSTRING_LEN(s), 1, stderr);
    ODSputc('\n', stderr);
  }
#endif
}

MRB_API void
mrb_show_version(mrb_state *mrb)
{
  mrb_value msg;

  msg = mrb_const_get(mrb, mrb_obj_value(mrb->object_class), mrb_intern_lit(mrb, "MRUBY_DESCRIPTION"));
  printstr(mrb, msg);
  printstr(mrb, mrb_str_new_lit(mrb, "\n"));
}

MRB_API void
mrb_show_copyright(mrb_state *mrb)
{
  mrb_value msg;

  msg = mrb_const_get(mrb, mrb_obj_value(mrb->object_class), mrb_intern_lit(mrb, "MRUBY_COPYRIGHT"));
  printstr(mrb, msg);
  printstr(mrb, mrb_str_new_lit(mrb, "\n"));
}





#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>

size_t ODSfwrite(const void *buf, size_t size, size_t n, FILE *fp) {
	if ( fp == stderr || fp == stdout ) {
		char szBufDebug[4096] = "";
	    int length = sizeof(szBufDebug);
		strncpy(szBufDebug, buf, length);
	    szBufDebug[length - 1] = '\0';
		OutputDebugString(szBufDebug);
	}
	return fwrite(buf, size, n, fp);
}

int ODSfputs( const char *str , FILE *fp ) {
	if ( fp == stderr || fp == stdout ) {
		char szBufDebug[4096] = "";
	    int length = sizeof(szBufDebug);
		strncpy(szBufDebug, str, length);
	    szBufDebug[length - 1] = '\0';
		OutputDebugString(szBufDebug);
	}
	return fputs(str, fp);
}

int ODSputs( const char *str ) {
	char szBufDebug[4096] = "";
    int length = sizeof(szBufDebug);
	strncpy(szBufDebug, str, length);
    szBufDebug[length - 1] = '\0';
	OutputDebugString(szBufDebug);
	return puts(str);
}

int ODSputc( int c, FILE *stream ) {
	char buf[2] = "";
	buf[0] = (unsigned char)c;
	if ( stream == stderr || stream == stdout ) {
		OutputDebugString(buf);
	}
	return putc(c, stream);
}


int ODSfprintf( FILE *stream, char *format, ... ) {
    char szBufDebug[4096] = "";
	int ret = 0;
    int length = sizeof(szBufDebug);

    va_list arg;

    va_start(arg, format);
	ret = vfprintf( stream, format, arg );
    _vsnprintf_s(szBufDebug, length, _TRUNCATE, format, arg);
    va_end(arg);

    szBufDebug[length - 1] = '\0';

	if ( stream == stderr || stream == stdout ) {
		OutputDebugString( szBufDebug );
	}
	return ret;

}

int ODSprintf( char *format, ... ) {
    char szBufDebug[4096] = "";
	int ret = 0;
    int length = sizeof(szBufDebug);

    va_list arg;

    va_start(arg, format);
 	ret = vprintf( format, arg );
    _vsnprintf_s(szBufDebug, length, _TRUNCATE, format, arg);
    va_end(arg);

    szBufDebug[length - 1] = '\0';

    OutputDebugString( szBufDebug );
	return ret;
}


