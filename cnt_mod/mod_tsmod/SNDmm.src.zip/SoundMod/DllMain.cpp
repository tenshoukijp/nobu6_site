
//Copyright 2006-2007 HOULBREQUE C�dric

//This file is part of IrrKlangWrapper.

//IrrKlangWrapper is free software; you can redistribute it and/or modify
//it under the terms of the GNU General Public License as published by
//the Free Software Foundation; either version 2 of the License, or
//(at your option) any later version.

//IrrKlangWrapper is distributed in the hope that it will be useful,
//but WITHOUT ANY WARRANTY; without even the implied warranty of
//MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//GNU General Public License for more details.

//You should have received a copy of the GNU General Public License
//along with IrrKlangWrapper; if not, write to the Free Software
//Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

// IrrKlangWrapper
// wrapper version 0.3 - IrrKlang version 0.4
// microbreak@orange.fr



#include <windows.h>
#include "SoundMod.h"

bool WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    switch (fdwReason)
    {
        case DLL_PROCESS_ATTACH:
            // attach to process
            // return FALSE to fail DLL load
            break;
        case DLL_THREAD_ATTACH:
            // attach to thread
            break;

        case DLL_THREAD_DETACH:
            // detach from thread
            break;

        case DLL_PROCESS_DETACH:
            // detach from process
            break;
	
	}
    return TRUE; // succesful
}
