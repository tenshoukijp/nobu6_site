#pragma once
#define IRRKLANG_STATIC

#include <irrKlang.h>
#include <iostream>
#include <string>
#include <map>
using namespace irrklang;
using namespace std;

// �ő��8���C���̃G�~�b�^�t��3D���ʉ������B
#define D3D_SOUND_EMITTER_CNT_MAX	16

// �T�E���h�G�~�b�^�[���B
struct T3DSoundEmitter {
	ISound *snd;
	float x;
	float y;
	float z;
	string simbol;
	int resid;
};

// ���̔z��
extern T3DSoundEmitter hSoundHandleArray[D3D_SOUND_EMITTER_CNT_MAX];

extern void irrAddDecorderMP3();

extern void WINAPI irrCreateDevice();
extern HANDLE WINAPI irrPlaySound2DStr(char *szFileName, bool isLoop);
extern HANDLE WINAPI irrPlaySound2DResID(int iResID, char *szResourceDllName, bool isLoop);
extern HANDLE WINAPI irrPlaySound3DStr(char *szFileName, float px, float py, float pz, float vx, float vy, float vz, bool isLoop);
extern HANDLE WINAPI irrPlaySound3DResID(int iResID, char *szResourceDllName, float px, float py, float pz, float vx, float vy, float vz, bool isLoop);
extern void WINAPI irrStopSound(HANDLE hSoundPtr);
extern void WINAPI irrStopAllSound();
extern bool WINAPI irrIsFinished(HANDLE hSoundPtr);
extern void WINAPI irrDeleteDevice();


