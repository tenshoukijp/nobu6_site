#pragma once

#pragma pack(1)

#include <windows.h>
#include <string>

using namespace std;

//#define USE_SOUND_MOD_DLL
#ifdef USE_SOUND_MOD_DLL


class SoundModInterface {

	typedef void (WINAPI *PFNCREATEDEVICE)(void);
	typedef void (WINAPI *PFNDELETEDEVICE)(void);
	typedef HANDLE (WINAPI *PFNPLAYSOUND2DSTR)(char *szFileName, bool isLoop);
	typedef HANDLE (WINAPI *PFNPLAYSOUND2DRESID)(int iResID, char *szDllName, bool isLoop);
	typedef HANDLE (WINAPI *PFNPLAYSOUND3DSTR)(char *szFileName, float px, float py, float pz, float vx, float vy, float vz, bool isLoop);
	typedef HANDLE (WINAPI *PFNPLAYSOUND3DRESID)(int iResID, char *szDllName, float px, float py, float pz, float vx, float vy, float vz, bool isLoop);
	typedef bool (WINAPI *PFNISFINISHED)(HANDLE hSoundPtr );
	typedef void (WINAPI *PFNSTOPSOUND)(HANDLE hSoundPtr );
	typedef void (WINAPI *PFNSTOPALLSOUND)();


private:
	// SoundMod.dll�̌Ăяo���B
	HMODULE hSoundMod;

	PFNCREATEDEVICE m_irrCreateDevice;
	PFNDELETEDEVICE m_irrDeleteDevice;
	PFNPLAYSOUND2DSTR m_irrPlaySound2DStr;
	PFNPLAYSOUND2DRESID m_irrPlaySound2DResID;
	PFNPLAYSOUND3DSTR m_irrPlaySound3DStr;
	PFNPLAYSOUND3DRESID m_irrPlaySound3DResID;
	PFNISFINISHED m_irrIsFinished;
	PFNSTOPSOUND m_irrStopSound;
	PFNSTOPALLSOUND m_irrStopAllSound;

public:
	inline SoundModInterface() {
		hSoundMod = NULL;
	}

	inline ~SoundModInterface() {
		// ���
		if ( hSoundMod ) {
			FreeLibrary(hSoundMod);
		}
		hSoundMod = NULL;
		m_irrCreateDevice = NULL;
		m_irrDeleteDevice = NULL;
		m_irrPlaySound2DStr = NULL;
		m_irrPlaySound2DResID = NULL;
		m_irrPlaySound3DStr = NULL;
		m_irrPlaySound3DResID = NULL;
		m_irrIsFinished = NULL;
		m_irrStopSound = NULL;
		m_irrStopAllSound = NULL;
	}
	// �f�o�C�X�̊m�� �� �֐��|�C���^�m��
	inline void irrCreateDevice() {
		if ( !hSoundMod ) {
			hSoundMod = LoadLibrary("SoundMod.dll");
			if ( hSoundMod ) {
				// �e���\�b�h�A�h���X���|�C���^�Ɋi�[
				m_irrCreateDevice = (PFNCREATEDEVICE)GetProcAddress( hSoundMod, "irrCreateDevice");
				m_irrDeleteDevice = (PFNDELETEDEVICE)GetProcAddress( hSoundMod, "irrDeleteDevice");
				m_irrPlaySound2DStr = (PFNPLAYSOUND2DSTR)GetProcAddress( hSoundMod, "irrPlaySound2DStr");
				m_irrPlaySound2DResID = (PFNPLAYSOUND2DRESID)GetProcAddress( hSoundMod, "irrPlaySound2DResID");
				m_irrPlaySound3DStr = (PFNPLAYSOUND3DSTR)GetProcAddress( hSoundMod, "irrPlaySound3DStr");
				m_irrPlaySound3DResID = (PFNPLAYSOUND3DRESID)GetProcAddress( hSoundMod, "irrPlaySound3DResID");
				m_irrIsFinished = (PFNISFINISHED)GetProcAddress( hSoundMod, "irrIsFinished");
				m_irrStopSound = (PFNSTOPSOUND)GetProcAddress( hSoundMod, "irrStopSound");
				m_irrStopAllSound = (PFNSTOPALLSOUND)GetProcAddress( hSoundMod, "irrStopAllSound");
			}

			if ( m_irrCreateDevice ) {
				// �f�o�C�X���g�p���鏀��
				m_irrCreateDevice();
			}
		}
	}

	// �f�o�C�X�폜
	inline void irrDeleteDevice() {
		if ( m_irrDeleteDevice ) {
			m_irrDeleteDevice();
		}
	}

	// �Q�c�̍Đ��A�t�@�C���l�[����
	inline HANDLE irrPlaySound2D( char *szFileName, bool isLoop=false ) {
		if ( m_irrPlaySound2DStr ) {
			return m_irrPlaySound2DStr( szFileName, isLoop );
		}
		return NULL;
	}

	// �Q�c�̍Đ��A���\�[�X�h�c��
	inline HANDLE irrPlaySound2D( int iResID, char *szDllName, bool isLoop=false ) {
		if ( m_irrPlaySound2DResID ) {
			return m_irrPlaySound2DResID( iResID, szDllName, isLoop );
		}
		return NULL;
	}

	// �R�c�̍Đ��A�t�@�C���l�[����
	inline HANDLE irrPlaySound3D( char *szFileName, float px, float py, float pz, float vx=0, float vy=0, float vz=0, bool isLoop=false ) {
		if ( m_irrPlaySound3DStr ) {
			return m_irrPlaySound3DStr( szFileName,  px,py,pz,  vx,vy,vz, isLoop );
		}
		return NULL;
	}

	// �R�c�̍Đ��A���\�[�X�h�c��
	inline HANDLE irrPlaySound3D( int iResID, char *szDllName, float px, float py, float pz, float vx=0, float vy=0, float vz=0, bool isLoop=false ) {
		if ( m_irrPlaySound3DResID ) {
			return m_irrPlaySound3DResID( iResID, szDllName, px,py,pz,  vx,vy,vz, isLoop );
		}
		return NULL;
	}

	// ���̒�~
	inline void irrStopSound( HANDLE hSound ) {
		if ( m_irrStopSound ) {
			m_irrStopSound( hSound );
		}
	}

	// ���̒�~
	inline void irrStopAllSound() {
		if ( m_irrStopAllSound ) {
			m_irrStopAllSound();
		}
	}

	// �����I�����Ă��邩
	inline bool irrIsFinished( HANDLE hSound ) {
		if ( m_irrIsFinished ) {
			return m_irrIsFinished( hSound );
		}
		return false;
	}

};



#else // NOT_USE_SOUND_MOD_DLL



#include "SoundMod.h"


class SoundModInterface {
private:

public:
	inline SoundModInterface() {
	}

	inline ~SoundModInterface() {
	}
	// �f�o�C�X�̊m�� �� �֐��|�C���^�m��
	inline void irrCreateDevice() {
		// �f�o�C�X���g�p���鏀��
		::irrCreateDevice();
	}

	// �f�o�C�X�폜
	inline void irrDeleteDevice() {
		::irrDeleteDevice();
	}

	// �Q�c�̍Đ��A�t�@�C���l�[����
	inline HANDLE irrPlaySound2D( char *szFileName, bool isLoop=false ) {
		return ::irrPlaySound2DStr( szFileName, isLoop );
	}

	// �Q�c�̍Đ��A���\�[�X�h�c��
	inline HANDLE irrPlaySound2D( int iResID, char *szDllName, bool isLoop=false ) {
		return ::irrPlaySound2DResID( iResID, szDllName, isLoop );
	}

	// �R�c�̍Đ��A�t�@�C���l�[����
	inline HANDLE irrPlaySound3D( char *szFileName, float px, float py, float pz, float vx=0, float vy=0, float vz=0, bool isLoop=false ) {
		return ::irrPlaySound3DStr( szFileName,  px,py,pz,  vx,vy,vz, isLoop );
	}

	// �R�c�̍Đ��A���\�[�X�h�c��
	inline HANDLE irrPlaySound3D( int iResID, char *szDllName, float px, float py, float pz, float vx=0, float vy=0, float vz=0, bool isLoop=false ) {
		return ::irrPlaySound3DResID( iResID, szDllName, px,py,pz,  vx,vy,vz, isLoop );
	}

	// ���̒�~
	inline void irrStopSound( HANDLE hSound ) {
		::irrStopSound( hSound );
	}

	// �S�Ẳ��̒�~
	inline void irrStopAllSound() {
		::irrStopAllSound();
	}

	// �����I�����Ă��邩
	inline bool irrIsFinished( HANDLE hSound ) {
		return ::irrIsFinished( hSound );
	}

};


#endif // USE_SOUND_MOD