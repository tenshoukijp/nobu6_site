#pragma once
#pragma pack(1)
#include <windows.h>

int CreateSoundFMap();
int ReadSoundFMap();
int CloseSoundFMap();