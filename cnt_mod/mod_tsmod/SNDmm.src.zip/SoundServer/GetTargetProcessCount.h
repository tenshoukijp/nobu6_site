#pragma once

int GetTargetProcessCount(char* process);