#pragma once

#pragma pack(1)


extern void CreateMidiPlayer(char *szMidiMapperName);
extern void ChangeMidiMapper(char *szMidiMapperName);
extern int PlayMidiPlayer(char *szTargetName, BOOL isLoop);
extern void StopMidiPlayer();
extern void DeleteMidiPlayer();
extern BOOL IsExistMidiMapper();

