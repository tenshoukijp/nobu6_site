#pragma once


void TDModPatchProcessMemory(); 
