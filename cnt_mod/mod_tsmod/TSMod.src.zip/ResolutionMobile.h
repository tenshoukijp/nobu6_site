#pragma once

void setMobileResolution();