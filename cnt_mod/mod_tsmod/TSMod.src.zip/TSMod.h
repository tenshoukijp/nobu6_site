// TSMod.h : TSMod_dummy.cpp �p�w�b�_
//
#pragma once

#include "CommonGlobalHandle.h"
#include "PluginMod.h"
#include "ScenarioMod.h"
#include "ScenarioDataStruct.h"
#include "ScenarioMessageN6PPatch.h"
#include "GameDataStruct.h"
#include "OutputDebugString.h"
#include "OutputDebugStream.h"
#include "OnigRegex.h"

extern FARPROC p_DirectDrawCreate;
