#include <stdio.h>

void XAUDIO2_OUTDBG( const char *format, ... );
