#pragma once


BOOL Hook_BitBltCustom( HDC, int, int, int, int, HDC, int, int, DWORD );

