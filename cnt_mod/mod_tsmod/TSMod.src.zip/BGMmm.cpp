#pragma comment(lib, "winmm.lib")
