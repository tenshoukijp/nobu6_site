#pragma once


struct TReservedTenki {
	int iRemainTurn;
	int iTenki;
	int iContinueTurn;
};

// �V�C�\��p�ϐ�
extern vector<TReservedTenki> iReservedWeatherOnChangeWeather;

