#pragma once

#define INT_KAOSWAPEX_BUSHOU_NUM		1932						// 1932�l 
#define INT_KAOSWAPUX_BUSHOU_NUM		2932						// 1932�l 

#define DDRAW_DLL_FILENAME				"DDraw.sys"
#define OLD_DDRAW_DLL_FILENAME			"DDraw.dll"

void checkKaoSwapExtend();
void writeFileDDrawDLL();