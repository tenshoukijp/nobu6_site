#define DPawn            87 /*  174 */
#define DLance          232 /*  464 */
#define DKnight         257 /*  514 */
#define DProPawn        534 /*  621 */
#define DProLance       489 /*  721 */
#define DSilver         369 /*  738 */
#define DProKnight      510 /*  767 */
#define DProSilver      495 /*  864 */
#define DGold           444 /*  888 */
#define DBishop         569 /* 1138 */
#define DRook           642 /* 1284 */
#define DHorse          827 /* 1396 */
#define DDragon         945 /* 1587 */
#define DKing         15000

