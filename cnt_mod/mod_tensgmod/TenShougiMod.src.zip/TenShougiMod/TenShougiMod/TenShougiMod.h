#pragma once;

#include "windows.h"


// .NET �Q��
using namespace System;
using namespace System::Collections;
using namespace System::Drawing;
using namespace System::Windows::Forms;
using namespace System::ComponentModel;
using namespace System::IO;

#include "TenShougiPipe.h"
#include "SharedMemory.h"