#define DPawn            87 /*  174 */
#define DLance          235 /*  470 */
#define DKnight         254 /*  508 */
#define DProPawn        530 /*  617 */
#define DProLance       482 /*  717 */
#define DSilver         371 /*  742 */
#define DProKnight      500 /*  754 */
#define DProSilver      489 /*  860 */
#define DGold           447 /*  894 */
#define DBishop         571 /* 1142 */
#define DRook           647 /* 1294 */
#define DHorse          832 /* 1403 */
#define DDragon         955 /* 1602 */
#define DKing         15000

