﻿using System;
namespace KKC
{
    public struct kifu_t
    {
        public string strFile;
        public move_t[] Move;
        public int numMove;
        public int intResult;
        public string strNameS;
        public string strNameG;
        public string strStartTime;
        public string strEndTime;
        public string strEvent;
        public string strEvent2;
        public string strSite;
        public string strTimeLimit;
        public string strTimeUsed;
        public string strOpening;
        public string strNote;
        public string strComment;
    }
}
