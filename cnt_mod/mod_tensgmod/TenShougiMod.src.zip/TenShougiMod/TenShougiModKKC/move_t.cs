﻿using System;
namespace KKC
{
    public struct move_t
    {
        public int fromsuji;
        public int fromdan;
        public int tosuji;
        public int todan;
        public int koma;
        public int promote;
        public int dtime;
        public int ttime;
        public string comment;
    }
}
