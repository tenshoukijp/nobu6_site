/* _inmmbridge.c - �N���C�A���g�� */
#include <stdio.h>
#include <io.h>
#include <windows.h>
#include "sockfp.h"

#ifdef _MSC_VER		/* BC++�ɍ��킹�� */
#define _argv __argv
#define _argc __argc
#endif

#define WM_WA_IPC WM_USER		/* WM_SMX_IPC������ */
#define WM_DCDP_IPC (WM_USER + 0x200)
#define IPC_PLAYFILE 100
#define IPC_SETVOLUME 122

#define APPNAME "_inmmbridge"
#define DEFAULT_PORT 8282

FILE *svin, *svout;

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
				   LPSTR lpszCmdLine, int nCmdShow);
void usage(int exitcode);
BOOL init_connection(const char *host, int port, const char *classname);
void end_connection(void);
void makewnd(HINSTANCE hInstance, const char *classname);
int msgloop(void);
LRESULT CALLBACK WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam);

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
				   LPSTR lpszCmdLine, int nCmdShow)
{
	int port, r;
	const char *classname, *host;

	if (_argc < 3)
		usage(1);
	
	switch (_argv[1][0]) {
	case 'w': case 'W': classname = "Winamp v1.x"; break;
	case 's': case 'S': classname = "SCMPX"; break;
	case 'd': case 'D': classname = "TMyanDigitalCDPlayerForm"; break;
	default: usage(1);
	}
	host = _argv[2];
	port = (_argc >= 4) ? atoi(_argv[3]) : DEFAULT_PORT;

	if (!init_connection(host, port, classname))
		return 1;
	
	makewnd(hInstance, classname);
	r = msgloop();
	
	end_connection();
	return r;
}

void usage(int exitcode)
{
	MessageBox(NULL, "usage: "APPNAME" {w|s|d} host [port]", APPNAME, MB_OK);
	exit(exitcode);
}

BOOL init_connection(const char *host, int port, const char *classname)
{
	char msg[1025];
	int result;
	struct WSAData wsad;
	int one = 1;
	
	if (WSAStartup(0x101, &wsad) != 0)
		return FALSE;
	
	/* �T�[�o�ɐڑ� */
	if (!clientsock(host, port, &svin, &svout)) {
		wsprintf(msg, "%s:%d �ɐڑ��ł��܂���B", host, port);
		MessageBox(NULL, msg, APPNAME, MB_OK);
		WSACleanup();
		return FALSE;
	}
	setsockopt(_get_osfhandle(fileno(svin)),
			   IPPROTO_TCP, TCP_NODELAY, (char *)&one, sizeof one);

	/* �T�[�o���ɃE�B���h�E�N���X��ʒm */
	fprintf_f(svout, "%s\n", classname);
	if (fscanf(svin, "%d", &result) != 1 || result == 0) {
		wsprintf(msg, "�T�[�o���ɃE�B���h�E %s ��������܂���B", classname);
		MessageBox(NULL, msg, APPNAME, MB_OK);
		end_connection();
		return FALSE;
	}
	return TRUE;
}

void end_connection(void)
{
	fclose(svin);
	fclose(svout);
	WSACleanup();
}

void makewnd(HINSTANCE hInstance, const char *classname)
{
	HWND hwnd;
	WNDCLASSEX wndclass;

	ZeroMemory(&wndclass, sizeof wndclass);
	wndclass.cbSize = sizeof wndclass;
	wndclass.style = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WndProc;
	wndclass.hInstance = hInstance;
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.lpszClassName = classname;
	
	RegisterClassEx(&wndclass);
	
	hwnd = CreateWindow(classname, APPNAME,
						WS_OVERLAPPED | WS_SYSMENU | WS_MINIMIZEBOX,
						CW_USEDEFAULT, CW_USEDEFAULT, 200, 100,
						NULL, NULL, hInstance, NULL);
	
	ShowWindow(hwnd, SW_SHOWDEFAULT);
	UpdateWindow(hwnd);
}

int msgloop(void)
{
	MSG msg;
	while (GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}

LRESULT CALLBACK WndProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	int r;
	COPYDATASTRUCT *cds;
	
	switch (iMsg) {
	case WM_WA_IPC:
	case WM_DCDP_IPC:
	case WM_COMMAND:
		r = 0;
		if (!InSendMessage())
			fprintf_f(svout, "post %d %d %d\n", iMsg, wParam, lParam);
		else if (lParam == IPC_PLAYFILE || lParam == IPC_SETVOLUME)
			fprintf_f(svout, "sendnotify %d %d %d\n", iMsg, wParam, lParam);
		else {
			fprintf_f(svout, "send %d %d %d\n", iMsg, wParam, lParam);
			fscanf(svin, "%d", &r);
		}
		return r;

	case WM_COPYDATA:
		cds = (COPYDATASTRUCT *)lParam;
		fprintf(svout, "copydata %d %d %d\n", wParam, cds->dwData, cds->cbData);
		fwrite(cds->lpData, cds->cbData, 1, svout);
		fflush(svout);
		return TRUE;

	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hwnd, iMsg, wParam, lParam);
}
