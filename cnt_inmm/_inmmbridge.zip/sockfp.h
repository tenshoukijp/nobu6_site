#ifndef SOCKFP_H_
#define SOCKFP_H_

#ifdef __cplusplus
extern "C" {
#endif

BOOL clientsock(const char* host, int port, FILE **rdfp, FILE **wtfp);
SOCKET serversock(int port);
BOOL acceptfp(SOCKET lsock, struct sockaddr *addr, int *addr_len,
			 FILE **rdfp, FILE **wtfp);
int fprintf_f(FILE *fp, const char* fmt, ...);

#ifdef __cplusplus
}
#endif

#endif /* SOCKFP_H_ */
