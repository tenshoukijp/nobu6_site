/* _inmmbridges.c - �T�[�o�� */
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <process.h>
#include <signal.h>
#include <windows.h>
#include "sockfp.h"

#define DEFAULT_PORT 8282

struct fppair {
	FILE *rd, *wt;
};

int main(int argc, char *argv[]);
BOOL winsock_init(void);
void winsock_end(void);
void onintr(int sig);
void thread_code(void *arg);
void echo_peername(SOCKET s);

int main(int argc, char *argv[])
{
	SOCKET svr;
	int port = DEFAULT_PORT;
	
	if (argc >= 2 && sscanf(argv[1], "%d", &port) != 1) {
		fprintf(stderr, "usage: _inmmbridges [port]\n");
		return 1;
	}
	if (!winsock_init()) {
		fprintf(stderr, "WinSock�̏������Ɏ��s���܂����B\n");
		return 1;
	}

	svr = serversock(port);
	if (svr == INVALID_SOCKET) {
		char *buf;
		fprintf(stderr, "�T�[�o���������ł��܂���: %d", WSAGetLastError());
		if (FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM
						  | FORMAT_MESSAGE_ALLOCATE_BUFFER
						  | FORMAT_MESSAGE_MAX_WIDTH_MASK,
						  NULL, WSAGetLastError(), 0, (LPTSTR)&buf, 0, NULL))
		{
			fprintf(stderr, "(%s)", buf);
			LocalFree(buf);
		}
		fprintf(stderr, "\n");
		return 1;
	}

	signal(SIGINT, onintr);

	printf("_inmmbridge server port: %d\n", port);
	printf("Ctrl+C�ŏI�����܂�\n");
	for (;;) {
		struct fppair *p = malloc(sizeof(struct fppair));
		if (!acceptfp(svr, NULL, NULL, &p->rd, &p->wt)) {
			fprintf(stderr, "acceptfp() failed\n");
			return 1;
		}
		else if (_beginthread(thread_code, 0, p) == (unsigned long)-1) {
			fprintf(stderr, "�X���b�h�̍쐬�Ɏ��s���܂����B\n");
			return 1;
		}
	}
}

BOOL winsock_init(void)
{
	struct WSAData wsad;
	if (WSAStartup(0x101, &wsad) != 0)
		return FALSE;
	atexit(winsock_end);
	return TRUE;
}

void winsock_end(void)
{
	WSACleanup();
}

void onintr(int sig)
{
	exit(0);	/* atexit()�Őݒ肵��winsock_end()���Ă�ŏI�� */
}

void thread_code(void *arg)
{
	char line[512];
	struct fppair *fpp = (struct fppair *)arg;
	FILE *cin = fpp->rd;
	FILE *cout = fpp->wt;
	HWND hwnd;

	free(fpp);

	echo_peername(_get_osfhandle(fileno(cin)));
	printf(" is accepted\n");
	
	/* �v�����ꂽ�E�B���h�E�������� */
	if (fgets(line, sizeof line, cin)) {
		line[strlen(line) - 1] = '\0';	/* \n����菜�� */
		printf("windowclass: \"%s\"\n", line);
		hwnd = FindWindow(line, NULL);
		fprintf_f(cout, "%d\n", (hwnd != NULL) ? 1 : 0);
		if (hwnd == NULL) {
			printf("... not found\n");
			goto fin;
		}
	}
	else
		goto fin;

	/* �����Ă��郁�b�Z�[�W���������� */
	while (fgets(line, sizeof line, cin)) {
		int a, b, c;
		printf("%s", line);
		if (sscanf(line, "post %d %d %d", &a, &b, &c) == 3)
			PostMessage(hwnd, a, b, c);
		else if (sscanf(line, "sendnotify %d %d %d", &a, &b, &c) == 3)
			SendNotifyMessage(hwnd, a, b, c);
		else if (sscanf(line, "send %d %d %d", &a, &b, &c) == 3)
			fprintf_f(cout, "%d\n", SendMessage(hwnd, a, b, c));
		else if (sscanf(line, "copydata %d %d %d", &a, &b, &c) == 3) {
			char *buf = malloc(c);
			if (buf != NULL && fread(buf, c, 1, cin) == 1) {
				COPYDATASTRUCT cds;
				cds.dwData = b;
				cds.cbData = c;
				cds.lpData = buf;
				SendMessage(hwnd, WM_COPYDATA, a, (LPARAM)&cds);
			}
			free(buf);
		}
		else ;	/* ���߂ł��Ȃ��s�͖������� */
	}
 fin:
	echo_peername(_get_osfhandle(fileno(cin)));
	printf(" is gone\n");
	fclose(cin);
	fclose(cout);
}

void echo_peername(SOCKET s)
{
	struct hostent *host;
	struct sockaddr_in sin;
	int len = sizeof(sin);
	
	if (getpeername(s, (struct sockaddr *)&sin, &len) != 0)
		return;

	host = gethostbyaddr((char *)&sin.sin_addr.s_addr,
						 sizeof(sin.sin_addr), AF_INET);
	if (host)
		printf("%s [%s]", host->h_name, inet_ntoa(sin.sin_addr));
}
