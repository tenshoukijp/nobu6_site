#include <shlwapi.h>
#include "BitMapToKaoSwap.h"

#pragma comment(lib, "shlwapi")

using namespace std;

template <int TNUM>
void doKaoswapImport(char *szTargetKaoSwapName) {

	auto *pBmpToKS = new BitMapToKaoSwapManager<TNUM>(szTargetKaoSwapName);

	int Err = pBmpToKS->ReadKaoSwap();
	if (!Err) {
		try {
			for (int i = 1; i <= TNUM; i++) {
				pBmpToKS->Execute(i);
			}
			pBmpToKS->WriteKaoSwap();
		}
		catch (...) { }
	}

	delete pBmpToKS;
}

void main(void) {
	char szPathName[512] = "";
	GetModuleFileName(NULL, szPathName, _countof(szPathName) );
	PathRemoveFileSpec(szPathName);
	SetCurrentDirectory(szPathName);
	doKaoswapImport<783>("kaodatap.s5");
}

