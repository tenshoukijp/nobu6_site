﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace CDCopier
{
    class Class1
    {
        [STAThread]
        static void Main()
        {
            Application.Run(new CDRipperForm.RipperForm());
        }
    }
}
