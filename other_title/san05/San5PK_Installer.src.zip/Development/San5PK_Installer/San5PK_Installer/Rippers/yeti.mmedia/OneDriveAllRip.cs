﻿using System;
using System.IO;
using System.Collections.Generic;
using Ripper;
using CDRipper.MMedia;
using WaveLib;

namespace CDRipper.MMedia
{
    public class OneDriveAllRip
    {
        public static void AllRip(String drivename, String targetdir)
        {
            CDDrive Drive;
            Drive = new CDDrive();
            //Get the first CD drive 
            if (Drive.Open(drivename.ToCharArray()[0]))
            {
                // We have access to CD drive
                if (Drive.IsCDReady())
                {
                    //There is a CD in the drive
                    if (Drive.Refresh())
                    { //TOC have been read

                        int Tracks = Drive.GetNumTracks();
                        byte[] Buffer = new byte[4096];
                        Drive.LockCD();
                        try
                        {
                            for (int i = 2; i <= Tracks; i++)
                            {
                                Stream Strm = new FileStream(string.Format(targetdir+"{0:00}.wav", i),
                                                             FileMode.Create, FileAccess.Write);
                                try
                                {
                                    uint Size = 0;
                                    while (Drive.ReadTrack(i, Buffer, ref Size, null) > 0)
                                    //If there is no error and datawas read 
                                    //successfully a positive number is returned
                                    {
                                        Strm.Write(Buffer, 0, (int)Size);
                                    }
                                }
                                finally
                                {
                                    Strm.Close();
                                }
                            }
                        }
                        finally
                        {
                            Drive.UnLockCD();
                        }
                    }
                }
            }
        }
    }
}
