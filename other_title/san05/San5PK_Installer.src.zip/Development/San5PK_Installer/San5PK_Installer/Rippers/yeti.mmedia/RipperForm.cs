//
//
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE. IT CAN BE DISTRIBUTED FREE OF CHARGE AS LONG AS THIS HEADER 
//  REMAINS UNCHANGED.
//
//  Email:  yetiicb@hotmail.com
//
//  Copyright (C) 2002-2003 Idael Cardoso. 
//

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Threading;

using Ripper;
using CDRipper.MMedia;
using WaveLib;

namespace CDRipperForm
{
    /// <summary>
    /// Summary description for Form1.
    /// </summary>
    public class RipperForm : System.Windows.Forms.Form
    {
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxDrives;
        private System.Windows.Forms.Button buttonOpen;

        private System.Windows.Forms.StatusBar statusBar;
        private System.Windows.Forms.Button buttonEject;
        private System.Windows.Forms.Button buttonLoad;
        private System.Windows.Forms.GroupBox groupBoxCDCtrls;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelTracks;
        private System.Windows.Forms.ListView listViewTracks;
        private System.Windows.Forms.ColumnHeader columnHeaderTrack;
        private System.Windows.Forms.ColumnHeader columnHeaderSize;
        private System.Windows.Forms.ColumnHeader columnHeaderType;
        private System.Windows.Forms.Button buttonSaveAs;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.ComponentModel.IContainer components;

        private Ripper.CDDrive m_Drive;
        private bool m_Ripping = false;
        private System.Windows.Forms.ToolTip toolTip1;
        private bool m_CancelRipping = false;


        private String m_strCDDriveName;
        private String m_strTargetBGMDir;
        private int m_left;
        private int m_bottom;

        private Thread rippingThread;

        // ���܂�ɂЂǂ��p�����^�n���� static�ɂ��āASet����ׂ������A�V�ċL�ƈ���āA�O���u�u�̂��������C���X�g�[������
        public RipperForm(String strCDDriveName, String strTargetBGMDir, int left, int bottom)
        {
            m_strCDDriveName = strCDDriveName; // �O���uV��CD�������Ă���h���C�u��
            m_strTargetBGMDir = strTargetBGMDir; // �C���X�g�[����̃f�B���N�g��
            m_left = left;
            m_bottom = bottom;
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            //
            // TODO: Add any constructor code after InitializeComponent call
            //
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Left = m_left;
            this.Top = m_bottom + 5;
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxDrives = new System.Windows.Forms.ComboBox();
            this.buttonOpen = new System.Windows.Forms.Button();
            this.statusBar = new System.Windows.Forms.StatusBar();
            this.groupBoxCDCtrls = new System.Windows.Forms.GroupBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.buttonSaveAs = new System.Windows.Forms.Button();
            this.listViewTracks = new System.Windows.Forms.ListView();
            this.columnHeaderTrack = new System.Windows.Forms.ColumnHeader();
            this.columnHeaderSize = new System.Windows.Forms.ColumnHeader();
            this.columnHeaderType = new System.Windows.Forms.ColumnHeader();
            this.labelTracks = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonLoad = new System.Windows.Forms.Button();
            this.buttonEject = new System.Windows.Forms.Button();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.groupBoxCDCtrls.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(16, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "CD �h���C�u:";
            // 
            // comboBoxDrives
            // 
            this.comboBoxDrives.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxDrives.Location = new System.Drawing.Point(80, 7);
            this.comboBoxDrives.Name = "comboBoxDrives";
            this.comboBoxDrives.Size = new System.Drawing.Size(80, 20);
            this.comboBoxDrives.TabIndex = 2;
            this.comboBoxDrives.SelectedIndexChanged += new System.EventHandler(this.comboBoxDrives_SelectedIndexChanged);
            // 
            // buttonOpen
            // 
            this.buttonOpen.Enabled = false;
            this.buttonOpen.Location = new System.Drawing.Point(176, 7);
            this.buttonOpen.Name = "buttonOpen";
            this.buttonOpen.Size = new System.Drawing.Size(75, 22);
            this.buttonOpen.TabIndex = 3;
            this.buttonOpen.Text = "�ڑ�";
            this.toolTip1.SetToolTip(this.buttonOpen, "CD�h���C�u�̐ڑ��Ɛؒf");
            this.buttonOpen.Click += new System.EventHandler(this.buttonOpen_Click);
            // 
            // statusBar
            // 
            this.statusBar.Location = new System.Drawing.Point(0, 339);
            this.statusBar.Name = "statusBar";
            this.statusBar.Size = new System.Drawing.Size(466, 20);
            this.statusBar.TabIndex = 4;
            // 
            // groupBoxCDCtrls
            // 
            this.groupBoxCDCtrls.Controls.Add(this.progressBar1);
           //  this.groupBoxCDCtrls.Controls.Add(this.buttonSaveAs);
            this.groupBoxCDCtrls.Controls.Add(this.listViewTracks);
            this.groupBoxCDCtrls.Controls.Add(this.labelTracks);
            /*
            this.groupBoxCDCtrls.Controls.Add(this.label2);
            this.groupBoxCDCtrls.Controls.Add(this.buttonLoad);
            this.groupBoxCDCtrls.Controls.Add(this.buttonEject);
            */
            this.groupBoxCDCtrls.Enabled = false;
            this.groupBoxCDCtrls.Location = new System.Drawing.Point(16, 16);
            this.groupBoxCDCtrls.Name = "groupBoxCDCtrls";
            this.groupBoxCDCtrls.Size = new System.Drawing.Size(332, 251);
            this.groupBoxCDCtrls.TabIndex = 5;
            this.groupBoxCDCtrls.TabStop = false;
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(12, 222);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(302, 21);
            this.progressBar1.TabIndex = 7;
            // 
            // buttonSaveAs
            // 
            this.buttonSaveAs.Enabled = false;
            this.buttonSaveAs.Location = new System.Drawing.Point(12, 222);
            this.buttonSaveAs.Name = "buttonSaveAs";
            this.buttonSaveAs.Size = new System.Drawing.Size(75, 21);
            this.buttonSaveAs.TabIndex = 6;
            this.buttonSaveAs.Text = "�ۑ�";
            this.buttonSaveAs.Click += new System.EventHandler(this.buttonSaveAs_Click);
            // 
            // listViewTracks
            // 
            this.listViewTracks.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeaderTrack,
            this.columnHeaderSize,
            this.columnHeaderType});
            this.listViewTracks.Location = new System.Drawing.Point(14, 15);
            this.listViewTracks.Name = "listViewTracks";
            this.listViewTracks.Size = new System.Drawing.Size(302, 195);
            this.listViewTracks.TabIndex = 5;
            this.toolTip1.SetToolTip(this.listViewTracks, "�ۑ��������g���b�N��I��ł�������");
            this.listViewTracks.UseCompatibleStateImageBehavior = false;
            this.listViewTracks.View = System.Windows.Forms.View.Details;
            this.listViewTracks.EnabledChanged += new System.EventHandler(this.listViewTracks_EnabledChanged);
            this.listViewTracks.SelectedIndexChanged += new System.EventHandler(this.listViewTracks_SelectedIndexChanged);
            // 
            // columnHeaderTrack
            // 
            this.columnHeaderTrack.Text = "�g���b�N";
            this.columnHeaderTrack.Width = 62;
            // 
            // columnHeaderSize
            // 
            this.columnHeaderSize.Text = "�T�C�Y (�o�C�g)";
            this.columnHeaderSize.Width = 105;
            // 
            // columnHeaderType
            // 
            this.columnHeaderType.Text = "�^�C�v";
            this.columnHeaderType.Width = 115;
            // 
            // labelTracks
            // 
            this.labelTracks.Location = new System.Drawing.Point(168, 15);
            this.labelTracks.Name = "labelTracks";
            this.labelTracks.Size = new System.Drawing.Size(88, 15);
            this.labelTracks.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(112, 15);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "�g���b�N:";
            // 
            // buttonLoad
            // 
            this.buttonLoad.Location = new System.Drawing.Point(16, 66);
            this.buttonLoad.Name = "buttonLoad";
            this.buttonLoad.Size = new System.Drawing.Size(75, 22);
            this.buttonLoad.TabIndex = 1;
            this.buttonLoad.Text = "�ǂݍ���";
            this.toolTip1.SetToolTip(this.buttonLoad, "Load (Close) the CD drive");
            this.buttonLoad.Click += new System.EventHandler(this.buttonLoad_Click);
            // 
            // buttonEject
            // 
            this.buttonEject.Location = new System.Drawing.Point(16, 37);
            this.buttonEject.Name = "buttonEject";
            this.buttonEject.Size = new System.Drawing.Size(75, 21);
            this.buttonEject.TabIndex = 0;
            this.buttonEject.Text = "Eject";
            this.toolTip1.SetToolTip(this.buttonEject, "Eject (Open) the CD drive");
            this.buttonEject.Click += new System.EventHandler(this.buttonEject_Click);
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.DefaultExt = "wav";
            this.saveFileDialog.Filter = "Wave files (*.wav)|*.wav|All files (*.*)|*.*";
            this.saveFileDialog.Title = "Save tract to:";
            // 
            // RipperForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 12);
            this.ClientSize = new System.Drawing.Size(366, 309);
            this.Controls.Add(this.groupBoxCDCtrls);
            this.Controls.Add(this.statusBar);
            // this.Controls.Add(this.buttonOpen);
            // this.Controls.Add(this.comboBoxDrives);
            // this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "RipperForm";
            this.Text = "CD ���b�s���O�t�F�C�Y";
            this.Load += new System.EventHandler(this.RipperForm_Load);
            this.Closing += new System.ComponentModel.CancelEventHandler(this.RipperForm_Closing);
            this.groupBoxCDCtrls.ResumeLayout(false);

            this.Shown += new EventHandler(RipperForm_Shown);

            this.ResumeLayout(false);

            rippingThread = new Thread(RippingStart);

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        // [STAThread]
        // static void Main()
        // {
        //     // Application.Run(new RipperForm());
        // }

        private void buttonClose_Click(object sender, System.EventArgs e)
        {
            Close();
        }

        private void RipperForm_Load(object sender, System.EventArgs e)
        {
            m_Drive = new CDDrive();
            m_Drive.CDInserted += new EventHandler(m_Drive_CDInserted);
            m_Drive.CDRemoved += new EventHandler(m_Drive_CDRemoved);
            /*
            char[] Drives = CDDrive.GetCDDriveLetters();
            foreach (char drive in Drives)
            {
                comboBoxDrives.Items.Add(drive.ToString());
            }
            if (comboBoxDrives.Items.Count > 0)
            {
                comboBoxDrives.SelectedIndex = 0;
            }
            */
            char drive = m_strCDDriveName.ToCharArray()[0]; // ���󂯎�����h���C�u��
            comboBoxDrives.Items.Add(drive.ToString());
            comboBoxDrives.SelectedIndex = 0;

            buttonOpen_Click(null, null);
        }

        private void RipperForm_Shown(Object o, EventArgs e)
        {
            rippingThread.Start();
        }

        private void RippingStart()
        {
            buttonSaveAs_Click(null, null);
        }

        private void UpdateVisualControls()
        {
            buttonOpen.Enabled = !m_Ripping & (comboBoxDrives.SelectedIndex >= 0);
            comboBoxDrives.Enabled = !m_Ripping & (!m_Drive.IsOpened);
            groupBoxCDCtrls.Enabled = !m_Ripping & (m_Drive.IsOpened);
            if (listViewTracks.SelectedIndices.Count > 0)
            {
                int track = listViewTracks.SelectedIndices[0] + 1;
                buttonSaveAs.Enabled = !m_Ripping & m_Drive.IsAudioTrack(track);
            }
            else
            {
                buttonSaveAs.Enabled = false;
            }
        }

        private void comboBoxDrives_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            UpdateVisualControls();
        }

        private void buttonOpen_Click(object sender, System.EventArgs e)
        {
            if (m_Drive.IsOpened)
            {
                m_Drive.Close();
                buttonOpen.Text = "�ڑ�";
                statusBar.Text = "CD �h���C�u�Ɛؒf���܂����B";
                listViewTracks.Items.Clear();
            }
            else
            {
                if (m_Drive.Open(comboBoxDrives.Text[0]))
                {
                    statusBar.Text = "CD �h���C�u�Ɛڑ����܂����B";
                    if (m_Drive.IsCDReady())
                    {
                        statusBar.Text += " �����������܂����B";
                        if (m_Drive.Refresh())
                        {
                            int Tracks = m_Drive.GetNumTracks();
                            for (int i = 1; i <= Tracks; i++)
                            {
                                ListViewItem item = new ListViewItem(new string[] { i.ToString(), m_Drive.TrackSize(i).ToString(), m_Drive.IsAudioTrack(i) ? "�I�[�f�B�I" : "�f�[�^" });
                                listViewTracks.Items.Add(item);
                            }
                        }
                    }
                    buttonOpen.Text = "�ؒf";
                }
                else
                {
                    statusBar.Text = "CD �h���C�u�Ɛڑ����邱�Ƃ��o���܂���B";
                }
            }
            progressBar1.Value = 0;
            UpdateVisualControls();
        }

        private void buttonEject_Click(object sender, System.EventArgs e)
        {
            listViewTracks.Items.Clear();
            progressBar1.Value = 0;
            if (m_Drive.EjectCD())
            {
                statusBar.Text = "CD ���C�W�F�N�g���܂����B";
            }
            else
            {
                statusBar.Text = "CD ���C�W�F�N�g���邱�Ƃ��o���܂���B";
            }
        }

        private void buttonLoad_Click(object sender, System.EventArgs e)
        {
            listViewTracks.Items.Clear();
            progressBar1.Value = 0;
            if (m_Drive.LoadCD())
            {
                statusBar.Text = "CD ��ǂݍ��݂܂����B";
            }
            else
            {
                statusBar.Text = "CD ��ǂݍ��ނ��Ƃ��o���܂���B";
            }
        }

        private void buttonCDReady_Click(object sender, System.EventArgs e)
        {
            listViewTracks.Items.Clear();
            progressBar1.Value = 0;
            if (m_Drive.IsCDReady())
            {
                statusBar.Text = "CD �̏������ł��܂����B";
                if (m_Drive.Refresh())
                {
                    int Tracks = m_Drive.GetNumTracks();
                    for (int i = 1; i <= Tracks; i++)
                    {
                        ListViewItem item = new ListViewItem(new string[] { i.ToString(), m_Drive.TrackSize(i).ToString(), m_Drive.IsAudioTrack(i) ? "�I�[�f�B�I" : "�f�[�^" });
                        listViewTracks.Items.Add(item);
                    }
                }
            }
            else
            {
                statusBar.Text = "CD �̏������o���Ă��܂���B";
            }
            UpdateVisualControls();
        }

        private void listViewTracks_SelectedIndexChanged(object sender, System.EventArgs e)
        {
            UpdateVisualControls();
        }

        private void listViewTracks_EnabledChanged(object sender, System.EventArgs e)
        {
            UpdateVisualControls();
        }

        private void CdReadProgress(object sender, ReadProgressEventArgs ea)
        {
            ulong Percent = ((ulong)ea.BytesRead * 100) / ea.Bytes2Read;
            progressBar1.Value = (int)Percent;
            Application.DoEvents();
            ea.CancelRead |= this.m_CancelRipping;
        }

        private WaveWriter m_Writer = null;

        public void WriteWaveData(object sender, DataReadEventArgs ea)
        {
            if (m_Writer != null)
            {
                m_Writer.Write(ea.Data, 0, (int)ea.DataSize);
            }
        }

        private void buttonSaveAs_Click(object sender, System.EventArgs e)
        {
            if (listViewTracks.Items.Count > 0)
            {
                for (int track = 1; track <= listViewTracks.Items.Count; track++)
                {
                    if (!m_Drive.IsAudioTrack(track))
                    {
                        continue;
                    }
                    /*
                    listViewTracks.Items[track - 1].Selected = true;
                    listViewTracks.Items[track - 1].Focused = true;
                    UpdateVisualControls();
                     */
                    String FileName = string.Format(m_strTargetBGMDir + "{0:00}.wav", track);
                    m_Ripping = true;
                    try
                    {
                        m_Drive.LockCD();
                        try
                        {
                            WaveFormat Format = new WaveFormat(44100, 16, 2);

                            Stream WaveFile = new FileStream(FileName, FileMode.Create, FileAccess.Write);
                            try
                            {
                                m_Writer = new WaveWriter(WaveFile, Format/*, m_Drive.TrackSize(track)*/);
                                try
                                {
                                    statusBar.Text = string.Format("�g���b�N {0} ��ǂݍ��ݒ�", track);
                                    UpdateVisualControls();
                                    DateTime InitTime = DateTime.Now;
                                    if (m_Drive.ReadTrack(track, new CdDataReadEventHandler(WriteWaveData), new CdReadProgressEventHandler(this.CdReadProgress)) > 0)
                                    {
                                        TimeSpan Duration = DateTime.Now - InitTime;
                                        double Speed = m_Drive.TrackSize(track) / Duration.TotalSeconds / Format.nAvgBytesPerSec;
                                        statusBar.Text = string.Format("�g���b�N {0} �� {1:0.00} �{���œǂݍ���ł��܂��B", track, Speed);
                                    }
                                    else
                                    {
                                        statusBar.Text = string.Format("�g���b�N {0} �œǂݍ��݃G���[���������܂����B", track);
                                        m_Writer.Close();
                                        WaveFile.Close();
                                        if (File.Exists(FileName))
                                        {
                                            File.Delete(FileName);
                                        }
                                        progressBar1.Value = 0;
                                    }
                                    if (m_CancelRipping)
                                    {
                                        m_Ripping = false;
                                        Close();
                                    }
                                }
                                finally
                                {
                                    m_Writer.Close();
                                    m_Writer = null;
                                }
                            }
                            finally
                            {
                                WaveFile.Close();
                            }
                        }
                        finally
                        {
                            m_Drive.UnLockCD();
                        }
                    }
                    finally
                    {
                        // �G���R�[�h
                        String dstFileName = LameEncodeWavToMp3(FileName);
                        // �G���R�[�h�o���Ă�����
                        if ( File.Exists(dstFileName) && dstFileName.Length > 2) {
                            // ���͍폜
                            File.Delete(FileName);
                        }
                        // ���b�s���O���b�N������
                        m_Ripping = false;
                    }
                }
            }
            statusBar.Text = "�G���R�[�h�t�F�C�Y���I�����܂����B";
            UpdateVisualControls();

            MessageBox.Show("�S�Ă̍s�����I�����܂����B");
            this.Close();
        }

        private String LameEncodeWavToMp3(String FileName)
        {

            String lameExe = Application.StartupPath + "\\LameMp3Enc.exe"; // Lame
            String srcFileName = FileName;
            String dstFileName = srcFileName;
            dstFileName.Replace(".wav", ".mp3");

            //Process�I�u�W�F�N�g���쐬����
            System.Diagnostics.Process p = new System.Diagnostics.Process();
            //�N��������s�t�@�C���̃p�X��ݒ肷��
            p.StartInfo.FileName = lameExe;
            //�R�}���h���C���������w�肷��
            p.StartInfo.Arguments = FileName + " -b 320"; // �ō��i����VBR

            p.StartInfo.CreateNoWindow= true; // �R���\�[���E�E�B���h�E���J���Ȃ�
            p.StartInfo.UseShellExecute = false; // �V�F���@�\���g�p���Ȃ�
       

            //�N������B�v���Z�X���N����������True��Ԃ��B
            bool result = p.Start();
            if (result)
            {
                string strMp3Name = System.IO.Path.GetFileNameWithoutExtension(FileName);
                strMp3Name = strMp3Name + ".mp3";
                statusBar.Text = FileName + "�� "+strMp3Name+" �ւƃG���R�[�h���Ă��܂��B���X���҂����������B";
                p.WaitForExit(); // �K���Ō�܂ő҂K�v������B�r���Ő؂�グ����Amp3�͏o���Ȃ��B

                return dstFileName;
            }
            return "";

        }

        private void RipperForm_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (m_Ripping)
            {
                if (MessageBox.Show("CD����̎�荞�݂��L�����Z�����܂����H", this.Text,
                  MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    this.m_CancelRipping = true;
                }
                e.Cancel = true;
            }
        }

        private void m_Drive_CDInserted(object sender, EventArgs e)
        {
            listViewTracks.Items.Clear();
            progressBar1.Value = 0;
            if (m_Drive.IsCDReady())
            {
                statusBar.Text = "CD �̏������ł��܂����B";
                if (m_Drive.Refresh())
                {
                    int Tracks = m_Drive.GetNumTracks();
                    for (int i = 1; i <= Tracks; i++)
                    {
                        ListViewItem item = new ListViewItem(new string[] { i.ToString(), m_Drive.TrackSize(i).ToString(), m_Drive.IsAudioTrack(i) ? "audio" : "data" });
                        listViewTracks.Items.Add(item);
                    }
                }
            }
            else
            {
                statusBar.Text = "�}�����ꂽ CD �̏������܂��o���Ă��܂���B";
            }
            UpdateVisualControls();
        }

        private void m_Drive_CDRemoved(object sender, EventArgs e)
        {
            listViewTracks.Items.Clear();
            progressBar1.Value = 0;
            statusBar.Text = "CD Removed";
            UpdateVisualControls();
        }
    }
}
