﻿
using System;
using System.Text;
using System.Drawing;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Ripper;
using CDRipper.MMedia;
using WaveLib;




class San5W95InstForm : Form
{

    static String strCDDriveName;
    // static String strNoCDErrMsg = "三国志V with PK の CDをドライブに挿入して下さい";

    static String strSystemDriveName; // ウィンドウズが入っている(多分HDDかSSDの)ドライブ名
    static String strDstDir = "_San5WPK95\\";

    Label lbStatusMsg; // ステータス表示用

    ProgressBar pbCopy;

    static int iStatus = 0;
    static int iPKStatus = 0;

    byte[] San5W95EXE;
    byte[] LOGO_S5;




    public San5W95InstForm()
    {

        this.Text = "データコピーフェイズ";

        this.Width = 350;
        this.Height = 200;

        pbCopy = new ProgressBar();
        pbCopy.Left = 20;
        pbCopy.Top = 20;
        pbCopy.Width = 280;
        pbCopy.Height = 20;

        lbStatusMsg = new Label();
        lbStatusMsg.Left = 50;
        lbStatusMsg.Top = 50;
        lbStatusMsg.Width = 280;
        lbStatusMsg.Height = 80;

        this.Controls.Add(pbCopy);
        this.Controls.Add(lbStatusMsg);

        // このプロジェクトのアセンブリのタイプを取得。
        System.Reflection.Assembly prj_assebmly = GetType().Assembly;
        System.Resources.ResourceManager r = new System.Resources.ResourceManager(String.Format("{0}.San5PK_installerRes", prj_assebmly.GetName().Name), prj_assebmly);

        System.Drawing.Icon iconform = (System.Drawing.Icon)(r.GetObject("icon"));
        this.Icon = iconform;

        San5W95EXE = (byte[])r.GetObject("San5W95EXE");
        San5W95EXE = UnCompressBytes(San5W95EXE);

        LOGO_S5 = (byte[])r.GetObject("LOGO");

        this.Shown += new EventHandler(Form_Shown);
        this.Closed += new EventHandler(Form_Closed);

    }



    private System.Windows.Forms.Timer tmrClock;

    public void Form_Shown(Object sender, EventArgs e)
    {

        // タイマーのインスタンス生成とイベントハンドラの追加
        tmrClock = new System.Windows.Forms.Timer();
        tmrClock.Tick += new EventHandler(tmrClock_Tick);

        // タイマーの間隔設定と始動
        tmrClock.Interval = 1000;
        tmrClock.Enabled = true;
    }


    public void tmrClock_Tick(Object sender, EventArgs e)
    {
        if (iStatus == 0)
        {
            tmrClock.Enabled = false;
            // 通常の三国志がチェックにひっかかった。
            if (San5W95ExistCheck(false))
            {
                iStatus = 1;
            }
            tmrClock.Enabled = true;
        }
        if (iStatus == 1)
        {
            iStatus++;
            tmrClock.Enabled = false;
            San5W95InstallExecute(false);
            tmrClock.Enabled = true;
        }

        if (iPKStatus == 0)
        {
            tmrClock.Enabled = false;
            // 通常の三国志がチェックにひっかかった。
            if (San5W95ExistCheck(true))
            {
                iPKStatus = 1;
            }
            tmrClock.Enabled = true;
        }

        if (iPKStatus == 1)
        {
            iPKStatus++;
            tmrClock.Enabled = false;
            San5W95InstallExecute(true);
            tmrClock.Enabled = true;
        }
    }

    public void Form_Closed(Object sender, EventArgs e)
    {
        // タイマーの停止
        tmrClock.Enabled = false;

    }


    private bool San5W95ExistCheck(bool isPK)
    {


        //三国志Vドライブを探す
        String strDrive = CheckValidLogicalDrive(isPK);

        // 存在しない
        if (strDrive == String.Empty)
        {
            // System.Windows.Forms.MessageBox.Show( strNoCDErrMsg, "エラー", MessageBoxButtons.OK, .MessageBoxIcon.Error);
            // this.Close();

            return false;
        }

        strCDDriveName = strDrive;

        strSystemDriveName = System.Environment.GetEnvironmentVariable("SystemDrive") + "\\";
        // 存在している。ファイルもまぁきっとある。
        if (isPK)
        {
            lbStatusMsg.Text = strCDDriveName + "ドライブに三国志5wPKのCDを発見しました！\n\n" +
                strSystemDriveName + strDstDir + " フォルダに\n追加分のキットのファイルを出力します。\n" +
                "後で、ご自身で三国志5wPKをインストールしたフォルダへとコピー＆上書きして下さい。";
        }
        else
        {
            lbStatusMsg.Text = strCDDriveName + "ドライブに三国志5のCDを発見しました！\n\n" +
                strSystemDriveName + strDstDir + " フォルダに\nインストールを試みます。\n";
        }

        return true;
    }


    private static bool CheckValidLogicalVolumeInfomation(System.IO.DriveInfo d, bool isPK)
    {
        try
        {
            if (d.DriveType != System.IO.DriveType.CDRom)
            {
                return false;
            }
            // ボリュームはCDタイプで、先頭の文字がSで、どこかに5がついてる。そして、どこかにWもついている。
            String strVolumeLabel = d.VolumeLabel;
            if (strVolumeLabel.Length < 1)
            {
                return false;
            }

            if (strVolumeLabel[0] == 'S' && strVolumeLabel.Contains("5") && strVolumeLabel.Contains("W"))
            {
                //
                if (isPK)
                {
                    if (strVolumeLabel.Contains("PK"))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
                else
                {
                    if (strVolumeLabel.Contains("PK"))
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
            }
            else
            {
                return false;
            }
        }
        catch (Exception e)
        {
            return false;
        }
    }

    // 素の三国志 // S[UA]N5W95

    // PKオンリー
    // PKがS5PKW95です。
    // WITHPK にもPKは付く。
    private static String CheckValidLogicalDrive(bool isPK)
    {

        //現在のコンピュータの論理ドライブを取得
        System.IO.DriveInfo[] drives = System.IO.DriveInfo.GetDrives();
        foreach (System.IO.DriveInfo d in drives)
        {
            if (CheckValidLogicalVolumeInfomation(d, isPK))
            {
                return d.Name;
            }
        }

        return String.Empty; // 無かった
    }


    private void San5W95InstallExecute(bool isPK)
    {

        String strBaseCDDir = strCDDriveName;

        String strErrorFile = "";

        List<String> strSrcFileNameList = new List<String>();
        List<String> strDstFileNameList = new List<String>();

        String strSrcDirectory = "";


        // SETUP.DATをShift-JISコードとして開く
        try
        {
            System.IO.StreamReader sr = new System.IO.StreamReader(
                strCDDriveName + "SETUP.DAT",
                System.Text.Encoding.GetEncoding("shift_jis")
                );

            int is_start = 0; // 1:次空白 2:開始前 3:開始している

            //内容を一行ずつ読み込む
            while (sr.Peek() > -1)
            {
                String line = sr.ReadLine();

                if (line.Contains("SrcDirectory"))
                {
                    strSrcDirectory = line.Split('=')[0].Trim() + "\\";
                }

                else if (is_start == 1 && line.Length < 2)
                {
                    is_start = 2;
                }
                else if (is_start == 2 && line.Length < 2)
                {
                    is_start = 3;
                }
                else if (line.Length < 2)
                {
                    continue;
                }
                else if (is_start == 2)
                {
                    line = line.Split(',')[0];
                    String[] strSplited = line.Split('>');
                    String before;
                    String after;
                    if (strSplited.Length == 1)
                    {
                        before = after = strSplited[0].Trim();

                    }
                    else
                    {
                        before = strSplited[0].Trim();
                        after = strSplited[1].Trim();
                    }

                    // SETUPディレクトリ内に該当ファイルがあるなら、それが優先、そうでなければ、直下
                    strSrcFileNameList.Add(strCDDriveName + strSrcDirectory + before);
                    strDstFileNameList.Add(strSystemDriveName + strDstDir + after);

                }

                if (line.Contains("AppVersion"))
                {
                    is_start = 1;
                }

            }
            //閉じる
            sr.Close();

        }
        catch (Exception)
        {
            strErrorFile = "SETUP.DAT";
        }

        // ここまでエラーがないなら、１つ１つ展開しながらコピー
        if (strErrorFile == "")
        {
            // プログレスバーの初期化
            pbCopy.Minimum = 0;
            pbCopy.Maximum = strSrcFileNameList.Count - 1;
            pbCopy.Value = 0;

            if (!System.IO.Directory.Exists(strSystemDriveName + strDstDir))
            {
                System.IO.Directory.CreateDirectory(strSystemDriveName + strDstDir);
            }
            for (int f = 0; f < strSrcFileNameList.Count; f++)
            {
                // コピー中のエラー対処
                try
                {
                    String src = strSrcFileNameList[f];
                    String dst = strDstFileNameList[f];

                    //ProcessStartInfoオブジェクトを作成する
                    System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo();
                    //メモ帳の実行ファイルのパスを指定する
                    psi.FileName = "expand.exe";

                    psi.Arguments = src + " " + dst;
                    //WindowStyleにMinimizedを指定して、非表示で起動されるようにする
                    psi.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                    //UseShellExecuteをTrueにする（デフォルトでTrueなので、変更する必要なし）
                    //psi.UseShellExecute = true;
                    //アプリケーションを起動する
                    System.Diagnostics.Process p = System.Diagnostics.Process.Start(psi);

                    //読み取り専用属性を削除する
                    // System.IO.FileAttributes attr = System.IO.File.GetAttributes(dst);
                    // System.IO.File.SetAttributes(dst, attr & (~System.IO.FileAttributes.ReadOnly));

                    //ProgressBar1の値を変更する
                    pbCopy.Value = f;
                }
                catch (UnauthorizedAccessException)
                {
                    strErrorFile = strDstFileNameList[f]; // エラーファイル控えておく
                }
            }
        }

        if (isPK)
        {

            // ここまでエラーがないなら、San5W95.exeを出力
            if (strErrorFile == "")
            {

                try
                {
                    // ------------------------ San5W95.exe
                    String fullPathName = strSystemDriveName + strDstDir + "San5W95.exe";

                    // ファイルを作成して書き込む。ファイルが存在しているときは、上書きする
                    System.IO.FileStream fs = new System.IO.FileStream(
                        fullPathName,
                        System.IO.FileMode.Create,
                        System.IO.FileAccess.Write);

                    fs.Write(San5W95EXE, 0, San5W95EXE.Length);

                    fs.Close();

                    DateTime dt = new DateTime(1996, 8, 31, 6, 0, 0); // タイムスタンプ

                    //作成日時の設定
                    System.IO.File.SetCreationTime(fullPathName, dt);
                    //更新日時の設定
                    System.IO.File.SetLastWriteTime(fullPathName, dt);

                }
                catch (UnauthorizedAccessException)
                {
                    strErrorFile = "San5W95.exe"; // エラーファイル控えておく
                }

            }

            // ここまでエラーがないなら、LOGO.S5を出力
            if (strErrorFile == "")
            {

                try
                {
                    // ------------------------ San5W95.exe
                    String fullPathName = strSystemDriveName + strDstDir + "logo.s5";

                    // ファイルを作成して書き込む。ファイルが存在しているときは、上書きする
                    System.IO.FileStream fs = new System.IO.FileStream(
                        fullPathName,
                        System.IO.FileMode.Create,
                        System.IO.FileAccess.Write);

                    fs.Write(LOGO_S5, 0, LOGO_S5.Length);

                    fs.Close();

                    DateTime dt = new DateTime(1996, 8, 31, 6, 0, 0); // タイムスタンプ

                    //作成日時の設定
                    System.IO.File.SetCreationTime(fullPathName, dt);
                    //更新日時の設定
                    System.IO.File.SetLastWriteTime(fullPathName, dt);

                }
                catch (UnauthorizedAccessException)
                {
                    strErrorFile = "logo.s5"; // エラーファイル控えておく
                }
            }
        }

        if (strErrorFile != "")
        {
            System.Windows.Forms.MessageBox.Show("コピー中でエラーが発生しました。\n" + "ファイル名:" + strErrorFile, "エラー", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        else
        {

            if (isPK)
            {
                Shift2ndFaze();
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("三国志 V (無印)のインストールを終了しました。\n\n続いて、三国志 V パワーアップのCDをトレイに入れてください。", "情報", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lbStatusMsg.Text = "パワーアップキットのCDを入れてください。";
            }
        }
    }


    //解凍を行う
    private byte[] UnCompressBytes(byte[] byteComp)
    {
        int num;
        byte[] buf = new byte[1024]; // 1Kbytesずつ処理する
        // 入力ストリーム
        System.IO.MemoryStream inStream = new System.IO.MemoryStream(byteComp);
        // 解凍ストリーム
        System.IO.Compression.GZipStream decompStream = new System.IO.Compression.GZipStream(inStream, System.IO.Compression.CompressionMode.Decompress);
        // 出力ストリーム
        System.IO.MemoryStream outStream = new System.IO.MemoryStream();

        while ((num = decompStream.Read(buf, 0, buf.Length)) > 0)
        {
            outStream.Write(buf, 0, num);
        }
        byte[] crypted_data = outStream.ToArray();

        Array.Reverse(crypted_data);

        return crypted_data;
    }



    private void Shift2ndFaze()
    {
        try
        {
            String bgmdir = strSystemDriveName + strDstDir + "bdat\\";
            System.IO.DirectoryInfo di = System.IO.Directory.CreateDirectory(bgmdir); // bdatというフォルダにBGM(01.wav～21.wav)を作成する。
            CDRipperForm.RipperForm ripper_form = new CDRipperForm.RipperForm(strCDDriveName, bgmdir, this.Left, this.Bottom);
            ripper_form.ShowDialog();

            this.Close();
        }
        catch (Exception)
        {
            System.Windows.Forms.MessageBox.Show(strSystemDriveName + strDstDir + "bdat" + " ディレクトリ作成中にエラーが発生しました", "エラー", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    [STAThread]
    public static void Main()
    {
        Application.Run(new San5W95InstForm());
    }

};



