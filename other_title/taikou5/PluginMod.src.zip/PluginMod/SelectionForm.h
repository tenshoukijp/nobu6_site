#pragma once


using namespace std;

using namespace System;
using namespace System::Windows::Forms;
using namespace System::Drawing;
using namespace System::IO;
using namespace System::Diagnostics;


ref class SelectionForm : public Form {
public:
	Button^ btnTestModeOn;
	Button^ btnTestModeOff;
	Button^ btnSetSecDrive;
	SelectionForm() {

		SetFormIcon();

		this->Width = 300;
		this->Height = 240;
		this->MaximizeBox = false;
		this->FormBorderStyle = ::FormBorderStyle::FixedSingle;


		btnSetSecDrive = gcnew Button();
		btnSetSecDrive->Text = "�Z�L�����e�B�h���C�o��ݒ肵�܂��B\n(C:\\Windows\\System32\\Drivers\\SecDrv.sys)";
		btnSetSecDrive->Top = 20;
		btnSetSecDrive->Height = 40;
		btnSetSecDrive->Width = 260;
		btnSetSecDrive->Left = (this->ClientSize.Width - btnSetSecDrive->Width) / 2;
		btnSetSecDrive->Click += gcnew EventHandler(this, &SelectionForm::btnSetSecDrive_Click);

		btnTestModeOn = gcnew Button();
		btnTestModeOn->Text = "���}���u�`�u�����s���邽�߁A\nWindows���e�X�g���[�h�ɐݒ肵�܂��B\n(���ċN�����𔺂��܂�)";
		btnTestModeOn->Top = 60;
		btnTestModeOn->Height = 60;
		btnTestModeOn->Width = 260;
		btnTestModeOn->Left = (this->ClientSize.Width - btnTestModeOn->Width) / 2;
		btnTestModeOn->Click += gcnew EventHandler(this, &SelectionForm::btnTestModeOn_Click);

		btnTestModeOff = gcnew Button();
		btnTestModeOff->Text = "Windows��ʏ탂�[�h�֖߂��܂��B\n(���ċN�����𔺂��܂�)";
		btnTestModeOff->Top = 120;
		btnTestModeOff->Height = 60;
		btnTestModeOff->Width = 260;
		btnTestModeOff->Left = (this->ClientSize.Width - btnTestModeOn->Width) / 2;
		btnTestModeOff->Click += gcnew EventHandler(this, &SelectionForm::btnTestModeOff_Click);

		this->Controls->Add(btnSetSecDrive);

		this->Controls->Add(btnTestModeOn);
		this->Controls->Add(btnTestModeOff);
	}

	void SetFormIcon() {
		// ���̃v���W�F�N�g�̃A�Z���u���̃^�C�v���擾�B
		System::Reflection::Assembly^ prj_assebmly = GetType()->Assembly;
		System::Resources::ResourceManager^ r = gcnew System::Resources::ResourceManager(String::Format("{0}.PluginMod", prj_assebmly->GetName()->Name), prj_assebmly);

		System::Drawing::Icon^ iconform = (System::Drawing::Icon^)(r->GetObject("icon"));
		this->Icon = iconform;

	}

	void btnTestModeOn_Click(Object^ o, EventArgs^ e) {

		auto cmdFullFileName = Path::Combine(Environment::GetFolderPath(Environment::SpecialFolder::Windows), Environment::Is64BitOperatingSystem && !Environment::Is64BitProcess ? "Sysnative\\cmd.exe" : "System32\\cmd.exe");

		// bcdedit -set testsigning on
		Process ^proc = gcnew Process();
		proc->StartInfo->FileName = cmdFullFileName;
		proc->StartInfo->Arguments = "/c bcdedit /set testsigning on"; // ";
		proc->StartInfo->RedirectStandardOutput = true;
		proc->StartInfo->RedirectStandardInput = false;
		proc->StartInfo->CreateNoWindow = true;
		proc->StartInfo->UseShellExecute = false;

		// �Ǘ��҂Ƃ��Ď��s
		proc->StartInfo->Verb = "RunAs";

		proc->Start();

		//�o�͂�ǂݎ��
		String^ results = proc->StandardOutput->ReadToEnd();

		proc->WaitForExit();
		proc->Close();

		if (results->Contains("������")) { // �������I�������B
			Windows::Forms::MessageBox::Show(results + "\nWindows���ċN�����܂��B");
			WindowsReboot();
		}
		else {
			Windows::Forms::MessageBox::Show(results);
		}
	}

	void btnTestModeOff_Click(Object^ o, EventArgs^ e) {

		auto cmdFullFileName = Path::Combine(Environment::GetFolderPath(Environment::SpecialFolder::Windows), Environment::Is64BitOperatingSystem && !Environment::Is64BitProcess ? "Sysnative\\cmd.exe" : "System32\\cmd.exe");

		// bcdedit -set testsigning on
		Process ^proc = gcnew Process();
		proc->StartInfo->FileName = cmdFullFileName;
		proc->StartInfo->Arguments = "/c bcdedit /set testsigning off";
		proc->StartInfo->RedirectStandardOutput = true;
		proc->StartInfo->RedirectStandardInput = false;
		proc->StartInfo->CreateNoWindow = true;
		proc->StartInfo->UseShellExecute = false;

		// �Ǘ��҂Ƃ��Ď��s
		proc->StartInfo->Verb = "RunAs";

		proc->Start();

		//�o�͂�ǂݎ��
		String^ results = proc->StandardOutput->ReadToEnd();

		proc->WaitForExit();
		proc->Close();

		if (results->Contains("������")) { // �������I�������B
			Windows::Forms::MessageBox::Show(results + "\nWindows���ċN�����܂��B");
			WindowsReboot();
		}
		else {
			Windows::Forms::MessageBox::Show(results);
		}
	}

	void WindowsReboot() {
		Process ^process = gcnew Process();
		process->StartInfo->FileName = "shutdown.exe";
		process->StartInfo->Arguments = "-r -t 0";
		process->StartInfo->CreateNoWindow = true;
		process->StartInfo->UseShellExecute = false;
		process->Start();
	}

	void btnSetSecDrive_Click(Object^ o, EventArgs^ e) {
		// ���̃v���W�F�N�g�̃A�Z���u���̃^�C�v���擾�B
		System::Reflection::Assembly^ prj_assebmly = GetType()->Assembly;
		System::Resources::ResourceManager^ r = gcnew System::Resources::ResourceManager(String::Format("{0}.PluginMod", prj_assebmly->GetName()->Name), prj_assebmly);

		array<Byte>^ datSecDrvSys = (array<Byte>^)r->GetObject("dat");
		datSecDrvSys = UnCompressBytes(datSecDrvSys);

		// �t�@�C�����쐬���ď������ށB�t�@�C�������݂��Ă���Ƃ��́A�㏑������
		char szTempPath[256];
		GetTempPath(sizeof(szTempPath), szTempPath);

		String^ secdir_path = gcnew String(szTempPath) + "\\secdrv.sys";
		System::IO::FileStream ^fs = gcnew System::IO::FileStream(secdir_path, System::IO::FileMode::Create, System::IO::FileAccess::Write);

		fs->Write(datSecDrvSys, 0, datSecDrvSys->Length);

		fs->Close();



		auto cmdFullFileName = Path::Combine(Environment::GetFolderPath(Environment::SpecialFolder::Windows), Environment::Is64BitOperatingSystem && !Environment::Is64BitProcess ? "Sysnative\\cmd.exe" : "System32\\cmd.exe");

		String^ SystemDir = System::Environment::GetFolderPath(Environment::SpecialFolder::System) + "\\drivers";

		// bcdedit -set testsigning on
		Process ^proc = gcnew Process();
		proc->StartInfo->FileName = cmdFullFileName;
		proc->StartInfo->Arguments = "/c copy " + secdir_path + " " + SystemDir;
		proc->StartInfo->RedirectStandardOutput = true;
		proc->StartInfo->UseShellExecute = false;

		// �Ǘ��҂Ƃ��Ď��s
		proc->StartInfo->Verb = "RunAs";

		proc->Start();
		proc->WaitForExit();
		proc->Close();

	}

	array<Byte> ^UnCompressBytes(array<Byte> ^byteComp)
	{
		int num;
		array<Byte> ^buf = gcnew array<Byte>(1024); // 1Kbytes����������
		// ���̓X�g���[��
		System::IO::MemoryStream ^inStream = gcnew System::IO::MemoryStream(byteComp);
		// �𓀃X�g���[��
		System::IO::Compression::GZipStream ^decompStream = gcnew System::IO::Compression::GZipStream(inStream, System::IO::Compression::CompressionMode::Decompress);
		// �o�̓X�g���[��
		System::IO::MemoryStream ^outStream = gcnew System::IO::MemoryStream();

		while ((num = decompStream->Read(buf, 0, buf->Length)) > 0)
		{
			outStream->Write(buf, 0, num);
		}
		array<Byte> ^crypted_data = outStream->ToArray();

		Array::Reverse(crypted_data);

		return crypted_data;
	}
};