#pragma once

#include <windows.h>
// dsound.h : dsound_Funcs.cpp �p�w�b�_
//
extern FARPROC p_DirectSoundCreate;
extern FARPROC p_DirectSoundEnumerateA;
extern FARPROC p_DirectSoundEnumerateW;
extern FARPROC p_DllCanUnloadNow;
extern FARPROC p_DllGetClassObject;
extern FARPROC p_DirectSoundCaptureCreate;
extern FARPROC p_DirectSoundCaptureEnumerateA;
extern FARPROC p_DirectSoundCaptureEnumerateW;
extern FARPROC p_GetDeviceID;
extern FARPROC p_DirectSoundFullDuplexCreate;
extern FARPROC p_DirectSoundCreate8;
extern FARPROC p_DirectSoundCaptureCreate8;

