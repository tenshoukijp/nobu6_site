﻿// Enums.cs

namespace N14PKLibrary
{
	/// <summary>データの種類</summary>
	public enum DataKind : int
	{
		/// <summary>不明データ</summary>
		UNKNOWN = -1,	// -1 不明

		/// <summary>建物データ</summary>
		建物,			// 00 建物

		/// <summary>武将データ</summary>
		武将,			// 01 武将

		/// <summary>勢力データ</summary>
		勢力,			// 02 勢力

		/// <summary>軍団データ</summary>
		軍団,			// 03 軍団

		/// <summary>城データ(区画データは城データに含まれる)</summary>
		城,				// 04 城

		/// <summary>城名データ</summary>
		城名,			// 05 城名

		/// <summary>部隊データ</summary>
		部隊,			// 06 部隊

		/// <summary>方針データ</summary>
		方針,			// 07 方針

		/// <summary>要所データ</summary>
		要所,			// 08 要所

		/// <summary>地形データ</summary>
		地形,			// 09 地形

		/// <summary>施設データ</summary>
		施設,			// 10 施設

		/// <summary>家宝データ</summary>
		家宝,			// 11 家宝

		/// <summary>国データ</summary>
		国,				// 12 国

		/// <summary>戦国伝データ
		/// <para>PKになってから中身は実質何もない(外部リソース化した？)</para></summary>
		戦国伝,			// 13 戦国伝

		/// <summary>地方データ</summary>
		地方,			// 14 地方

		/// <summary>街道データ</summary>
		街道,			// 15 街道

		/// <summary>改名データ</summary>
		改名,			// 16 改名

		/// <summary>不明</summary>
		DATA17,			// 17

		/// <summary>特性データ</summary>
		特性,			// 18 特性

		/// <summary>特性習得条件データ</summary>
		習得条件,		// 19 特性習得条件

		/// <summary>成長型データ</summary>
		成長型,			// 20 成長型

		/// <summary>不明</summary>
		DATA21,			// 21

		/// <summary>兵科陣形データ(天道の残骸か？)</summary>
		兵科陣形,		// 22 兵科・陣形(未使用？天道のデータがそのまま？)

		/// <summary>戦法データ</summary>
		戦法,			// 23 戦法

		/// <summary>効果データ</summary>
		効果,			// 24 効果

		/// <summary>軍略データ</summary>
		軍略,			// 25 軍略

		/// <summary>政策データ</summary>
		政策,			// 26 政策

		/// <summary>国人衆データ</summary>
		国人衆,			// 27 国人衆

		/// <summary>不明</summary>
		DATA28,			// 28

		/// <summary>不明</summary>
		DATA29,			// 29

		/// <summary>不明</summary>
		DATA30,			// 30

		/// <summary>不明</summary>
		DATA31,			// 31

		/// <summary>不明</summary>
		DATA32,			// 32

		/// <summary>城郭データ</summary>
		城郭			// 33 城郭
	}
}
