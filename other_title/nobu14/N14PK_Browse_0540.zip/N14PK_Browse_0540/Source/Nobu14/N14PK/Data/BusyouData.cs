﻿// BusyouData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>武将データ</summary>
	public class BusyouData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;


		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>000h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x000 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x000 ); }
		}

		/// <summary>004~00Eh 11バイト 姓(シフトJIS Nullターミネイト)</summary>
		public String Sei
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x004, 11 ); }
			set { MyTextConverter.StringToBytes( value, 11 ).CopyTo( this._rec, 0x004 ); }
		}

		/// <summary>00F~01Bh 11バイト 名(シフトJIS Nullターミネイト)</summary>
		public String Mei
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x00F, 11 ); }
			set { MyTextConverter.StringToBytes( value, 11 ).CopyTo( this._rec, 0x00F ); }
		}

		/// <summary>01A~02Ch 19バイト 姓読み(シフトJIS Nullターミネイト)</summary>
		public String SeiYomi
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x01A, 19 ); }
			set { MyTextConverter.StringToBytes( value, 19 ).CopyTo( this._rec, 0x01A ); }
		}

		/// <summary>02D~03Fh 19バイト 名読み(シフトJIS Nullターミネイト)</summary>
		public String MeiYomi
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x02D, 19 ); }
			set { MyTextConverter.StringToBytes( value, 19 ).CopyTo( this._rec, 0x02D ); }
		}

		/// <summary>040~05Fh 11バイト 名2(シフトJIS Nullターミネイト)
		/// <para>Meiに通称が設定されている場合は本名、Meiが本名の場合はデータなし</para></summary>
		public String Mei2
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x040, 11 ); }
			set { MyTextConverter.StringToBytes( value, 19 ).CopyTo( this._rec, 0x040 ); }
		}

		/// <summary>04B~05Dh 19バイト 名2読み(シフトJIS Nullターミネイト)
		/// <para>Meiに通称が設定されている場合は本名、Meiが本名の場合はデータなし</para></summary>
		public String Mei2Yomi
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x04B, 19 ); }
			set { MyTextConverter.StringToBytes( value, 19 ).CopyTo( this._rec, 0x04B ); }
		}

		/// <summary>05Eh 2バイト 0固定？</summary>
		public UInt16 h05E_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x05E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x05E ); }
		}

		/// <summary>060h 4バイト 列伝ポインタ(PK以降のDLC武将・新規登録武将のみ？)</summary>
		public UInt32 PtrRetsuden
		{
			get { return BitConverter.ToUInt32( this._rec, 0x060 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x060 ); }
		}

		/// <summary>064h 4バイト 0固定？</summary>
		public UInt32 h064_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x064 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x064 ); }
		}

		/// <summary>068h 4バイト 0固定？</summary>
		public UInt32 h068_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x068 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x068 ); }
		}

		/// <summary>06Ch 4バイト 0固定？</summary>
		public UInt32 h06C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x06C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x06C ); }
		}

		/// <summary>070h 4バイト 不明
		/// <para>列伝ポインタを持つデータには何らかの値(確認時0x93)</para></summary>
		public UInt32 h070_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x070 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x070 ); }
		}

		/// <summary>074h 4バイト 不明
		/// <para>列伝ポインタを持つデータには0x9F、その他のデータは0x0F ？</para></summary>
		public UInt32 h074_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x074 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x074 ); }
		}

		/// <summary>078h 4バイト 0固定？</summary>
		public UInt32 h078_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x078 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x078 ); }
		}

		/// <summary>07Ch 4バイト 親愛武将リスト(2ポインタタイプ)</summary>
		public UInt32 PtrShinaiList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x07C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x07C ); }
		}

		/// <summary>080h 4バイト 親愛武将リストカウンタ</summary>
		public UInt32 CntShinaiList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x080 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x080 ); }
		}

		/// <summary>084h 4バイト 0固定？</summary>
		public UInt32 h084_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x084 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x084 ); }
		}

		/// <summary>088h 4バイト 嫌悪武将リスト(2ポインタタイプ)</summary>
		public UInt32 PtrKenoList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x088 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x088 ); }
		}

		/// <summary>08Ch 4バイト 嫌悪武将リストカウンタ</summary>
		public UInt32 CntKenoList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x08C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x08C ); }
		}

		/// <summary>090h 4バイト 0固定</summary>
		public UInt32 h090_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x090 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x090 ); }
		}

		/// <summary>094h 4バイト 戦法リスト(2ポインタタイプ)</summary>
		public UInt32 PtrSenpouList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x094 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x094 ); }
		}

		/// <summary>098h 4バイト 戦法リストカウンタ</summary>
		public UInt32 CntSenpouList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x098 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x098 ); }
		}

		/// <summary>09Ch 4バイト 0固定？</summary>
		public UInt32 h09C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x09C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x09C ); }
		}

		/// <summary>0A0h 4バイト 家宝ポインタ</summary>
		public UInt32 PtrKahou
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0A0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0A0 ); }
		}

		/// <summary>0A4h 4バイト 父ポインタ</summary>
		public UInt32 PtrChichi
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0A4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0A4 ); }
		}

		/// <summary>0A8h 4バイト 養父ポインタ</summary>
		public UInt32 PtrYoufu
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0A8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0A8 ); }
		}

		/// <summary>0ACh 4バイト 配偶者ポインタ</summary>
		public UInt32 PtrHaigusya
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0AC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0AC ); }
		}

		/// <summary>0B0h 4バイト 国ポインタ 普通に城にいる武将でもゼロの場合がある！？</summary>
		public UInt32 PtrKuni
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0B0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0B0 ); }
		}

		/// <summary>0B4h 4バイト 軍団ポインタ</summary>
		public UInt32 PtrGundan
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0B4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0B4 ); }
		}

		/// <summary>0B8h 4バイト 勢力ポインタ
		/// <para>値が入ってるのは謹慎中武将、または捕虜の滅亡勢力当主(ともに軍団ポインタは0)だけ？</para></summary>
		public UInt32 PtrSeiryoku
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0B8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0B8 ); }
		}

		/// <summary>0BCh 4バイト 所在ポインタ 所在タイプにより参照しているデータが異なる</summary>
		public UInt32 PtrSyozai
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0BC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0BC ); }
		}

		/// <summary>0C0h 4バイト 所在タイプ
		/// <para>0:なし、3:城、4:部隊、5:任務(移動？)、15:国人衆</para></summary>
		public UInt32 SyozaiType
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0C0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0C0 ); }
		}

		/// <summary>0C4h 4バイト ポインタ(飛んだ先には家宝データを複数含むサイズ0x60のデータ)お気に入り家宝？</summary>
		public UInt32 Ptr_0C4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0C4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0C0 ); }
		}

		/// <summary>0C8h 2バイト 血族ID</summary>
		public Int16 KetsuzokuID
		{
			get { return BitConverter.ToInt16( this._rec, 0x0C8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0C8 ); }
		}

		/// <summary>0CAh 2バイト 0xFFFF固定？</summary>
		public UInt16 h0CA_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0CA ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0CA ); }
		}

		/// <summary>0CCh 2バイト 顔グラID1</summary>
		public UInt16 KaoguraID1
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0CC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0CC ); }
		}

		/// <summary>0CEh 2バイト 0xFFFF固定？</summary>
		public UInt16 h0CE_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0CE ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0CE ); }
		}

		/// <summary>0D0h 2バイト 顔グラID2</summary>
		public UInt16 KaoguraID2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0D0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D0 ); }
		}

		/// <summary>0D2h 2バイト 生年</summary>
		public UInt16 YearSei
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0D2 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D2 ); }
		}

		/// <summary>0D4h 2バイト 登場年</summary>
		public UInt16 YearToujou
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0D4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D4 ); }
		}

		/// <summary>0D6h 2バイト 没年</summary>
		public UInt16 YearBotsu
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0D6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D6 ); }
		}

		/// <summary>0D8h 1バイト 0xFF固定？</summary>
		public Byte h0D8
		{
			get { return this._rec[0x0D8]; }
			set { this._rec[0x0D6] = value; }
		}

		/// <summary>0D9h 1バイト 相性？</summary>
		public Byte h0D9
		{
			get { return this._rec[0x0D9]; }
			set { this._rec[0x0D9] = value; }
		}

		/// <summary>0DAh 1バイト 創造(0~:保守、40~:中道、70~:創造)</summary>
		public Byte Souzou
		{
			get { return this._rec[0x0DA]; }
			set { this._rec[0x0DA] = value; }
		}

		/// <summary>0DBh 1バイト 統率</summary>
		public Byte Tousotsu
		{
			get { return this._rec[0x0DB]; }
			set { this._rec[0x0DB] = value; }
		}

		/// <summary>0DCh 1バイト 武勇</summary>
		public Byte Buyuu
		{
			get { return this._rec[0x0DC]; }
			set { this._rec[0x0DC] = value; }
		}

		/// <summary>0DDh 1バイト 知略</summary>
		public Byte Chiryaku
		{
			get { return this._rec[0x0DD]; }
			set { this._rec[0x0DD] = value; }
		}

		/// <summary>0DEh 1バイト 政治</summary>
		public Byte Seiji
		{
			get { return this._rec[0x0DE]; }
			set { this._rec[0x0DE] = value; }
		}

		/// <summary>0DFh 1バイト 叛心 自勢力の武将には使われない？</summary>
		public Byte Hanshin
		{
			get { return this._rec[0x0DF]; }
			set { this._rec[0x0DF] = value; }
		}

		/// <summary>0E0~0FFh 32バイト 特性データ配列
		/// <apra>特性1つにつき1ビット = 256データ ※特性データ数は247(PKver 1.0.0.1)なので未使用部分がある</apra></summary>
		public Boolean[] TokuseiFlags
		{
			get
			{
				// 配列の要素にアクセスするたびに get される
				// 要素を変更する場合は、別途配列の参照またはコピーに対して変更し配列自体を set する
				var flags = new bool[256];
				for ( var i = 0; i < flags.Length; i++ )
				{
					flags[i] = MyBitConverter.ToBoolean( this._rec, 0x0E0, (uint)i );
				}
				return flags;
			}
			set
			{
				if ( value.Length != this.TokuseiFlags.Length ) { return; }
				for ( var i = 0; i < value.Length; i++ )
				{
					MyBitConverter.IntoBytes( value[i], this._rec, 0x0E0, (uint)i );
				}
			}
		}

		/// <summary>100h 4バイト 登場国ポインタ</summary>
		public UInt32 PtrToujouKuni
		{
			get { return BitConverter.ToUInt32( this._rec, 0x100 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x100 ); }
		}

		/// <summary>104h 4バイト 母ポインタ</summary>
		public UInt32 PtrHaha
		{
			get { return BitConverter.ToUInt32( this._rec, 0x104 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x104 ); }
		}

		/// <summary>108h 2バイト 統率経験(100毎に能力 +1)</summary>
		public UInt16 TousotsuExp
		{
			get { return BitConverter.ToUInt16( this._rec, 0x108 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x108 ); }
		}

		/// <summary>10Ah 2バイト 武勇経験(100毎に能力 +1)</summary>
		public UInt16 BuyuuExp
		{
			get { return BitConverter.ToUInt16( this._rec, 0x10A ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x10A ); }
		}

		/// <summary>10Ch 2バイト 知略経験(100毎に能力 +1)</summary>
		public UInt16 ChiryakuExp
		{
			get { return BitConverter.ToUInt16( this._rec, 0x10C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x10C ); }
		}

		/// <summary>10Eh 2バイト 政治経験(100毎に能力 +1)</summary>
		public UInt16 SeijiExp
		{
			get { return BitConverter.ToUInt16( this._rec, 0x10E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x10E ); }
		}

		/// <summary>110h 2バイト 年(用途不明)</summary>
		public UInt16 DateYearUnknown
		{
			get { return BitConverter.ToUInt16( this._rec, 0x110 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x110 ); }
		}

		/// <summary>112h 1バイト 月(用途不明)</summary>
		public Byte DateMonthUnknown
		{
			get { return this._rec[0x112]; }
			set { this._rec[0x112] = value; }
		}

		/// <summary>113h 1バイト 日(用途不明)</summary>
		public Byte DateDayUnknown
		{
			get { return this._rec[0x113]; }
			set { this._rec[0x113] = value; }
		}

		/// <summary>114h 2バイト 時(用途不明)</summary>
		public UInt16 DateHourUnknown
		{
			get { return BitConverter.ToUInt16( this._rec, 0x114 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x114 ); }
		}

		/// <summary>116h 2バイト 仕官年</summary>
		public UInt16 DateYearShikan
		{
			get { return BitConverter.ToUInt16( this._rec, 0x116 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x116 ); }
		}

		/// <summary>118h 1バイト 仕官月</summary>
		public Byte DateMonthShikan
		{
			get { return this._rec[0x118]; }
			set { this._rec[0x118] = value; }
		}

		/// <summary>119h 1バイト 仕官日</summary>
		public Byte DateDayShikan
		{
			get { return this._rec[0x119]; }
			set { this._rec[0x119] = value; }
		}

		/// <summary>11Ah 2バイト 仕官時</summary>
		public UInt16 DateHourShikan
		{
			get { return BitConverter.ToUInt16( this._rec, 0x11A ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x11A ); }
		}

		/// <summary>11C~13Bh 32バイト 忠誠補正配列
		/// <para>使用されているのは26バイトで、残り6バイトは0固定</para></summary>
		public SByte[] ChuuseiHoseiList
		{
			get
			{
				// 配列の要素にアクセスするたびに get される
				// 要素を変更する場合は、別途配列の参照またはコピーに対して変更し配列自体を set する
				var array = new sbyte[32];
				for ( var i = 0; i < array.Length; i++ )
				{
					array[i] = (sbyte)this._rec[0x11C + i];
				}
				return array;
			}
			set
			{
				if ( value.Length != this.ChuuseiHoseiList.Length ) { return; }
				for ( var i = 0; i < value.Length; i++ )
				{
					this._rec[0x11C + i] = (byte)value[i];
				}
			}
		}

		/// <summary>13Ch 4バイト ポインタ
		/// <para>飛んだ先はサイズ0x30のデータ(武将データ間でかぶることなくずら～っと並んでいる)</para></summary>
		public UInt32 Ptr_13C
		{
			get { return BitConverter.ToUInt32( this._rec, 0x13C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x13C ); }
		}

		/// <summary>140h 4バイト</summary>
		public UInt32 h140_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x140 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x140 ); }
		}

		/// <summary>144h 4バイト 0固定？</summary>
		public UInt32 h144_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x144 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x144 ); }
		}

		/// <summary>148h 4バイト 0固定？</summary>
		public UInt32 h148_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x148 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x148 ); }
		}

		/// <summary>14Ch 4バイト ポインタ
		/// <para>飛んだ先はサイズ0x30のデータ(Ptr_13C で飛んだ先にあるデータと一部かぶる)</para></summary>
		public UInt32 Ptr_14C
		{
			get { return BitConverter.ToUInt32( this._rec, 0x14C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x14C ); }
		}

		/// <summary>150h 4バイト</summary>
		public UInt32 h150_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x150 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x150 ); }
		}

		/// <summary>154h 4バイト 0固定？</summary>
		public UInt32 h154_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x154 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x154 ); }
		}

		/// <summary>158h 2バイト 0固定？</summary>
		public UInt16 h158_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x158 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x158 ); }
		}

		/// <summary>15Ah 1バイト 身分ID
		/// <para>-1:?、0:生前、1:成人前、(2:未発見)、3:浪人、4:捕虜、(5:人質)、6:姫、7:通常(大名/家臣/一門/隠居)、8:死亡/非登場</para></summary>
		public SByte MibunID
		{
			get { return (sbyte)this._rec[0x15A]; }
			set { this._rec[0x15A] = (byte)value; }
		}

		/// <summary>15Bh 1バイト 馬印ID</summary>
		public Byte UmajirushiID
		{
			get { return this._rec[0x15B]; }
			set { this._rec[0x15B] = value; }
		}

		/// <summary>15Ch 1バイト 武将固有の旗ID</summary>
		public Byte HataID
		{
			get { return this._rec[0x15C]; }
			set { this._rec[0x15C] = value; }
		}

		/// <summary>15Dh 1バイト</summary>
		public Byte h15D
		{
			get { return this._rec[0x15D]; }
			set { this._rec[0x15D] = value; }
		}

		/// <summary>15Eh 1バイト 成長型ID</summary>
		public Byte SeichougataID
		{
			get { return this._rec[0x15E]; }
			set { this._rec[0x15E] = value; }
		}

		/// <summary>15Fh 1バイト</summary>
		public Byte h15F
		{
			get { return this._rec[0x15F]; }
			set { this._rec[0x15F] = value; }
		}

		// 160~163h の4バイトを32ビットデータとして扱う

		/// <summary>160~163h bit00 隠居フラグ 1:隠居</summary>
		public Boolean IsInkyo
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x160, 0 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 0 ); }
		}

		/// <summary>160~163h bit01 女性フラグ 1:女</summary>
		public Boolean IsJosei
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x160, 1 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 1 ); }
		}

		/// <summary>160~163h bit02 病死フラグ 1:病死</summary>
		public Boolean IsByoushi
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x160, 2 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 2 ); }
		}

		/// <summary>160~163h bit03 0固定？</summary>
		public Boolean h160_b03
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x160, 3 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 3 ); }
		}

		/// <summary>160~163h bit04 0固定？</summary>
		public Boolean h160_b04
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x160, 4 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 4 ); }
		}

		/// <summary>160~163h bit05~06(2ビット) 信仰ID
		/// <para>0:なし、1:仏教、2:一向宗、3:基督教</para></summary>
		public UInt32 ShinkouID
		{
			get { return MyBitConverter.ToUInt32( this._rec, 0x160, 5, 2 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 5, 2 ); }
		}

		/// <summary>160~163h bit07~09(3ビット) 出自ID
		/// <para>0:武士、1:高家、2:僧侶、3:商人、4:海賊、5:忍者、6:剣豪、7:庶民</para></summary>
		public UInt32 SyutsujiID
		{
			get { return MyBitConverter.ToUInt32( this._rec, 0x160, 7, 3 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 7, 3 ); }
		}

		/// <summary>160~163h bit10 0固定？</summary>
		public Boolean h160_b10
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x160, 10 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 10 ); }
		}

		/// <summary>160~163h bit11 0固定？</summary>
		public Boolean h160_b11
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x160, 11 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 11 ); }
		}

		/// <summary>160~163h bit12~13(2ビット)
		/// <para>傷病状態ID 0:健康、1:負傷、2:病気</para></summary>
		public UInt32 SyoubyouID
		{
			get { return MyBitConverter.ToUInt32( this._rec, 0x160, 12, 2 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 12, 2 ); }
		}

		/// <summary>160~163h bit14~18(5ビット) 声タイプID</summary>
		public UInt32 KoeTypeID
		{
			get { return MyBitConverter.ToUInt32( this._rec, 0x160, 14, 5 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 14, 5 ); }
		}

		/// <summary>160~163h bit19~20(2ビット) 武将の格
		/// <para>0:C、1:B、2:A、3:S</para></summary>
		public UInt32 KakuID
		{
			get { return MyBitConverter.ToUInt32( this._rec, 0x160, 19, 2 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 19, 2 ); }
		}

		/// <summary>160~163h bit21 0固定？</summary>
		public Boolean h160_b21
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x160, 21 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 21 ); }
		}

		/// <summary>160~163h bit22 0固定？</summary>
		public Boolean h160_b22
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x160, 22 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 22 ); }
		}

		/// <summary>160~163h bit23 不明
		/// <para>確認時は木下秀長、上杉政虎、蒲生氏郷、立花道雪の4名にしかフラグが立っていなかった</para></summary>
		public Boolean h160_b23
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x160, 23 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 23 ); }
		}

		/// <summary>160~163h bit24 0固定？</summary>
		public Boolean h160_b24
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x160, 24 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 24 ); }
		}

		/// <summary>160~163h bit25 不明(登録武将、DLC武将、一部の頭領以外はフラグが立っている)</summary>
		public Boolean h160_b25
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x160, 25 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 25 ); }
		}

		/// <summary>160~163h bit26 0固定？</summary>
		public Boolean h160_b26
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x160, 26 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 26 ); }
		}

		/// <summary>160~163h bit27 不明(登録武将、DLC武将、一部の頭領以外はフラグが立っている)</summary>
		public Boolean h160_b27
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x160, 27 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 27 ); }
		}

		/// <summary>160~163h bit28 0固定？</summary>
		public Boolean h160_b28
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x160, 28 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 28 ); }
		}

		/// <summary>160~163h bit29~31(3ビット) 士道ID
		/// <para>0:名、1:家、2:才、3:利、4:義、5:創造、6:道、7:志</para></summary>
		public UInt32 ShidouID
		{
			get { return MyBitConverter.ToUInt32( this._rec, 0x160, 29, 3 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x160, 29, 3 ); }
		}

		// 164~167h の4バイトを32ビットデータとして扱う

		/// <summary>164~167h bit00~03(4ビット) 必要忠誠</summary>
		public UInt32 HitsuyouChuusei
		{
			get { return MyBitConverter.ToUInt32( this._rec, 0x164, 0, 4 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 0, 4 ); }
		}

		/// <summary>164~167h bit04</summary>
		public Boolean h164_b04
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 4 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 4 ); }
		}

		/// <summary>164~167h bit05</summary>
		public Boolean h164_b05
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 5 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 5 ); }
		}

		/// <summary>164~167h bit06</summary>
		public Boolean h164_b06
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 6 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 6 ); }
		}

		/// <summary>164~167h bit07</summary>
		public Boolean h164_b07
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 7 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 7 ); }
		}

		/// <summary>164~167h bit08</summary>
		public Boolean h164_b08
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 8 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 8 ); }
		}

		/// <summary>164~167h bit09</summary>
		public Boolean h164_b09
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 9 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 9 ); }
		}

		/// <summary>164~167h bit10</summary>
		public Boolean h164_b10
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 10 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 10 ); }
		}

		/// <summary>164~167h bit11</summary>
		public Boolean h164_b11
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 11 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 11 ); }
		}

		/// <summary>164~167h bit12</summary>
		public Boolean h164_b12
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 12 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 12 ); }
		}

		/// <summary>164~167h bit13</summary>
		public Boolean h164_b13
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 13 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 13 ); }
		}

		/// <summary>164~167h bit14</summary>
		public Boolean h164_b14
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 14 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 14 ); }
		}

		/// <summary>164~167h bit15</summary>
		public Boolean h164_b15
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 15 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 15 ); }
		}

		/// <summary>164~167h bit16</summary>
		public Boolean h164_b16
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 16 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 16 ); }
		}

		/// <summary>164~167h bit17 顔グラLLフラグ</summary>
		public Boolean IsLLKao
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 17 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 17 ); }
		}

		/// <summary>164~167h bit18 0固定？</summary>
		public Boolean h164_b18
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 18 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 18 ); }
		}

		/// <summary>164~167h bit19 0固定？</summary>
		public Boolean h164_b19
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 19 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 19 ); }
		}

		/// <summary>164~167h bit20 0固定？</summary>
		public Boolean h164_b20
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 20 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 20 ); }
		}

		/// <summary>164~167h bit21 1固定？</summary>
		public Boolean h164_b21
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 21 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 21 ); }
		}

		/// <summary>164~167h bit22 1固定？</summary>
		public Boolean h164_b22
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 22 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 22 ); }
		}

		/// <summary>164~167h bit23 1固定？</summary>
		public Boolean h164_b23
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 23 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 23 ); }
		}

		/// <summary>164~167h bit24</summary>
		public Boolean h164_b24
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 24 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 24 ); }
		}

		/// <summary>164~167h bit25</summary>
		public Boolean h164_b25
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 25 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 25 ); }
		}

		/// <summary>164~167h bit26 0固定？</summary>
		public Boolean h164_b26
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 26 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 26 ); }
		}

		/// <summary>164~167h bit27 0固定？</summary>
		public Boolean h164_b27
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 27 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 27 ); }
		}

		/// <summary>164~167h bit28 0固定？</summary>
		public Boolean h164_b28
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 28 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 28 ); }
		}

		/// <summary>164~167h bit29 0固定？</summary>
		public Boolean h164_b29
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 29 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 29 ); }
		}

		/// <summary>164~167h bit30 0固定？</summary>
		public Boolean h164_b30
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 30 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 30 ); }
		}

		/// <summary>164~167h bit31 0固定？</summary>
		public Boolean h164_b31
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x164, 31 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x164, 31 ); }
		}


		/// <summary>168h 2バイト 0xFFFF固定？</summary>
		public UInt16 h168_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x168 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x168 ); }
		}

		/// <summary>16Ah 2バイト 0固定？</summary>
		public UInt16 h16A_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x16A ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x16A ); }
		}

		/// <summary>16Ch 2バイト 0固定？</summary>
		public UInt16 h16C_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x16C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x16C ); }
		}

		/// <summary>16Eh 2バイト 0固定？</summary>
		public UInt16 h16E_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x16E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x16E ); }
		}

		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
