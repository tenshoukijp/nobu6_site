﻿// TokuseiSyuutokuJoukenData.cs

using System;

namespace N14PKLibrary.Data
{
	/// <summary>特性習得条件データ</summary>
	public class TokuseiSyuutokuJoukenData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>0h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0 ); }
		}

		/// <summary>4h 1バイト 統率</summary>
		public Byte Tousotsu
		{
			get { return this._rec[0x4]; }
			set { this._rec[0x4] = value; }
		}

		/// <summary>5h 1バイト 武勇</summary>
		public Byte Buyuu
		{
			get { return this._rec[0x5]; }
			set { this._rec[0x5] = value; }
		}

		/// <summary>6h 1バイト 知略</summary>
		public Byte Chiryaku
		{
			get { return this._rec[0x6]; }
			set { this._rec[0x6] = value; }
		}

		/// <summary>7h 1バイト 政治</summary>
		public Byte Seiji
		{
			get { return this._rec[0x7]; }
			set { this._rec[0x7] = value; }
		}

		/// <summary>8h 1バイト 性別 0:男性、1:女性</summary>
		public Byte Seibetsu
		{
			get { return this._rec[0x8]; }
			set { this._rec[0x8] = value; }
		}

		/// <summary>9h 1バイト 0固定 未使用？</summary>
		public Byte B1_9
		{
			get { return this._rec[0x9]; }
			set { this._rec[0x9] = value; }
		}

		/// <summary>Ah 1バイト 0固定 未使用？</summary>
		public Byte B1_A
		{
			get { return this._rec[0xA]; }
			set { this._rec[0xA] = value; }
		}

		/// <summary>Bh 1バイト 0固定 未使用？</summary>
		public Byte B1_B
		{
			get { return this._rec[0xB]; }
			set { this._rec[0xB] = value; }
		}

		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
