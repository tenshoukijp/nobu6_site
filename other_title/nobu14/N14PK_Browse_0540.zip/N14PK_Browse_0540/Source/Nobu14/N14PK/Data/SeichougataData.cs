﻿// SeichougataData.cs

using System;

namespace N14PKLibrary.Data
{
	/// <summary>成長型データ</summary>
	public class SeichougataData : IData
	{
		private const int _tokuseiCount = 247;

		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>000h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x000 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x000 ); }
		}

		/// <summary>004h 15バイト 成長型名(シフトJIS Nullターミネイト)</summary>
		public String Name
		{
			get { return HelperClass.MyTextConverter.BytesToString( this._rec, 0x004, 15 ); }
			set { HelperClass.MyTextConverter.StringToBytes( value, 15 ).CopyTo( this._rec, 0x004 ); }
		}

		/// <summary>013~109h 247バイト 各特性の習得条件ID</summary>
		public SByte[] TokuseiSyuutokuJoukenIDList
		{
			get
			{
				// 配列の要素にアクセスするたびに get される
				// 要素を変更する場合は、別途配列の参照またはコピーに対して変更し配列自体を set する
				var array = new sbyte[_tokuseiCount];
				for ( var i = 0; i < array.Length; i++ )
				{
					array[i] = (sbyte)this._rec[0x013 + i];
				}
				return array;
			}
			set
			{
				if ( value.Length != this.TokuseiSyuutokuJoukenIDList.Length ) { return; }
				for ( var i = 0; i < value.Length; i++ )
				{
					this._rec[0x013 + i] = (byte)value[i];
				}
			}
		}

		/// <summary>10Ah 2バイト ソート用？の数値が入っている</summary>
		public UInt16 SortID
		{
			get { return BitConverter.ToUInt16( this._rec, 0x10A ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x10A ); }
		}

		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
