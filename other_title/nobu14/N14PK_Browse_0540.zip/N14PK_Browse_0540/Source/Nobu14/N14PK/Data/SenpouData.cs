﻿// SenpouData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>戦法データ</summary>
	/// <remarks>90hからの4バイトはビットフラグになっていて効果データに対応している</remarks>
	public class SenpouData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>00h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00 ); }
		}

		/// <summary>04~0Eh 11 バイト 戦法名(シフトJIS nullターミネイト)</summary>
		public String Name
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x04, 11 ); }
			set { MyTextConverter.StringToBytes( value, 11 ).CopyTo( this._rec, 0x04 ); }
		}

		/// <summary>0F~25h 23 バイト 戦法名読み(シフトJIS nullターミネイト)</summary>
		public String Yomi
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x0F, 23 ); }
			set { MyTextConverter.StringToBytes( value, 23 ).CopyTo( this._rec, 0x0F ); }
		}

		/// <summary>26~46h 33 バイト ヘルプ(シフトJIS nullターミネイト)</summary>
		public String HelpText
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x26, 33 ); }
			set { MyTextConverter.StringToBytes( value, 33 ).CopyTo( this._rec, 0x26 ); }
		}

		/// <summary>47h 1バイト</summary>
		public SByte h47
		{
			get { return (sbyte)this._rec[0x47]; }
			set { this._rec[0x47] = (byte)value; }
		}

		/// <summary>48h 1バイト 系統ID
		/// <para>-1:不使用？、0:強化、1:回復、2:妨害、3:特性、4:突撃、5:斉射</para></summary>
		public SByte KeitouID
		{
			get { return (sbyte)this._rec[0x48]; }
			set { this._rec[0x48] = (byte)value; }
		}

		/// <summary>49h 1バイト</summary>
		public SByte h49
		{
			get { return (sbyte)this._rec[0x49]; }
			set { this._rec[0x49] = (byte)value; }
		}

		/// <summary>4Ah 1バイト 効果範囲？ 円の中心位置？ 15以上フリーズ、強化系は12、妨害系は13で全範囲</summary>
		public SByte koukaHanni
		{
			get { return (sbyte)this._rec[0x4A]; }
			set { this._rec[0x4A] = (byte)value; }
		}

		/// <summary>4Bh 1バイト 効果数？</summary>
		public SByte Koukasuu
		{
			get { return (sbyte)this._rec[0x4B]; }
			set { this._rec[0x4B] = (byte)value; }
		}

		/// <summary>4Ch 2バイト 采配値、または特性ID</summary>
		public Int16 SaihaiOrTokuseiID	// 4Ch 2バイト 采配/特性ID
		{
			get { return BitConverter.ToInt16( this._rec, 0x4C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x4C ); }
		}

		/// <summary>4Eh 2バイト</summary>
		public Int16 h4E_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x4E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x4E ); }
		}

		// 50hからの64バイト(1データ2バイト * 1効果4データ * 8効果) 効果に関する詳細データ

		/// <summary>50h 2バイト 効果1 ID</summary>
		public Int16 Kouka1ID
		{
			get { return BitConverter.ToInt16( this._rec, 0x50 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x50 ); }
		}

		/// <summary>52h 2バイト 効果1 値1 効果時間</summary>
		public Int16 Kouka1Value1
		{
			get { return BitConverter.ToInt16( this._rec, 0x52 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x52 ); }
		}

		/// <summary>54h 2バイト 効果1 値2 対象？ 0自分 1自中心範囲 2敵</summary>
		public Int16 Kouka1Value2
		{
			get { return BitConverter.ToInt16( this._rec, 0x54 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x54 ); }
		}

		/// <summary>56h 2バイト 効果1 値3 増減量(%) 最大250(効果値？)</summary>
		public Int16 Kouka1Value3
		{
			get { return BitConverter.ToInt16( this._rec, 0x56 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x56 ); }
		}


		/// <summary>58h 2バイト 効果2 ID</summary>
		public Int16 Kouka2ID
		{
			get { return BitConverter.ToInt16( this._rec, 0x58 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x58 ); }
		}

		/// <summary>5Ah 2バイト 効果2 値1</summary>
		public Int16 Kouka2Value1
		{
			get { return BitConverter.ToInt16( this._rec, 0x5A ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x5A ); }
		}

		/// <summary>5Ch 2バイト 効果2 値2</summary>
		public Int16 Kouka2Value2
		{
			get { return BitConverter.ToInt16( this._rec, 0x5C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x5C ); }
		}

		/// <summary>5Eh 2バイト 効果2 値3</summary>
		public Int16 Kouka2Value3
		{
			get { return BitConverter.ToInt16( this._rec, 0x5E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x5E ); }
		}


		/// <summary>60h 2バイト 効果3 ID</summary>
		public Int16 Kouka3ID
		{
			get { return BitConverter.ToInt16( this._rec, 0x60 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x60 ); }
		}

		/// <summary>62h 2バイト 効果3 値1</summary>
		public Int16 Kouka3Value1
		{
			get { return BitConverter.ToInt16( this._rec, 0x62 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x62 ); }
		}

		/// <summary>64h 2バイト 効果3 値2</summary>
		public Int16 Kouka3Value2
		{
			get { return BitConverter.ToInt16( this._rec, 0x64 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x64 ); }
		}

		/// <summary>66h 2バイト 効果3 値3</summary>
		public Int16 Kouka3Value3
		{
			get { return BitConverter.ToInt16( this._rec, 0x66 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x66 ); }
		}


		/// <summary>68h 2バイト 効果4 ID</summary>
		public Int16 Kouka4ID
		{
			get { return BitConverter.ToInt16( this._rec, 0x68 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x68 ); }
		}

		/// <summary>6Ah 2バイト 効果4 値1</summary>
		public Int16 Kouka4Value1
		{
			get { return BitConverter.ToInt16( this._rec, 0x6A ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x6A ); }
		}

		/// <summary>6Ch 2バイト 効果4 値2</summary>
		public Int16 Kouka4Value2
		{
			get { return BitConverter.ToInt16( this._rec, 0x6C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x6C ); }
		}

		/// <summary>6Eh 2バイト 効果4 値3</summary>
		public Int16 Kouka4Value3
		{
			get { return BitConverter.ToInt16( this._rec, 0x6E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x6E ); }
		}


		/// <summary>70h 2バイト 効果5 ID</summary>
		public Int16 Kouka5ID
		{
			get { return BitConverter.ToInt16( this._rec, 0x70 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x70 ); }
		}

		/// <summary>72h 2バイト 効果5 値1</summary>
		public Int16 Kouka5Value1
		{
			get { return BitConverter.ToInt16( this._rec, 0x72 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x72 ); }
		}

		/// <summary>74h 2バイト 効果5 値2</summary>
		public Int16 Kouka5Value2
		{
			get { return BitConverter.ToInt16( this._rec, 0x74 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x74 ); }
		}

		/// <summary>76h 2バイト 効果5 値3</summary>
		public Int16 Kouka5Value3
		{
			get { return BitConverter.ToInt16( this._rec, 0x76 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x76 ); }
		}


		/// <summary>78h 2バイト 効果6 ID</summary>
		public Int16 Kouka6ID
		{
			get { return BitConverter.ToInt16( this._rec, 0x78 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x78 ); }
		}

		/// <summary>7Ah 2バイト 効果6 値1</summary>
		public Int16 Kouka6Value1
		{
			get { return BitConverter.ToInt16( this._rec, 0x7A ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x7A ); }
		}

		/// <summary>7Ch 2バイト 効果6 値2</summary>
		public Int16 Kouka6Value2
		{
			get { return BitConverter.ToInt16( this._rec, 0x7C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x7C ); }
		}

		/// <summary>7Eh 2バイト 効果6 値3</summary>
		public Int16 Kouka6Value3
		{
			get { return BitConverter.ToInt16( this._rec, 0x7E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x7E ); }
		}


		/// <summary>80h 2バイト 効果7 ID</summary>
		public Int16 Kouka7ID
		{
			get { return BitConverter.ToInt16( this._rec, 0x80 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x80 ); }
		}

		/// <summary>82h 2バイト 効果7 値1</summary>
		public Int16 Kouka7Value1
		{
			get { return BitConverter.ToInt16( this._rec, 0x82 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x82 ); }
		}

		/// <summary>84h 2バイト 効果7 値2</summary>
		public Int16 Kouka7Value2
		{
			get { return BitConverter.ToInt16( this._rec, 0x84 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x84 ); }
		}

		/// <summary>86h 2バイト 効果7 値3</summary>
		public Int16 Kouka7Value3
		{
			get { return BitConverter.ToInt16( this._rec, 0x86 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x86 ); }
		}


		/// <summary>88h 2バイト 効果8 ID</summary>
		public Int16 Kouka8ID
		{
			get { return BitConverter.ToInt16( this._rec, 0x88 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x88 ); }
		}

		/// <summary>8Ah 2バイト 効果8 値1</summary>
		public Int16 Kouka8Value1
		{
			get { return BitConverter.ToInt16( this._rec, 0x8A ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x8A ); }
		}

		/// <summary>8Ch 2バイト 効果8 値2</summary>
		public Int16 Kouka8Value2
		{
			get { return BitConverter.ToInt16( this._rec, 0x8C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x8C ); }
		}

		/// <summary>8Eh 2バイト 効果8 値3</summary>
		public Int16 Kouka8Value3
		{
			get { return BitConverter.ToInt16( this._rec, 0x8E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x8E ); }
		}

		// 90hからの4バイトはビットフラグになっていて効果データに対応している

		/// <summary>90h bit00</summary>
		public Boolean Kouka01
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 0 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 0 ); }
		}

		/// <summary>90h bit01</summary>
		public Boolean Kouka02
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 1 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 1 ); }
		}

		/// <summary>90h bit02</summary>
		public Boolean Kouka03
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 2 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 2 ); }
		}

		/// <summary>90h bit03</summary>
		public Boolean Kouka04
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 3 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 3 ); }
		}

		/// <summary>90h bit04</summary>
		public Boolean Kouka05
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 4 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 4 ); }
		}

		/// <summary>90h bit05</summary>
		public Boolean Kouka06
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 5 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 5 ); }
		}

		/// <summary>90h bit06</summary>
		public Boolean Kouka07
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 6 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 6 ); }
		}

		/// <summary>90h bit07</summary>
		public Boolean Kouka08
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 7 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 7 ); }
		}

		/// <summary>90h bit08</summary>
		public Boolean Kouka09
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 8 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 8 ); }
		}

		/// <summary>90h bit09</summary>
		public Boolean Kouka10
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 9 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 9 ); }
		}

		/// <summary>90h bit10</summary>
		public Boolean Kouka11
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 10 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 10 ); }
		}

		/// <summary>90h bit11</summary>
		public Boolean Kouka12
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 11 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 11 ); }
		}

		/// <summary>90h bit12</summary>
		public Boolean Kouka13
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 12 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 12 ); }
		}

		/// <summary>90h bit13</summary>
		public Boolean Kouka14
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 13 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 13 ); }
		}

		/// <summary>90h bit14</summary>
		public Boolean Kouka15
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 14 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 14 ); }
		}

		/// <summary>90h bit15</summary>
		public Boolean Kouka16
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 15 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 15 ); }
		}

		/// <summary>90h bit16</summary>
		public Boolean Kouka17
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 16 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 16 ); }
		}

		/// <summary>90h bit17</summary>
		public Boolean Kouka18
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 17 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 17 ); }
		}

		/// <summary>90h bit18</summary>
		public Boolean Kouka19
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 18 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 18 ); }
		}

		/// <summary>90h bit19</summary>
		public Boolean Kouka20
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 19 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 19 ); }
		}

		/// <summary>90h bit20</summary>
		public Boolean Kouka21
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 20 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 20 ); }
		}

		/// <summary>90h bit21</summary>
		public Boolean Kouka22
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 21 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 21 ); }
		}

		/// <summary>90h bit22</summary>
		public Boolean Kouka23
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 22 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 22 ); }
		}

		/// <summary>90h bit23</summary>
		public Boolean Kouka24
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 23 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 23 ); }
		}

		/// <summary>90h bit24</summary>
		public Boolean Kouka25
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 24 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 24 ); }
		}

		/// <summary>90h bit25</summary>
		public Boolean Kouka26
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 25 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 25 ); }
		}

		/// <summary>90h bit26</summary>
		public Boolean Kouka27
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 26 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 26 ); }
		}

		/// <summary>90h bit27</summary>
		public Boolean Kouka28
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 27 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 27 ); }
		}

		/// <summary>90h bit28</summary>
		public Boolean Kouka29
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 28 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 28 ); }
		}

		/// <summary>90h bit29</summary>
		public Boolean Kouka30
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 29 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 29 ); }
		}

		/// <summary>90h bit30</summary>
		public Boolean Kouka31
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 30 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 30 ); }
		}

		/// <summary>90h bit31</summary>
		public Boolean Kouka32
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x90, 31 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x90, 31 ); }
		}


		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
