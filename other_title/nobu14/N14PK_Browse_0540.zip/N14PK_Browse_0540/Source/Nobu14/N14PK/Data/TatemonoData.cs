﻿// TatemonoData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>建物データ</summary>
	public class TatemonoData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>00h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00 ); }
		}

		/// <summary>04h 4バイト 施設ポインタ</summary>
		public UInt32 PtrShisetsu
		{
			get { return BitConverter.ToUInt32( this._rec, 0x04 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x04 ); }
		}

		/// <summary>08h 4バイト 何かのX位置</summary>
		public UInt32 PosX1
		{
			get { return BitConverter.ToUInt32( this._rec, 0x08 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x08 ); }
		}

		/// <summary>0Ch 4バイト 何かのY位置</summary>
		public UInt32 PosY1
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0C ); }
		}

		/// <summary>10h 2バイト キャプション？のX位置</summary>
		public UInt16 PosX2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x10 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x10 ); }
		}

		/// <summary>12h 2バイト キャプション？のY位置</summary>
		public UInt16 PosY2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x12 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x12 ); }
		}

		/// <summary>14h 4バイト 0固定？</summary>
		public UInt32 h14_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x14 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x14 ); }
		}

		/// <summary>18h 4バイト 国ポインタ 支城建設後に確認すると値が入ってない場合がある</summary>
		public UInt32 PtrKuni
		{
			get { return BitConverter.ToUInt32( this._rec, 0x18 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x18 ); }
		}

		/// <summary>1Ch 2バイト 現在耐久</summary>
		public Int16 TaikyuuNow
		{
			get { return BitConverter.ToInt16( this._rec, 0x1C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1C ); }
		}

		/// <summary>1Eh 2バイト 0固定？</summary>
		public UInt16 h1E_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x1E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1E ); }
		}

		/// <summary>20h 1バイト 0x01 / 0x02 / 0xFF</summary>
		public SByte h20
		{
			get { return (sbyte)this._rec[0x20]; }
			set { this._rec[0x20] = (byte)value; }
		}

		/// <summary>21h 1バイト</summary>
		public Byte h21
		{
			get { return this._rec[0x21]; }
			set { this._rec[0x21] = (byte)value; }
		}

		/// <summary>22h 1バイト 0固定？</summary>
		public Byte h22
		{
			get { return this._rec[0x22]; }
			set { this._rec[0x22] = (byte)value; }
		}

		/// <summary>23h 1バイト 0固定？</summary>
		public Byte h23
		{
			get { return this._rec[0x23]; }
			set { this._rec[0x23] = (byte)value; }
		}

		/// <summary>24h 4バイト 拠点タイプID(0:なし、1:城、3:国人衆)</summary>
		public Int32 KyotenTypeID
		{
			get { return BitConverter.ToInt32( this._rec, 0x24 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x24 ); }
		}

		/// <summary>28h 4バイト 拠点ポインタ 拠点タイプIDにより参照するデータが異なる(城 / 国人衆)</summary>
		public UInt32 PtrKyoten
		{
			get { return BitConverter.ToUInt32( this._rec, 0x28 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1E ); }
		}

		/// <summary>2Ch 2バイト 0固定？</summary>
		public Int16 h2C_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x2C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2C ); }
		}

		/// <summary>2Eh 2バイト 何かのID(重複あり)か？</summary>
		public Int16 h2E_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x2E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2E ); }
		}


		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
