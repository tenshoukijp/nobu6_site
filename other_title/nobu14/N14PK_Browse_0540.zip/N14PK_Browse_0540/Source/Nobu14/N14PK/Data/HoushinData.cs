﻿// HoushinData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>方針データ</summary>
	public class HoushinData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }

		/// <summary>00h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00 ); }
		}

		/// <summary>04~10h 13バイト 名称(シフトJIS nullターミネイト)</summary>
		public String Name
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x04, 13 ); }
			set { MyTextConverter.StringToBytes( value, 13 ).CopyTo( this._rec, 0x04 ); }
		}

		/// <summary>11h 1バイト</summary>
		public Byte h11
		{
			get { return this._rec[0x11]; }
			set { this._rec[0x11] = (byte)value; }
		}

		/// <summary>12h 1バイト</summary>
		public Byte h12
		{
			get { return this._rec[0x12]; }
			set { this._rec[0x12] = (byte)value; }
		}

		/// <summary>13h 1バイト</summary>
		public Byte h13
		{
			get { return this._rec[0x13]; }
			set { this._rec[0x13] = (byte)value; }
		}

		/// <summary>14h 1バイト</summary>
		public Byte h14
		{
			get { return this._rec[0x14]; }
			set { this._rec[0x14] = (byte)value; }
		}

		/// <summary>15h 1バイト</summary>
		public Byte h15
		{
			get { return this._rec[0x15]; }
			set { this._rec[0x15] = (byte)value; }
		}

		/// <summary>16h 1バイト</summary>
		public Byte h16
		{
			get { return this._rec[0x16]; }
			set { this._rec[0x16] = (byte)value; }
		}

		/// <summary>17h 1バイト</summary>
		public Byte h17
		{
			get { return this._rec[0x17]; }
			set { this._rec[0x17] = (byte)value; }
		}

		/// <summary>18h 1バイト</summary>
		public Byte h18
		{
			get { return this._rec[0x18]; }
			set { this._rec[0x18] = (byte)value; }
		}

		/// <summary>19h 1バイト</summary>
		public Byte h19
		{
			get { return this._rec[0x19]; }
			set { this._rec[0x19] = (byte)value; }
		}

		/// <summary>1Ah 1バイト</summary>
		public Byte h1A
		{
			get { return this._rec[0x1A]; }
			set { this._rec[0x1A] = (byte)value; }
		}

		/// <summary>1Bh 1バイト</summary>
		public Byte h1B
		{
			get { return this._rec[0x1B]; }
			set { this._rec[0x1B] = (byte)value; }
		}

		/// <summary>1Ch 1バイト</summary>
		public Byte h1C
		{
			get { return this._rec[0x1C]; }
			set { this._rec[0x1C] = (byte)value; }
		}

		/// <summary>1Dh 1バイト</summary>
		public Byte h1D
		{
			get { return this._rec[0x1D]; }
			set { this._rec[0x1D] = (byte)value; }
		}

		/// <summary>1Eh 1バイト</summary>
		public Byte h1E
		{
			get { return this._rec[0x1E]; }
			set { this._rec[0x1E] = (byte)value; }
		}

		/// <summary>1Fh 1バイト</summary>
		public Byte h1F
		{
			get { return this._rec[0x1F]; }
			set { this._rec[0x1F] = (byte)value; }
		}

		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
