﻿// SeisakuData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>政策データ</summary>
	public class SeisakuData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }

		/// <summary>00h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x000 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x000 ); }
		}

		/// <summary>004~010h 13バイト 名称(シフトJIS nullターミネイト)</summary>
		public String Name
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x004, 13 ); }
			set { MyTextConverter.StringToBytes( value, 13 ).CopyTo( this._rec, 0x004 ); }
		}

		/// <summary>011~029h 25バイト 読み(シフトJIS nullターミネイト)</summary>
		public String Yomi
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x011, 25 ); }
			set { MyTextConverter.StringToBytes( value, 25 ).CopyTo( this._rec, 0x011 ); }
		}

		/// <summary>02A~04Ch 35バイト 利点1(シフトJIS nullターミネイト)</summary>
		public String Riten1
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x02A, 35 ); }
			set { MyTextConverter.StringToBytes( value, 35 ).CopyTo( this._rec, 0x02A ); }
		}

		/// <summary>04D~092h 70バイト 利点2(シフトJIS nullターミネイト)</summary>
		public String Riten2
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x04D, 70 ); }
			set { MyTextConverter.StringToBytes( value, 70 ).CopyTo( this._rec, 0x04D ); }
		}

		/// <summary>093~0B5h 35バイト 欠点1(シフトJIS nullターミネイト)</summary>
		public String Ketten1
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x093, 35 ); }
			set { MyTextConverter.StringToBytes( value, 35 ).CopyTo( this._rec, 0x093 ); }
		}

		/// <summary>0B6~0FBh 70バイト 欠点2(シフトJIS nullターミネイト)</summary>
		public String Ketten2
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x0B6, 70 ); }
			set { MyTextConverter.StringToBytes( value, 70 ).CopyTo( this._rec, 0x0B6 ); }
		}

		/// <summary>0FCh 2バイト 費用</summary>
		public UInt16 Hiyou
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0FC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0FC ); }
		}

		/// <summary>0FEh 2バイト 実施可能創造性下限</summary>
		public Int16 Souzouseilowerlimit
		{
			get { return BitConverter.ToInt16( this._rec, 0x0FE ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0FE ); }
		}

		/// <summary>100h 2バイト 実施可能創造性上限</summary>
		public Int16 SouzouseiUpperlimit
		{
			get { return BitConverter.ToInt16( this._rec, 0x100 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x100 ); }
		}

		/// <summary>102h 2バイト</summary>
		public Int16 h102_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x102 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x102 ); }
		}

		/// <summary>104h 4バイト 前提政策ポインタ</summary>
		public UInt32 PtrZenteiSeisaku
		{
			get { return BitConverter.ToUInt32( this._rec, 0x104 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x104 ); }
		}

		/// <summary>108h 4バイト</summary>
		public Int32 h108_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x108 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x108 ); }
		}

		/// <summary>10Ch 4バイト 専用血族ID</summary>
		public Int32 SenyouKetsuzokuID
		{
			get { return BitConverter.ToInt32( this._rec, 0x10C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x10C ); }
		}

		/// <summary>110h 1バイト 政策タイプ
		/// <para>0:惣無事令、1:専用、2:創造、3:中道、4:保守、5:なし</para></summary>
		public SByte SeisakuTypeID
		{
			get { return (sbyte)this._rec[0x110]; }
			set { this._rec[0x110] = (byte)value; }
		}

		/// <summary>111h 1バイト 石高</summary>
		public SByte h111
		{
			get { return (sbyte)this._rec[0x111]; }
			set { this._rec[0x111] = (byte)value; }
		}

		/// <summary>112h 1バイト 商業</summary>
		public SByte h112
		{
			get { return (sbyte)this._rec[0x112]; }
			set { this._rec[0x112] = (byte)value; }
		}

		/// <summary>113h 1バイト 兵舎</summary>
		public SByte h113
		{
			get { return (sbyte)this._rec[0x113]; }
			set { this._rec[0x113] = (byte)value; }
		}

		/// <summary>114h 1バイト 収穫</summary>
		public SByte h114
		{
			get { return (sbyte)this._rec[0x114]; }
			set { this._rec[0x114] = (byte)value; }
		}

		/// <summary>115h 1バイト 収入</summary>
		public SByte h115
		{
			get { return (sbyte)this._rec[0x115]; }
			set { this._rec[0x115] = (byte)value; }
		}

		/// <summary>116h 1バイト 国人兵</summary>
		public SByte h116
		{
			get { return (sbyte)this._rec[0x116]; }
			set { this._rec[0x116] = (byte)value; }
		}

		/// <summary>117h 1バイト 0固定？</summary>
		public SByte h117
		{
			get { return (sbyte)this._rec[0x117]; }
			set { this._rec[0x117] = (byte)value; }
		}

		/// <summary>118h 1バイト 懐柔</summary>
		public SByte h118
		{
			get { return (sbyte)this._rec[0x118]; }
			set { this._rec[0x118] = (byte)value; }
		}

		/// <summary>119h 1バイト 敵城包囲時の士気ゲージ減少</summary>
		public SByte h119
		{
			get { return (sbyte)this._rec[0x119]; }
			set { this._rec[0x119] = (byte)value; }
		}

		/// <summary>11Ah 1バイト 0固定？</summary>
		public SByte h11A
		{
			get { return (sbyte)this._rec[0x11A]; }
			set { this._rec[0x11A] = (byte)value; }
		}

		/// <summary>11Bh 1バイト 人口</summary>
		public SByte h11B
		{
			get { return (sbyte)this._rec[0x11B]; }
			set { this._rec[0x11B] = (byte)value; }
		}

		/// <summary>11Ch 1バイト 最大領民兵(*10%)</summary>
		public SByte h11C
		{
			get { return (sbyte)this._rec[0x11C]; }
			set { this._rec[0x11C] = (byte)value; }
		}

		/// <summary>11Dh 1バイト 本城最大常備兵(*10%)</summary>
		public SByte h11D
		{
			get { return (sbyte)this._rec[0x11D]; }
			set { this._rec[0x11D] = (byte)value; }
		}

		/// <summary>11Eh 1バイト 最大民忠</summary>
		public SByte h11E
		{
			get { return (sbyte)this._rec[0x11E]; }
			set { this._rec[0x11E] = (byte)value; }
		}

		/// <summary>11Fh 1バイト 兵舎の石高制限解除(兵農分離)</summary>
		public SByte h11F
		{
			get { return (sbyte)this._rec[0x11F]; }
			set { this._rec[0x11F] = (byte)value; }
		}

		/// <summary>120h 1バイト 0固定？</summary>
		public SByte h120
		{
			get { return (sbyte)this._rec[0x120]; }
			set { this._rec[0x120] = (byte)value; }
		}

		/// <summary>121h 1バイト 取引価格(%)</summary>
		public SByte h121
		{
			get { return (sbyte)this._rec[0x121]; }
			set { this._rec[0x121] = (byte)value; }
		}

		/// <summary>122h 1バイト 商人(堺)</summary>
		public SByte h122
		{
			get { return (sbyte)this._rec[0x122]; }
			set { this._rec[0x122] = (byte)value; }
		}

		/// <summary>123h 1バイト 商人(南蛮)</summary>
		public SByte h123
		{
			get { return (sbyte)this._rec[0x123]; }
			set { this._rec[0x123] = (byte)value; }
		}

		/// <summary>124h 1バイト 一揆発生率</summary>
		public SByte h124
		{
			get { return (sbyte)this._rec[0x124]; }
			set { this._rec[0x124] = (byte)value; }
		}

		/// <summary>125h 1バイト 港収入</summary>
		public SByte h125
		{
			get { return (sbyte)this._rec[0x125]; }
			set { this._rec[0x125] = (byte)value; }
		}

		/// <summary>126h 1バイト 0固定？</summary>
		public SByte h126
		{
			get { return (sbyte)this._rec[0x126]; }
			set { this._rec[0x126] = (byte)value; }
		}

		/// <summary>127h 1バイト 0固定？</summary>
		public SByte h127
		{
			get { return (sbyte)this._rec[0x127]; }
			set { this._rec[0x127] = (byte)value; }
		}

		/// <summary>128h 1バイト 忠誠補正(能力主義)</summary>
		public SByte h128
		{
			get { return (sbyte)this._rec[0x128]; }
			set { this._rec[0x128] = (byte)value; }
		}

		/// <summary>129h 1バイト 忠誠補正(指出検地)</summary>
		public SByte h129
		{
			get { return (sbyte)this._rec[0x129]; }
			set { this._rec[0x129] = (byte)value; }
		}

		/// <summary>12Ah 1バイト 忠誠補正(所領安堵)</summary>
		public SByte h12A
		{
			get { return (sbyte)this._rec[0x12A]; }
			set { this._rec[0x12A] = (byte)value; }
		}

		/// <summary>12Bh 1バイト 0固定？</summary>
		public SByte h12B
		{
			get { return (sbyte)this._rec[0x12B]; }
			set { this._rec[0x12B] = (byte)value; }
		}

		/// <summary>12Ch 1バイト 外交収入(%)</summary>
		public SByte h12C
		{
			get { return (sbyte)this._rec[0x12C]; }
			set { this._rec[0x12C] = (byte)value; }
		}

		/// <summary>12Dh 1バイト 0固定？</summary>
		public SByte h12D
		{
			get { return (sbyte)this._rec[0x12D]; }
			set { this._rec[0x12D] = (byte)value; }
		}

		/// <summary>12Eh 1バイト 0xFF固定？</summary>
		public SByte h12E
		{
			get { return (sbyte)this._rec[0x12E]; }
			set { this._rec[0x12E] = (byte)value; }
		}

		/// <summary>12Fh 1バイト 0xFF固定？</summary>
		public SByte h12F
		{
			get { return (sbyte)this._rec[0x12F]; }
			set { this._rec[0x12F] = (byte)value; }
		}

		/// <summary>130h 1バイト 0固定？</summary>
		public SByte h130
		{
			get { return (sbyte)this._rec[0x130]; }
			set { this._rec[0x130] = (byte)value; }
		}

		/// <summary>131h 1バイト 外交制限解除(遠交近攻策)</summary>
		public SByte h131
		{
			get { return (sbyte)this._rec[0x131]; }
			set { this._rec[0x131] = (byte)value; }
		}

		/// <summary>132h 1バイト 近工作効果</summary>
		public SByte h132
		{
			get { return (sbyte)this._rec[0x132]; }
			set { this._rec[0x132] = (byte)value; }
		}

		/// <summary>133h 1バイト 遠工作効果</summary>
		public SByte h133
		{
			get { return (sbyte)this._rec[0x133]; }
			set { this._rec[0x133] = (byte)value; }
		}

		/// <summary>134h 1バイト 0固定？</summary>
		public SByte h134
		{
			get { return (sbyte)this._rec[0x134]; }
			set { this._rec[0x134] = (byte)value; }
		}

		/// <summary>135h 1バイト 惣無事令</summary>
		public SByte h135
		{
			get { return (sbyte)this._rec[0x135]; }
			set { this._rec[0x135] = (byte)value; }
		}

		/// <summary>136h 1バイト 軍馬鉄砲配備攻撃増</summary>
		public SByte h136
		{
			get { return (sbyte)this._rec[0x136]; }
			set { this._rec[0x136] = (byte)value; }
		}

		/// <summary>137h 1バイト 軍馬鉄砲未配備攻撃減</summary>
		public SByte h137
		{
			get { return (sbyte)this._rec[0x137]; }
			set { this._rec[0x137] = (byte)value; }
		}

		/// <summary>138h 1バイト 軍馬配備攻撃増</summary>
		public SByte h138
		{
			get { return (sbyte)this._rec[0x138]; }
			set { this._rec[0x138] = (byte)value; }
		}

		/// <summary>139h 1バイト 軍馬未配備攻撃減</summary>
		public SByte h139
		{
			get { return (sbyte)this._rec[0x139]; }
			set { this._rec[0x139] = (byte)value; }
		}

		/// <summary>13Ah 1バイト 鉄砲配備攻撃増</summary>
		public SByte h13A
		{
			get { return (sbyte)this._rec[0x13A]; }
			set { this._rec[0x13A] = (byte)value; }
		}

		/// <summary>13Bh 1バイト 鉄砲未配備攻撃減</summary>
		public SByte h13B
		{
			get { return (sbyte)this._rec[0x13B]; }
			set { this._rec[0x13B] = (byte)value; }
		}

		/// <summary>13Ch 1バイト 0固定？</summary>
		public SByte h13C
		{
			get { return (sbyte)this._rec[0x13C]; }
			set { this._rec[0x13C] = (byte)value; }
		}

		/// <summary>13Dh 1バイト 0固定？</summary>
		public SByte h13D
		{
			get { return (sbyte)this._rec[0x13D]; }
			set { this._rec[0x13D] = (byte)value; }
		}

		/// <summary>13Eh 1バイト 支城最大常備兵(*10%)</summary>
		public SByte h13E
		{
			get { return (sbyte)this._rec[0x13E]; }
			set { this._rec[0x13E] = (byte)value; }
		}

		/// <summary>13Fh 1バイト 忠誠補正(創造)</summary>
		public SByte h13F
		{
			get { return (sbyte)this._rec[0x13F]; }
			set { this._rec[0x13F] = (byte)value; }
		}

		/// <summary>140h 1バイト 忠誠補正(中道)</summary>
		public SByte h140
		{
			get { return (sbyte)this._rec[0x140]; }
			set { this._rec[0x140] = (byte)value; }
		}

		/// <summary>141h 1バイト 忠誠補正(保守)</summary>
		public SByte h141
		{
			get { return (sbyte)this._rec[0x141]; }
			set { this._rec[0x141] = (byte)value; }
		}

		/// <summary>142h 1バイト 陣効果</summary>
		public SByte h142
		{
			get { return (sbyte)this._rec[0x142]; }
			set { this._rec[0x142] = (byte)value; }
		}

		/// <summary>143h 1バイト 経験補正</summary>
		public SByte h143
		{
			get { return (sbyte)this._rec[0x143]; }
			set { this._rec[0x143] = (byte)value; }
		}

		/// <summary>144h 1バイト 兵糧補給効率</summary>
		public SByte h144
		{
			get { return (sbyte)this._rec[0x144]; }
			set { this._rec[0x144] = (byte)value; }
		}

		/// <summary>145h 1バイト 疲労補正(%)</summary>
		public SByte h145
		{
			get { return (sbyte)this._rec[0x145]; }
			set { this._rec[0x145] = (byte)value; }
		}

		/// <summary>146h 1バイト</summary>
		public SByte h146
		{
			get { return (sbyte)this._rec[0x146]; }
			set { this._rec[0x146] = (byte)value; }
		}

		/// <summary>147h 1バイト</summary>
		public SByte h147
		{
			get { return (sbyte)this._rec[0x147]; }
			set { this._rec[0x147] = (byte)value; }
		}

		/// <summary>148h 1バイト 行軍影響</summary>
		public SByte h148
		{
			get { return (sbyte)this._rec[0x148]; }
			set { this._rec[0x148] = (byte)value; }
		}

		/// <summary>149h 1バイト 朝廷工作上昇量</summary>
		public SByte h149
		{
			get { return (sbyte)this._rec[0x149]; }
			set { this._rec[0x149] = (byte)value; }
		}

		/// <summary>14Ah 1バイト 密談効果上昇量1</summary>
		public SByte h14A
		{
			get { return (sbyte)this._rec[0x14A]; }
			set { this._rec[0x14A] = (byte)value; }
		}

		/// <summary>14Bh 1バイト 軍団長の軍略効果上昇量</summary>
		public SByte h14B
		{
			get { return (sbyte)this._rec[0x14B]; }
			set { this._rec[0x14B] = (byte)value; }
		}

		/// <summary>14Ch 1バイト 直轄軍団の統治範囲</summary>
		public SByte h14C
		{
			get { return (sbyte)this._rec[0x14C]; }
			set { this._rec[0x14C] = (byte)value; }
		}

		/// <summary>14Dh 1バイト 捕縛登用率</summary>
		public SByte h14D
		{
			get { return (sbyte)this._rec[0x14D]; }
			set { this._rec[0x14D] = (byte)value; }
		}

		/// <summary>14Eh 1バイト 0固定？</summary>
		public SByte h14E
		{
			get { return (sbyte)this._rec[0x14E]; }
			set { this._rec[0x14E] = (byte)value; }
		}

		/// <summary>14Fh 1バイト 0固定？</summary>
		public SByte h14F
		{
			get { return (sbyte)this._rec[0x14F]; }
			set { this._rec[0x14F] = (byte)value; }
		}

		/// <summary>150h 1バイト</summary>
		public SByte h150
		{
			get { return (sbyte)this._rec[0x150]; }
			set { this._rec[0x150] = (byte)value; }
		}

		/// <summary>151h 1バイト</summary>
		public SByte h151
		{
			get { return (sbyte)this._rec[0x151]; }
			set { this._rec[0x151] = (byte)value; }
		}

		/// <summary>152h 1バイト</summary>
		public SByte h152
		{
			get { return (sbyte)this._rec[0x152]; }
			set { this._rec[0x152] = (byte)value; }
		}

		/// <summary>153h 1バイト 0固定？</summary>
		public SByte h153
		{
			get { return (sbyte)this._rec[0x153]; }
			set { this._rec[0x153] = (byte)value; }
		}


		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
