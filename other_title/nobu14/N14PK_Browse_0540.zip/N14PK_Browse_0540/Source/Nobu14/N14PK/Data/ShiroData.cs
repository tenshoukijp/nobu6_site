﻿// ShiroData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>城データ</summary>
	/// <remarks><para>014C~214Bh (Magic 4バイト + データ 12バイト) 計10h(16) が 512 繰り返し 詳細不明</para>
	/// <para>2E46~2E7Bh 35h(53)バイト 詳細不明</para>
	/// <para>上記箇所はプロパティ化していない</para></remarks>
	public class ShiroData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>区画データオフセット</summary>
		private const Int32 _OffsetKukakuData = 0x214C;

		/// <summary>区画データサイズ</summary>
		private const Int32 _SizeOfKukakuData = 0x14C;

		/// <summary>区画データ数</summary>
		private const Int32 _KukakuCount = 10;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>0000h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0000 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0000 ); }
		}

		/// <summary>0004h 4バイト 0固定？</summary>
		public UInt32 h0004_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0004 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0004 ); }
		}

		/// <summary>0008h 4バイト 0固定？</summary>
		public UInt32 h0008_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0008 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0008 ); }
		}

		/// <summary>000Ch 4バイト 0固定？</summary>
		public UInt32 h000C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x000C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x000C ); }
		}

		/// <summary>0010h 4バイト 0固定？</summary>
		public UInt32 h0010_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0010 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0010 ); }
		}

		/// <summary>0014h 4バイト 軍団ポインタ</summary>
		public UInt32 PtrGundan
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0014 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0014 ); }
		}

		/// <summary>0018h 4バイト 兵数</summary>
		public UInt32 Heisuu
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0018 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0018 ); }
		}

		/// <summary>001Ch 4バイト 包囲部隊リスト(2ポインタタイプ)</summary>
		public UInt32 PtrHouiButaiList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x001C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x001C ); }
		}

		/// <summary>0020h 4バイト リストカウンタ</summary>
		public Int32 CntHouiButaiList
		{ 
			get { return BitConverter.ToInt32( this._rec, 0x0020 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0020 ); }
		}

		/// <summary>0024h 4バイト 0固定？</summary>
		public UInt32 h0024_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0024 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0024 ); }
		}

		/// <summary>0028h 4バイト 0固定？</summary>
		public UInt32 h0028_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0028 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0028 ); }
		}

		/// <summary>002Ch 4バイト</summary>
		public UInt32 h002C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x002C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x002C ); }
		}

		/// <summary>0030h 4バイト リスト(2ポインタタイプ)</summary>
		public UInt32 PtrList_0030
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0030 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0030 ); }
		}

		/// <summary>0034h 4バイト リストカウンタ</summary>
		public Int32 CntList_0030
		{
			get { return BitConverter.ToInt32( this._rec, 0x0034 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0034 ); }
		}

		/// <summary>0038h 4バイト 0固定？</summary>
		public UInt32 h0038_4
		{ 
			get { return BitConverter.ToUInt32( this._rec, 0x0038 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0038 ); }
		}

		/// <summary>003Ch 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber2
		{
			get { return BitConverter.ToUInt32( this._rec, 0x003C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x003C ); }
		}

		/// <summary>0040h 4バイト ポインタ 飛んだ先のデータがよくわからない</summary>
		public UInt32 Ptr_0040
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0040 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0040 ); }
		}

		/// <summary>0044h 4バイト ポインタリスト(2ポインタタイプ)</summary>
		public UInt32 PtrList_0044
		{ 
			get { return BitConverter.ToUInt32( this._rec, 0x0044 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0044 ); }
		}

		/// <summary>0048h 4バイト リストカウンタ</summary>
		public Int32 CntList_0044
		{
			get { return BitConverter.ToInt32( this._rec, 0x0048 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0048 ); }
		}

		/// <summary>004Ch 4バイト 0固定？</summary>
		public UInt32 h004C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x004C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x004C ); }
		}

		/// <summary>0050h 4バイト 出陣部隊リスト(2ポインタタイプ)</summary>
		public UInt32 PtrSyutsujinButaiList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0050 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0050 ); }
		}

		/// <summary>0054h 4バイト リストカウンタ</summary>
		public Int32 CntSyutsujinButaiList
		{
			get { return BitConverter.ToInt32( this._rec, 0x0054 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0054 ); }
		}

		/// <summary>0058h 4バイト 0固定？</summary>
		public UInt32 h0058_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0058 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0058 ); }
		}

		/// <summary>005Ch 4バイト ポインタ</summary>
		public UInt32 Ptr_005C
		{
			get { return BitConverter.ToUInt32( this._rec, 0x005C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x005C ); }
		}

		/// <summary>005Ch 4バイト 任務中武将リスト(2ポインタタイプ)</summary>
		public UInt32 PtrNinmuList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x005C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x005C ); }
		}

		/// <summary>0060h 4バイト リストカウンタ</summary>
		public Int32 CntNinmuList
		{
			get { return BitConverter.ToInt32( this._rec, 0x0060 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0060 ); }
		}

		/// <summary>0064h 4バイト 0固定？</summary>
		public UInt32 h0064_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0064 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0064 ); }
		}

		/// <summary>0068h 4バイト ポインタリスト(2ポインタタイプ)</summary>
		public UInt32 PtrList_0068
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0068 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0068 ); }
		}

		/// <summary>006Ch 4バイト リストカウンタ</summary>
		public Int32 CntList_0068
		{
			get { return BitConverter.ToInt32( this._rec, 0x006C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x006C ); }
		}

		/// <summary>0070h 4バイト 0固定？</summary>
		public UInt32 h0070_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0070 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0070 ); }
		}

		/// <summary>0074h 4バイト 行動可能武将リスト(2ポインタタイプ)</summary>
		public UInt32 PtrKoudoukanouList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0074 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0074 ); }
		}

		/// <summary>0078h 4バイト リストカウンタ</summary>
		public Int32 CntKoudoukanouList
		{
			get { return BitConverter.ToInt32( this._rec, 0x0078 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0078 ); }
		}

		/// <summary>007Ch 4バイト 0固定？</summary>
		public UInt32 h007C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x007C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x007C ); }
		}

		/// <summary>0080h 4バイト ポインタリスト(2ポインタタイプ)</summary>
		public UInt32 PtrList_0080
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0080 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0080 ); }
		}

		/// <summary>0084h 4バイト リストカウンタ</summary>
		public Int32 CntList_0080
		{
			get { return BitConverter.ToInt32( this._rec, 0x0084 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0084 ); }
		}

		/// <summary>0088h 4バイト 0固定？</summary>
		public UInt32 h0088_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0088 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0088 ); }
		}

		/// <summary>008Ch 4バイト 浪人リスト(2ポインタタイプ)</summary>
		public UInt32 PtrRouninList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x008C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x008C ); }
		}

		/// <summary>0090h 4バイト リストカウンタ</summary>
		public Int32 CntRouninList
		{
			get { return BitConverter.ToInt32( this._rec, 0x0090 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0090 ); }
		}

		/// <summary>0094h 4バイト 0固定？</summary>
		public UInt32 h0094_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0094 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0094 ); }
		}

		/// <summary>0098h 4バイト リスト(2ポインタタイプ)</summary>
		public UInt32 PtrList_0098
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0098 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0098 ); }
		}

		/// <summary>009Ch 4バイト リストカウンタ</summary>
		public Int32 CntList_0098
		{
			get { return BitConverter.ToInt32( this._rec, 0x009C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x009C ); }
		}

		/// <summary>00A0h 4バイト 0固定？</summary>
		public UInt32 h00A0_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00A0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00A0 ); }
		}

		/// <summary>00A4h 4バイト 城周辺の部隊リスト(2ポインタタイプ)</summary>
		public UInt32 PtrSyuuhenButaiList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00A4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00A4 ); }
		}

		/// <summary>00A8h 4バイト リストカウンタ</summary>
		public Int32 CntSyuuhenButaiList
		{
			get { return BitConverter.ToInt32( this._rec, 0x00A8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00A8 ); }
		}

		/// <summary>00ACh 4バイト 0固定？</summary>
		public UInt32 h00AC_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00AC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00AC ); }
		}

		/// <summary>00B0h 4バイト 建物リスト(2ポインタタイプ)</summary>
		public UInt32 PtrTatemonoList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00B0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00B0 ); }
		}

		/// <summary>00B4h 4バイト リストカウンタ</summary>
		public Int32 CntTatemonoList
		{
			get { return BitConverter.ToInt32( this._rec, 0x00B4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00B4 ); }
		}

		/// <summary>00B8h 4バイト 0固定？</summary>
		public UInt32 h00B8_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00B8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00B8 ); }
		}

		/// <summary>00BCh 4バイト 城名ポインタ</summary>
		public UInt32 PtrShiroName
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00BC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00BC ); }
		}

		/// <summary>00C0h 4バイト 城主武将ポインタ</summary>
		public UInt32 PtrJousyu
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00C0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00C0 ); }
		}

		/// <summary>00C4h 4バイト 建物ポインタ(現在耐久は建物データ内)</summary>
		public UInt32 PtrTatemono
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00C4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00C4 ); }
		}

		/// <summary>00C8h 2バイト 築城年(開始)</summary>
		public UInt16 DateYearChikujou
		{
			get { return BitConverter.ToUInt16( this._rec, 0x00C8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00C8 ); }
		}

		/// <summary>00CAh 1バイト 築城月(開始)</summary>
		public Byte DateMonthChikujou
		{
			get { return this._rec[0x00CA]; }
			set { this._rec[0x00CA] = value; }
		}

		/// <summary>00CBh 1バイト 築城日(開始)</summary>
		public Byte DateDayChikujou
		{
			get { return this._rec[0x00CB]; }
			set { this._rec[0x00CB] = value; }
		}

		/// <summary>00CCh 2バイト 築城時(開始)</summary>
		public UInt16 DateHourChikujou
		{
			get { return BitConverter.ToUInt16( this._rec, 0x00CC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00CC ); }
		}

		/// <summary>00D0h 4バイト 奉行武将ポインタ</summary>
		public UInt32 PtrBugyou
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00D0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00D0 ); }
		}

		/// <summary>00D4h 4バイト 人口</summary>
		public Int32 Jinkou
		{
			get { return BitConverter.ToInt32( this._rec, 0x00D4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00D4 ); }
		}

		/// <summary>00D8h 2バイト 商業(現在)</summary>
		public Int16 SyougyouNow
		{
			get { return BitConverter.ToInt16( this._rec, 0x00D8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00D8 ); }
		}

		/// <summary>00DAh 2バイト 石高(現在)</summary>
		public Int16 KokudakaNow
		{
			get { return BitConverter.ToInt16( this._rec, 0x00DA ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00DA ); }
		}

		/// <summary>00DCh 2バイト 兵舎(現在)</summary>
		public Int16 HeisyaNow
		{
			get { return BitConverter.ToInt16( this._rec, 0x00DC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00DC ); }
		}

		/// <summary>00DEh 2バイト 商業(最大)</summary>
		public Int16 SyougyouMax
		{
			get { return BitConverter.ToInt16( this._rec, 0x00DE ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00DE ); }
		}

		/// <summary>00E0h 2バイト 石高(最大)</summary>
		public Int16 KokudakaMax
		{
			get { return BitConverter.ToInt16( this._rec, 0x00E0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00E0 ); }
		}

		/// <summary>00E2h 2バイト 兵舎(最大)</summary>
		public Int16 HeisyaMax
		{
			get { return BitConverter.ToInt16( this._rec, 0x00E2 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00E2 ); }
		}

		/// <summary>00E4h 2バイト 耐久(最大)</summary>
		public Int16 TaikyuuMax
		{
			get { return BitConverter.ToInt16( this._rec, 0x00E4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00E4 ); }
		}

		/// <summary>00E6h 2バイト 城士気</summary>
		public Int16 Shiki
		{
			get { return BitConverter.ToInt16( this._rec, 0x00E6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00E6 ); }
		}

		/// <summary>00E8h 2バイト</summary>
		public Int16 h00E8_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x00E8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00E8 ); }
		}

		/// <summary>00EAh 2バイト 民忠</summary>
		public Int16 Tamichuu
		{
			get { return BitConverter.ToInt16( this._rec, 0x00EA ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00EA ); }
		}

		/// <summary>00ECh 4バイト 城郭ポインタ 天守</summary>
		public UInt32 PtrJoukaku1
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00EC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00EC ); }
		}

		/// <summary>00F0h 4バイト 城郭ポインタ 城門</summary>
		public UInt32 PtrJoukaku2
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00F0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00F0 ); }
		}

		/// <summary>00F4h 4バイト 城郭ポインタ 塀</summary>
		public UInt32 PtrJoukaku3
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00F4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00F4 ); }
		}

		/// <summary>00F8h 4バイト 城郭ポインタ 出丸</summary>
		public UInt32 PtrJoukaku4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00F8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00F8 ); }
		}

		/// <summary>00FCh 4バイト 城郭ポインタ 矢倉</summary>
		public UInt32 PtrJoukaku5
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00FC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00FC ); }
		}

		/// <summary>0100h 4バイト 城郭ポインタ 曲輪</summary>
		public UInt32 PtrJoukaku6
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0100 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0100 ); }
		}

		/// <summary>0104h 4バイト 城郭ポインタ 施設</summary>
		public UInt32 PtrJoukaku7
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0104 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0104 ); }
		}

		/// <summary>0108h 4バイト 0固定？</summary>
		public UInt32 h0108_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0108 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0108 ); }
		}

		/// <summary>010Ch 4バイト 0固定？</summary>
		public UInt32 h010C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x010C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x010C ); }
		}

		/// <summary>0110h 4バイト 0固定？</summary>
		public UInt32 h0110_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0110 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0110 ); }
		}

		/// <summary>0114h 4バイト 0固定？</summary>
		public UInt32 h0114_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0114 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0114 ); }
		}

		/// <summary>0118h 4バイト 0固定？</summary>
		public UInt32 h0118_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0118 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0118 ); }
		}

		/// <summary>011Ch 4バイト 0固定？</summary>
		public UInt32 h011C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x011C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x011C ); }
		}

		/// <summary>0120h 4バイト 0固定？</summary>
		public UInt32 h0120_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0120 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0120 ); }
		}

		/// <summary>0124h 4バイト 0固定？</summary>
		public UInt32 h0124_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0124 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0124 ); }
		}

		/// <summary>0128h 4バイト 0固定？</summary>
		public UInt32 h0128_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0128 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0128 ); }
		}

		/// <summary>012Ch 4バイト 0固定？</summary>
		public UInt32 h012C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x012C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x012C ); }
		}

		/// <summary>0130h 2バイト 0固定？</summary>
		public UInt16 h0130_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0130 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0130 ); }
		}

		/// <summary>0132h 2バイト</summary>
		public UInt16 h0132_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0132 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0132 ); }
		}

		/// <summary>0134h 1バイト</summary>
		public Byte h0134
		{
			get { return this._rec[0x0134]; }
			set { this._rec[0x0134] = value; }
		}

		/// <summary>0135h 1バイト</summary>
		public Byte h0135
		{
			get { return this._rec[0x0135]; }
			set { this._rec[0x0135] = value; }
		}

		/// <summary>0136h 1バイト</summary>
		public Byte h0136
		{
			get { return this._rec[0x0136]; }
			set { this._rec[0x0136] = value; }
		}

		/// <summary>0137h 1バイト</summary>
		public Byte h0137
		{
			get { return this._rec[0x0137]; }
			set { this._rec[0x0137] = value; }
		}

		/// <summary>0138h 1バイト</summary>
		public Byte h0138
		{
			get { return this._rec[0x0138]; }
			set { this._rec[0x0138] = value; }
		}

		/// <summary>0139h 1バイト</summary>
		public Byte h0139
		{
			get { return this._rec[0x0139]; }
			set { this._rec[0x0139] = value; }
		}

		/// <summary>013Ah 1バイト</summary>
		public Byte h013A
		{
			get { return this._rec[0x013A]; }
			set { this._rec[0x013A] = value; }
		}

		/// <summary>013Bh 1バイト 用地関連のフラグ ゲーム内編集機能で全開にすると第7ビットが立つ</summary>
		public Byte h013B
		{
			get { return this._rec[0x013B]; }
			set { this._rec[0x013B] = value; }
		}

		/// <summary>013Bh bit0~1(2ビット) 用地サイズに使用するParam値(COST_N14PK_HONJOU(SHIJOU)_YAMAJIRO(HIRAJIRO)_MAX_LV0～3)のLV
		/// <para>YAMAJIRO / HIRAJIRO のどちらを使用するかは、要所データの 3Eh の第2ビットの値による</para></summary>
		public Int32 YouchiLV
		{
			get { return MyBitConverter.ToInt32( this._rec, 0x013B, 0, 2 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x013B, 0, 2 ); }
		}

		/// <summary>013Bh bit7 用地サイズ全開フラグ ゲーム内編集機能で全開にするとこのフラグが立つ</summary>
		public Boolean IsYouchiZenkai
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x013B, 7 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x013B, 7 ); }
		}

		/// <summary>013Ch 2バイト</summary>
		public UInt16 h013C_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x013C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x013C ); }
		}

		/// <summary>013Eh 2バイト</summary>
		public UInt16 h013E_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x013E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x013E ); }
		}

		/// <summary>0140h 2バイト</summary>
		public UInt16 h0140_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0140 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0140 ); }
		}

		/// <summary>0142h 2バイト</summary>
		public UInt16 h0142_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0142 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0142 ); }
		}

		/// <summary>0144h 2バイト</summary>
		public UInt16 h0144_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0144 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0144 ); }
		}

		/// <summary>0146h 2バイト</summary>
		public UInt16 h0146_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0146 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0146 ); }
		}

		/// <summary>0148h 2バイト</summary>
		public UInt16 h0148_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0148 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0148 ); }
		}

		/// <summary>014Ah 2バイト</summary>
		public UInt16 h014A_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x014A ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x014A ); }
		}

		// 014C~214Bh (Magic 4バイト + データ 12バイト) 計10h(16) が 512 繰り返し 詳細不明

		/// <summary>214C~2E43h 区画データ配列
		/// <para>(Magic 4バイト + 城ポインタ 4バイト + Magic 4バイト + 城ポインタ 4バイト + データ 316バイト) 計0x14C(332)バイト が 10 繰り返し</para></summary>
		public KukakuData[] Kukaku
		{
			get
			{
				var kukaku = new KukakuData[ShiroData._KukakuCount];
				for ( var i = 0; i < kukaku.Length; i++ )
				{
					kukaku[i] = new KukakuData();
					kukaku[i].SetRecord( this._rec );
					kukaku[i].SetBase( ShiroData._OffsetKukakuData + ShiroData._SizeOfKukakuData * i );
					kukaku[i].Address = this.Address + ( ShiroData._OffsetKukakuData + ShiroData._SizeOfKukakuData * (uint)i );
					kukaku[i].ID = this.ID * ShiroData._KukakuCount + i;
				}
				return kukaku;
			}
		}

		/// <summary>2E44h 1バイト 使用区画数(拡張可能含む)
		/// <para>実際に使用している区画数より大きい値を入れることで拡張可能になる</para>
		/// <para>毎月人口に基づき算出され値が更新される(拡張済みの区画が元に戻るようなことはない)</para></summary>
		public Byte KukakuUsed
		{
			get { return this._rec[0x2E44]; }
			set { this._rec[0x2E44] = value; }
		}

		/// <summary>2E45h 1バイト 最大区画数</summary>
		public Byte KukakuMax
		{
			get { return this._rec[0x2E45]; }
			set { this._rec[0x2E45] = value; }
		}

		// 2E46~2E7Bh 37h(53)バイト 詳細不明


		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
