﻿// GunryakuData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>軍略データ</summary>
	public class GunryakuData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>00h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00 ); }
		}

		/// <summary>04h 1バイト 効果タイプID
		/// <para>政策の効果順に共通しているようだ</para></summary>
		public Byte KoukaTypeID
		{
			get { return this._rec[0x04]; }
			set { this._rec[0x04] = value; }
		}

		/// <summary>05h 1バイト 効果値？</summary>
		public SByte KoukaValue
		{
			get { return (sbyte)this._rec[0x05]; }
			set { this._rec[0x05] = (byte)value; }
		}

		/// <summary>06~0Eh 9バイト 名称(シフトJIS nullターミネイト)</summary>
		public String Name
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x06, 9 ); }
			set { MyTextConverter.StringToBytes( value, 9 ).CopyTo( this._rec, 0x06 ); }
		}

		/// <summary>0F~37h 41バイト 名称(シフトJIS nullターミネイト)</summary>
		public String Help
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x0F, 41 ); }
			set { MyTextConverter.StringToBytes( value, 41 ).CopyTo( this._rec, 0x0F ); }
		}

		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
