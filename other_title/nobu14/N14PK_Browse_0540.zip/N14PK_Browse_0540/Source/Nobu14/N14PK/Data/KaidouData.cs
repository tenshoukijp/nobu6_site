﻿// KaidouData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>街道データ</summary>
	public class KaidouData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>00h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00 ); }
		}

		/// <summary>04h 4バイト X位置？</summary>
		public UInt32 PosX
		{
			get { return BitConverter.ToUInt32( this._rec, 0x04 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x04 ); }
		}

		/// <summary>08h 4バイト Y位置？</summary>
		public UInt32 PosY
		{
			get { return BitConverter.ToUInt32( this._rec, 0x08 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x08 ); }
		}

		/// <summary>0Ch 4バイト 要所ポインタ1</summary>
		public UInt32 PtrYousyo1
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0C ); }
		}

		/// <summary>10h 4バイト 要所ポインタ2</summary>
		public UInt32 PtrYousyo2
		{
			get { return BitConverter.ToUInt32( this._rec, 0x10 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x10 ); }
		}

		/// <summary>14h 4バイト 街道長？</summary>
		public UInt32 h14_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x14 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x14 ); }
		}

		/// <summary>18h 4バイト 整備レベル 0:1、1:2、2:3、3:4、4:5</summary>
		public UInt32 SeibiLV
		{
			get { return BitConverter.ToUInt32( this._rec, 0x18 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x18 ); }
		}

		/// <summary>1Ch 1バイト 状態フラグ
		/// <para>0x00,0x01,0x03,0x11 を確認。0x11は街道のポイントとキャプション双方表示されない</para></summary>
		public Byte JoutaiFlag
		{
			get { return this._rec[0x1C]; }
			set { this._rec[0x1C] = value; }
		}

		/// <summary>1Dh 1バイト 地形ID
		/// <para>0:平地、1:山地、2:平地(川)、3:近海、4:遠海</para></summary>
		public Byte ChikeiID
		{
			get { return this._rec[0x1D]; }
			set { this._rec[0x1D] = value; }
		}

		/// <summary>1Eh 1バイト 0固定？</summary>
		public Byte h1E
		{
			get { return this._rec[0x1E]; }
			set { this._rec[0x1E] = value; }
		}

		/// <summary>1Fh 1バイト 0固定？</summary>
		public Byte h1F
		{
			get { return this._rec[0x1F]; }
			set { this._rec[0x1F] = value; }
		}

		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
