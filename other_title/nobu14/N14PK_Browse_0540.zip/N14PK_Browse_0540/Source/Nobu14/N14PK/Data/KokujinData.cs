﻿// KokujinData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>国人衆データ</summary>
	/// <remarks>004~017h 0x14(20)バイト
	/// <para>040~093h 0x54(84)バイト</para>
	/// <para>0FC~2CBh 1D0(464)バイト</para>
	/// <para>上記箇所は0固定？ プロパティ化していない</para></remarks>
	public class KokujinData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>00h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00 ); }
		}

		// 004~017h 20バイト 0固定？


		/// <summary>018h 4バイト 現兵数</summary>
		public Int32 Heisuu
		{
			get { return BitConverter.ToInt32( this._rec, 0x018 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x018 ); }
		}

		/// <summary>01Ch 4バイト リスト(2ポインタタイプ)</summary>
		public UInt32 PtrList_01C
		{
			get { return BitConverter.ToUInt32( this._rec, 0x01C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x01C ); }
		}

		/// <summary>020h 4バイト リストカウンタ</summary>
		public Int32 CntList_01C
		{
			get { return BitConverter.ToInt32( this._rec, 0x020 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x020 ); }
		}

		/// <summary>024h 4バイト 0固定？</summary>
		public UInt32 h024_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x024 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x024 ); }
		}

		/// <summary>028h 4バイト 0固定？</summary>
		public UInt32 h028_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x028 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x028 ); }
		}

		/// <summary>02Ch 4バイト 0固定？</summary>
		public UInt32 h02C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x02C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x02C ); }
		}


		/// <summary>030h 4バイト リスト(2ポインタタイプ)</summary>
		public UInt32 PtrList_030
		{
			get { return BitConverter.ToUInt32( this._rec, 0x030 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x030 ); }
		}

		/// <summary>034h 4バイト リストカウンタ</summary>
		public Int32 CntList_030
		{
			get { return BitConverter.ToInt32( this._rec, 0x034 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x034 ); }
		}

		/// <summary>038h 4バイト 0固定？</summary>
		public UInt32 h038_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x038 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x038 ); }
		}


		/// <summary>03Ch 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber_03C
		{
			get { return BitConverter.ToUInt32( this._rec, 0x03C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x03C ); }
		}

		// 040~093h 84バイト 0固定？


		/// <summary>094h 4バイト 特能ID
		/// <para>0:義勇、銭納、米納、傭兵、番匠、鉄砲、軍馬、土竜、剣豪、水軍、寺社、11:隠密</para></summary>
		public Int32 TokunouID
		{
			get { return BitConverter.ToInt32( this._rec, 0x094 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x094 ); }
		}


		/// <summary>098h 4バイト 部隊リスト(2ポインタタイプ)</summary>
		public UInt32 PtrButaiList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x098 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x098 ); }
		}

		/// <summary>09Ch 4バイト リストカウンタ</summary>
		public Int32 CntButaiList
		{
			get { return BitConverter.ToInt32( this._rec, 0x09C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x09C ); }
		}

		/// <summary>0A0h 4バイト 0固定？</summary>
		public UInt32 h0A0_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0A0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0A0 ); }
		}


		/// <summary>0A4~0AEh 11バイト 名称(シフトJIS nullターミネイト)</summary>
		public String Name
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x0A4, 11 ); }
			set { MyTextConverter.StringToBytes( value, 11 ).CopyTo( this._rec, 0x0A4 ); }
		}

		/// <summary>0AF~0CBh 29バイト 読み(シフトJIS nullターミネイト)</summary>
		public String Yomi
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x0AF, 29 ); }
			set { MyTextConverter.StringToBytes( value, 29 ).CopyTo( this._rec, 0x0AF ); }
		}

		// 支持勢力データ 8バイト * 6勢力

		/// <summary>0CCh 4バイト 支持勢力ポインタ1</summary>
		public UInt32 PtrShijiSeiryoku1
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0CC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0CC ); }
		}

		/// <summary>0D0h 1バイト</summary>
		public Byte h0D0
		{
			get { return this._rec[0x0D0]; }
			set { this._rec[0x0D0] = value; }
		}

		/// <summary>0D1h 1バイト 0固定 未使用？</summary>
		public Byte h0D1
		{
			get { return this._rec[0x0D1]; }
			set { this._rec[0x0D1] = value; }
		}

		/// <summary>0D2h 1バイト 支持率1</summary>
		public SByte Shijiritsu1
		{
			get { return (sbyte)this._rec[0x0D2]; }
			set { this._rec[0x0D2] = (byte)value; }
		}

		/// <summary>0D3h 1バイト 0固定 未使用？</summary>
		public Byte h0D3
		{
			get { return this._rec[0x0D3]; }
			set { this._rec[0x0D3] = value; }
		}


		/// <summary>0D4h 4バイト 支持勢力ポインタ2</summary>
		public UInt32 PtrShijiSeiryoku2
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0D4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D4 ); }
		}

		/// <summary>0D8h 1バイト</summary>
		public Byte h0D8
		{
			get { return this._rec[0x0D8]; }
			set { this._rec[0x0D8] = value; }
		}

		/// <summary>0D9h 1バイト 0固定 未使用？</summary>
		public Byte h0D9
		{
			get { return this._rec[0x0D9]; }
			set { this._rec[0x0D9] = value; }
		}

		/// <summary>0DAh 1バイト 支持率2</summary>
		public SByte Shijiritsu2
		{
			get { return (sbyte)this._rec[0x0DA]; }
			set { this._rec[0x0DA] = (byte)value; }
		}

		/// <summary>0DBh 1バイト 0固定 未使用？</summary>
		public Byte h0DB
		{
			get { return this._rec[0x0DB]; }
			set { this._rec[0x0DB] = value; }
		}


		/// <summary>0DCh 4バイト 支持勢力ポインタ3</summary>
		public UInt32 PtrShijiSeiryoku3
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0DC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0DC ); }
		}

		/// <summary>0E0h 1バイト</summary>
		public Byte h0E0
		{
			get { return this._rec[0x0E0]; }
			set { this._rec[0x0E0] = value; }
		}

		/// <summary>0E1h 1バイト 0固定 未使用？</summary>
		public Byte h0E1
		{
			get { return this._rec[0x0E1]; }
			set { this._rec[0x0E1] = value; }
		}

		/// <summary>0E2h 1バイト 支持率3</summary>
		public SByte Shijiritsu3
		{
			get { return (sbyte)this._rec[0x0E2]; }
			set { this._rec[0x0E2] = (byte)value; }
		}

		/// <summary>0E3h 1バイト 0固定 未使用？</summary>
		public Byte h0E3
		{
			get { return this._rec[0x0E3]; }
			set { this._rec[0x0E3] = value; }
		}


		/// <summary>0E4h 4バイト 支持勢力ポインタ4</summary>
		public UInt32 PtrShijiSeiryoku4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0E4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0E4 ); }
		}

		/// <summary>0E8h 1バイト</summary>
		public Byte h0E8
		{
			get { return this._rec[0x0E8]; }
			set { this._rec[0x0E8] = value; }
		}

		/// <summary>0D1h 1バイト 0固定 未使用？</summary>
		public Byte h0E9
		{
			get { return this._rec[0x0E9]; }
			set { this._rec[0x0E9] = value; }
		}

		/// <summary>0EAh 1バイト 支持率4</summary>
		public SByte Shijiritsu4
		{
			get { return (sbyte)this._rec[0x0EA]; }
			set { this._rec[0x0EA] = (byte)value; }
		}

		/// <summary>0D1h 1バイト 0固定 未使用？</summary>
		public Byte h0EB
		{
			get { return this._rec[0x0EB]; }
			set { this._rec[0x0EB] = value; }
		}


		/// <summary>0ECh 4バイト 支持勢力ポインタ5</summary>
		public UInt32 PtrShijiSeiryoku5
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0EC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0EC ); }
		}

		/// <summary>0F0h 1バイト</summary>
		public Byte h0F0
		{
			get { return this._rec[0x0F0]; }
			set { this._rec[0x0F0] = value; }
		}

		/// <summary>0F1h 1バイト 0固定 未使用？</summary>
		public Byte h0F1
		{
			get { return this._rec[0x0F1]; }
			set { this._rec[0x0F1] = value; }
		}

		/// <summary>0F2h 1バイト 支持率5</summary>
		public SByte Shijiritsu5
		{
			get { return (sbyte)this._rec[0x0F2]; }
			set { this._rec[0x0F2] = (byte)value; }
		}

		/// <summary>0F3h 1バイト 0固定 未使用？</summary>
		public Byte h0F3
		{
			get { return this._rec[0x0F3]; }
			set { this._rec[0x0F3] = value; }
		}


		/// <summary>0F4h 4バイト 支持勢力ポインタ6</summary>
		public UInt32 PtrShijiSeiryoku6
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0F4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0F4 ); }
		}

		/// <summary>0F8h 1バイト</summary>
		public Byte h0F8
		{
			get { return this._rec[0x0F8]; }
			set { this._rec[0x0F8] = value; }
		}

		/// <summary>0F9h 1バイト 0固定 未使用？</summary>
		public Byte h0F9
		{
			get { return this._rec[0x0F9]; }
			set { this._rec[0x0F9] = value; }
		}

		/// <summary>0FAh 1バイト 支持率6</summary>
		public SByte Shijiritsu6
		{
			get { return (sbyte)this._rec[0x0FA]; }
			set { this._rec[0x0FA] = (byte)value; }
		}

		/// <summary>0FBh 1バイト 0固定 未使用？</summary>
		public Byte h0FB
		{
			get { return this._rec[0x0FB]; }
			set { this._rec[0x0FB] = value; }
		}

		// 0FC~2CBh 1D0(464)バイト 0固定？


		/// <summary>2CCh 4バイト 頭領ポインタ</summary>
		public UInt32 PtrTouryou
		{
			get { return BitConverter.ToUInt32( this._rec, 0x2CC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2CC ); }
		}

		/// <summary>2D0h 4バイト 所属勢力ポインタ</summary>
		public UInt32 PtrSyozokuSeiryoku
		{
			get { return BitConverter.ToUInt32( this._rec, 0x2D0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2D0 ); }
		}

		/// <summary>2D4h 4バイト ポインタ</summary>
		public UInt32 Ptr_2D4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x2D4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2D4 ); }
		}

		/// <summary>2D8h 4バイト 取込時に配下となる武将ポインタ</summary>
		public UInt32 PtrTorikomiBusyou
		{
			get { return BitConverter.ToUInt32( this._rec, 0x2D8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2D8 ); }
		}

		/// <summary>2DCh 2バイト 何かのID</summary>
		public Int16 h2DC_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x2DC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2DC ); }
		}

		/// <summary>2DEh 2バイト 最大兵数</summary>
		public Int16 HeisuuMax
		{
			get { return BitConverter.ToInt16( this._rec, 0x2DE ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2DE ); }
		}


		/// <summary>2E0h 2バイト フラグ？</summary>
		public UInt16 h2E0_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x2E0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2E0 ); }
		}

		/// <summary>2E2h 2バイト 0固定？</summary>
		public UInt16 h2E2_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x2E2 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2E2 ); }
		}

		/// <summary>2E4h 2バイト 0固定？</summary>
		public UInt16 h2E4_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x2E4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2E4 ); }
		}

		/// <summary>2E6h 2バイト 0固定？</summary>
		public UInt16 h2E6_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x2E6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2E6 ); }
		}

		/// <summary>2E8h 2バイト 0固定？</summary>
		public UInt16 h2E8_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x2E8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2E8 ); }
		}

		/// <summary>2EAh 2バイト 0固定？</summary>
		public UInt16 h2EA_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x2EA ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2EA ); }
		}

		/// <summary>2ECh 2バイト フラグ？</summary>
		public UInt16 h2EC_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x2EC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2EC ); }
		}

		/// <summary>2EEh 2バイト フラグ？</summary>
		public UInt16 h2EE_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x2EE ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2EE ); }
		}

		/// <summary>2F0h 2バイト 0固定？</summary>
		public UInt16 h2F0_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x2F0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2F0 ); }
		}

		/// <summary>2F2h 2バイト 0固定？</summary>
		public UInt16 h2F2_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x2F2 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2F2 ); }
		}


		/// <summary>2F4h 4バイト 不明ポインタ</summary>
		public UInt32 Ptr_2F4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x2F4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2F4 ); }
		}

		/// <summary>2F8h 4バイト 2 or 8？</summary>
		public UInt32 h2F8_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x2F8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2F8 ); }
		}


		/// <summary>2FCh 4バイト リスト(2ポインタタイプ)</summary>
		public UInt32 PtrList_2FC
		{
			get { return BitConverter.ToUInt32( this._rec, 0x2FC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2F4 ); }
		}

		/// <summary>300h 4バイト リストカウンタ</summary>
		public Int32 CntList_2FC
		{
			get { return BitConverter.ToInt32( this._rec, 0x300 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x300 ); }
		}

		/// <summary>304h 4バイト 0固定？</summary>
		public UInt32 h304_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x304 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x304 ); }
		}


		/// <summary>308h 4バイト 建物ポインタ</summary>
		public UInt32 PtrTatemono
		{
			get { return BitConverter.ToUInt32( this._rec, 0x308 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x308 ); }
		}


		/// <summary>30Ch 4バイト リスト(2ポインタタイプ)</summary>
		public UInt32 PtrList_30C
		{
			get { return BitConverter.ToUInt32( this._rec, 0x30C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x30C ); }
		}

		/// <summary>310h 4バイト リストカウンタ</summary>
		public Int32 CntList_30C
		{
			get { return BitConverter.ToInt32( this._rec, 0x310 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x310 ); }
		}

		/// <summary>314h 4バイト 0固定？</summary>
		public UInt32 h314_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x314 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x314 ); }
		}


		/// <summary>318h 4バイト 城リスト(2ポインタ＆ポインタデータサイズ0x10タイプ)</summary>
		public UInt32 PtrShiroList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x318 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x318 ); }
		}

		/// <summary>31Ch 4バイト リストカウンタ</summary>
		public Int32 CntShiroList
		{
			get { return BitConverter.ToInt32( this._rec, 0x31C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x31C ); }
		}

		/// <summary>320h 4バイト 0固定？</summary>
		public UInt32 h320_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x320 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x320 ); }
		}

		// PKで追加された24バイト

		/// <summary>324h 4バイト</summary>
		public UInt32 h324_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x324 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x324 ); }
		}

		/// <summary>328h 4バイト</summary>
		public UInt32 h328_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x328 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x328 ); }
		}

		/// <summary>32Ch 4バイト</summary>
		public UInt32 h32C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x32C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x32C ); }
		}

		/// <summary>330h 4バイト</summary>
		public UInt32 h330_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x330 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x330 ); }
		}

		/// <summary>334h 4バイト</summary>
		public UInt32 h334_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x334 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x334 ); }
		}

		/// <summary>338h 4バイト</summary>
		public UInt32 h338_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x338 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x338 ); }
		}

		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
