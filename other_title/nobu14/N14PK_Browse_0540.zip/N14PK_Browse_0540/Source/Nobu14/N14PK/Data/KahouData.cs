﻿// KahouData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>家宝データ</summary>
	public class KahouData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>00h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00 ); }
		}

		/// <summary>04~10h 13バイト 名称(シフトJIS nullターミネイト)</summary>
		public String Name
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x04, 13 ); }
			set { MyTextConverter.StringToBytes( value, 13 ).CopyTo( this._rec, 0x04 ); }
		}

		/// <summary>11~2Fh 31バイト 読み(シフトJIS nullターミネイト)</summary>
		public String Yomi
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x11, 31 ); }
			set { MyTextConverter.StringToBytes( value, 31 ).CopyTo( this._rec, 0x11 ); }

		}

		/// <summary>30h 4バイト 保有勢力ポインタ</summary>
		public UInt32 PtrHoyuuSeiryoku
		{
			get { return BitConverter.ToUInt32( this._rec, 0x30 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x30 ); }
		}

		/// <summary>34h 4バイト 保有武将ポインタ</summary>
		public UInt32 PtrHoyuuBusyou
		{
			get { return BitConverter.ToUInt32( this._rec, 0x34 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x34 ); }
		}

		/// <summary>38h 4バイト 細かい分類？</summary>
		public UInt32 BunruiID
		{
			get { return BitConverter.ToUInt32( this._rec, 0x38 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x38 ); }
		}

		/// <summary>3Ch 4バイト 等級ID
		/// <para>0:なし、1:十等級、2:九等級、…、10:一等級</para></summary>
		public UInt32 ToukyuuID
		{
			get { return BitConverter.ToUInt32( this._rec, 0x3C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x3C ); }
		}

		/// <summary>40h 4バイト 家宝タイプID
		/// <para>0:茶器、1:武具、2:名馬、3:書物、4:絵画、5:香木、6:舶来、7:唐物</para></summary>
		public UInt32 KahouTypeID
		{
			get { return BitConverter.ToUInt32( this._rec, 0x40 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x40 ); }
		}

		// 44h の1バイトはビットデータとして扱う

		/// <summary>44h bit0 登場フラグ？
		/// <para>勢力または個人が所有している(家宝情報に表示される)場合は1。0で再販されるかは不明</para></summary>
		public Boolean h44_b0
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x44, 0 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x44, 0 ); }
		}

		/// <summary>44h bit1 フラグ 不明</summary>
		public Boolean h44_b1
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x44, 1 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x44, 1 ); }
		}

		/// <summary>44h bit2~3(2ビット) 生産地ID
		/// <para>0:日本、1:南蛮、2:明</para></summary>
		public UInt32 SanchiID
		{
			get { return MyBitConverter.ToUInt32( this._rec, 0x44, 2, 2 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x44, 2, 2 ); }
		}

		/// <summary>44h bit4 不明</summary>
		public Boolean h44_b4
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x44, 4 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x44, 4 ); }
		}

		/// <summary>44h bit5 未使用？</summary>
		public Boolean h44_b5
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x44, 5 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x44, 5 ); }
		}

		/// <summary>44h bit6 未使用？</summary>
		public Boolean h44_b6
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x44, 6 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x44, 6 ); }
		}

		/// <summary>44h bit7 未使用？</summary>
		public Boolean h44_b7
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x44, 7 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x44, 7 ); }
		}


		/// <summary>45h 1バイト 0固定？</summary>
		public Byte h45
		{
			get { return this._rec[0x45]; }
			set { this._rec[0x45] = value; }
		}

		/// <summary>46h 1バイト 0固定？</summary>
		public Byte h46
		{
			get { return this._rec[0x46]; }
			set { this._rec[0x46] = value; }
		}

		/// <summary>47h 1バイト 0固定？</summary>
		public Byte h47
		{
			get { return this._rec[0x47]; }
			set { this._rec[0x47] = value; }
		}

		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
