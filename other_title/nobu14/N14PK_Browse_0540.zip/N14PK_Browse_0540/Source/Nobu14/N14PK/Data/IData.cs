﻿// IData.cs

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace N14PKLibrary.Data
{
	/// <summary>テーブル内各データのインタフェース</summary>
	public interface IData
	{
		/// <summary>データアドレス</summary>
		UInt32 Address { set; get; }

		/// <summary>データID</summary>
		Int32 ID { set; get; }

		/// <summary>データ内にレコードをセットする</summary>
		/// <param name="recoed">レコード</param>
		void SetRecord( Byte[] recoed );

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		Byte[] GetRecord();
	}
}
