﻿// KuniData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>国データ</summary>
	public class KuniData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;


		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>00h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00 ); }
		}

		/// <summary>04h 4バイト 地方ポインタ</summary>
		public UInt32 PtrChihou
		{
			get { return BitConverter.ToUInt32( this._rec, 0x04 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x04 ); }
		}

		/// <summary>08h 4バイト ポインタ 飛んだ先に国ポインタが2つ入ってる？</summary>
		public UInt32 Ptr_08
		{
			get { return BitConverter.ToUInt32( this._rec, 0x08 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x08 ); }
		}

		/// <summary>0Ch 4バイト ポインタ Ptr_10 と同値？</summary>
		public UInt32 Ptr_0C
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0C ); }
		}

		/// <summary>10h 4バイト ポインタ Ptr_0C と同値？</summary>
		public UInt32 Ptr_10
		{
			get { return BitConverter.ToUInt32( this._rec, 0x10 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x10 ); }
		}

		/// <summary>14h 4バイト 0固定？</summary>
		public Int32 h14_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x14 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x14 ); }
		}

		/// <summary>18h 4バイト 城リストポインタ(2ポインタタイプ)</summary>
		public UInt32 PtrShiroList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x18 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x18 ); }
		}

		/// <summary>1Ch 4バイト 城数</summary>
		public Int32 CntShiroList
		{
			get { return BitConverter.ToInt32( this._rec, 0x1C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1C ); }
		}

		/// <summary>20h 4バイト 0固定？</summary>
		public Int32 h20_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x20 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x20 ); }
		}

		/// <summary>24h 4バイト ポインタ</summary>
		public UInt32 Ptr_24
		{
			get { return BitConverter.ToUInt32( this._rec, 0x24 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x24 ); }
		}

		/// <summary>28h 4バイト ポインタ Ptr_2C と同値？</summary>
		public UInt32 Ptr_28
		{
			get { return BitConverter.ToUInt32( this._rec, 0x28 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x28 ); }
		}

		/// <summary>2Ch 4バイト ポインタ Ptr_28 と同値？</summary>
		public UInt32 Ptr_2C
		{
			get { return BitConverter.ToUInt32( this._rec, 0x2C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2C ); }
		}

		/// <summary>30h 4バイト 0固定？</summary>
		public Int32 h30_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x30 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x30 ); }
		}

		/// <summary>34h 4バイト 4固定？</summary>
		public Int32 h34_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x34 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x34 ); }
		}

		/// <summary>38h 1バイト 0固定？</summary>
		public Byte h38
		{
			get { return this._rec[0x38]; }
			set { this._rec[0x38] = (byte)value; }
		}

		/// <summary>39h 11バイト 名称(シフトJIS nullターミネイト)</summary>
		public String Name
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x39, 11 ); }
			set { MyTextConverter.StringToBytes( value, 11 ).CopyTo( this._rec, 0x39 ); }
		}

		/// <summary>44h 19バイト 読み(シフトJIS nullターミネイト)</summary>
		public String Yomi
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x44, 19 ); }
			set { MyTextConverter.StringToBytes( value, 19 ).CopyTo( this._rec, 0x44 ); }
		}

		/// <summary>57h 1バイト 0x01 / 0xFF どちらかが入ってる？</summary>
		public SByte h57
		{
			get { return (sbyte)this._rec[0x57]; }
			set { this._rec[0x57] = (byte)value; }
		}

		/// <summary>58h 4バイト 国リストポインタ(2ポインタタイプ)</summary>
		public UInt32 PtrKuniList1
		{
			get { return BitConverter.ToUInt32( this._rec, 0x58 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x58 ); }
		}

		/// <summary>5Ch 4バイト 国数</summary>
		public Int32 CntKuniList1
		{
			get { return BitConverter.ToInt32( this._rec, 0x5C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x5C ); }
		}

		/// <summary>60h 4バイト 0固定？</summary>
		public Int32 h60_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x60 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x60 ); }
		}

		/// <summary>64h 4バイト 要所リストポインタ(2ポインタタイプ)</summary>
		public UInt32 PtrYousyoList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x64 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x64 ); }
		}

		/// <summary>68h 4バイト 要所数</summary>
		public Int32 CntYousyoList
		{
			get { return BitConverter.ToInt32( this._rec, 0x68 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x68 ); }
		}

		/// <summary>6Ch 4バイト 0固定？</summary>
		public Int32 h6C_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x6C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x6C ); }
		}

		/// <summary>70h 1バイト 0x00 または 0x0B ？</summary>
		public Byte h70
		{
			get { return this._rec[0x70]; }
			set { this._rec[0x70] = (byte)value; }
		}

		/// <summary>71h 1バイト 0x00 または 0x0F ？</summary>
		public Byte h71
		{
			get { return this._rec[0x71]; }
			set { this._rec[0x71] = (byte)value; }
		}

		/// <summary>72h 1バイト 0x00 または 0x17 ？</summary>
		public Byte h72
		{
			get { return this._rec[0x72]; }
			set { this._rec[0x72] = (byte)value; }
		}

		/// <summary>73h 1バイト 0x00 または 0x17 ？</summary>
		public Byte h73
		{
			get { return this._rec[0x73]; }
			set { this._rec[0x73] = (byte)value; }
		}

		/// <summary>74h 1バイト 0x00 または 0x41 ？</summary>
		public Byte h74
		{
			get { return this._rec[0x74]; }
			set { this._rec[0x74] = (byte)value; }
		}

		/// <summary>75h 1バイト 0x00 または 0x14 ？</summary>
		public Byte h75
		{
			get { return this._rec[0x75]; }
			set { this._rec[0x75] = (byte)value; }
		}

		/// <summary>76h 1バイト 0x00 または 0x1E ？</summary>
		public Byte h76
		{
			get { return this._rec[0x76]; }
			set { this._rec[0x76] = (byte)value; }
		}

		/// <summary>77h 1バイト 0x00 または 0x41 ？</summary>
		public Byte h77
		{
			get { return this._rec[0x77]; }
			set { this._rec[0x77] = (byte)value; }
		}

		/// <summary>78h 1バイト 0x00 または 0x46 ？</summary>
		public Byte h78
		{
			get { return this._rec[0x78]; }
			set { this._rec[0x78] = (byte)value; }
		}

		/// <summary>79h 1バイト 1固定？</summary>
		public Byte h79
		{
			get { return this._rec[0x79]; }
			set { this._rec[0x79] = (byte)value; }
		}

		/// <summary>7Ah 1バイト 1固定？</summary>
		public Byte h7A
		{
			get { return this._rec[0x7A]; }
			set { this._rec[0x7A] = (byte)value; }
		}

		/// <summary>7Bh 1バイト 0固定？</summary>
		public Byte h7B
		{
			get { return this._rec[0x7B]; }
			set { this._rec[0x7B] = (byte)value; }
		}

		/// <summary>7Ch 4バイト 0固定？</summary>
		public Int32 h7C_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x7C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x7C ); }
		}

		/// <summary>80h 4バイト 国リスト2ポインタ(3ポインタタイプ)</summary>
		public UInt32 PtrKuniList2
		{
			get { return BitConverter.ToUInt32( this._rec, 0x80 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x80 ); }
		}

		/// <summary>84h 4バイト 国数</summary>
		public Int32 CntKuniList2
		{
			get { return BitConverter.ToInt32( this._rec, 0x84 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x84 ); }
		}

		/// <summary>88h 4バイト 0固定？</summary>
		public Int32 h88_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x88 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x88 ); }
		}


		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
