﻿// TokuseiData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>特性データ</summary>
	public class TokuseiData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>00h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00 ); }
		}

		/// <summary>04~10h 13バイト 特性名(シフトJIS Nullターミネイト)</summary>
		public String Name
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x04, 13 ); }
			set { MyTextConverter.StringToBytes( value, 13 ).CopyTo( this._rec, 0x04 ); }
		}

		/// <summary>11~25h 21バイト 読み(シフトJIS Nullターミネイト)</summary>
		public String Yomi
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x11, 21 ); }
			set { MyTextConverter.StringToBytes( value, 21 ).CopyTo( this._rec, 0x11 ); }
		}

		/// <summary>26~76h 81バイト ヘルプ(シフトJIS Nullターミネイト)</summary>
		public String HelpText1
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x26, 81 ); }
			set { MyTextConverter.StringToBytes( value, 81 ).CopyTo( this._rec, 0x26 ); }
		}

		/// <summary>77~9Fh 41バイト ヘルプ(シフトJIS Nullターミネイト)</summary>
		public String HelpText2
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x77, 41 ); }
			set { MyTextConverter.StringToBytes( value, 41 ).CopyTo( this._rec, 0x77 ); }
		}

		/// <summary>A0h 4バイト 下位特性ポインタ</summary>
		public UInt32 PtrKaiTokusei
		{
			get { return BitConverter.ToUInt32( this._rec, 0xA0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xA0 ); }
		}

		/// <summary>A4h 4バイト 反特性ポインタ</summary>
		public UInt32 PtrHanTokusei
		{
			get { return BitConverter.ToUInt32( this._rec, 0xA4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xA4 ); }
		}


		/// <summary>A8h 1バイト 格ID
		/// <para>0:E、1:D、2:C、3:B、4:A、5:S</para></summary>
		public SByte KakuID
		{
			get { return (sbyte)this._rec[0xA8]; }
			set { this._rec[0xA8] = (byte)value; }
		}

		/// <summary>A9h 1バイト 系統ID
		/// <para>0:統率、1:武勇、2:知略、3:政治、4:内政、5:合戦、6:役職、7:官位、8:？、9:ダミー用 ※8:は使われていない</para></summary>
		public SByte KeitouID
		{
			get { return (sbyte)this._rec[0xA9]; }
			set { this._rec[0xA9] = (byte)value; }
		}

		/// <summary>AAh 1バイト 0固定？</summary>
		public SByte hAA
		{
			get { return (sbyte)this._rec[0xAA]; }
			set { this._rec[0xAA] = (byte)value; }
		}

		/// <summary>ABh 1バイト 0固定？</summary>
		public SByte hAB
		{
			get { return (sbyte)this._rec[0xAB]; }
			set { this._rec[0xAB] = (byte)value; }
		}

		/// <summary>ACh 1バイト 不明 ダミーデータには1、それ以外は0</summary>
		public SByte hAC
		{
			get { return (sbyte)this._rec[0xAC]; }
			set { this._rec[0xAC] = (byte)value; }
		}

		/// <summary>ADh 1バイト 兵数条件</summary>
		public SByte HeisuuJouken
		{
			get { return (sbyte)this._rec[0xAD]; }
			set { this._rec[0xAD] = (byte)value; }
		}

		/// <summary>AEh 1バイト 条件</summary>
		public SByte Jouken
		{
			get { return (sbyte)this._rec[0xAE]; }
			set { this._rec[0xAE] = (byte)value; }
		}

		/// <summary>AFh 1バイト 発動率</summary>
		public SByte Hatsudouritsu
		{
			get { return (sbyte)this._rec[0xAF]; }
			set { this._rec[0xAF] = (byte)value; }
		}

		/// <summary>B0h 1バイト 不明</summary>
		public SByte hB0
		{
			get { return (sbyte)this._rec[0xB0]; }
			set { this._rec[0xB0] = (byte)value; }
		}

		/// <summary>B1h 1バイト 不明</summary>
		public SByte hB1
		{
			get { return (sbyte)this._rec[0xB1]; }
			set { this._rec[0xB1] = (byte)value; }
		}

		/// <summary>B2h 1バイト 階位</summary>
		public SByte Kaii
		{
			get { return (sbyte)this._rec[0xB2]; }
			set { this._rec[0xB2] = (byte)value; }
		}

		/// <summary>B3h 1バイト ソートID</summary>
		public Byte SortID
		{
			get { return this._rec[0xB3]; }
			set { this._rec[0xB3] = value; }
		}


		/// <summary>B4h 2バイト 不明</summary>
		public Int16 hB4_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xB4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xB4 ); }
		}

		/// <summary>B6h 2バイト 腰兵糧</summary>
		public Int16 Hyourou
		{
			get { return BitConverter.ToInt16( this._rec, 0xB6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xB6 ); }
		}

		/// <summary>B8h 2バイト 攻撃1</summary>
		public Int16 Kougeki1
		{
			get { return BitConverter.ToInt16( this._rec, 0xB8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xB8 ); }
		}

		/// <summary>BAh 2バイト 守備1</summary>
		public Int16 Syubi1
		{
			get { return BitConverter.ToInt16( this._rec, 0xBA ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xBA ); }
		}

		/// <summary>BCh 2バイト 攻撃2</summary>
		public Int16 Kougeki2
		{
			get { return BitConverter.ToInt16( this._rec, 0xBC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xBC ); }
		}

		/// <summary>BEh 2バイト 守備2</summary>
		public Int16 Syubi2
		{
			get { return BitConverter.ToInt16( this._rec, 0xBE ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xBE ); }
		}

		/// <summary>C0h 2バイト 移動速度</summary>
		public Int16 Idou
		{
			get { return BitConverter.ToInt16( this._rec, 0xC0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xC0 ); }
		}

		/// <summary>C2h 2バイト 形態変更</summary>
		public Int16 Keitaihenkou
		{
			get { return BitConverter.ToInt16( this._rec, 0xC2 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xC2 ); }
		}

		/// <summary>C4h 2バイト 士気ゲージ</summary>
		public Int16 Shiki
		{
			get { return BitConverter.ToInt16( this._rec, 0xC4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xC4 ); }
		}

		/// <summary>C6h 2バイト 陣(設営効果)</summary>
		public Int16 Jin
		{
			get { return BitConverter.ToInt16( this._rec, 0xC6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xC6 ); }
		}

		/// <summary>C8h 2バイト 挟撃効果</summary>
		public Int16 Kyougeki
		{
			get { return BitConverter.ToInt16( this._rec, 0xC8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xC8 ); }
		}

		/// <summary>CAh 2バイト 行動不可</summary>
		public Int16 Koudoufuka
		{
			get { return BitConverter.ToInt16( this._rec, 0xCA ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xCA ); }
		}

		/// <summary>CCh 2バイト 混乱</summary>
		public Int16 Konran
		{
			get { return BitConverter.ToInt16( this._rec, 0xCC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xCC ); }
		}


		/// <summary>CEh 2バイト 未使用？</summary>
		public Int16 hCE_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xCE ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xCE ); }
		}

		/// <summary>D0h 2バイト 未使用？</summary>
		public Int16 hD0_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xD0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xD0 ); }
		}

		/// <summary>D2h 2バイト 未使用？</summary>
		public Int16 hD2_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xD2 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xD2 ); }
		}

		/// <summary>D4h 2バイト 未使用？</summary>
		public Int16 hD4_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xD4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xD4 ); }
		}

		/// <summary>D6h 2バイト 未使用？</summary>
		public Int16 hD6_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xD6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xD6 ); }
		}

		/// <summary>D8h 2バイト 未使用？</summary>
		public Int16 hD8_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xD8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xD8 ); }
		}

		/// <summary>DAh 2バイト 未使用？</summary>
		public Int16 hDA_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xDA ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xDA ); }
		}

		/// <summary>DCh 2バイト 未使用？</summary>
		public Int16 hDC_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xDC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xDC ); }
		}

		/// <summary>DEh 2バイト 未使用？</summary>
		public Int16 hDE_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xDE ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xDE ); }
		}

		/// <summary>E0h 2バイト 未使用？</summary>
		public Int16 hE0_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xE0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xE0 ); }
		}

		/// <summary>E2h 2バイト 未使用？</summary>
		public Int16 hE2_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xE2 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xE2 ); }
		}

		/// <summary>E4h 2バイト 未使用？</summary>
		public Int16 hE4_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xE4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xE4 ); }
		}

		/// <summary>E6h 2バイト 未使用？</summary>
		public Int16 hE6_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xE6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xE6 ); }
		}

		/// <summary>E8h 2バイト 未使用？</summary>
		public Int16 hE8_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xE8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xE8 ); }
		}

		/// <summary>EAh 2バイト 未使用？</summary>
		public Int16 hEA_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xEA ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xEA ); }
		}

		/// <summary>ECh 2バイト 未使用？</summary>
		public Int16 hEC_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xEC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xEC ); }
		}

		/// <summary>EEh 2バイト 未使用？</summary>
		public Int16 hEE_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xEE ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xEE ); }
		}

		/// <summary>F0h 2バイト 未使用？</summary>
		public Int16 hF0_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xF0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xF0 ); }
		}

		/// <summary>F2h 2バイト 未使用？</summary>
		public Int16 hF2_2
		{
			get { return BitConverter.ToInt16( this._rec, 0xF2 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0xF2 ); }
		}


		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
