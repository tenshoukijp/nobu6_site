﻿// ButaiData.cs

using System;

using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>部隊データ</summary>
	public class ButaiData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>000h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x000 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x000 ); }
		}

		/// <summary>004h 4バイト 目標ポインタ1 目標タイプにより参照するデータが異なる</summary>
		public UInt32 PtrMokuhyou1
		{
			get { return BitConverter.ToUInt32( this._rec, 0x004 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x004 ); }
		}

		/// <summary>008h 4バイト 目標タイプ(3:拠点、4:部隊、17:要所)</summary>
		public Int32 MokuhyouTypeID1
		{
			get { return BitConverter.ToInt32( this._rec, 0x008 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x008 ); }
		}

		/// <summary>00Ch 4バイト 目標ポインタ2 目標タイプにより参照するデータが異なる</summary>
		public UInt32 PtrMokuhyou2
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00C ); }
		}

		/// <summary>010h 4バイト 目標タイプ(3:拠点、4:部隊、17:要所)</summary>
		public Int32 MokuhyouTypeID2
		{
			get { return BitConverter.ToInt32( this._rec, 0x010 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x010 ); }
		}


		/// <summary>014h 4バイト 所属軍団ポインタ</summary>
		public UInt32 PtrGundan
		{
			get { return BitConverter.ToUInt32( this._rec, 0x014 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x014 ); }
		}

		/// <summary>018h 4バイト 兵数</summary>
		public Int32 Heisuu
		{
			get { return BitConverter.ToInt32( this._rec, 0x018 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x018 ); }
		}


		/// <summary>01Ch 4バイト 交戦部隊リスト(2ポインタタイプ)</summary>
		public UInt32 PtrKousenButaiList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x01C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x01C ); }
		}

		/// <summary>020h 4バイト リストカウンタ</summary>
		public Int32 CntKousenButaiList
		{
			get { return BitConverter.ToInt32( this._rec, 0x020 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x020 ); }
		}

		/// <summary>024h 4バイト 0固定？</summary>
		public Int32 h024_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x024 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x024 ); }
		}


		/// <summary>028h 4バイト 0固定？</summary>
		public Int32 h028_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x028 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x028 ); }
		}

		/// <summary>02Ch 4バイト 数値</summary>
		public Int32 h02C_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x02C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x02C ); }
		}


		/// <summary>030h 4バイト 会戦部隊リスト(2ポインタタイプ)</summary>
		public UInt32 PtrKaisenButaiList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x030 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x030 ); }
		}

		/// <summary>034h 4バイト リストカウンタ</summary>
		public Int32 CntKaisenButaiList
		{
			get { return BitConverter.ToInt32( this._rec, 0x034 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x034 ); }
		}

		/// <summary>038h 4バイト 0固定？</summary>
		public Int32 h038_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x038 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x038 ); }
		}


		/// <summary>03Ch 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber_03C
		{
			get { return BitConverter.ToUInt32( this._rec, 0x03C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x03C ); }
		}

		/// <summary>040h 4バイト 所属拠点ポインタ
		/// <para>所属拠点タイプIDにより参照するデータが異なる(城 / 国人衆)</para></summary>
		public UInt32 PtrKyoten
		{
			get { return BitConverter.ToUInt32( this._rec, 0x040 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x040 ); }
		}

		/// <summary>044h 4バイト 所属拠点タイプID(3:城、15:国人衆)</summary>
		public Int32 KyotenTypeID
		{
			get { return BitConverter.ToInt32( this._rec, 0x044 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x044 ); }
		}


		/// <summary>048h 4バイト 編成武将リスト(2ポインタタイプ)</summary>
		public UInt32 PtrHenseiList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x048 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x048 ); }
		}

		/// <summary>04Ch 4バイト リストカウンタ</summary>
		public Int32 CntHenseiList
		{
			get { return BitConverter.ToInt32( this._rec, 0x04C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x04C ); }
		}

		/// <summary>050h 4バイト 0固定？</summary>
		public Int32 h050_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x050 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x050 ); }
		}


		/// <summary>054h 4バイト 捕虜リスト(2ポインタタイプ)</summary>
		public UInt32 PtrHoryoList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x054 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x054 ); }
		}

		/// <summary>058h 4バイト リストカウンタ</summary>
		public Int32 CntHoryoList
		{
			get { return BitConverter.ToInt32( this._rec, 0x058 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x058 ); }
		}

		/// <summary>05Ch 4バイト 0固定？</summary>
		public Int32 h05C_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x05C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x05C ); }
		}


		/// <summary>060h 4バイト X位置？</summary>
		public Int32 PosX
		{
			get { return BitConverter.ToInt32( this._rec, 0x060 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x060 ); }
		}

		/// <summary>064h 4バイト Y位置？</summary>
		public Int32 PosY
		{
			get { return BitConverter.ToInt32( this._rec, 0x064 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x064 ); }
		}

		/// <summary>068h 4バイト 向き関連？</summary>
		public Int32 Direction1
		{
			get { return BitConverter.ToInt32( this._rec, 0x068 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x068 ); }
		}

		/// <summary>06Ch 4バイト 向き関連？</summary>
		public Int32 Direction2
		{
			get { return BitConverter.ToInt32( this._rec, 0x06C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x06C ); }
		}


		/// <summary>070h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber_070
		{
			get { return BitConverter.ToUInt32( this._rec, 0x070 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x070 ); }
		}

		/// <summary>074h 4バイト 数値 ウェイポイントデータ使用数？</summary>
		public Int32 h074_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x074 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x074 ); }
		}

		// ウェイポイントに関するデータ？ * 8個

		/// <summary>078h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber_WP1
		{
			get { return BitConverter.ToUInt32( this._rec, 0x078 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x078 ); }
		}

		/// <summary>07Ch 4バイト 目標ポインタ 目標タイプにより参照するデータが異なる</summary>
		public UInt32 PtrMokuhyou_WP1
		{
			get { return BitConverter.ToUInt32( this._rec, 0x07C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x07C ); }
		}

		/// <summary>080h 4バイト 目標タイプ(3:拠点、4:部隊、17:要所)</summary>
		public Int32 MokuhyouTypeID_WP1
		{
			get { return BitConverter.ToInt32( this._rec, 0x080 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x080 ); }
		}

		/// <summary>084h 2バイト 数値</summary>
		public Int16 B2_WP1_1
		{
			get { return BitConverter.ToInt16( this._rec, 0x084 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x084 ); }
		}

		/// <summary>086h 2バイト 数値</summary>
		public Int16 B2_WP1_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x086 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x086 ); }
		}


		/// <summary>088h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber_WP2
		{
			get { return BitConverter.ToUInt32( this._rec, 0x088 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x088 ); }
		}

		/// <summary>08Ch 4バイト 目標ポインタ 目標タイプにより参照するデータが異なる</summary>
		public UInt32 PtrMokuhyou_WP2
		{
			get { return BitConverter.ToUInt32( this._rec, 0x08C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x08C ); }
		}

		/// <summary>090h 4バイト 目標タイプ(3:拠点、4:部隊、17:要所)</summary>
		public Int32 MokuhyouTypeID_WP2
		{
			get { return BitConverter.ToInt32( this._rec, 0x090 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x090 ); }
		}

		/// <summary>094h 2バイト 数値</summary>
		public Int16 B2_WP2_1
		{
			get { return BitConverter.ToInt16( this._rec, 0x094 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x094 ); }
		}

		/// <summary>096h 2バイト 数値</summary>
		public Int16 B2_WP2_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x096 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x096 ); }
		}


		/// <summary>098h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber_WP3
		{
			get { return BitConverter.ToUInt32( this._rec, 0x098 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x098 ); }
		}

		/// <summary>09Ch 4バイト 目標ポインタ 目標タイプにより参照するデータが異なる</summary>
		public UInt32 PtrMokuhyou_WP3
		{
			get { return BitConverter.ToUInt32( this._rec, 0x09C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x09C ); }
		}

		/// <summary>0A0h 4バイト 目標タイプ(3:拠点、4:部隊、17:要所)</summary>
		public Int32 MokuhyouTypeID_WP3
		{
			get { return BitConverter.ToInt32( this._rec, 0x0A0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0A0 ); }
		}

		/// <summary>0A4h 2バイト 数値</summary>
		public Int16 B2_WP3_1
		{
			get { return BitConverter.ToInt16( this._rec, 0x0A4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0A4 ); }
		}

		/// <summary>0A6h 2バイト 数値</summary>
		public Int16 B2_WP3_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x0A6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0A6 ); }
		}


		/// <summary>0A8h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber_WP4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0A8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0A8 ); }
		}

		/// <summary>0ACh 4バイト 目標ポインタ 目標タイプにより参照するデータが異なる</summary>
		public UInt32 PtrMokuhyou_WP4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0AC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0AC ); }
		}

		/// <summary>0B0h 4バイト 目標タイプ(3:拠点、4:部隊、17:要所)</summary>
		public Int32 MokuhyouTypeID_WP4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0B0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0B0 ); }
		}

		/// <summary>0B4h 2バイト 数値</summary>
		public Int16 B2_WP4_1
		{
			get { return BitConverter.ToInt16( this._rec, 0x0B4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0B4 ); }
		}

		/// <summary>0B6h 2バイト 数値</summary>
		public Int16 B2_WP4_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x0B6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0B6 ); }
		}


		/// <summary>0B8h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber_WP5
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0B8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x014 ); }
		}

		/// <summary>0BCh 4バイト 目標ポインタ 目標タイプにより参照するデータが異なる</summary>
		public UInt32 PtrMokuhyou_WP5
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0BC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0BC ); }
		}

		/// <summary>0C0h 4バイト 目標タイプ(3:拠点、4:部隊、17:要所)</summary>
		public Int32 MokuhyouTypeID_WP5
		{
			get { return BitConverter.ToInt32( this._rec, 0x0C0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0C0 ); }
		}

		/// <summary>0C4h 2バイト 数値</summary>
		public Int16 B2_WP5_1
		{
			get { return BitConverter.ToInt16( this._rec, 0x0C4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0C4 ); }
		}

		/// <summary>0C6h 2バイト 数値</summary>
		public Int16 B2_WP5_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x0C6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0C6 ); }
		}


		/// <summary>0C8h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber_WP6
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0C8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0C8 ); }
		}

		/// <summary>0CCh 4バイト 目標ポインタ 目標タイプにより参照するデータが異なる</summary>
		public UInt32 PtrMokuhyou_WP6
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0CC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0CC ); }
		}

		/// <summary>0D0h 4バイト 目標タイプ(3:拠点、4:部隊、17:要所)</summary>
		public Int32 MokuhyouTypeID_WP6
		{
			get { return BitConverter.ToInt32( this._rec, 0x0D0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D0 ); }
		}

		/// <summary>0D4h 2バイト 数値</summary>
		public Int16 B2_WP6_1
		{
			get { return BitConverter.ToInt16( this._rec, 0x0D4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D4 ); }
		}

		/// <summary>0D6h 2バイト 数値</summary>
		public Int16 B2_WP6_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x0D6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D6 ); }
		}


		/// <summary>0D8h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber_WP7
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0D8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D8 ); }
		}

		/// <summary>0DCh 4バイト 目標ポインタ 目標タイプにより参照するデータが異なる</summary>
		public UInt32 PtrMokuhyou_WP7
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0DC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0DC ); }
		}

		/// <summary>0E0h 4バイト 目標タイプ(3:拠点、4:部隊、17:要所)</summary>
		public Int32 MokuhyouTypeID_WP7
		{
			get { return BitConverter.ToInt32( this._rec, 0x0E0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0E0 ); }
		}

		/// <summary>0E4h 2バイト 数値</summary>
		public Int16 B2_WP7_1
		{
			get { return BitConverter.ToInt16( this._rec, 0x0E4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0E4 ); }
		}

		/// <summary>0E6h 2バイト 数値</summary>
		public Int16 B2_WP7_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x0E6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0E6 ); }
		}


		/// <summary>0E8h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber_WP8
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0E8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0E8 ); }
		}

		/// <summary>0ECh 4バイト 目標ポインタ 目標タイプにより参照するデータが異なる</summary>
		public UInt32 PtrMokuhyou_WP8
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0EC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0EC ); }
		}

		/// <summary>0F0h 4バイト 目標タイプ(3:拠点、4:部隊、17:要所)</summary>
		public Int32 MokuhyouTypeID_WP8
		{
			get { return BitConverter.ToInt32( this._rec, 0x0F0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0F0 ); }
		}

		/// <summary>0F4h 2バイト 数値</summary>
		public Int16 B2_WP8_1
		{
			get { return BitConverter.ToInt16( this._rec, 0x0F4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0F4 ); }
		}

		/// <summary>0F6h 2バイト 数値</summary>
		public Int16 B2_WP8_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x0F6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0F6 ); }
		}


		/// <summary>0F8h 2バイト 最大兵数</summary>
		public Int16 HeisuuMax
		{
			get { return BitConverter.ToInt16( this._rec, 0x0F8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0F8 ); }
		}

		/// <summary>0FAh 1バイト 兵糧日数</summary>
		public Byte HyourouNissuu
		{
			get { return this._rec[0x0FA]; }
			set { this._rec[0x0FA] = value; }
		}

		/// <summary>0FBh 1バイト 0固定？</summary>
		public Byte h0FB
		{
			get { return this._rec[0x0FB]; }
			set { this._rec[0x128] = value; }
		}

		// 0FC~0FFh の4バイトはビットフラグぽい

		/// <summary>0FCh 1バイト ビットフラグ？</summary>
		public Byte h0FC
		{
			get { return this._rec[0x0FC]; }
			set { this._rec[0x0FC] = value; }
		}

		/// <summary>0FDh 1バイト ビットフラグ？</summary>
		public Byte h0FD
		{
			get { return this._rec[0x0FD]; }
			set { this._rec[0x0FD] = value; }
		}

		/// <summary>0FEh 1バイト ビットフラグ？</summary>
		public Byte h0FE
		{
			get { return this._rec[0x0FE]; }
			set { this._rec[0x0FE] = value; }
		}

		/// <summary>0FFh bit0</summary>
		public Boolean h0FF_b0
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x0FC, 24 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x0FC, 24 ); }
		}

		/// <summary>0FFh bit1</summary>
		public Boolean h0FF_b1
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x0FC, 25 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x0FC, 25 ); }
		}

		/// <summary>0FFh bit2</summary>
		public Boolean h0FF_b2
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x0FC, 26 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x0FC, 26 ); }
		}

		/// <summary>0FFh bit3</summary>
		public Boolean h0FF_b3
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x0FC, 27 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x0FC, 27 ); }
		}

		/// <summary>0FFh bit4 軍馬配備フラグ</summary>
		public Boolean HasGunba
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x0FC, 28 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x0FC, 28 ); }
		}

		/// <summary>0FFh bit5 鉄砲配備フラグ</summary>
		public Boolean HasTeppou
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x0FC, 29 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x0FC, 29 ); }
		}

		/// <summary>0FFh bit6</summary>
		public Boolean h0FF_b6
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x0FC, 30 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x0FC, 30 ); }
		}

		/// <summary>0FFh bit7</summary>
		public Boolean h0FF_b7
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x0FC, 31 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x0FC, 31 ); }
		}


		/// <summary>100h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber_100
		{
			get { return BitConverter.ToUInt32( this._rec, 0x100 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x100 ); }
		}

		/// <summary>104h 4バイト 数値</summary>
		public Int32 h104_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x104 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x104 ); }
		}

		/// <summary>108h 4バイト ポインタ</summary>
		public UInt32 Ptr_108
		{
			get { return BitConverter.ToUInt32( this._rec, 0x108 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x108 ); }
		}

		/// <summary>10Ch 4バイト ポインタ</summary>
		public UInt32 Ptr_10C
		{
			get { return BitConverter.ToUInt32( this._rec, 0x10C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x10C ); }
		}

		/// <summary>110h 4バイト</summary>
		public Int32 h110_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x110 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x110 ); }
		}

		/// <summary>114h 4バイト</summary>
		public Int32 h114_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x114 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x114 ); }
		}

		/// <summary>118h 4バイト ポインタ</summary>
		public UInt32 Ptr_118
		{
			get { return BitConverter.ToUInt32( this._rec, 0x118 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x118 ); }
		}

		/// <summary>11Ch 4バイト 数値</summary>
		public Int32 h11C_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x11C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x11C ); }
		}

		/// <summary>120h 4バイト</summary>
		public Int32 h120_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x120 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x120 ); }
		}

		/// <summary>124h 4バイト ポインタ</summary>
		public UInt32 Ptr_124
		{
			get { return BitConverter.ToUInt32( this._rec, 0x124 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x124 ); }
		}

		/// <summary>128h 4バイト 数値</summary>
		public Int32 h128_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x128 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x128 ); }
		}

		/// <summary>12Ch 4バイト</summary>
		public Int32 h12C_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x12C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x12C ); }
		}

		/// <summary>130h 4バイト</summary>
		public Int32 h130_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x130 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x130 ); }
		}

		/// <summary>134h 4バイト 目標ポインタ3
		/// <para>データテーブルの範囲外(目標タイプが要所の場合)のものもある(リストポインタか？)</para></summary>
		public UInt32 PtrMokuhyou3
		{
			get { return BitConverter.ToUInt32( this._rec, 0x134 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x134 ); }
		}

		/// <summary>138h 4バイト 目標タイプ(3:拠点、4:部隊、17:要所)</summary>
		public Int32 MokuhyouTypeID3
		{
			get { return BitConverter.ToInt32( this._rec, 0x138 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x138 ); }
		}


		/// <summary>13Ch 4バイト</summary>
		public UInt32 h13C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x13C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x13C ); }
		}

		/// <summary>140h 4バイト</summary>
		public UInt32 h140_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x140 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x140 ); }
		}

		/// <summary>144h 4バイト</summary>
		public UInt32 h144_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x144 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x144 ); }
		}

		/// <summary>148h 4バイト</summary>
		public UInt32 h148_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x148 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x148 ); }
		}

		/// <summary>14Ch 4バイト</summary>
		public UInt32 h14C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x14C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x14C ); }
		}

		/// <summary>150h 4バイト</summary>
		public UInt32 h150_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x150 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x150 ); }
		}

		/// <summary>154h 4バイト</summary>
		public UInt32 h154_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x154 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x154 ); }
		}

		/// <summary>158h 4バイト</summary>
		public UInt32 h158_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x158 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x158 ); }
		}

		/// <summary>15Ch 4バイト</summary>
		public UInt32 h15C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x15C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x15C ); }
		}

		/// <summary>160h 4バイト</summary>
		public UInt32 h160_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x160 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x160 ); }
		}

		/// <summary>164h 4バイト</summary>
		public UInt32 h164_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x164 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x164 ); }
		}

		/// <summary>168h 4バイト</summary>
		public UInt32 h168_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x168 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x168 ); }
		}

		/// <summary>16Ch 4バイト</summary>
		public UInt32 h16C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x16C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x16C ); }
		}

		/// <summary>170h 4バイト</summary>
		public UInt32 h170_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x170 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x170 ); }
		}

		/// <summary>174h 4バイト</summary>
		public UInt32 h174_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x174 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x174 ); }
		}

		/// <summary>178h 4バイト</summary>
		public UInt32 h178_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x178 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x178 ); }
		}

		/// <summary>17Ch 4バイト</summary>
		public UInt32 h17C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x17C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x17C ); }
		}

		/// <summary>180h 4バイト</summary>
		public UInt32 h180_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x180 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x180 ); }
		}

		/// <summary>184h 4バイト</summary>
		public UInt32 h184_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x184 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x184 ); }
		}

		/// <summary>188h 4バイト</summary>
		public UInt32 h188_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x188 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x188 ); }
		}

		/// <summary>18Ch 4バイト</summary>
		public UInt32 h18C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x18C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x18C ); }
		}

		/// <summary>190h 4バイト</summary>
		public UInt32 h190_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x190 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x190 ); }
		}

		/// <summary>194h 4バイト</summary>
		public UInt32 h194_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x194 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x194 ); }
		}

		/// <summary>198h 4バイト</summary>
		public UInt32 h198_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x198 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x198 ); }
		}

		/// <summary>19Ch 4バイト</summary>
		public UInt32 h19C_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x19C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x19C ); }
		}

		/// <summary>1A0h 4バイト</summary>
		public UInt32 h1A0_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x1A0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1A0 ); }
		}

		/// <summary>1A4h 4バイト</summary>
		public UInt32 h1A4_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x1A4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1A4 ); }
		}

		/// <summary>1A8h 4バイト</summary>
		public UInt32 h1A8_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x1A8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1A8 ); }
		}

		/// <summary>1ACh 4バイト</summary>
		public UInt32 h1AC_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x1AC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1AC ); }
		}

		/// <summary>1B0h 4バイト</summary>
		public UInt32 h1B0_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x1B0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1B0 ); }
		}

		/// <summary>1B4h 4バイト</summary>
		public UInt32 h1B4_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x1B4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1B4 ); }
		}

		/// <summary>1B8h 4バイト</summary>
		public UInt32 h1B8_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x1B8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1B8 ); }
		}

		/// <summary>1BCh 4バイト</summary>
		public UInt32 h1BC_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x1BC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1BC ); }
		}

		/// <summary>1C0h 4バイト</summary>
		public UInt32 h1C0_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x1C0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1C0 ); }
		}

		/// <summary>1C4h 4バイト</summary>
		public UInt32 h1C4_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x1C4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1C4 ); }
		}

		/// <summary>1C8h 4バイト</summary>
		public UInt32 h1C8_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x1C8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1C8 ); }
		}

		/// <summary>1CCh 4バイト</summary>
		public UInt32 h1CC_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x1CC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1CC ); }
		}

		/// <summary>1D0h 4バイト</summary>
		public UInt32 h1D0_4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x1D0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1D0 ); }
		}


		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
