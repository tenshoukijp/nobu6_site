﻿// KukakuData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
		/// <summary>区画データ</summary>
		/// <remarks><para>区画データは城データ内に10区画分存在する</para>
		/// <para>024~123h の 0x100(256)バイトは詳細不明</para></remarks>
	public class KukakuData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>城データ内でのベースポジション</summary>
		private int _base;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>000h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber1
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x000 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x000 ); }
		}

		/// <summary>004h 4バイト 城ポインタ</summary>
		public UInt32 PtrShiro1
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x004 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x004 ); }
		}

		/// <summary>008h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber2
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x008 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x008 ); }
		}

		/// <summary>00Ch 4バイト 城ポインタ</summary>
		public UInt32 PtrShiro2
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x00C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x00C ); }
		}

		/// <summary>010h 2バイト 区画ID 0~9</summary>
		public UInt16 KukakuID
		{
			get { return BitConverter.ToUInt16( this._rec, this._base + 0x010 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x010 ); }
		}

		/// <summary>012h 2バイト</summary>
		public UInt16 h012_2
		{
			get { return BitConverter.ToUInt16( this._rec, this._base + 0x012 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x011 ); }
		}

		/// <summary>014h 2バイト</summary>
		public UInt16 h014_2
		{
			get { return BitConverter.ToUInt16( this._rec, this._base + 0x014 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x014 ); }
		}

		/// <summary>016h 2バイト</summary>
		public UInt16 h016_2
		{
			get { return BitConverter.ToUInt16( this._rec, this._base + 0x016 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x016 ); }
		}

		/// <summary>018h 2バイト</summary>
		public UInt16 h018_2
		{
			get { return BitConverter.ToUInt16( this._rec, this._base + 0x018 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x018 ); }
		}

		/// <summary>01Ah 1バイト 施設ID</summary>
		public SByte ShisetsuID
		{
			get { return (sbyte)this._rec[this._base + 0x01A]; }
			set { this._rec[this._base + 0x01A] = (byte)value; }
		}

		/// <summary>01Bh 1バイト 建設中施設ID</summary>
		public SByte KensetsuchuuShisetsuID
		{
			get { return (sbyte)this._rec[this._base + 0x01B]; }
			set { this._rec[this._base + 0x01B] = (byte)value; }
		}

		/// <summary>01Ch 1バイト 区画に施設を建設済みなら 2、未建設なら -1</summary>
		public SByte h01C
		{
			get { return (sbyte)this._rec[this._base + 0x01C]; }
			set { this._rec[this._base + 0x01C] = (byte)value; }
		}

		/// <summary>01Dh 1バイト</summary>
		public Byte h01D
		{
			get { return this._rec[this._base + 0x01D]; }
			set { this._rec[this._base + 0x01D] = (byte)value; }
		}

		/// <summary>01Eh 2バイト キャプション？ X位置</summary>
		public UInt16 PosX
		{
			get { return BitConverter.ToUInt16( this._rec, this._base + 0x01E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x01E ); }
		}

		/// <summary>020h 2バイト キャプション？ Y位置</summary>
		public UInt16 PosY
		{
			get { return BitConverter.ToUInt16( this._rec, this._base + 0x020 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x020 ); }
		}

		/// <summary>022h 2バイト 0固定 未使用？</summary>
		public Int16 h022_2
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x022 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x022 ); }
		}

		// 024~123h 4バイト * 64 データ 計100h(256) 詳細不明
		#region 024~123h

		/// <summary>024h 4バイト</summary>
		public UInt32 h024_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x024 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x024 ); }
		}

		/// <summary>028h 4バイト</summary>
		public UInt32 h028_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x028 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x028 ); }
		}

		/// <summary>02Ch 4バイト</summary>
		public UInt32 h02C_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x02C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x02C ); }
		}

		/// <summary>030h 4バイト</summary>
		public UInt32 h030_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x030 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x030 ); }
		}

		/// <summary>034h 4バイト</summary>
		public UInt32 h034_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x034 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x034 ); }
		}

		/// <summary>038h 4バイト</summary>
		public UInt32 h038_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x038 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x038 ); }
		}

		/// <summary>03Ch 4バイト</summary>
		public UInt32 h03C_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x03C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x03C ); }
		}

		/// <summary>040h 4バイト</summary>
		public UInt32 h040_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x040 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x040 ); }
		}

		/// <summary>044h 4バイト</summary>
		public UInt32 h044_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x044 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x044 ); }
		}

		/// <summary>048h 4バイト</summary>
		public UInt32 h048_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x048 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x048 ); }
		}

		/// <summary>04Ch 4バイト</summary>
		public UInt32 h04C_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x04C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x04C ); }
		}

		/// <summary>050h 4バイト</summary>
		public UInt32 h050_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x050 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x050 ); }
		}

		/// <summary>054h 4バイト</summary>
		public UInt32 h054_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x054 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x054 ); }
		}

		/// <summary>058h 4バイト</summary>
		public UInt32 h058_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x058 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x058 ); }
		}

		/// <summary>05Ch 4バイト</summary>
		public UInt32 h05C_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x05C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x05C ); }
		}

		/// <summary>060h 4バイト</summary>
		public UInt32 h060_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x060 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x060 ); }
		}

		/// <summary>064h 4バイト</summary>
		public UInt32 h064_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x064 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x064 ); }
		}

		/// <summary>068h 4バイト</summary>
		public UInt32 h068_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x068 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x068 ); }
		}

		/// <summary>06Ch 4バイト</summary>
		public UInt32 h06C_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x06C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x06C ); }
		}

		/// <summary>070h 4バイト</summary>
		public UInt32 h070_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x070 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x070 ); }
		}

		/// <summary>074h 4バイト</summary>
		public UInt32 h074_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x074 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x074 ); }
		}

		/// <summary>078h 4バイト</summary>
		public UInt32 h078_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x078 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x078 ); }
		}

		/// <summary>07Ch 4バイト</summary>
		public UInt32 h07C_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x07C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x07C ); }
		}

		/// <summary>080h 4バイト</summary>
		public UInt32 h080_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x080 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x080 ); }
		}

		/// <summary>084h 4バイト</summary>
		public UInt32 h084_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x084 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x084 ); }
		}

		/// <summary>088h 4バイト</summary>
		public UInt32 h088_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x088 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x088 ); }
		}

		/// <summary>08Ch 4バイト</summary>
		public UInt32 h08C_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x08C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x08C ); }
		}

		/// <summary>090h 4バイト</summary>
		public UInt32 h090_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x090 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x090 ); }
		}

		/// <summary>094h 4バイト</summary>
		public UInt32 h094_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x094 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x094 ); }
		}

		/// <summary>098h 4バイト</summary>
		public UInt32 h098_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x098 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x098 ); }
		}

		/// <summary>09Ch 4バイト</summary>
		public UInt32 h09C_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x09C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x09C ); }
		}

		/// <summary>0A0h 4バイト</summary>
		public UInt32 h0A0_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0A0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0A0 ); }
		}

		/// <summary>0A4h 4バイト</summary>
		public UInt32 h0A4_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0A4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0A4 ); }
		}

		/// <summary>0A8h 4バイト</summary>
		public UInt32 h0A8_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0A8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0A8 ); }
		}

		/// <summary>0ACh 4バイト</summary>
		public UInt32 h0AC_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0AC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0AC ); }
		}

		/// <summary>0B0h 4バイト</summary>
		public UInt32 h0B0_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0B0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0B0 ); }
		}

		/// <summary>0B4h 4バイト</summary>
		public UInt32 h0B4_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0B4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0B4 ); }
		}

		/// <summary>0B8h 4バイト</summary>
		public UInt32 h0B8_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0B8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0B8 ); }
		}

		/// <summary>0BCh 4バイト</summary>
		public UInt32 h0BC_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0BC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0BC ); }
		}

		/// <summary>0C0h 4バイト</summary>
		public UInt32 h0C0_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0C0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0C0 ); }
		}

		/// <summary>0C4h 4バイト</summary>
		public UInt32 h0C4_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0C4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0C4 ); }
		}

		/// <summary>0C8h 4バイト</summary>
		public UInt32 h0C8_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0C8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0C8 ); }
		}

		/// <summary>0CCh 4バイト</summary>
		public UInt32 h0CC_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0CC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0CC ); }
		}

		/// <summary>0D0h 4バイト</summary>
		public UInt32 h0D0_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0D0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0D0 ); }
		}

		/// <summary>0D4h 4バイト</summary>
		public UInt32 h0D4_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0D4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0D4 ); }
		}

		/// <summary>0D8h 4バイト</summary>
		public UInt32 h0D8_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0D8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0D8 ); }
		}

		/// <summary>0DCh 4バイト</summary>
		public UInt32 h0DC_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0DC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0DC ); }
		}

		/// <summary>0E0h 4バイト</summary>
		public UInt32 h0E0_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0E0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0E0 ); }
		}

		/// <summary>0E4h 4バイト</summary>
		public UInt32 h0E4_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0E4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0E4 ); }
		}

		/// <summary>0E8h 4バイト</summary>
		public UInt32 h0E8_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0E8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0E8 ); }
		}

		/// <summary>0ECh 4バイト</summary>
		public UInt32 h0EC_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0EC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0EC ); }
		}

		/// <summary>0F0h 4バイト</summary>
		public UInt32 h0F0_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0F0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0F0 ); }
		}

		/// <summary>0F4h 4バイト</summary>
		public UInt32 h0F4_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0F4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0F4 ); }
		}

		/// <summary>0F8h 4バイト</summary>
		public UInt32 h0F8_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0F8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0F8 ); }
		}

		/// <summary>0FCh 4バイト</summary>
		public UInt32 h0FC_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x0FC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x0FC ); }
		}

		/// <summary>100h 4バイト</summary>
		public UInt32 h100_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x100 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x100 ); }
		}

		/// <summary>104h 4バイト</summary>
		public UInt32 h104_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x104 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x104 ); }
		}

		/// <summary>108h 4バイト</summary>
		public UInt32 h108_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x108 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x108 ); }
		}

		/// <summary>10Ch 4バイト</summary>
		public UInt32 h10C_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x10C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x10C ); }
		}

		/// <summary>110h 4バイト</summary>
		public UInt32 h110_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x110 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x110 ); }
		}

		/// <summary>114h 4バイト</summary>
		public UInt32 h114_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x114 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x114 ); }
		}

		/// <summary>118h 4バイト</summary>
		public UInt32 h118_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x118 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x118 ); }
		}

		/// <summary>11Ch 4バイト</summary>
		public UInt32 h11C_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x11C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x11C ); }
		}

		/// <summary>120h 4バイト</summary>
		public UInt32 h120_4
		{
			get { return BitConverter.ToUInt32( this._rec, this._base + 0x120 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x120 ); }
		}
		#endregion


		/// <summary>124h 2バイト 石高最大</summary>
		public Int16 KokudakaMax
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x124 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x124 ); }
		}

		/// <summary>126h 2バイト 商業最大</summary>
		public Int16 SyougyouMax
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x126 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x126 ); }
		}

		/// <summary>128h 2バイト 兵舎最大</summary>
		public Int16 HeisyaMax
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x128 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x128 ); }
		}

		/// <summary>12Ah 2バイト 0固定？</summary>
		public Int16 h12A_2
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x12A ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x12A ); }
		}

		/// <summary>12Ch 2バイト 0固定？</summary>
		public Int16 h12C_2
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x12C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x12C ); }
		}

		/// <summary>12Eh 2バイト 0固定？</summary>
		public Int16 h12E_2
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x12E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x12E ); }
		}

		/// <summary>130h 2バイト</summary>
		public Int16 h130_2
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x130 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x130 ); }
		}

		/// <summary>132h 2バイト 区画基本値</summary>
		public Int16 KukakuBase
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x132 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x132 ); }
		}

		/// <summary>134~135h の隣接区画フラグ(10ビット分)を配列化したもの</summary>
		public Boolean[] IsRinsetsu
		{
			get
			{
				// 配列の要素にアクセスするたびに get される
				// 要素を変更する場合は、別途配列の参照またはコピーに対して変更し配列自体を set する
				var flags = new bool[10];
				for ( uint i = 0; i < flags.Length; i++ )
				{
					flags[i] = MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, i );
				}
				return flags;
			}
			set
			{
				if ( value.Length != this.IsRinsetsu.Length ) { return; }
				for ( uint i = 0; i < value.Length; i++ )
				{
					MyBitConverter.IntoBytes( value[i], this._rec, (uint)this._base + 0x134, i );
				}
			}
		}

		/// <summary>134~135h bit0 区画1との隣接フラグ</summary>
		public Boolean Rinsetsu1
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 0 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 0 ); }
		}

		/// <summary>134~135h bit1 区画2との隣接フラグ</summary>
		public Boolean Rinsetsu2
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 1 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 1 ); }
		}

		/// <summary>134~135h bit2 区画3との隣接フラグ</summary>
		public Boolean Rinsetsu3
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 2 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 2 ); }
		}

		/// <summary>134~135h bit3 区画4との隣接フラグ</summary>
		public Boolean Rinsetsu4
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 3 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 3 ); }
		}

		/// <summary>134~135h bit4 区画5との隣接フラグ</summary>
		public Boolean Rinsetsu5
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 4 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 4 ); }
		}

		/// <summary>134~135h bit5 区画6との隣接フラグ</summary>
		public Boolean Rinsetsu6
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 5 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 5 ); }
		}

		/// <summary>134~135h bit6 区画7との隣接フラグ</summary>
		public Boolean Rinsetsu7
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 6 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 6 ); }
		}

		/// <summary>134~135h bit7 区画8との隣接フラグ</summary>
		public Boolean Rinsetsu8
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 7 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 7 ); }
		}

		/// <summary>134~135h bit8 区画9との隣接フラグ</summary>
		public Boolean Rinsetsu9
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 8 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 8 ); }
		}

		/// <summary>134~135h bit9 区画10との隣接フラグ</summary>
		public Boolean Rinsetsu10
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 9 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 9 ); }
		}
		#region 未使用

		/// <summary>134~135h bit10 未使用</summary>
		public Boolean h134_b10
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 10 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 10 ); }
		}

		/// <summary>134~135h bit11 未使用</summary>
		public Boolean h134_b11
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 11 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 11 ); }
		}

		/// <summary>134~135h bit12 未使用</summary>
		public Boolean h134_b12
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 12 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 12 ); }
		}

		/// <summary>134~135h bit13 未使用</summary>
		public Boolean h134_b13
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 13 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 13 ); }
		}

		/// <summary>134~135h bit14 未使用</summary>
		public Boolean h134_b14
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 14 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 14 ); }
		}

		/// <summary>134~135h bit15 未使用</summary>
		public Boolean h134_b15
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x134, 15 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x134, 15 ); }
		}
		#endregion


		/// <summary>136h 2バイト</summary>
		public Int16 h136_2
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x136 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x136 ); }
		}

		/// <summary>138h 2バイト 100になると建設可能になる？</summary>
		public Int16 h138_2
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x138 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x138 ); }
		}

		/// <summary>13Ah 2バイト 資源ID(施設ID)</summary>
		public Int16 ShigenID
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x13A ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x13A ); }
		}

		/// <summary>13Ch 2バイト</summary>
		public Int16 h13C_2
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x13C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x13C ); }
		}

		/// <summary>13Eh 2バイト 何かのX位置</summary>
		public UInt16 PosX2
		{
			get { return BitConverter.ToUInt16( this._rec, this._base + 0x13E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x13E ); }
		}

		/// <summary>140h 2バイト 何かのY位置</summary>
		public UInt16 PosY2
		{
			get { return BitConverter.ToUInt16( this._rec, this._base + 0x140 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x140 ); }
		}

		/// <summary>142h 2バイト</summary>
		public Int16 h142_2
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x142 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x142 ); }
		}

		/// <summary>144h 2バイト</summary>
		public Int16 h144_2
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x144 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x144 ); }
		}

		/// <summary>146h 2バイト</summary>
		public Int16 h146_2
		{
			get { return BitConverter.ToInt16( this._rec, this._base + 0x146 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, this._base + 0x146 ); }
		}

		// 148~14Bh の4バイトは32ビットデータとして使用

		/// <summary>148h bit0~4 5ビット 石高ランク基本値 0~17</summary>
		public Int32 KokudakaRankBase
		{
			get { return MyBitConverter.ToInt32( this._rec, (uint)this._base + 0x148, 0, 5 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x148, 0, 5 ); }
		}

		/// <summary>148h bit5~9 5ビット 商業ランク基本値 0~17</summary>
		public Int32 SyougyouRankBase
		{
			get { return MyBitConverter.ToInt32( this._rec, (uint)this._base + 0x148, 5, 5 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x148, 5, 5 ); }
		}

		/// <summary>148h bit10~14 5ビッ 兵舎ランク基本値 0~17</summary>
		public Int32 HeisyaRankBase
		{
			get { return MyBitConverter.ToInt32( this._rec, (uint)this._base + 0x148, 10, 5 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x148, 10, 5 ); }
		}

		/// <summary>148h bit15~19 5ビット 石高ランク補正値 0~17</summary>
		public Int32 KokudakaRankHosei
		{
			get { return MyBitConverter.ToInt32( this._rec, (uint)this._base + 0x148, 15, 5 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x148, 15, 5 ); }
		}

		/// <summary>148h bit20~24 5ビット 商業ランク補正値 0~17</summary>
		public Int32 SyougyouRankHosei
		{
			get { return MyBitConverter.ToInt32( this._rec, (uint)this._base + 0x148, 20, 5 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x148, 20, 5 ); }
		}

		/// <summary>148h bit25~29 5ビット 兵舎ランク補正値 0~17</summary>
		public Int32 HeisyaRankHosei
		{
			get { return MyBitConverter.ToInt32( this._rec, (uint)this._base + 0x148, 25, 5 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x148, 25, 5 ); }
		}

		/// <summary>148h bit30 有効な区画フラグ？</summary>
		public Boolean h148_b30
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x148, 30 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x148, 30 ); }
		}

		/// <summary>148h bit31 拡張済みフラグ？</summary>
		public Boolean IsKakuchouzumi
		{
			get { return MyBitConverter.ToBoolean( this._rec, (uint)this._base + 0x148, 31 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, (uint)this._base + 0x148, 31 ); }
		}

		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}

		/// <summary>城データ内でのベースポジションをセット</summary>
		/// <param name="baseposition">城データ先頭からのオフセット</param>
		public void SetBase( int baseposition )
		{
			this._base = baseposition;
		}

	}
}
