﻿// ShiroNameData.cs

using System;

using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>城名データ</summary>
	public class ShiroNameData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>00h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00 ); }
		}

		/// <summary>04~10h 13 バイト 城名(シフトJIS Nullターミネイト)</summary>
		public String Name
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x04, 13 ); }
			set { MyTextConverter.StringToBytes( value, 13 ).CopyTo( this._rec, 0x04 ); }
		}

		/// <summary>11~2Fh 31 バイト 城名読み(シフトJIS Nullターミネイト)</summary>
		public String Yomi
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x11, 31 ); }
			set { MyTextConverter.StringToBytes( value, 31 ).CopyTo( this._rec, 0x11 ); }
		}

		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
