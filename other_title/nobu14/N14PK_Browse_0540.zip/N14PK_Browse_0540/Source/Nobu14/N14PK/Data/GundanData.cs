﻿// GundanData.cs

using System;

namespace N14PKLibrary.Data
{
	/// <summary>軍団データ</summary>
	/// <remarks>074~127h の 0xB4(180)バイト は未解析でプロパティ化していない</remarks>
	public class GundanData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>00h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00 ); }
		}

		/// <summary>04h 4バイト 方針ポインタ</summary>
		public UInt32 PtrHoushin
		{
			get { return BitConverter.ToUInt32( this._rec, 0x04 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x04 ); }
		}

		/// <summary>08h 4バイト 城リスト1(2ポインタタイプ)</summary>
		public UInt32 PtrShiroList1
		{
			get { return BitConverter.ToUInt32( this._rec, 0x08 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x08 ); }
		}

		/// <summary>0Ch 4バイト リストカウンタ</summary>
		public Int32 CntShiroList1
		{
			get { return BitConverter.ToInt32( this._rec, 0x0C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0C ); }
		}

		/// <summary>10h 4バイト 0固定？</summary>
		public Int32 h10_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x10 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x10 ); }
		}

		/// <summary>14h 4バイト 城リスト2(2ポインタタイプ)</summary>
		public UInt32 PtrShiroList2
		{
			get { return BitConverter.ToUInt32( this._rec, 0x14 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x14 ); }
		}

		/// <summary>18h 4バイト リストカウンタ</summary>
		public Int32 CntShiroList2
		{
			get { return BitConverter.ToInt32( this._rec, 0x18 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x18 ); }
		}

		/// <summary>1Ch 4バイト 0固定？</summary>
		public Int32 h1C_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x1C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x1C ); }
		}

		/// <summary>20h 4バイト 軍団長武将ポインタ</summary>
		public UInt32 PtrGundanchou
		{
			get { return BitConverter.ToUInt32( this._rec, 0x20 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x20 ); }
		}

		/// <summary>24h 4バイト 本拠ポインタ(直轄範囲外軍団とCOM軍団は 0 )</summary>
		public UInt32 PtrHonkyo
		{
			get { return BitConverter.ToUInt32( this._rec, 0x24 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x24 ); }
		}

		/// <summary>28h 4バイト 勢力ポインタ</summary>
		public UInt32 PtrSeiryoku
		{
			get { return BitConverter.ToUInt32( this._rec, 0x28 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x28 ); }
		}

		/// <summary>2Ch 4バイト 0固定？</summary>
		public Int32 h2C_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x2C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2C ); }
		}

		/// <summary>40h 4バイト 勢力ポインタ2 この勢力の意味は？ 値が入る状況は？</summary>
		public UInt32 PtrSeiryoku2
		{
			get { return BitConverter.ToUInt32( this._rec, 0x40 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x40 ); }
		}

		/// <summary>44h 4バイト 金銭</summary>
		public Int32 Kinsen
		{
			get { return BitConverter.ToInt32( this._rec, 0x44 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x44 ); }
		}

		/// <summary>48h 4バイト 兵糧</summary>
		public Int32 Hyourou
		{
			get { return BitConverter.ToInt32( this._rec, 0x48 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x48 ); }
		}

		/// <summary>4Ch 4バイト 鉄砲</summary>
		public Int32 Teppou
		{
			get { return BitConverter.ToInt32( this._rec, 0x4C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x4C ); }
		}

		/// <summary>50h 4バイト 軍馬</summary>
		public Int32 Gunba
		{
			get { return BitConverter.ToInt32( this._rec, 0x50 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x50 ); }
		}

		/// <summary>54h 4バイト 労力</summary>
		public Int32 Rouryoku
		{
			get { return BitConverter.ToInt32( this._rec, 0x54 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x54 ); }
		}

		/// <summary>58h 4バイト</summary>
		public Int32 h58_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x58 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x58 ); }
		}

		/// <summary>5Ch 4バイト 支配城リスト(2ポインタタイプ)</summary>
		public UInt32 PtrShihaiShiroList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x5C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x5C ); }
		}

		/// <summary>60h 4バイト リストカウンタ</summary>
		public Int32 CntShihaiShiroList
		{
			get { return BitConverter.ToInt32( this._rec, 0x60 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x60 ); }
		}

		/// <summary>64h 4バイト 0固定？</summary>
		public Int32 h64_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x64 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x64 ); }
		}

		/// <summary>68h 4バイト 武将リスト(2ポインタタイプ) 改修と設営実行時にデータが入っていたのを確認</summary>
		public UInt32 PtrBusyouList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x68 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x68 ); }
		}

		/// <summary>6Ch 4バイト リストカウンタ</summary>
		public Int32 CntBusyouList
		{
			get { return BitConverter.ToInt32( this._rec, 0x6C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x6C ); }
		}

		/// <summary>70h 4バイト 0固定？</summary>
		public Int32 h70_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x70 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x70 ); }
		}
		// 74~127h 180バイト 未解析


		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
