﻿// SeiryokuData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>勢力データ</summary>
	/// <remarks><para>0028~00BFh 0x98(152)バイト 未解析</para>
	/// <para>0158~051Fh 0x3C8(968)バイト 0固定？</para>
	/// <para>10D8~10EFh 0x18(24)バイト 未解析</para>
	/// <para>1174~11C7 0x54(84)バイト 未解析</para>
	/// <para>12C6~12D3 0x0E(14)バイト 未解析</para>
	/// <para>12DC~12FB 0x20(32)バイト 未解析</para>
	/// <para>上記箇所はプロパティ化していない</para></remarks>
	public class SeiryokuData : IData
	{
		/// <summary>外交データ(勢力データ内に勢力数分存在する)</summary>
		public class GaikouData
		{
			private SeiryokuData _seiryoku;
			private Int32 _offset;

			/// <summary>ID</summary>
			public Int32 ID { get; private set; }

			/// <summary>00h 4バイト 婚姻同盟対象の武将ポインタ</summary>
			public UInt32 PtrKoninBusyou	// 00h 4バイト ID勢力の婚姻武将ポインタ
			{
				get { return BitConverter.ToUInt32( this._seiryoku._rec, this._offset + 0x00 ); }
				set { BitConverter.GetBytes( value ).CopyTo( this._seiryoku._rec, this._offset + 0x00 ); }
			}

			/// <summary>04h 1バイト 信用値</summary>
			public SByte Shinyou			// 04h 1バイト ID勢力に対する信用値
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x04]; }
				set { this._seiryoku._rec[this._offset + 0x04] = (byte)value; }
			}

			/// <summary>05h 1バイト 不明</summary>
			public SByte h05				// 05h 1バイト
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x05]; }
				set { this._seiryoku._rec[this._offset + 0x05] = (byte)value; }
			}

			/// <summary>06h 1バイト 不明</summary>
			public SByte h06				// 06h 1バイト
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x06]; }
				set { this._seiryoku._rec[this._offset + 0x06] = (byte)value; }
			}

			/// <summary>07h 1バイト 不明</summary>
			public SByte h07				// 07h 1バイト
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x07]; }
				set { this._seiryoku._rec[this._offset + 0x07] = (byte)value; }
			}

			/// <summary>08h 1バイト 不明</summary>
			public SByte h08				// 08h 1バイト
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x08]; }
				set { this._seiryoku._rec[this._offset + 0x04] = (byte)value; }
			}

			/// <summary>09h 1バイト 不明</summary>
			public SByte h09				// 09h 1バイト
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x09]; }
				set { this._seiryoku._rec[this._offset + 0x09] = (byte)value; }
			}

			/// <summary>0Ah 1バイト 不明</summary>
			public SByte h0A				// 0Ah 1バイト
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x0A]; }
				set { this._seiryoku._rec[this._offset + 0x0A] = (byte)value; }
			}

			/// <summary>0Bh 1バイト 不明</summary>
			public SByte h0B				// 0Bh 1バイト
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x0B]; }
				set { this._seiryoku._rec[this._offset + 0x0B] = (byte)value; }
			}

			/// <summary>0Ch 1バイト 不明</summary>
			public SByte h0C				// 0Ch 1バイト
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x0C]; }
				set { this._seiryoku._rec[this._offset + 0x0C] = (byte)value; }
			}

			/// <summary>0Dh 1バイト 不明</summary>
			public SByte h0D				// 0Dh 1バイト
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x0D]; }
				set { this._seiryoku._rec[this._offset + 0x0D] = (byte)value; }
			}

			/// <summary>0Eh 1バイト 不明</summary>
			public SByte h0E				// 0Eh 1バイト
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x0E]; }
				set { this._seiryoku._rec[this._offset + 0x0E] = (byte)value; }
			}

			/// <summary>0Fh 1バイト 不明</summary>
			public SByte h0F				// 0Fh 1バイト
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x0F]; }
				set { this._seiryoku._rec[this._offset + 0x0F] = (byte)value; }
			}

			/// <summary>10h 1バイト 不明</summary>
			public SByte h10				// 10h 1バイト
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x10]; }
				set { this._seiryoku._rec[this._offset + 0x10] = (byte)value; }
			}

			/// <summary>11h 1バイト 不明</summary>
			public SByte h11				// 11h 1バイト
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x11]; }
				set { this._seiryoku._rec[this._offset + 0x11] = (byte)value; }
			}

			/// <summary>12h 1バイト 不明</summary>
			public SByte h12				// 12h 1バイト
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x12]; }
				set { this._seiryoku._rec[this._offset + 0x12] = (byte)value; }
			}

			/// <summary>13h 1バイト 不明</summary>
			public SByte h13				// 13h 1バイト
			{
				get { return (sbyte)this._seiryoku._rec[this._offset + 0x13]; }
				set { this._seiryoku._rec[this._offset + 0x13] = (byte)value; }
			}

			///// <summary>14h 1バイト 不明</summary>
			//public SByte h14				// 14h 1バイト
			//{
			//	get { return (sbyte)this._seiryoku._rec[this._offset + 0x14]; }
			//	set { this._seiryoku._rec[this._offset + 0x14] = (byte)value; }
			//}

			///// <summary>15h 1バイト 不明</summary>
			//public SByte h15				// 15h 1バイト
			//{
			//	get { return (sbyte)this._seiryoku._rec[this._offset + 0x15]; }
			//	set { this._seiryoku._rec[this._offset + 0x15] = (byte)value; }
			//}

			///// <summary>16h 1バイト 不明</summary>
			//public SByte h16				// 16h 1バイト
			//{
			//	get { return (sbyte)this._seiryoku._rec[this._offset + 0x16]; }
			//	set { this._seiryoku._rec[this._offset + 0x16] = (byte)value; }
			//}

			///// <summary>17h 1バイト 不明</summary>
			//public SByte h17				// 17h 1バイト
			//{
			//	get { return (sbyte)this._seiryoku._rec[this._offset + 0x17]; }
			//	set { this._seiryoku._rec[this._offset + 0x17] = (byte)value; }
			//}

			/// <summary>コンストラクタ</summary>
			/// <param name="seiryoku">勢力データ</param>
			/// <param name="id">外交データID</param>
			public GaikouData( SeiryokuData seiryoku, Int32 id )
			{
				this._seiryoku = seiryoku;
				this.ID = id;
				this._offset = SeiryokuData._OffsetGaikouData + SeiryokuData._SizeOfGaikouData * id;
			}
		}

		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>外交データオフセット</summary>
		private const Int32 _OffsetGaikouData = 0x0568;

		/// <summary>外交データサイズ</summary>
		private const Int32 _SizeOfGaikouData = 20;

		/// <summary>勢力数</summary>
		private const Int32 _SeiryokuCount = 120;

		/// <summary>特性データ数</summary>
		private const Int32 _TokuseiCount = 247;

		/// <summary>伝授特性データオフセット</summary>
		private const Int32 _OffsetDenjuTokusei = 0x0FEC;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }

		/// <summary>0000h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0000 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0000 ); }
		}

		/// <summary>0004~0010h 13バイト 名(シフトJIS nullターミネイト)</summary>
		public String Name
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x0004, 13 ); }
			set { MyTextConverter.StringToBytes( value, 13 ).CopyTo( this._rec, 0x0004 ); }
		}

		/// <summary>0011~0027h 23バイト 読み(シフトJIS nullターミネイト)</summary>
		public String Yomi
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x0011, 23 ); }
			set { MyTextConverter.StringToBytes( value, 23 ).CopyTo( this._rec, 0x0011 ); }
		}

		// 0028~00BFh 0x98(152)バイト 未解析 フラグっぽいものが散見される

		/// <summary>00C0h 4バイト 固有政策ポインタ 勢力の血族ID、または政策側の血族IDをあわせる必要がある</summary>
		public UInt32 PtrKoyuuSeisaku
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00C0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00C0 ); }
		}

		/// <summary>00C4h 4バイト ポインタ メモリでは勢力データと軍団データの間</summary>
		public UInt32 Ptr_00C4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00C4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00C4 ); }
		}

		/// <summary>00C8h 4バイト ポインタ Ptr_00CC と同値？ メモリでは勢力データと軍団データの間</summary>
		public UInt32 Ptr_00C8
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00C8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00C8 ); }
		}

		/// <summary>00CCh 4バイト ポインタ Ptr_00C8 と同値？</summary>
		public UInt32 Ptr_00CC
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00CC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00CC ); }
		}

		/// <summary>00D0h 4バイト</summary>
		public Int32 h00D0_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x00D0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00D0 ); }
		}

		/// <summary>00D4h 4バイト 軍団リスト(2ポインタタイプ)</summary>
		public UInt32 PtrGundanList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00D4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00D4 ); }
		}

		/// <summary>00D8h 4バイト リストカウンタ</summary>
		public Int32 CntGundanList
		{
			get { return BitConverter.ToInt32( this._rec, 0x00D8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00D8 ); }
		}

		/// <summary>00DCh 4バイト 0固定？</summary>
		public Int32 h00DC_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x00DC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00DC ); }
		}


		/// <summary>00E0h 4バイト 成人前武将リスト(2ポインタタイプ)</summary>
		public UInt32 PtrSeijinmaeList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00E0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00E0 ); }
		}

		/// <summary>00E4h 4バイト リストカウンタ</summary>
		public Int32 CntSeijinmaeList
		{
			get { return BitConverter.ToInt32( this._rec, 0x00E4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00E4 ); }
		}

		/// <summary>00E8h 4バイト 0固定？</summary>
		public Int32 h00E8_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x00E8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00E8 ); }
		}

		/// <summary>00ECh 4バイト リスト(2ポインタタイプ)</summary>
		public UInt32 PtrList_00EC
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00EC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00EC ); }
		}

		/// <summary>00F0h 4バイト リストカウンタ</summary>
		public Int32 CntList_00EC
		{
			get { return BitConverter.ToInt32( this._rec, 0x00F0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00F0 ); }
		}

		/// <summary>00F4h 4バイト 0固定？</summary>
		public Int32 h00F4_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x00F4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00F4 ); }
		}


		/// <summary>00F8h 4バイト リスト(2ポインタタイプ)</summary>
		public UInt32 PtrList_00F8
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00F8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00F8 ); }
		}

		/// <summary>00FCh 4バイト リストカウンタ</summary>
		public Int32 CntList_00F8
		{
			get { return BitConverter.ToInt32( this._rec, 0x00FC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00FC ); }
		}

		/// <summary>0100h 4バイト 0固定？</summary>
		public Int32 h0100_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0100 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0100 ); }
		}

		/// <summary>0104h 4バイト 姫リスト(2ポインタタイプ)</summary>
		public UInt32 PtrHimeList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0104 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0104 ); }
		}

		/// <summary>0108h 4バイト リストカウンタ</summary>
		public Int32 CntHimeList
		{
			get { return BitConverter.ToInt32( this._rec, 0x0108 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0108 ); }
		}

		/// <summary>010Ch 4バイト 0固定？</summary>
		public Int32 h010C_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x010C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x010C ); }
		}

		/// <summary>0110h 4バイト</summary>
		public Int32 h0110_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0110 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0110 ); }
		}

		/// <summary>0114h 4バイト 同盟勢力リスト(3ポインタタイプ)</summary>
		public UInt32 PtrDoumeiList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0114 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0114 ); }
		}

		/// <summary>0118h 4バイト リストカウンタ</summary>
		public Int32 CntDoumeiList
		{
			get { return BitConverter.ToInt32( this._rec, 0x0118 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0118 ); }
		}

		/// <summary>011Ch 4バイト 0固定？</summary>
		public Int32 h011C_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x011C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x011C ); }
		}

		/// <summary>0120h 4バイト</summary>
		public Int32 h0120_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0120 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0120 ); }
		}

		/// <summary>0124h 4バイト 停戦勢力リスト(3ポインタタイプ)</summary>
		public UInt32 PtrTeisenList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0124 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0124 ); }
		}

		/// <summary>0128h 4バイト リストカウンタ</summary>
		public Int32 CntTeisenList
		{
			get { return BitConverter.ToInt32( this._rec, 0x0128 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0128 ); }
		}

		/// <summary>012Ch 4バイト 0固定？</summary>
		public Int32 h012C_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x012C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x012C ); }
		}

		/// <summary>0130h 4バイト 家宝リスト(2ポインタタイプ)</summary>
		public UInt32 PtrKahouList
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0130 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0130 ); }
		}

		/// <summary>0134h 4バイト リストカウンタ</summary>
		public Int32 CntKahouList
		{
			get { return BitConverter.ToInt32( this._rec, 0x0134 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0134 ); }
		}

		/// <summary>0138h 4バイト 0固定？</summary>
		public Int32 h0138_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0138 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0138 ); }
		}

		/// <summary>013Ch 4バイト 当主ポインタ</summary>
		public UInt32 PtrTousyu
		{
			get { return BitConverter.ToUInt32( this._rec, 0x013C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x013C ); }
		}

		/// <summary>0140h 4バイト 0x00 / 0x01 / 0xFF</summary>
		public Int32 h0140_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0140 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0140 ); }
		}

		/// <summary>0144h 4バイト 家紋ID</summary>
		public Int32 KamonID
		{
			get { return BitConverter.ToInt32( this._rec, 0x0144 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0144 ); }
		}

		/// <summary>0148h 4バイト 何かのIDか？</summary>
		public Int32 h0148_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0148 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0148 ); }
		}

		/// <summary>014Ch 4バイト 何かのIDか？</summary>
		public Int32 h014C_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x014C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x014C ); }
		}

		/// <summary>0150h 4バイト 血族ID</summary>
		public Int32 KetsuzokuID
		{
			get { return BitConverter.ToInt32( this._rec, 0x0150 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0150 ); }
		}

		/// <summary>0154h 4バイト 従属先勢力ポインタ</summary>
		public UInt32 PtrJuuzokuSeiryoku
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0154 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0154 ); }
		}

		// 0158~051Fh 0x3C8(968)バイト 0固定？

		/// <summary>0520h 4バイト 勢力リスト(3ポインタタイプ)</summary>
		public UInt32 PtrSeiryokuList_0520
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0520 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0520 ); }
		}

		/// <summary>0524h 4バイト リストカウンタ</summary>
		public Int32 CntSeiryokuList_0520
		{
			get { return BitConverter.ToInt32( this._rec, 0x0524 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0524 ); }
		}

		/// <summary>0528h 4バイト 0固定？</summary>
		public Int32 h0528_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0528 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0528 ); }
		}

		/// <summary>052Ch 4バイト</summary>
		public Int32 h052C_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x052C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x052C ); }
		}

		/// <summary>0530h 4バイト 勢力リスト(3ポインタタイプ)</summary>
		public UInt32 PtrSeiryokuList_0530 
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0530 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0530 ); }
		}

		/// <summary>0534h 4バイト リストカウンタ</summary>
		public Int32 CntSeiryokuList_0530
		{
			get { return BitConverter.ToInt32( this._rec, 0x0534 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0534 ); }
		}

		/// <summary>0538h 4バイト 0固定？</summary>
		public Int32 h0538_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0538 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0538 ); }
		}

		// 日時データ * 4

		/// <summary>053Ch 2バイト 年1</summary>
		public Int16 Year1
		{
			get { return BitConverter.ToInt16( this._rec, 0x053C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x053C ); }
		}

		/// <summary>053Eh 1バイト 月1</summary>
		public SByte Month1
		{
			get { return (sbyte)this._rec[0x053E]; }
			set { this._rec[0x053E] = (byte)value; }
		}

		/// <summary>053Fh 1バイト 日1</summary>
		public SByte Day1
		{
			get { return (sbyte)this._rec[0x053F]; }
			set { this._rec[0x053F] = (byte)value; }
		}

		/// <summary>0540h 2バイト 時1</summary>
		public Int16 Hour1
		{
			get { return BitConverter.ToInt16( this._rec, 0x0540 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0540 ); }
		}

		/// <summary>0542h 2バイト 年2</summary>
		public Int16 Year2
		{
			get { return BitConverter.ToInt16( this._rec, 0x0542 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0542 ); }
		}

		/// <summary>0544h 1バイト 月2</summary>
		public SByte Month2
		{
			get { return (sbyte)this._rec[0x0544]; }
			set { this._rec[0x0544] = (byte)value; }
		}

		/// <summary>0545h 1バイト 日2</summary>
		public SByte Day2
		{
			get { return (sbyte)this._rec[0x0545]; }
			set { this._rec[0x0545] = (byte)value; }
		}

		/// <summary>0546h 2バイト 時2</summary>
		public Int16 Hour2
		{
			get { return BitConverter.ToInt16( this._rec, 0x0546 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0546 ); }
		}

		/// <summary>0548h 2バイト 年3</summary>
		public Int16 Year3
		{
			get { return BitConverter.ToInt16( this._rec, 0x0548 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0548 ); }
		}

		/// <summary>054Ah 1バイト 月3</summary>
		public SByte Month3
		{
			get { return (sbyte)this._rec[0x054A]; }
			set { this._rec[0x054A] = (byte)value; }
		}

		/// <summary>054Bh 1バイト 日3</summary>
		public SByte Day3
		{
			get { return (sbyte)this._rec[0x054B]; }
			set { this._rec[0x054B] = (byte)value; }
		}

		/// <summary>054Ch 2バイト 時3</summary>
		public Int16 Hour3
		{
			get { return BitConverter.ToInt16( this._rec, 0x054C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x054C ); }
		}

		/// <summary>054Eh 2バイト 年4</summary>
		public Int16 Year4
		{
			get { return BitConverter.ToInt16( this._rec, 0x054E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x054E ); }
		}

		/// <summary>0550h 1バイト 月4</summary>
		public SByte Month4
		{
			get { return (sbyte)this._rec[0x0550]; }
			set { this._rec[0x0550] = (byte)value; }
		}

		/// <summary>0551h 1バイト 日4</summary>
		public SByte Day4
		{
			get { return (sbyte)this._rec[0x0551]; }
			set { this._rec[0x0551] = (byte)value; }
		}

		/// <summary>0552h 2バイト 時4</summary>
		public Int16 Hour4
		{
			get { return BitConverter.ToInt16( this._rec, 0x0552 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0552 ); }
		}

		/// <summary>0554h 4バイト 拠点ポインタ シナリオ開始時の本拠？</summary>
		public UInt32 PtrSyokiHonkyo
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0554 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0554 ); }
		}

		/// <summary>0558h 4バイト 武将ポインタ シナリオ開始時の当主？</summary>
		public UInt32 PtrSyokiTousyu
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0558 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0558 ); }
		}

		/// <summary>055Ch 1バイト</summary>
		public Byte h055C
		{
			get { return this._rec[0x04E5]; }
			set { this._rec[0x04E5] = (byte)value; }
		}

		/// <summary>055Dh 1バイト</summary>
		public Byte h055D
		{
			get { return this._rec[0x04E5]; }
			set { this._rec[0x04E5] = (byte)value; }
		}

		/// <summary>055Eh 2バイト 年5</summary>
		public Int16 Year5
		{
			get { return BitConverter.ToInt16( this._rec, 0x055E ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x055E ); }
		}

		/// <summary>0560h 1バイト 月5</summary>
		public SByte Month5
		{
			get { return (sbyte)this._rec[0x0560]; }
			set { this._rec[0x0560] = (byte)value; }
		}

		/// <summary>0561h 1バイト 日5</summary>
		public SByte Day5
		{
			get { return (sbyte)this._rec[0x0561]; }
			set { this._rec[0x0561] = (byte)value; }
		}

		/// <summary>0562h 2バイト 時5</summary>
		public Int16 Hour5
		{
			get { return BitConverter.ToInt16( this._rec, 0x0562 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0562 ); }
		}

		/// <summary>0564h 4バイト</summary>
		public Int32 h0564_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0564 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0564 ); }
		}

		// 0568~0EC7h 0x960(2400)バイト 各勢力に対する外交データ(信用や婚姻同盟対象武将など) 20バイト * 120勢力

		/// <summary>外交データ配列
		/// <para>各勢力に対する外交データ(信用や婚姻同盟対象武将など) 24バイト * 120勢力</para></summary>
		public GaikouData[] Gaikou
		{
			get
			{
				var array = new GaikouData[SeiryokuData._SeiryokuCount];
				for ( var i = 0; i < SeiryokuData._SeiryokuCount; i++ )
				{
					array[i] = new GaikouData( this, i );
				}
				return array;
			}
		}

		/// <summary>0EC8h 4バイト</summary>
		public Int32 h0EC8_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0EC8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0EC8 ); }
		}

		/// <summary>0ECCh 4バイト 勢力リスト(3ポインタタイプ)</summary>
		public UInt32 PtrSeiryokuList_0ECC
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0ECC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0ECC ); }
		}

		/// <summary>0ED0h 4バイト リストカウンタ</summary>
		public Int32 CntSeiryokuList_0ECC
		{
			get { return BitConverter.ToInt32( this._rec, 0x0ED0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0ED0 ); }
		}

		/// <summary>0ED4h 4バイト 0固定？</summary>
		public Int32 h0ED4_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0ED4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0ED4 ); }
		}

		/// <summary>0ED8h 4バイト</summary>
		public Int32 h0ED8_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0ED8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0ED8 ); }
		}

		/// <summary>0EDCh 4バイト 勢力リスト(3ポインタタイプ)</summary>
		public UInt32 PtrSeiryokuList_0EDC
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0EDC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0EDC ); }
		}

		/// <summary>0EE0h 4バイト リストカウンタ</summary>
		public Int32 CntSeiryokuList_0EDC
		{
			get { return BitConverter.ToInt32( this._rec, 0x0EE0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0EE0 ); }
		}

		/// <summary>0EE4h 4バイト 0固定？</summary>
		public Int32 h0EE4_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0EE4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0EE4 ); }
		}

		/// <summary>0EE8h 4バイト</summary>
		public Int32 h0EE8_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0EE8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0EE8 ); }
		}

		/// <summary>0EECh 4バイト 勢力リスト(3ポインタタイプ)</summary>
		public UInt32 PtrSeiryokuList_0EEC
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0EEC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0EEC ); }
		}

		/// <summary>0EF0h 4バイト リストカウンタ</summary>
		public Int32 CntSeiryokuList_0EEC
		{
			get { return BitConverter.ToInt32( this._rec, 0x0EF0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0EF0 ); }
		}

		/// <summary>0EF4h 4バイト 0固定？</summary>
		public Int32 h0EF4_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0EF4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0EF4 ); }
		}

		// 0EF8~0F09h 0x18(24)バイト 未解析

		/// <summary>0F10~0F93h 132バイト 態度(シフトJIS nullターミネイト) たぶんこんなに長くない</summary>
		public String Taido
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x0F10, 132 ); }
			set { MyTextConverter.StringToBytes( value, 132 ).CopyTo( this._rec, 0x0F10 ); }
		}

		// 0F94~0FE7 0x54(84)バイト 未解析

		/// <summary>0FE8h 2バイト 支配城総数</summary>
		public Int16 Shirosuu
		{
			get { return BitConverter.ToInt16( this._rec, 0x0FE8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0FE8 ); }
		}

		/// <summary>0FEAh 1バイト</summary>
		public Byte h0FEA
		{
			get { return this._rec[0x0FEA]; }
			set { this._rec[0x0FEA] = value; }
		}

		/// <summary>0FEBh 1バイト 本城数？ じゃないっぽい</summary>
		public Byte h0FEB
		{
			get { return this._rec[0x0FEB]; }
			set { this._rec[0x0FEB] = value; }
		}

		// 0FEC~10E3 248バイト 伝授用データ

		/// <summary>0FEC~10E2 247バイト 伝授用特性の所持数配列
		/// <para>官位は0/1のみ、役職は無視される？、左大臣・右大臣・関白も無視される？</para></summary>
		public SByte[] DenjuTokuseiArray
		{
			get
			{
				var array = new sbyte[SeiryokuData._TokuseiCount];
				for ( var i = 0; i < array.Length; i++ )
				{
					array[i] = (sbyte)this._rec[SeiryokuData._OffsetDenjuTokusei + i];
				}
				return array;
			}
			set
			{
				for ( var i = 0; i < value.Length; i++ )
				{
					this._rec[SeiryokuData._OffsetDenjuTokusei + i] = (byte)value[i];
				}
			}
		}

		/// <summary>10E3h 1バイト 0固定？ 伝授特性データのサイズ合わせか</summary>
		public Byte h10E3
		{
			get { return this._rec[0x10E3]; }
			set { this._rec[0x10E3] = value; }
		}

		/// <summary>10E4h 2バイト 創造性</summary>
		public Int16 Souzousei
		{
			get { return BitConverter.ToInt16( this._rec, 0x10E4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x10E4 ); }
		}

		// 10E6~10F3 0x0E(14)バイト 未解析

		/// <summary>10F4h 4バイト 旗ID</summary>
		public Int32 HataID
		{
			get { return BitConverter.ToInt32( this._rec, 0x10F4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x10F4 ); }
		}

		/// <summary>10F8h 4バイト 朝廷信用</summary>
		public Int32 ChouteiShinyou
		{
			get { return BitConverter.ToInt32( this._rec, 0x10F8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x10F8 ); }
		}

		// 10FC~111B 0x20(32)バイト 未解析

		// 111Ch はビットフラグ(bit1 のプレイヤー勢力フラグ以外未使用？)
		/// <summary>111Ch bit0</summary>
		public Boolean h111C_b0
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x111C, 0 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x111C, 0, 1 ); }
		}

		/// <summary>111Ch bit1 プレイヤー勢力？
		/// <para>このフラグが立っている勢力は、プレイヤーが部隊の出陣・操作可能。挙動が怪しいので触らない方がいい</para></summary>
		public Boolean IsPlayer
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x111C, 1 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x111C, 1 ); }
		}

		/// <summary>111Ch bit2</summary>
		public Boolean h111C_b2
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x111C, 2 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x111C, 2 ); }
		}

		/// <summary>111Ch bit3</summary>
		public Boolean h111C_b3
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x111C, 3 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x111C, 3 ); }
		}

		/// <summary>111Ch bit4</summary>
		public Boolean h111C_b4
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x111C, 4 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x111C, 4 ); }
		}

		/// <summary>111Ch bit5</summary>
		public Boolean h111C_b5
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x111C, 5 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x111C, 5 ); }
		}

		/// <summary>111Ch bit6</summary>
		public Boolean h111C_b6
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x111C, 6 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x111C, 6 ); }
		}

		/// <summary>111Ch bit7</summary>
		public Boolean h111C_b7
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x111C, 7 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x111C, 7 ); }
		}

		/// <summary>111Dh 1バイト</summary>
		public Byte h111D
		{
			get { return this._rec[0x111D]; }
			set { this._rec[0x111D] = value; }
		}

		/// <summary>111Eh 1バイト</summary>
		public Byte h111E
		{
			get { return this._rec[0x111E]; }
			set { this._rec[0x111E] = value; }
		}

		/// <summary>111Fh 1バイト</summary>
		public Byte h111F
		{
			get { return this._rec[0x111F]; }
			set { this._rec[0x111F] = value; }
		}

		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
