﻿// JoukakuData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>城郭データ</summary>
	public class JoukakuData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>000h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x000 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x000 ); }
		}

		/// <summary>004~00Ch 9バイト 名称(シフトJIS nullターミネイト)</summary>
		public String Name
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x004, 9 ); }
			set { MyTextConverter.StringToBytes( value, 9 ).CopyTo( this._rec, 0x004 ); }
		}

		/// <summary>00D~01Fh 19バイト 読み(シフトJIS nullターミネイト)</summary>
		public String Yomi
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x00D, 19 ); }
			set { MyTextConverter.StringToBytes( value, 19 ).CopyTo( this._rec, 0x00D ); }
		}

		/// <summary>020~048h 41バイト ヘルプ1行目(シフトJIS nullターミネイト)</summary>
		public String HelpText1
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x020, 41 ); }
			set { MyTextConverter.StringToBytes( value, 41 ).CopyTo( this._rec, 0x020 ); }
		}

		/// <summary>049~071h 41バイト ヘルプ2行目(シフトJIS nullターミネイト)</summary>
		public String HelpText2
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x049, 41 ); }
			set { MyTextConverter.StringToBytes( value, 41 ).CopyTo( this._rec, 0x049 ); }
		}

		/// <summary>072~09Ah 41バイト ヘルプ3行目(シフトJIS nullターミネイト)</summary>
		public String HelpText3
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x072, 41 ); }
			set { MyTextConverter.StringToBytes( value, 41 ).CopyTo( this._rec, 0x072 ); }
		}

		/// <summary>09B~0C3h 41バイト ヘルプ4行目 未使用(シフトJIS nullターミネイト)</summary>
		public String HelpText4
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x09B, 41 ); }
			set { MyTextConverter.StringToBytes( value, 41 ).CopyTo( this._rec, 0x09B ); }
		}


		/// <summary>0C4h 2バイト 城郭タイプID
		/// <para>0:天守、1:城門、2:塀、3:出丸、4:矢倉、5:曲輪、6:施設</para></summary>
		public Int16 JoukakuTypeID
		{
			get { return BitConverter.ToInt16( this._rec, 0x0C4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0C4 ); }
		}

		/// <summary>0C6h 2バイト 耐久</summary>
		public Int16 Taikyuu
		{
			get { return BitConverter.ToInt16( this._rec, 0x0C6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0C6 ); }
		}


		/// <summary>0C8h 2バイト</summary>
		public Int16 h0C8_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x0C8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0C8 ); }
		}

		/// <summary>0CAh 2バイト</summary>
		public Int16 h0CA_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x0CA ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0CA ); }
		}

		/// <summary>0CCh 1バイト 用地</summary>
		public Byte Youchi
		{
			get { return this._rec[0x0CC]; }
			set { this._rec[0x0CC] = value; }
		}

		/// <summary>0CDh 1バイト</summary>
		public SByte h0CD
		{
			get { return (sbyte)this._rec[0x0CD]; }
			set { this._rec[0x0CD] = (byte)value; }
		}

		/// <summary>0CEh 1バイト 0xFF固定？</summary>
		public SByte h0CE
		{
			get { return (sbyte)this._rec[0x0CE]; }
			set { this._rec[0x0CE] = (byte)value; }
		}

		/// <summary>0CFh 1バイト 0固定？</summary>
		public Byte h0CF
		{
			get { return this._rec[0x0CF]; }
			set { this._rec[0x0CF] = value; }
		}


		/// <summary>0D0h 2バイト 対包囲</summary>
		public Int16 TaiHoui
		{
			get { return BitConverter.ToInt16( this._rec, 0x0D0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D0 ); }
		}

		/// <summary>0D2h 2バイト 対強行</summary>
		public Int16 TaiKyoukou
		{
			get { return BitConverter.ToInt16( this._rec, 0x0D2 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D2 ); }
		}

		/// <summary>0D4h 2バイト 0固定？</summary>
		public Int16 h0D4_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x0D4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D4 ); }
		}

		/// <summary>0D6h 2バイト 対焼き討ち</summary>
		public Int16 TaiYakiuchi
		{
			get { return BitConverter.ToInt16( this._rec, 0x0D6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D6 ); }
		}

		/// <summary>0D8h 2バイト 0固定？</summary>
		public Int16 h0D8_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x0D8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D8 ); }
		}

		/// <summary>0DAh 2バイト 補給兵の強さ増加値</summary>
		public Int16 Hokyuuhei
		{
			get { return BitConverter.ToInt16( this._rec, 0x0DA ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0DA ); }
		}

		/// <summary>0DCh 2バイト 領民兵の強さ増加値</summary>
		public Int16 Ryouminhei
		{
			get { return BitConverter.ToInt16( this._rec, 0x0DC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0DC ); }
		}

		/// <summary>0DEh 2バイト 常備兵増加数</summary>
		public Int16 Joubihei
		{
			get { return BitConverter.ToInt16( this._rec, 0x0DE ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0DE ); }
		}

		/// <summary>0E0h 2バイト 包囲している部隊への攻撃 0:×、1:○</summary>
		public Int16 TaiHouibutai
		{
			get { return BitConverter.ToInt16( this._rec, 0x0E0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0E0 ); }
		}

		/// <summary>0E2h 2バイト 必要石高</summary>
		public Int16 HituyouKokudaka
		{
			get { return BitConverter.ToInt16( this._rec, 0x0E2 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0E2 ); }
		}

		/// <summary>0E4h 2バイト 必要商業</summary>
		public Int16 HitsuyouSyougyou
		{
			get { return BitConverter.ToInt16( this._rec, 0x0E4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0E4 ); }
		}

		/// <summary>0E6h 2バイト 必要兵舎</summary>
		public Int16 HitsuyouHeisya
		{
			get { return BitConverter.ToInt16( this._rec, 0x0E6 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0E6 ); }
		}


		/// <summary>0E8h 4バイト 0xFFFFFFFF固定？</summary>
		public Int32 h0E8_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0E8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0E8 ); }
		}

		/// <summary>0ECh 4バイト 0xFFFFFFFF固定？</summary>
		public Int32 h0EC_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0EC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0EC ); }
		}

		/// <summary>0F0h 4バイト 0固定？</summary>
		public Int32 h0F0_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0F0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0F0 ); }
		}

		/// <summary>0F4h 4バイト 城郭ID(前提？)</summary>
		public Int32 JoukakuID_0F4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0F4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0F4 ); }
		}


		/// <summary>0F8h 1バイト</summary>
		public Byte h0F8
		{
			get { return this._rec[0x0F8]; }
			set { this._rec[0x0F8] = value; }
		}

		/// <summary>0F9h 1バイト 0固定？</summary>
		public Byte h0F9
		{
			get { return this._rec[0x0F9]; }
			set { this._rec[0x0F9] = value; }
		}

		/// <summary>0FAh 1バイト</summary>
		public SByte h0FA
		{
			get { return (sbyte)this._rec[0x0FA]; }
			set { this._rec[0x0FA] = (byte)value; }
		}

		/// <summary>0FBh 1バイト 最大民忠増加値</summary>
		public SByte SaidaiTamichuuZouka
		{
			get { return (sbyte)this._rec[0x0FB]; }
			set { this._rec[0x0FB] = (byte)value; }
		}

		/// <summary>0FCh 4バイト 人口増加値</summary>
		public Int32 JinkouZouka
		{
			get { return BitConverter.ToInt32( this._rec, 0x0FC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0FC ); }
		}

		/// <summary>100h 4バイト 必要資源(施設)ID</summary>
		public Int32 HitsuyouShigenID
		{
			get { return BitConverter.ToInt32( this._rec, 0x100 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x100 ); }
		}

		/// <summary>104h 4バイト 影響施設ID(当該施設の数に応じて効果が上昇する)</summary>
		public Int32 EikyouShisetsuID1
		{
			get { return BitConverter.ToInt32( this._rec, 0x104 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x104 ); }
		}

		/// <summary>108h 4バイト 影響施設ID(当該施設の数に応じて効果が上昇する)</summary>
		public Int32 EikyouShisetsuID2
		{
			get { return BitConverter.ToInt32( this._rec, 0x108 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x108 ); }
		}

		/// <summary>10Ch 4バイト 必要港(施設)ID</summary>
		public Int32 HitsuyouMinatoID
		{
			get { return BitConverter.ToInt32( this._rec, 0x10C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x10C ); }
		}


		/// <summary>110h 1バイト 収穫増加値</summary>
		public Byte SyuukakuZouka
		{
			get { return this._rec[0x110]; }
			set { this._rec[0x110] = value; }
		}

		/// <summary>111h 1バイト 金銭収入増加値</summary>
		public Byte SyuunyuuZouka
		{
			get { return this._rec[0x111]; }
			set { this._rec[0x111] = value; }
		}

		/// <summary>112h 1バイト 0固定？</summary>
		public Byte h112
		{
			get { return this._rec[0x112]; }
			set { this._rec[0x112] = value; }
		}

		/// <summary>113h 1バイト 0固定？</summary>
		public Byte h113
		{
			get { return this._rec[0x113]; }
			set { this._rec[0x113] = value; }
		}

		/// <summary>114h 1バイト 腰兵糧消費減少</summary>
		public Byte HyourousyouhiGensyou
		{
			get { return this._rec[0x114]; }
			set { this._rec[0x114] = value; }
		}

		/// <summary>115h 1バイト 傷兵回復速度上昇値</summary>
		public Byte SyouheiKaifukusokudoZouka
		{
			get { return this._rec[0x115]; }
			set { this._rec[0x115] = value; }
		}

		/// <summary>116h 1バイト 0固定？</summary>
		public Byte h116
		{
			get { return this._rec[0x116]; }
			set { this._rec[0x116] = value; }
		}

		/// <summary>117h 1バイト 0固定？</summary>
		public Byte h117
		{
			get { return this._rec[0x117]; }
			set { this._rec[0x117] = value; }
		}

		/// <summary>118h 1バイト 遠海移動速度・海戦能力上昇(造船所のみ10) 119と同値</summary>
		public Byte KaisenNouryokuZouka1
		{
			get { return this._rec[0x118]; }
			set { this._rec[0x118] = value; }
		}

		/// <summary>119h 1バイト 遠海移動速度・海戦能力上昇(造船所のみ10) 118と同値</summary>
		public Byte KaisenNouryokuZouka2
		{
			get { return this._rec[0x119]; }
			set { this._rec[0x119] = value; }
		}

		/// <summary>11Ah 1バイト 所属部隊攻撃力増加値</summary>
		public Byte SyozokuButaiKougekiryokuZouka
		{
			get { return this._rec[0x11A]; }
			set { this._rec[0x11A] = value; }
		}

		/// <summary>11Bh 1バイト 対捕縛</summary>
		public Byte TaiHobaku
		{
			get { return this._rec[0x11B]; }
			set { this._rec[0x11B] = value; }
		}

		/// <summary>11Ch 1バイト 創造武将所属部隊強化 11Dと同値</summary>
		public Byte ButaiKyoukaSouzou1
		{
			get { return this._rec[0x11C]; }
			set { this._rec[0x11C] = value; }
		}

		/// <summary>11Dh 1バイト 創造武将所属部隊強化 11Cと同値</summary>
		public Byte ButaiKyoukaSouzou2
		{
			get { return this._rec[0x11D]; }
			set { this._rec[0x11D] = value; }
		}

		/// <summary>11Eh 1バイト 中道武将所属部隊強化 11Fと同値</summary>
		public Byte ButaiKyoukaChuudou1
		{
			get { return this._rec[0x11E]; }
			set { this._rec[0x11E] = value; }
		}

		/// <summary>11Fh 1バイト 中道武将所属部隊強化 11Eと同値</summary>
		public Byte ButaiKyoukaChuudou2
		{
			get { return this._rec[0x11F]; }
			set { this._rec[0x11F] = value; }
		}

		/// <summary>120h 1バイト 保守武将所属部隊強化 121と同値</summary>
		public Byte ButaiKyoukaHosyu1
		{
			get { return this._rec[0x120]; }
			set { this._rec[0x120] = value; }
		}

		/// <summary>121h 1バイト 保守武将所属部隊強化 120と同値</summary>
		public Byte ButaiKyoukaHosyu2
		{
			get { return this._rec[0x121]; }
			set { this._rec[0x121] = value; }
		}

		/// <summary>122h 1バイト 軍馬配備時の攻撃力上昇値</summary>
		public Byte GunbaKougekiryokuZouka
		{
			get { return this._rec[0x122]; }
			set { this._rec[0x122] = value; }
		}

		/// <summary>123h 1バイト 鉄砲配備時の攻撃力上昇値</summary>
		public Byte TeppouKougekiryokuZouka
		{
			get { return this._rec[0x123]; }
			set { this._rec[0x123] = value; }
		}

		// 124h の1バイトはビットフラグぽい

		/// <summary>bit0 124h</summary>
		public Boolean h124_b0
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x124, 0 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x124, 0 ); }
		}

		/// <summary>bit1 124h</summary>
		public Boolean h124_b1
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x124, 1 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x124, 1 ); }
		}

		/// <summary>bit2 124h</summary>
		public Boolean h124_b2
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x124, 2 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x124, 2 ); }
		}

		/// <summary>bit3 124h</summary>
		public Boolean h124_b3
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x124, 3 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x124, 3 ); }
		}

		/// <summary>bit4 124h</summary>
		public Boolean h124_b4
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x124, 4 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x124, 4 ); }
		}

		/// <summary>bit5 124h</summary>
		public Boolean h124_b5
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x124, 5 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x124, 5 ); }
		}

		/// <summary>bit6 124h</summary>
		public Boolean h124_b6
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x124, 6 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x124, 6 ); }
		}

		/// <summary>bit7 124h</summary>
		public Boolean h124_b7
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x124, 7 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x124, 7 ); }
		}


		/// <summary>125h 1バイト 0固定？</summary>
		public Byte h125
		{
			get { return this._rec[0x125]; }
			set { this._rec[0x125] = value; }
		}

		/// <summary>126h 1バイト 0固定？</summary>
		public Byte h126
		{
			get { return this._rec[0x126]; }
			set { this._rec[0x126] = value; }
		}

		/// <summary>127h 1バイト 0固定？</summary>
		public Byte h127
		{
			get { return this._rec[0x127]; }
			set { this._rec[0x127] = value; }
		}

		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
