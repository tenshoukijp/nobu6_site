﻿// KoukaData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>効果データ</summary>
	public class KoukaData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }

		/// <summary>00h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00 ); }
		}

		/// <summary>04h 13バイト 名称(シフトJIS nullターミネイト)</summary>
		public String Name
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x04, 13 ); }
			set { MyTextConverter.StringToBytes( value, 13 ).CopyTo( this._rec, 0x04 ); }
		}

		/// <summary>11h 43バイト ヘルプテキスト(シフトJIS nullターミネイト)</summary>
		public String HelpText
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x11, 43 ); }
			set { MyTextConverter.StringToBytes( value, 43 ).CopyTo( this._rec, 0x11 ); }
		}

		/// <summary>3Ch 1バイト</summary>
		public Byte h3C
		{
			get { return this._rec[0x3C]; }
			set { this._rec[0x3C] = value; }
		}

		/// <summary>3Dh 1バイト</summary>
		public Byte h3D
		{
			get { return this._rec[0x3D]; }
			set { this._rec[0x3D] = value; }
		}

		/// <summary>3Eh 1バイト</summary>
		public Byte h3E
		{
			get { return this._rec[0x3E]; }
			set { this._rec[0x3E] = value; }
		}

		/// <summary>3Fh 1バイト</summary>
		public Byte h3F
		{
			get { return this._rec[0x3F]; }
			set { this._rec[0x3F] = value; }
		}

		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
