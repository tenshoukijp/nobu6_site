﻿// ParamData.cs

using System;

using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>Paramデータ</summary>
	public class ParamData : IData
	{
		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }

		/// <summary>パラメータ名</summary>
		public String Name			{ get; set; }

		/// <summary>パラメータ値</summary>
		public Int32 Value			{ get; set; }

		/// <summary>初期値</summary>
		public Int32? DefaultValue	{ get; set; }

		/// <summary>レコード(パラメータ値)をセットする</summary>
		/// <param name="record">レコード)</param>
		public void SetRecord( Byte[] record )
		{
			this.Value = BitConverter.ToInt32( record, 0 );
		}

		/// <summary>レコード(パラメータ値)を取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return BitConverter.GetBytes( this.Value );
		}
	}
}
