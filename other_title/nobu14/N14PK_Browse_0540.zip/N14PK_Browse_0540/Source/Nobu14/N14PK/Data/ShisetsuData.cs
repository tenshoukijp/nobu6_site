﻿// ShisetsuData.cs

using System;

using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>施設データ</summary>
	public class ShisetsuData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>000h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x000 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x000 ); }
		}

		/// <summary>004~012h 15バイト 名称(シフトJIS NULLターミネイト)</summary>
		public String Name
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x004, 15 ); }
			set { MyTextConverter.StringToBytes( value, 15 ).CopyTo( this._rec, 0x004 ); }
		}

		/// <summary>013~02Dh 27バイト 読み(シフトJIS NULLターミネイト)</summary>
		public String Yomi
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x013, 27 ); }
			set { MyTextConverter.StringToBytes( value, 27 ).CopyTo( this._rec, 0x013 ); }
		}

		/// <summary>02E~056h 41バイト ヘルプ1(シフトJIS NULLターミネイト)</summary>
		public String HelpText1
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x02E, 41 ); }
			set { MyTextConverter.StringToBytes( value, 41 ).CopyTo( this._rec, 0x02E ); }
		}

		/// <summary>057~07Fh 41バイト ヘルプ2(シフトJIS NULLターミネイト)</summary>
		public String HelpText2
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x057, 41 ); }
			set { MyTextConverter.StringToBytes( value, 41 ).CopyTo( this._rec, 0x057 ); }
		}

		/// <summary>080~A8Fh 41バイト ヘルプ3(シフトJIS NULLターミネイト)</summary>
		public String HelpText3
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x080, 41 ); }
			set { MyTextConverter.StringToBytes( value, 41 ).CopyTo( this._rec, 0x080 ); }
		}

		/// <summary>0A9~D1Fh 41バイト ヘルプ4 未使用(シフトJIS NULLターミネイト)</summary>
		public String HelpText4
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x0A9, 41 ); }
			set { MyTextConverter.StringToBytes( value, 41 ).CopyTo( this._rec, 0x0A9 ); }
		}

		/// <summary>0D2h 2バイト 0固定？</summary>
		public UInt16 h0D2_2
		{
			get { return BitConverter.ToUInt16( this._rec, 0x0D2 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D1 ); }
		}

		/// <summary>0D4h 4バイト ポインタ</summary>
		public UInt32 Ptr_0D4
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0D4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D4 ); }
		}

		/// <summary>0D8h 4バイト ポインタ</summary>
		public UInt32 Ptr_0D8
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0D8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0D8 ); }
		}

		/// <summary>0DCh 4バイト ポインタ</summary>
		public UInt32 Ptr_0DC
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0DC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0DC ); }
		}

		/// <summary>0E0h 4バイト 0固定？</summary>
		public Int32 h0E0_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0E0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0E0 ); }
		}

		/// <summary>0E4h 4バイト 6固定？</summary>
		public Int32 h0E4_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0E4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0E4 ); }
		}

		/// <summary>0E8h 4バイト h0EC_4 と同値？</summary>
		public Int32 h0E8_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0E8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0E8 ); }
		}

		/// <summary>0ECh 4バイト h0E8_4 と同値？</summary>
		public Int32 h0EC_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0EC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0EC ); }
		}

		/// <summary>0F0h 4バイト 施設タイプID
		/// <para>0:城、1:資源、2:内政施設、3:未使用、4:未使用、5:国人衆、6:港・鉱山、7:神社仏閣、8:整備中</para></summary>
		public Int32 ShisetsuTypeID
		{
			get { return BitConverter.ToInt32( this._rec, 0x0F0 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0F0 ); }
		}

		/// <summary>0F4h 4バイト</summary>
		public Int32 h0F4_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0F4 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0F4 ); }
		}

		/// <summary>0F8h 4バイト 0固定？</summary>
		public Int32 h0F8_4
		{
			get { return BitConverter.ToInt32( this._rec, 0x0F8 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0F8 ); }
		}


		/// <summary>0FCh 4バイト 前提条件となる施設ポインタ</summary>
		public UInt32 PtrZenteiShisetsu
		{
			get { return BitConverter.ToUInt32( this._rec, 0x0FC ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x0FC ); }
		}

		/// <summary>100h 2バイト 耐久</summary>
		public Int16 Taikyuu
		{
			get { return BitConverter.ToInt16( this._rec, 0x100 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x100 ); }
		}

		/// <summary>102h 2バイト 費用</summary>
		public Int16 Hiyou
		{
			get { return BitConverter.ToInt16( this._rec, 0x102 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x102 ); }
		}

		/// <summary>104h 2バイト 0固定？</summary>
		public Int16 h104_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x104 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x104 ); }
		}

		/// <summary>106h 2バイト</summary>
		public Int16 h106_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x106 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x106 ); }
		}

		/// <summary>108h 2バイト h111 と同値？</summary>
		public Int16 h108_2
		{
			get { return BitConverter.ToInt16( this._rec, 0x108 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x108 ); }
		}

		/// <summary>10Ah 2バイト 必要資源(施設)ID</summary>
		public Int16 HitsuyouShigenID
		{
			get { return BitConverter.ToInt16( this._rec, 0x10A ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x10A ); }
		}

		/// <summary>10Ch 1バイト 農業上昇ランク</summary>
		public Byte UpRankNougyou
		{
			get { return this._rec[0x10C]; }
			set { this._rec[0x10C] = value; }
		}

		/// <summary>10Dh 1バイト 商業上昇ランク</summary>
		public Byte UpRankSyougyou
		{
			get { return this._rec[0x10D]; }
			set { this._rec[0x10D] = value; }
		}

		/// <summary>10Eh 1バイト 兵舎上昇ランク</summary>
		public Byte UpRankHeisya
		{
			get { return this._rec[0x10E]; }
			set { this._rec[0x10E] = value; }
		}

		/// <summary>10Fh 1バイト 人口関連1</summary>
		public Byte Jinkou1
		{
			get { return this._rec[0x10F]; }
			set { this._rec[0x10F] = value; }
		}

		/// <summary>110h 1バイト</summary>
		public Byte h110
		{
			get { return this._rec[0x110]; }
			set { this._rec[0x110] = value; }
		}

		/// <summary>111h 1バイト h108_2 と同値？</summary>
		public Byte h111
		{
			get { return this._rec[0x111]; }
			set { this._rec[0x111] = value; }
		}

		/// <summary>112h 1バイト 隣接農業上昇ランク</summary>
		public Byte UpRankNougyouRinsetsu
		{
			get { return this._rec[0x112]; }
			set { this._rec[0x112] = value; }
		}

		/// <summary>113h 1バイト 隣接商業上昇ランク</summary>
		public Byte UpRankSyougyouRinsetsu
		{
			get { return this._rec[0x113]; }
			set { this._rec[0x113] = value; }
		}

		/// <summary>114h 1バイト 隣接兵舎上昇ランク</summary>
		public Byte UpRankHeisyaRinsetsu
		{
			get { return this._rec[0x114]; }
			set { this._rec[0x114] = value; }
		}

		/// <summary>115h 1バイト 創造性</summary>
		public SByte Souzousei
		{
			get { return (sbyte)this._rec[0x115]; }
			set { this._rec[0x115] = (byte)value; }
		}

		/// <summary>116h 1バイト</summary>
		public Byte h116
		{
			get { return this._rec[0x116]; }
			set { this._rec[0x116] = value; }
		}

		/// <summary>117h 1バイト 人口関連2</summary>
		public Byte Jinkou2
		{
			get { return this._rec[0x117]; }
			set { this._rec[0x117] = value; }
		}

		/// <summary>118h 1バイト</summary>
		public Byte h118
		{
			get { return this._rec[0x118]; }
			set { this._rec[0x118] = value; }
		}

		/// <summary>119h 1バイト 施設レベル</summary>
		public Byte ShisetsuLV
		{
			get { return this._rec[0x119]; }
			set { this._rec[0x119] = value; }
		}

		/// <summary>11Ah 1バイト</summary>
		public Byte h11A
		{
			get { return this._rec[0x11A]; }
			set { this._rec[0x11A] = value; }
		}

		/// <summary>11Bh 1バイト</summary>
		public Byte h11B
		{
			get { return this._rec[0x11B]; }
			set { this._rec[0x11B] = value; }
		}

		/// <summary>11Ch 1バイト</summary>
		public Byte h11C
		{
			get { return this._rec[0x11C]; }
			set { this._rec[0x11C] = value; }
		}

		/// <summary>11Dh 1バイト</summary>
		public SByte h11D
		{
			get { return (sbyte)this._rec[0x11D]; }
			set { this._rec[0x11D] = (byte)value; }
		}

		// 11Eh の1バイトはビットフラグとして扱う

		/// <summary>11Eh bit0</summary>
		public Boolean h11E_b00
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x11E, 0 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x11E, 0 ); }
		}

		/// <summary>11Eh bit1 区画タイプ農業</summary>
		public Boolean IsNougyouKukaku
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x11E, 1 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x11E, 1 ); }
		}

		/// <summary>11Eh bit2 区画タイプ商業</summary>
		public Boolean IsSyougyouKukaku
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x11E, 2 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x11E, 2 ); }
		}

		/// <summary>11Eh bit3 区画タイプ兵舎</summary>
		public Boolean IsHeisyaKukaku
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x11E, 3 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x11E, 3 ); }
		}

		/// <summary>11Eh bit4</summary>
		public Boolean h11E_b04
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x11E, 4 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x11E, 4 ); }
		}

		/// <summary>11Eh bit5 収入関連</summary>
		public Boolean h11E_b05
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x11E, 5 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x11E, 5 ); }
		}

		/// <summary>11Eh bit6 未使用？</summary>
		public Boolean h11E_b06
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x11E, 6 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x11E, 6 ); }
		}

		/// <summary>11Eh bit7 未使用？</summary>
		public Boolean h11E_b07
		{
			get { return MyBitConverter.ToBoolean( this._rec, 0x11E, 7 ); }
			set { MyBitConverter.IntoBytes( value, this._rec, 0x11E, 7 ); }
		}

		/// <summary>11Fh 1バイト ビットフラグ？</summary>
		public Byte h11F
		{
			get { return this._rec[0x11F]; }
			set { this._rec[0x11F] = value; }
		}

		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
