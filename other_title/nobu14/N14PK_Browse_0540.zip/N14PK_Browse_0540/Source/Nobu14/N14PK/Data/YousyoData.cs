﻿// YousyoData.cs

using System;
using N14PKLibrary.HelperClass;

namespace N14PKLibrary.Data
{
	/// <summary>要所データ</summary>
	public class YousyoData : IData
	{
		/// <summary>レコード</summary>
		private byte[] _rec;

		/// <summary>アドレス</summary>
		public UInt32 Address { get; set; }

		/// <summary>ID</summary>
		public Int32 ID { get; set; }


		/// <summary>00h 4バイト マジックナンバー</summary>
		public UInt32 MagicNumber
		{
			get { return BitConverter.ToUInt32( this._rec, 0x00 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x00 ); }
		}

		/// <summary>04~0Eh 11バイト 名称(シフトJIS nullターミネイト)</summary>
		public String Name
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x04, 11 ); }
			set { MyTextConverter.StringToBytes( value, 11 ).CopyTo( this._rec, 0x04 ); }
		}

		/// <summary>0F~23h 21バイト 読み(シフトJIS nullターミネイト)</summary>
		public String Yomi
		{
			get { return MyTextConverter.BytesToString( this._rec, 0x0F, 21 ); }
			set { MyTextConverter.StringToBytes( value, 21 ).CopyTo( this._rec, 0x0F ); }
		}

		/// <summary>24h 4バイト 国ポインタ</summary>
		public UInt32 PtrKuni
		{
			get { return BitConverter.ToUInt32( this._rec, 0x24 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x24 ); }
		}

		/// <summary>28h 4バイト X位置</summary>
		public UInt32 PosX
		{
			get { return BitConverter.ToUInt32( this._rec, 0x28 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x28 ); }
		}

		/// <summary>2Ch 4バイト Y位置</summary>
		public UInt32 PosY 
		{
			get { return BitConverter.ToUInt32( this._rec, 0x2C ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x2C ); }
		}

		/// <summary>30h 4バイト 拠点ポインタ 拠点タイプIDにより参照するデータが異なる</summary>
		public UInt32 PtrKyoten
		{
			get { return BitConverter.ToUInt32( this._rec, 0x30 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x30 ); }
		}

		/// <summary>34h 4バイト 拠点タイプID(0:なし、3:城、15:国人衆)</summary>
		public Int32 KyotenTypeID
		{
			get { return BitConverter.ToInt32( this._rec, 0x34 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x34 ); }
		}

		/// <summary>38h 4バイト 陣設営勢力ポインタ</summary>
		public UInt32 PtrJinSetsueiSeiryoku
		{
			get { return BitConverter.ToUInt32( this._rec, 0x38 ); }
			set { BitConverter.GetBytes( value ).CopyTo( this._rec, 0x38 ); }
		}

		/// <summary>3Ch 1バイト 陣レベル 0:1～2:3</summary>
		public SByte JinLevel
		{
			get { return (sbyte)this._rec[0x3C]; }
			set { this._rec[0x3C] = (byte)value; }
		}

		/// <summary>3Dh 1バイト 数値 0固定？</summary>
		public Byte h3D
		{
			get { return this._rec[0x3D]; }
			set { this._rec[0x3D] = (byte)value; }
		}

		/// <summary>3Eh 1バイト フラグ系
		/// <para>第2ビットが1の場合、当該要所の城用地サイズに使用するParam値は "COST_N14PK_HONJOU(SHIJOU)_YAMAJIRO_MAX_LV0～3" のいずれか</para>
		/// <para>第2ビットが0の場合、当該要所の城用地サイズに使用するParam値は "COST_N14PK_HONJOU(SHIJOU)_HIRAJIRO_MAX_LV0～3" のいずれか</para></summary>
		public Byte h3E 
		{
			get { return this._rec[0x3E]; }
			set { this._rec[0x3E] = (byte)value; }
		}

		/// <summary>3Fh 1バイト 数値 0固定？</summary>
		public Byte h3F 
		{
			get { return this._rec[0x3F]; }
			set { this._rec[0x3F] = (byte)value; }
		}

		/// <summary>データ内にレコードをセットする</summary>
		/// <remarks>各データはレコードの参照を持つ</remarks>
		/// <param name="record">レコード</param>
		public void SetRecord( Byte[] record )
		{
			this._rec = record;
		}

		/// <summary>データ内のレコードを取得する</summary>
		/// <returns>レコード</returns>
		public Byte[] GetRecord()
		{
			return this._rec;
		}
	}
}
