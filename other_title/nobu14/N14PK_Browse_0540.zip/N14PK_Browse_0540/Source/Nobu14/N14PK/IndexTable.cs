﻿// IndexTable.cs

using System;
using System.Collections.Generic;

namespace N14PKLibrary
{
	/// <summary>各データテーブルの構造情報を管理するクラス</summary>
	public class IndexTable
	{
		/// <summary>データテーブル構造情報</summary>
		public class Index
		{
			/// <summary>ポインタテーブル開始アドレス</summary>
			public UInt32 PtrPointerTableBegin;

			/// <summary>ポインタテーブル終了アドレス</summary>
			public UInt32 PtrPointerTableEnd;

			/// <summary>不明</summary>
			public UInt32 Unknown1;

			/// <summary>不明</summary>
			public UInt32 Unknown2;
		}

		/// <summary>プロセスメモリ</summary>
		private HelperClass.ProcessMemory _pm;

		/// <summary>バージョン別の設定情報(メモリアドレスや定数など)</summary>
		private VersionConfig.IVersionConfig _config;

		/// <summary>インデクステーブル開始アドレス</summary>
		/// ゲーム起動中は変わることが無いため、サーチ結果をスタティックで保持して次回検索をスルーする
		public static UInt32 Address { get; private set; }

		/// <summary>IndexTable 内のインデクス数</summary>
		public UInt32 Count
		{
			get { return this._config.IndexTblRecordCount; }
		}

		/// <summary>インデクス配列</summary>
		private Index[] _indexes;


		/// <summary>コンストラクタ</summary>
		/// <remarks>バージョン別設定情報にインデクステーブル開始アドレスが設定されていなければプロセスメモリをサーチする</remarks>
		/// <param name="process">プロセス管理</param>
		/// <param name="config">バージョン別設定情報</param>
		/// <exception cref="ApplicationException">インデクステーブルが見つからない場合に発生する例外</exception>
		public IndexTable( HelperClass.ProcessMemory process, VersionConfig.IVersionConfig config )
		{
			this._pm = process;
			this._config = config;

			this.SetIndex();
		}

		/// <summary>インデクスデータをセットする</summary>
		private void SetIndex()
		{
			if ( IndexTable.Address == 0 && this._config.IndexTblPointerAddress != 0 )
			{
				// インデクステーブルへのポインタアドレス(ベースアドレスからのオフセット)が設定されている
				var indexTblAddress = BitConverter.ToUInt32( this._pm.ReadMemory( this._pm.BaseAddress + this._config.IndexTblPointerAddress, sizeof( UInt32 ), skipError: true ), 0 );
				IndexTable.Address = indexTblAddress + this._config.OffsetIndexTblAddress;
			}

#if DEBUG
			var sw = new System.Diagnostics.Stopwatch();
			sw.Start();
#endif
			while ( !this.ReadIndexData() )
			{
				// インデクステーブルアドレスをサーチする。(indexTblPointerAddress == 0(未知バージョン)か指定したアドレスで見つからない場合)
				// 武将データテーブル→ポインタテーブル→インデックテーブル と辿って検索する
				// リードエラーを無視してプロセスメモリにアクセスするため、エラー時の読み取りサイズ範囲に目的のデータがあるとヒットしない
				// ヒープエントリを取得してブロックの状態を確認しながらやると、ものすご～く時間がかかって実用に耐えない。ベターな方法がわからない

				var kakizakiAddress = this.SearchKakizakiAddress();
				if ( kakizakiAddress == 0 )
				{
					throw new ApplicationException( "蠣崎季広の武将データが見つかりません。\n(ゲームがタイトル画面の場合は見つけられません)" );
				}

				var busyouPointarTableAddress = this.SearchPointerTableAddress( kakizakiAddress );
				if ( busyouPointarTableAddress == 0 )
				{
					throw new ApplicationException( "武将ポインタテーブルが見つかりません。" );
				}

				IndexTable.Address = this.SearchindexTblAddress( busyouPointarTableAddress );
				if ( IndexTable.Address == 0 )
				{
					throw new ApplicationException( "インデクステーブルが見つかりません。" );
				}
			}
#if DEBUG
			sw.Stop();
			System.Diagnostics.Debug.WriteLine( "インデクスアドレスセット 処理時間:" + sw.ElapsedMilliseconds + " ms" );

			var pattern = new byte[4];
			BitConverter.GetBytes( IndexTable.Address - 0xB0 ).CopyTo( pattern, 0x000 );
			uint readSize = 0x00010000;				// 一度に読み込むサイズ 64KB
			var address = this._pm.BaseAddress;
			while ( address < this._pm.PrivateMemorySize )
			{
				// 予約・フリー領域等へのReadエラーを無視して読み込む
				var buff = this._pm.ReadMemory( address, readSize, skipError: true );
				// サーチ
				var index = HelperClass.MyArray.QuickSearch( buff, pattern );
				if ( index != -1 )
				{
					System.Diagnostics.Debug.WriteLine( "BaseAddress: " + this._pm.BaseAddress.ToString( "X8" ) );
					System.Diagnostics.Debug.WriteLine( "IndexTblPointerAddress: " + ( address + index ).ToString( "X8" ) );
					break;
				}
				address += readSize - (UInt32)pattern.Length;
			}
#endif
		}

		/// <summary>プロセスメモリからインデクスデータを読み込んでセット</summary>
		/// <returns>データが正しくセットされた場合は true を返す</returns>
		private bool ReadIndexData()
		{
			if ( ( IndexTable.Address == 0 ) || ( IndexTable.Address < this._pm.HeapAddresses[0] ) || ( this._pm.VirtualMemorySize < IndexTable.Address ) )
			{
				// アドレスじゃなさげな値
				return false;
			}

			this._indexes = new Index[this._config.IndexTblRecordCount];
			for ( UInt32 i = 0; i < this._config.IndexTblRecordCount; i++ )
			{
				var address = IndexTable.Address + this._config.IndexTblRecordSize * i;
				this._indexes[i] = new Index();
				this._indexes[i].PtrPointerTableBegin	= BitConverter.ToUInt32( this._pm.ReadMemory( address, sizeof( UInt32 ), skipError: true ), 0 );
				this._indexes[i].PtrPointerTableEnd		= BitConverter.ToUInt32( this._pm.ReadMemory( address + 0x4, sizeof( UInt32 ), skipError: true ), 0 );
				this._indexes[i].Unknown1				= BitConverter.ToUInt32( this._pm.ReadMemory( address + 0x8, sizeof( UInt32 ), skipError: true ), 0 );
				this._indexes[i].Unknown2				= BitConverter.ToUInt32( this._pm.ReadMemory( address + 0xC, sizeof( UInt32 ), skipError: true ), 0 );
			}

			// 武将データ数を取得してインデクスデータが正しく読み込めたかどうか判断する
			var busyouCount = ( this._indexes[(int)DataKind.武将].PtrPointerTableEnd - this._indexes[(int)DataKind.武将].PtrPointerTableBegin ) / sizeof( UInt32 );

			return ( busyouCount == this._config.BusyouDataCount );
		}

		/// <summary>武将データテーブル開始アドレス(蠣崎季広のデータ)サーチ</summary>
		/// <returns>武将データテーブル開始アドレス</returns>
		private uint SearchKakizakiAddress()
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "武将データ(蠣崎季広)サーチ" );
#endif
			bool isHitKakizaki = false;				// ヒットフラグ
			uint readSize = 0x00010000;				// 一度に読み込むサイズ 64KB
			byte[] pattern = new byte[]
			{
				0xE5, 0x79, 0x8D, 0xE8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,   // 蠣崎
				0x8B, 0x47, 0x8D, 0x4C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00	// 季広
			};

			var address = this._pm.HeapAddresses[0];
			while ( !isHitKakizaki && ( address < this._pm.PrivateMemorySize ) )
			{
					// 予約・フリー領域等へのReadエラーを無視して読み込む
				var buff = this._pm.ReadMemory( address, readSize, skipError: true );
				// サーチ
				var index = HelperClass.MyArray.QuickSearch( buff, pattern );
				if ( index != -1 )
				{
					// ヒットしたアドレスから-8hしたアドレスを4バイト読み込む(武将データ数が格納されている(はず))
					var busyouCount = BitConverter.ToInt32( this._pm.ReadMemory( (UInt32)( address + index - 8 ), sizeof( UInt32 ), skipError: true ), 0 );
					if ( busyouCount == this._config.BusyouDataCount )
					{
						// 武将データで確定
						return (UInt32)( address + index - 4 );  // 姓アドレス - 4h(MagicNumber) が武将データテーブル開始アドレス
					}
				}
				address += readSize - (UInt32)pattern.Length;
			}
			return 0;
		}

		/// <summary>武将ポインタテーブルサーチ</summary>
		/// <param name="kakizakiAddress">武将データテーブル開始アドレス(蠣崎季広のデータ)</param>
		/// <returns>武将ポインタテーブル開始アドレス</returns>
		private uint SearchPointerTableAddress( UInt32 kakizakiAddress )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "武将ポインタテーブルサーチ" );
#endif
			bool isHitPointerTable = false;			// ヒットフラグ
			uint readSize = 0x00010000;				// 一度に読み込むサイズ 64KB
			byte[] pattern;
			int checkCount = 8;						// 確認するデータ数

			// 検索パターンの作成
			// ポインタテーブルは、各武将データのアドレスが4バイトずつ並んでいるのでそれを検索する
			pattern = new byte[sizeof( UInt32 ) * checkCount];
			for ( var i = 0; i < checkCount; i++ )
			{
				BitConverter.GetBytes( kakizakiAddress + this._config.BusyouDataRecoedSize * (uint)i ).CopyTo( pattern, sizeof( UInt32 ) * i );
			}

			var address = this._pm.HeapAddresses[0];
			while ( !isHitPointerTable && ( address < this._pm.PrivateMemorySize ) )
			{
				// 予約・フリー領域等へのReadエラーを無視して読み込む
				var buff = this._pm.ReadMemory( address, readSize, skipError: true );
				// サーチ
				var index = HelperClass.MyArray.QuickSearch( buff, pattern );
				if ( index != -1 )
				{
					return (UInt32)( address + index );
				}
				address += readSize - (UInt32)pattern.Length;
			}
			return 0;
		}

		/// <summary>インデクステーブルアドレスをサーチする</summary>
		/// <returns>インデクステーブルアドレス</returns>
		private uint SearchindexTblAddress( UInt32 busyouPointarTableAddress )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "インデクステーブルアドレスサーチ" );
#endif
			// 武将ポインタテーブル開始アドレスを元にインデクステーブル検索
			bool isHitindexTbl = false;		// ヒットフラグ
			uint readSize = 0x00010000;			// 一度に読み込むサイズ 64KB
			byte[] pattern;

			// 検索パターンの作成
			// インデクスデータは、ポインタテーブル開始アドレス・ポインタテーブル終了アドレス・(ポインタテーブル終了アドレスと同値) の順に並んでいるのでそれを検索する
			pattern = new byte[sizeof( UInt32 ) * 3];   // アドレス3つ分
			BitConverter.GetBytes( busyouPointarTableAddress ).CopyTo( pattern, sizeof( UInt32 ) * 0 );
			BitConverter.GetBytes( busyouPointarTableAddress + (uint)sizeof( UInt32 ) * this._config.BusyouDataCount ).CopyTo( pattern, sizeof( UInt32 ) * 1 );
			BitConverter.GetBytes( busyouPointarTableAddress + (uint)sizeof( UInt32 ) * this._config.BusyouDataCount ).CopyTo( pattern, sizeof( UInt32 ) * 2 );

			var address = this._pm.HeapAddresses[0];
			while ( !isHitindexTbl && ( address < this._pm.PrivateMemorySize ) )
			{
				var buff = this._pm.ReadMemory( address, readSize, skipError: true );
				// サーチ
				var index = HelperClass.MyArray.QuickSearch( buff, pattern );
				if ( index != -1 )
				{
					return (UInt32)( address + index - ( this._config.IndexTblRecordSize * (int)DataKind.武将 ) );
				}
				address += readSize - (UInt32)pattern.Length;
			}
			return 0;
		}

		/// <summary>インデクサ</summary>
		/// <param name="n">インデクス</param>
		/// <returns>インデクスクラス</returns>
		public Index this[uint n]
		{
			get
			{
				if ( 0 <= n && n < this._indexes.Length )
				{
					return this._indexes[n];
				}
				else
				{
					return null;
				}
			}
		}

		/// <summary>イテレータ</summary>
		/// <returns>インデクスクラス</returns>
		public IEnumerator<Index> GetEnumerator()
		{
			for ( var i = 0; i < this._indexes.Length; i++ )
			{
				yield return this._indexes[i];
			}
		}
	}
}
