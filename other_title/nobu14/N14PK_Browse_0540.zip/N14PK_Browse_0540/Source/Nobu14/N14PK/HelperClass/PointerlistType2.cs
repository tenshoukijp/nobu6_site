﻿// PointerlistType2.cs

using System;
using System.Collections.Generic;
using System.Text;


namespace N14PKLibrary.HelperClass
{
	/// <summary>データ内で使用されている2ポインタタイプのリストデータ操作用クラス</summary>
	/// <remarks>リスト間のポインタデータ移動・既存データへ上書き・削除 はできるが、新規のポインタデータを作成して追加するのは無理</remarks>
	public class PointerlistType2
	{
		/// <summary>リストを構成するポインタデータ</summary>
		public class PointerData
		{
			/// <summary>レコード</summary>
			public byte[] Record	{ get; set; }

			/// <summary>アドレス</summary>
			public UInt32 Address	{ get; set; }

			/// <summary>要書き込みフラグ</summary>
			public bool NeedsWrite	{ get; set; }

			/// <summary>要削除フラグ</summary>
			public bool NeedsDelete	{ get; set; }

			/// <summary>先頭フラグ</summary>
			public bool IsFirst		{ get; set; }

			/// <summary>末尾フラグ</summary>
			public bool IsLast		{ get; set; }

			/// <summary>00h 4バイト 次ポインタデータへのポインタ</summary>
			public UInt32 PtrNextPointerData
			{
				get { return BitConverter.ToUInt32( this.Record, 0x00 ); }
				set
				{
					if ( value == this.PtrNextPointerData ) { return; }
					BitConverter.GetBytes( value ).CopyTo( this.Record, 0x00 );
					this.NeedsWrite = true;
				}
			}

			/// <summary>04h 4バイト 前ポインタデータへのポインタ</summary>
			public UInt32 PtrPrePointerData
			{
				get { return BitConverter.ToUInt32( this.Record, 0x04 ); }
				set
				{
					if ( value == this.PtrPrePointerData ) { return; }
					BitConverter.GetBytes( value ).CopyTo( this.Record, 0x04 );
					this.NeedsWrite = true;
				}
			}

			/// <summary>08h 4バイト 目的のデータへのポインタ</summary>
			public UInt32 PtrTargetData
			{
				get { return BitConverter.ToUInt32( this.Record, 0x08 ); }
				set
				{
					if ( value == this.PtrTargetData ) { return; }
					BitConverter.GetBytes( value ).CopyTo( this.Record, 0x08 );
					this.NeedsWrite = true;
				}
			}

			/// <summary>0Ch 4バイト 何らかの数値
			/// <para>ポインタデータサイズが0Chの場合があり、その場合はこのデータはない</para></summary>
			public int Value
			{
				get { return BitConverter.ToInt32( this.Record, 0x0C ); }
				set
				{
					if ( value == this.Value ) { return; }
					BitConverter.GetBytes( value ).CopyTo( this.Record, 0x0C );
					this.NeedsWrite = true;
				}
			}
		}

			/// <summary>アドレス</summary>
		public UInt32 Address { get; private set; }


		/// <summary>先頭ポインタデータへのポインタ</summary>
		public UInt32 PtrFirstPointerData
		{
			get { return this._indexItem.PtrNextPointerData; }
			set
			{
				if ( value == this.PtrFirstPointerData ) { return; }
				this._indexItem.PtrNextPointerData = value;
			}
		}

		/// <summary>末尾ポインタデータへのポインタ</summary>
		public UInt32 PtrLastPointerData
		{
			get { return this._indexItem.PtrPrePointerData; }
			set
			{
				if ( value == this._indexItem.PtrPrePointerData ) { return; }
				this._indexItem.PtrPrePointerData = value;
			}
		}

		/// <summary>ポインタデータリスト</summary>
		public List<PointerData> Items { get; set; }

		/// <summary>リスト内のポインタデータ数</summary>
		public int Count
		{
			get { return ( null != this.Items ) ? this.Items.Count : 0; }
		}

		private N14PK _n14pk;					// ツール管理
		private uint _size;						// ポインタデータサイズ
		private PointerData _indexItem;			// 管理用データ
		private DataKind _datakind;				// データの種類


		/// <summary>コンストラクタ</summary>
		/// コンストラクタ 生成時に失敗した場合に null を返したいので private にして外部からアクセス不可にする
		/// <param name="n14pk">ツール管理</param>
		/// <param name="address">アドレス</param>
		/// <param name="datakind">データの種類</param>
		/// <param name="size">データサイズ( 0x0C と 0x10 の2パターンがある。デフォルトは 0x0C )</param>
		private PointerlistType2( N14PK n14pk, UInt32 address, DataKind datakind, uint size )
		{
			this._n14pk = n14pk;
			this.Address = address;
			this._datakind = datakind;
			this._size = size;
			this.SetItems();
		}

		/// <summary>2ポインタタイプのポインタリストを生成する</summary>
		/// <remarks>プロセスメモリからリストデータを読み取る</remarks>
		/// 外部からはこのメソッドを使ってインスタンス生成する
		/// <param name="n14pk">ゲームプロセス管理</param>
		/// <param name="address">ポインタリストアドレス</param>
		/// <param name="datakind">データの種類</param>
		/// <param name="size">データサイズ( 0x0C と 0x10 の2パターンがある )</param>
		/// <returns>ポインタリスト</returns>
		public static PointerlistType2 Create( N14PK n14pk, UInt32 address, DataKind datakind = DataKind.UNKNOWN, uint size = 0x0C )
		{
			if ( address == 0 )
			{
				return null;
			}

			return new PointerlistType2( n14pk, address, datakind, size );
		}
		/// <summary>2ポインタタイプのポインタリストを生成する</summary>
		/// <remarks>プロセスメモリからリストデータを読み取る</remarks>
		/// <param name="n14pk">ゲームプロセス管理</param>
		/// <param name="address">ポインタリストアドレス</param>
		/// <param name="size">データサイズ( 0x0C と 0x10 の2パターンがある )</param>
		/// <returns>ポインタリスト</returns>
		public static PointerlistType2 Create( N14PK n14pk, UInt32 address, uint size = 0x0C ) { return PointerlistType2.Create( n14pk, address, DataKind.UNKNOWN, size ); }

		/// <summary>インデクサ</summary>
		/// <param name="n">配列インデクス</param>
		/// <returns>ポインタデータ</returns>
		public PointerData this[int n]
		{
			get
			{
				if ( 0 <= n && n < this.Items.Count )
				{
					return this.Items[n];
				}

				return null;
			}
		}

		// ポインタデータをプロセスメモリから読み込んでセットする
		private void SetItems()
		{
			// 管理用データ読み込み
			var indexrec = this._n14pk.ReadMemory( this.Address, this._size );
			this._indexItem = new PointerData() { Record = indexrec };
			if ( ( this.Address == this.PtrFirstPointerData )
				|| ( this.PtrFirstPointerData == 0 )
				|| ( this.PtrLastPointerData == 0 )
				)
			{
				// 先頭ポインタデータへのポインタと読み込みアドレスが同じ→ポインタデータなし
				return;
			}

			this.Items = new List<PointerData>();
			var address = this.PtrFirstPointerData;
			do
			{
				// ポインタデータ取得
				var itemrec = this._n14pk.ReadMemory( address, this._size );
				var data = new PointerData()
				{
					Record = itemrec,
					Address = address,
					NeedsWrite = false,
					NeedsDelete = false,
					IsFirst = false,
					IsLast = false
				};
				this.Items.Add( data );

				if ( address == this.PtrLastPointerData )
				{
					// 末尾ポインタデータ
					break;
				}

				// 次ポインタデータのアドレス
				address = data.PtrNextPointerData;
			}
			while ( address != this.Address );	// 次に読み込むアドレスが管理用データのアドレスではない

			if ( 0 < this.Items.Count )
			{
				// 先頭データに先頭フラグセット
				this.Items[0].IsFirst = true;
				// 末尾データに末尾フラグセット
				this.Items[this.Items.Count - 1].IsLast = true;
			}
			else
			{
				this.Items = null;
				return;
			}
		}

		#region 操作用メソッド
		/// <summary>データアドレスからポインタデータを取得する</summary>
		/// <param name="address">データアドレス</param>
		/// <returns>ポインタデータ</returns>
		public PointerData GetPointerDataByTargetDataAddress( UInt32 address )
		{
			if ( this.Count == 0 ) { return null; }
			return this.Items.Find( d => d.PtrTargetData == address );
		}

		/// <summary>先頭のポインタデータを取得する</summary>
		/// <returns>ポインタデータ</returns>
		public PointerData GetFirstPointerData()
		{
			if ( this.Count == 0 ) { return null; }
			return this.Items[0];
		}

		/// <summary>末尾のポインタデータを取得する</summary>
		/// <returns>ポインタデータ</returns>
		public PointerData GetLastPointerData()
		{
			if ( this.Count == 0 ) { return null; }
			return this.Items[this.Count - 1];
		}

		/// <summary>先頭のデータアドレスを取得する</summary>
		/// <returns>データアドレス</returns>
		public UInt32 GetFirstPtrTargetData()
		{
			if ( this.Count == 0 ) { return 0; }
			return this.Items[0].PtrTargetData;
		}

		/// <summary>末尾のデータアドレスを取得する</summary>
		/// <returns>データアドレス</returns>
		public UInt32 GetLastPtrTargetData()
		{
			if ( this.Count == 0 ) { return 0; }
			return this.Items[this.Count - 1].PtrTargetData;
		}

		/// <summary>指定したデータアドレスを持つポインタデータの1つ前のポインタデータを取得する</summary>
		/// <param name="address">データアドレス</param>
		/// <returns>ポインタデータ</returns>
		public PointerData GetPrePointerDataByTargetDataAddress( UInt32 address )
		{
			if ( this.Count == 0 ) { return null; }
			var index = this.Items.FindIndex( d => d.PtrTargetData == address );
			return ( 0 < index ) ? this[index - 1] : null;
		}

		/// <summary>指定したデータアドレスを持つポインタデータの1つ後ろのポインタデータを取得する</summary>
		/// <param name="address">データアドレス</param>
		/// <returns>ポインタデータ</returns>
		public PointerData GetNextPointerDataByTargetDataAddress( UInt32 address )
		{
			if ( this.Count == 0 ) { return null; }
			var index = this.Items.FindIndex( d => d.PtrTargetData == address );
			return ( 0 < index && index < this.Count - 1) ? this[index + 1] : null;
		}

		/// <summary>指定したデータアドレスの1つ前のデータアドレスを取得する</summary>
		/// <param name="address">データアドレス</param>
		/// <returns>データアドレス</returns>
		public UInt32 GetPrePtrTargetDataByTargetDataAddress( UInt32 address )
		{
			var data = GetPrePointerDataByTargetDataAddress( address );
			return ( data != null ) ? data.PtrTargetData : 0;
		}

		/// <summary>指定したデータアドレスの1つ後ろのデータアドレスを取得する</summary>
		/// <param name="address">データアドレス</param>
		/// <returns>データアドレス</returns>
		public UInt32 GetNextPtrTargetDataByTargetDataAddress( UInt32 address )
		{
			var data = GetNextPointerDataByTargetDataAddress( address );
			return ( data != null ) ? data.PtrTargetData : 0;
		}

		/// <summary>ポインタリストをポインタデータ配列順にセットし直す</summary>
		private void ResetItems()
		{
			if ( this.Count == 0 )
			{
				// ポインタデータがない場合
				if ( this.PtrFirstPointerData != this.Address )
				{
					// 先頭ポインタデータへのポインタに管理用データのアドレスをセット
					this.PtrFirstPointerData = this.Address;
					this._indexItem.NeedsWrite = true;
				}
				if ( this.PtrLastPointerData != this.Address )
				{
					// 末尾ポインタデータへのポインタに管理用データのアドレスをセット
					this.PtrLastPointerData = this.Address;
					this._indexItem.NeedsWrite = true;
				}
			}
			else if ( this.Count == 1 )
			{
				// ポインタデータが1つだけある場合
				if ( this.PtrFirstPointerData != this.Items[0].Address )
				{
					// 先頭ポインタデータへのポインタセット
					this.PtrFirstPointerData = this.Items[0].Address;
					this._indexItem.NeedsWrite = true;
				}
				if ( this.PtrLastPointerData != this.Items[0].Address )
				{
					// 末尾ポインタデータへのポインタセット
					this.PtrLastPointerData = this.Items[0].Address;
					this._indexItem.NeedsWrite = true;
				}
				if ( this.Items[0].PtrPrePointerData != this.Address )
				{
					// ポインタデータの前ポインタデータへのポインタに 管理用データのアドレスをセット(呪文のようだ…)
					this.Items[0].PtrPrePointerData = this.Address;
					this.Items[0].NeedsWrite = true;
				}
				if ( this.Items[0].PtrNextPointerData != this.Address )
				{
					// ポインタデータの次ポインタデータへのポインタに 管理用データのアドレスをセット
					this.Items[0].PtrNextPointerData = this.Address;
					this.Items[0].NeedsWrite = true;
				}
				// 先頭データ＆末尾データフラグセット
				this.Items[0].IsFirst = true;
				this.Items[0].IsLast = true;
			}
			else
			{
				// ポインタデータが2つ以上ある
				if ( this.PtrFirstPointerData != this.Items[0].Address )
				{
					// 先頭ポインタデータへのポインタセット
					this.PtrFirstPointerData = this.Items[0].Address;
					this._indexItem.NeedsWrite = true;
				}
				if ( this.PtrLastPointerData != this.Items[Items.Count - 1].Address )
				{
					// 末尾ポインタデータへのポインタセット
					this.PtrLastPointerData = this.Items[Items.Count - 1].Address;
					this._indexItem.NeedsWrite = true;
				}

				if ( this.Items[0].PtrPrePointerData != this.Address )
				{
					// 先頭ポインタデータの前ポインタデータへのポインタに 管理用データのアドレスをセット
					this.Items[0].PtrPrePointerData = this.Address;
					this.Items[0].NeedsWrite = true;
				}
				if ( this.Items[0].PtrNextPointerData != this.Items[1].Address )
				{
					// 先頭ポインタデータの次ポインタデータへのポインタに 2つ目のポインタデータのアドレスをセット
					this.Items[0].PtrNextPointerData = this.Items[1].Address;
					this.Items[0].NeedsWrite = true;
				}
				// 先頭ポインタデータに先頭データフラグセット
				this.Items[0].IsFirst = true;
				this.Items[0].IsLast = false;

				for ( int i = 1; i < this.Count - 1; i++ )
				{
					// 2つ目以降(中間)のポインタデータ
					if ( this.Items[i].PtrPrePointerData != this.Items[i - 1].Address )
					{
						// ポインタデータの前ポインタデータへのポインタに 前ポインタデータのアドレスをセット
						this.Items[i].PtrPrePointerData = this.Items[i - 1].Address;
						this.Items[i].NeedsWrite = true;
					}
					if ( this.Items[i].PtrNextPointerData != this.Items[i + 1].Address )
					{
						// ポインタデータの次ポインタデータへのポインタに 次ポインタデータのアドレスをセット
						this.Items[i].PtrNextPointerData = this.Items[i + 1].Address;
						this.Items[i].NeedsWrite = true;
					}
					this.Items[i].IsFirst = false;
					this.Items[i].IsLast = false;
				}

				// 末尾ポインタデータ
				if ( this.Items[this.Count - 1].PtrPrePointerData != this.Items[this.Count - 2].Address )
				{
					this.Items[this.Count - 1].PtrPrePointerData = this.Items[this.Count - 2].Address;
					this.Items[this.Count - 1].NeedsWrite = true;
				}
				if ( this.Items[this.Count - 1].PtrNextPointerData != this.Address )
				{
					// 末尾ポインタデータの次ポインタデータへのポインタに 管理用データのアドレスをセット
					this.Items[this.Count - 1].PtrNextPointerData = this.Address;
					this.Items[this.Count - 1].NeedsWrite = true;
				}
				// 末尾ポインタデータに末尾データフラグセット
				this.Items[this.Count - 1].IsFirst = false;
				this.Items[this.Count - 1].IsLast = true;
			}
			this.CommitPointerlist();
		}

		/// <summary>指定したデータアドレスを持つポインタデータを削除する(削除後にリストの整合性を取る)</summary>
		/// <param name="address">データアドレス</param>
		/// <returns>削除に成功したら true を返す</returns>
		public bool RemoveByTargetDataAddress( UInt32 address )
		{
			// 下記コードだとリスト内に当該データアドレスを持つポインタデータが複数あっても1つしか削除しない(問題ないか？)
			if ( this.Count == 0 ) { return false; }

			var index = this.Items.FindIndex( d => d.PtrTargetData == address );
			if ( index == -1 ) { return false; }

			this.Items.RemoveAt( index );
			this.ResetItems();

			return true;
		}

		/// <summary>指定したポインタデータを末尾に追加する(追加後にリストの整合性を取る)</summary>
		/// <param name="pointerdata">追加するポインタデータ</param>
		/// <returns>追加に成功したら true を返す</returns>
		public bool AddLast( PointerData pointerdata )
		{
			if ( this.Items == null )
			{
				this.Items = new List<PointerData>();
			}

			this.Items.Add( pointerdata );
			this.ResetItems();

			return true;
		}

		/// <summary>指定したデータアドレスを持つポインタデータがポインタリスト内に存在するかチェックする</summary>
		/// <param name="address">データアドレス</param>
		/// <returns>含まれていれば true を返す</returns>
		public bool IsContainTargetDataAddress( UInt32 address )
		{
			if ( this.Count == 0 ) { return false; }

			var index = this.Items.FindIndex( d => d.PtrTargetData == address );

			return index != -1;
		}

		/// <summary>指定したデータアドレスを持つポインタデータのリスト内インデクスを取得する</summary>
		/// <param name="address">データアドレス</param>
		/// <returns>インデクス</returns>
		public int GetIndexPointerDataByTargetDataAddress( UInt32 address )
		{
			if ( this.Count == 0 ) { return -1; }
			return this.Items.FindIndex( d => d.PtrTargetData == address );
		}

		/// <summary>指定したデータアドレスを指定したインデクスにあるポインタデータに上書きする</summary>
		/// <param name="address">データアドレス</param>
		/// <param name="index">ポインタデータのインデクス</param>
		/// <returns>上書きに成功したら true を返す</returns>
		public bool WriteTargetDataAddress( UInt32 address, int index )
		{
			if ( index < 0 || this.Count <= index ) { return false; }

			this.Items[index].PtrTargetData = address;
			this.Items[index].NeedsWrite = true;

			return this.CommitPointerlist();
		}

		/// <summary>データアドレスの配列を取得する</summary>
		/// <returns>データアドレス配列</returns>
		public UInt32[] GetPtrTargetDataArray()
		{
			if ( this.Count == 0 ) { return new UInt32[0]; }

			var list = new List<UInt32>();

			foreach ( var d in this.Items )
			{
				list.Add( d.PtrTargetData );
			}
			return list.ToArray();
		}
		#endregion

		/// <summary>ポインタデータに変更があった場合プロセスメモリに書き込む</summary>
		private bool CommitPointerlist()
		{
			if ( this._indexItem.NeedsWrite )
			{
				this._n14pk.WriteMemory( this.Address, this._indexItem.Record );
				this._indexItem.NeedsWrite = false;
			}

			if ( this.Count == 0 ) { return true; }

			foreach ( var d in this.Items )
			{
				if ( d.NeedsWrite )
				{
					this._n14pk.WriteMemory( d.Address, d.Record );
					d.NeedsWrite = false;
				}
			}

			return true;
		}
	}
}
