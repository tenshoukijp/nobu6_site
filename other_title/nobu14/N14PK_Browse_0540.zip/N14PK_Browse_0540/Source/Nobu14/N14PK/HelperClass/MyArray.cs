﻿// MyArray.cs

using System;

namespace N14PKLibrary.HelperClass
{
	/// <summary>オレオレ配列</summary>
	public static class MyArray
	{
		/// <summary>パターンサーチ</summary>
		/// <remarks>見つからない場合は -1 を返す</remarks>
		/// <param name="source">検索対象</param>
		/// <param name="pattern">検索パターン</param>
		/// <returns>インデクス</returns>
		public static int QuickSearch( Byte[] source, Byte[] pattern )
		{
			var sLen = source.Length;
			var pLen = pattern.Length;

			for ( var sPos = 0; sPos <= sLen - pLen; sPos++ )
			{
				var pPos = 0;
				for ( ; pPos < pLen; pPos++ )
				{
					if ( source[sPos + pPos] != pattern[pPos] )
					{
						break;
					}
				}

				if ( pPos == pLen )
				{
					// パターンマッチ
					return sPos;
				}

				//if ( sPos == sLen - pLen )
				//{
				//	break;
				//}
			}
			return -1;  // パターンマッチなし
		}
	}
}
