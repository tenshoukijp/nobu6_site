﻿// CRC32.cs

using System;
using System.Collections.Generic;

namespace N14PKLibrary.HelperClass
{
	/// <summary>CRC32</summary>
	public static class CRC32
	{
		private const uint _CRC32_MASK = 0xFFFFFFFF;

		/// <summary>CRC32算出</summary>
		/// <param name="buff">対象バイト列</param>
		/// <returns>CRC32値</returns>
		static public uint Compute( IEnumerable<byte> buff )
		{
			// テーブルセット
			var table = new UInt32[256];
			for ( uint i = 0; i < 256; i++ )
			{
				var c = i;
				for ( var j = 0; j < 8; j++ )
				{
					c = ( ( c & 1 ) == 1 ) ? ( 0xEDB88320 ^ ( c >> 1 ) ) : ( c >> 1 );
				}
				table[i] = c;
			}

			// CRC32算出
			var crc = _CRC32_MASK;
			foreach ( var d in buff )
			{
				crc = table[( crc ^ d ) & 0xFF] ^ ( crc >> 8 );
			}

			return crc ^ _CRC32_MASK;
		}
	}
}
