﻿// MyTextConverter.cs

using System;

namespace N14PKLibrary.HelperClass
{
	/// <summary>オレオレテキストコンバータ</summary>
	public static class MyTextConverter
	{
		/// <summary>バイト列をシフトJIS文字列へ変換する</summary>
		/// <remarks>ついでに "立花誾千代" の "誾" が ゲーム内では正しく表示されるが、shift-jisコードだと "┌" になるので変換する</remarks>
		/// <param name="bytes">変換するバイト列</param>
		/// <param name="index">変換開始位置のインデクス</param>
		/// <param name="count">変換するバイト数</param>
		/// <returns>変換された文字列</returns>
		public static String BytesToString( Byte[] bytes, int index, int count )
		{
			var str = System.Text.Encoding.GetEncoding( "shift_jis" ).GetString( bytes, index, count );

			var n = str.IndexOf( '\0' );
			if ( n != -1 )
			{
				str = str.Remove( n );
			}

			// "立花誾千代" の "誾" が ゲーム内では正しく表示されるが、shift-jisコードだと "┌" になる。どういう理屈なのかわからないが変換する
			str = str.Replace( "┌", "誾" );  // 0x84a1 → 0xFBA7

			return str;
		}

		/// <summary>文字列をシフトJISバイト列に変換する</summary>
		/// <remarks>ついでに "立花誾千代" の "誾" が ゲーム内では正しく表示されるが、shift-jisコードだと "┌" になるので変換する</remarks>
		/// <param name="str">変換する文字列</param>
		/// <param name="size">変換後のバイト列サイズ</param>
		/// <returns>変換されたバイト列</returns>
		public static Byte[] StringToBytes( String str, int size )
		{
			// "立花誾千代" の "誾" が ゲーム内では正しく表示されるが、shift-jisコードだと "┌" になる。どういう理屈なのかわからないが変換する
			str = str.Replace( "誾", "┌" );  // 0xFBA7 → 0x84a1

			var bytes = System.Text.Encoding.GetEncoding("shift_jis").GetBytes( str );
			Array.Resize<Byte>( ref bytes, bytes.Length + 1 );
			
			if ( size < bytes.Length )
			{
				Array.Resize<Byte>( ref bytes, size );
				bytes[bytes.Length - 1] = (Byte)'\0';
			}
			return bytes;
		}
	}
}
