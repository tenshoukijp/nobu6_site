﻿// ProcessMemory.cs

using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace N14PKLibrary.HelperClass
{
	/// <summary>プロセス管理クラス</summary>
	public class ProcessMemory : IDisposable
	{
		private System.Diagnostics.Process _process;
		private string _processName;
		private UInt32[] _heapAddresses;

		/// <summary>コンストラクタ</summary>
		/// <param name="processName">対象プロセス名</param>
		/// <exception cref="ArgumentException">引数で指定したプロセス名が空白、または null の場合に発生する例外</exception>
		public ProcessMemory( string processName )
		{
			if ( string.IsNullOrEmpty( processName ) )
			{
				throw new ArgumentException( "プロセス名が指定されていません。" );
			}

			this._processName = processName;
			this._process = this.GetProcess( this._processName );
			this._heapAddresses = this.GetHeapAddreses();
			this.Version = this.GetVersion();
			this.VersionInt = this.GetVersionInt();
		}

		/// <summary>インスタンスを破棄する</summary>
		public void Dispose()
		{
			if ( this._process != null )
			{
				this._process = null;
			}
		}

		/// <summary>プロセスID</summary>
		public int ProcessID
		{
			get { return this._process.Id; }
		}

		/// <summary>ファイルバージョン</summary>
		public string Version { get; private set; }

		private string GetVersion()
		{
			// ピリオド区切りを想定していたが、以前 Vista 32bit でカンマ+半角スペース区切り(Ex "1, 2, 3, 4") で文字列が返るらしいとレポがあったのでピリオド区切りに整形する
			// どういう環境で差異が出るのかわからないが念のため
			var versionString = this._process.MainModule.FileVersionInfo.FileVersion;
			versionString = versionString.Replace( " ", string.Empty );
			versionString = versionString.Replace( ',', '.' );
			return versionString;
		}

		/// <summary>ファイルバージョン(4桁整数)</summary>
		/// <remarks>メジャーパート以外の数値が2桁以上の場合は意味を成さない</remarks>
		public int VersionInt { get; private set; }

		private int GetVersionInt()
		{
			var v1 = this._process.MainModule.FileVersionInfo.FileMajorPart;
			var v2 = this._process.MainModule.FileVersionInfo.FileMinorPart;
			var v3 = this._process.MainModule.FileVersionInfo.FileBuildPart;
			var v4 = this._process.MainModule.FileVersionInfo.FilePrivatePart;
			return ( v1 * 1000 ) + ( v2 * 100 ) + ( v3 * 10 ) + v4;
		}

		/// <summary>フルパス</summary>
		public string Fullpath
		{
			get { return this._process.MainModule.FileName; }
		}

		/// <summary>ディレクトリパス</summary>
		public string Directrypath
		{
			get
			{
				var index = this.Fullpath.ToLower().LastIndexOf( this._processName.ToLower() );
				return this.Fullpath.Remove( index );
			}
		}

		/// <summary>ヒープアドレス</summary>
		public UInt32[] HeapAddresses
		{
			get { return this._heapAddresses; }
		}

		/// <summary>ベースアドレス</summary>
		public UInt32 BaseAddress
		{
			get { return (UInt32)this._process.MainModule.BaseAddress; }
		}

		/// <summary>エントリポイントアドレス</summary>
		public UInt32 EntryPointAddress
		{
			get { return (UInt32)this._process.MainModule.EntryPointAddress; }
		}

		/// <summary>プライベートメモリサイズ</summary>
		public uint PrivateMemorySize
		{
			get { return (uint)this._process.PrivateMemorySize64; }
		}

		/// <summary>仮想メモリサイズ</summary>
		public uint VirtualMemorySize
		{
			get { return (uint)this._process.VirtualMemorySize64; }
		}

		/// <summary>物理メモリサイズ</summary>
		public uint WorkingSet
		{
			get { return (uint)this._process.WorkingSet64; }
		}

		/// <summary>Win32API ラストエラー</summary>
		/// <param name="APIName">エラーが発生したAPI名</param>
		/// <returns>メッセージボックス用のテキスト(エラーが発生したAPI名、エラーコード、エラーコードに対応するメッセージテキスト)</returns>
		private string GetWin32ErrorMessage( string APIName )
		{
			StringBuilder lpBuffer = new StringBuilder( 256 );
			int errorCode = Marshal.GetLastWin32Error();
			Win32API.FormatMessage( Win32API.FormatMessageFlags.FORMAT_MESSAGE_FROM_SYSTEM, IntPtr.Zero, (UInt32)errorCode, 0U, lpBuffer, lpBuffer.Capacity, IntPtr.Zero );

			return "Win32API Error : " + APIName + "\n"
					+ "コード : 0x" + errorCode.ToString( "X8" ) + "\n"
					+ lpBuffer.ToString();
		}

		/// <summary>引数で指定した文字列と一致するプロセス名のプロセスを取得する</summary>
		/// <param name="processName">対象のプロセス名</param>
		/// <returns>プロセス情報</returns>
		/// <exception cref="ArgumentException">引数で指定したプロセス名が見つからなかった場合に発生する例外</exception>
		private System.Diagnostics.Process GetProcess( string processName )
		{
			// 同一コンピュータ上の任意名のプロセスをすべて取得する
			System.Diagnostics.Process[] hProcesses = System.Diagnostics.Process.GetProcessesByName( processName );

			if ( hProcesses.Length == 0 )
			{
				throw new ApplicationException( "プロセス \"" + processName + "\" を取得できません。\nゲームが起動しているか確認して下さい。" );
			}
			else
			{
				return hProcesses[0];
			}
		}

		/// <summary>ヒープアドレスを取得する</summary>
		/// <returns>ヒープアドレス配列</returns>
		/// <exception cref="ApplicationException">スナップショット作成、またはヒープリスト取得時に発生する例外</exception>
		private UInt32[] GetHeapAddreses()
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "N14PK.Helper.ProcessMemory.GetHeapAddreses()" );
#endif
			var hl = new Win32API.HEAPLIST32() { dwSize = (uint)Marshal.SizeOf( typeof( Win32API.HEAPLIST32 ) ), };
			var addresses = new List<UInt32>();
			IntPtr hSnapshot = IntPtr.Zero;
			try
			{
				// スナップショット作成
				hSnapshot = Win32API.CreateToolhelp32Snapshot( Win32API.SnapshotFlags.TH32CS_SNAPHEAPLIST, (uint)this.ProcessID );
				if ( (int)hSnapshot == -1 )
				{
					throw new ApplicationException( this.GetWin32ErrorMessage( "CreateToolhelp32Snapshot" ) );
				}

				// ヒープリストを取得する
				if ( Win32API.Heap32ListFirst( hSnapshot, ref hl ) )
				{
					do
					{
						addresses.Add( hl.th32HeapID );
					} while ( Win32API.Heap32ListNext( hSnapshot, ref hl ) );

					addresses.Sort();
					return addresses.ToArray();
				}
				else
				{
					throw new ApplicationException( this.GetWin32ErrorMessage( "Heap32ListFirst" ) );
				}
			}
			catch ( Exception ex )
			{
				throw new ApplicationException( ex.Message );
			}
			finally
			{
				Win32API.CloseHandle( hSnapshot );
			}
		}

		/// <summary>プロセスメモリ読み込み</summary>
		/// <param name="address">読み込み開始アドレス</param>
		/// <param name="size">読み込みサイズ</param>
		/// <param name="skipError">読み込みエラー無視フラグ</param>
		/// <returns>読み込んだデータ</returns>
		/// <exception cref="ApplicationException">読み込みに失敗した場合に発生する例外</exception>
		public byte[] ReadMemory( UInt32 address, UInt32 size, bool skipError = false )
		{
			var buff = new byte[size];
			uint numberOfBytesRead;
			bool hasError;

			hasError = !Win32API.ReadProcessMemory( this._process.Handle, (IntPtr)address, buff, size, out numberOfBytesRead );
			if ( !skipError && hasError )
			{
				throw new ApplicationException( this.GetWin32ErrorMessage( "ReadProcessMemory" ) );
			}

			return buff;
		}

		/// <summary>プロセスメモリ書き込み</summary>
		/// <param name="address">書き込み開始アドレス</param>
		/// <param name="buff">書き込みデータ</param>
		/// <returns>書き込んだバイト数</returns>
		/// <exception cref="ApplicationException">書き込みに失敗した場合に発生する例外</exception>
		public uint WriteMemory( UInt32 address, Byte[] buff )
		{
			uint numberOfBytesWrite;
			bool hasError;

			hasError = !Win32API.WriteProcessMemory( this._process.Handle, (IntPtr)address, buff, (UInt32)buff.Length, out numberOfBytesWrite );

			if ( hasError )
			{
				throw new ApplicationException( this.GetWin32ErrorMessage( "WriteProcessMemory" ) );
			}

			return numberOfBytesWrite;
		}
	}
}
