﻿// MyBitConverter.cs

using System;
using System.Runtime.InteropServices;

namespace N14PKLibrary.HelperClass
{
	/// <summary>オレオレビットコンバータ</summary>
	public static class MyBitConverter
	{
		/// <summary>バイト配列から バイト位置 と ビット位置 を指定して Boolean へ変換する</summary>
		/// <param name="bytes">対象バイト配列</param>
		/// <param name="byteindex">開始バイトのインデクス</param>
		/// <param name="bitindex">ターゲットビットのインデクス</param>
		/// <returns>ブール値</returns>
		public static Boolean ToBoolean( Byte[] bytes, UInt32 byteindex, UInt32 bitindex )
		{
			byteindex += bitindex / 8;
			bitindex %= 8;

			// パラメータチェック
			if ( bytes.Length <= byteindex )
			{
				// 取得位置がバイト配列を超えている
				throw new ArgumentOutOfRangeException( "MyBitConverter.ToBoolean()\n取得位置がバイト配列の範囲外です。" );
			}

			// ビットマスク設定
			Byte mask = 1;
			mask <<= (Int32)bitindex;

			return ( bytes[byteindex] & mask ) == 0 ? false : true;
		}

		/// <summary>バイト配列から 開始バイト 開始ビット ビットサイズ を指定して Int32値 を取得する</summary>
		/// <param name="bytes">バイト配列</param>
		/// <param name="byteindex">開始バイトインデクス</param>
		/// <param name="bitindex">開始ビットインデクス</param>
		/// <param name="bitsize">取得ビットサイズ</param>
		/// <returns>変換された値</returns>
		public static Int32 ToInt32( Byte[] bytes, UInt32 byteindex, UInt32 bitindex, UInt32 bitsize )
		{
			byteindex += bitindex / 8;
			bitindex %= 8;

			// データ取得に必要なバイト数
			var length = (UInt32)Math.Ceiling( ( bitindex + bitsize ) / 8.0D );

			// パラメータチェック
			if ( 32 < bitsize )
			{
				throw new ArgumentOutOfRangeException( "MyBitConverter.ToInt32()\n取得ビットサイズが32ビットを超えています。" );
			}
			if ( bytes.Length <= byteindex + length )
			{
				throw new ArgumentOutOfRangeException( "MyBitConverter.ToInt32()\n取得位置がバイト配列の範囲外です。" );
			}

			return (Int32)BytesToUInt64( bytes, byteindex, bitindex, bitsize, length );
		}

		/// <summary>バイト配列から 開始バイト 開始ビット ビットサイズ を指定して UInt32値 を取得する</summary>
		/// <param name="bytes">バイト配列</param>
		/// <param name="byteindex">開始バイトインデクス</param>
		/// <param name="bitindex">開始ビットインデクス</param>
		/// <param name="bitsize">取得ビットサイズ</param>
		/// <returns>変換された値</returns>
		public static UInt32 ToUInt32( Byte[] bytes, UInt32 byteindex, UInt32 bitindex, UInt32 bitsize )
		{
			byteindex += bitindex / 8;
			bitindex %= 8;

			// データ取得に必要なバイト数
			var length = (UInt32)Math.Ceiling( ( bitindex + bitsize ) / 8.0D );

			// パラメータチェック
			if ( 32 < bitsize )
			{
				throw new ArgumentOutOfRangeException( "MyBitConverter.ToUInt32()\n取得ビットサイズが32ビットを超えています。" );
			}
			if ( bytes.Length < byteindex + length )
			{
				throw new ArgumentOutOfRangeException( "MyBitConverter.ToUInt32()\n取得位置がバイト配列の範囲外です。" );
			}

			return (UInt32)BytesToUInt64( bytes, byteindex, bitindex, bitsize, length );
		}

		/// <summary>バイト配列から 開始バイト 開始ビット ビットサイズ を指定して Int16値 を取得する</summary>
		/// <param name="bytes">バイト配列</param>
		/// <param name="byteindex">開始バイトインデクス</param>
		/// <param name="bitindex">開始ビットインデクス</param>
		/// <param name="bitsize">取得ビットサイズ</param>
		/// <returns>変換された値</returns>
		public static Int16 ToInt16( Byte[] bytes, UInt32 byteindex, UInt32 bitindex, UInt32 bitsize )
		{
			byteindex += bitindex / 8;
			bitindex %= 8;

			// データ取得に必要なバイト数
			var length = (UInt32)Math.Ceiling( ( bitindex + bitsize ) / 8.0D );

			// パラメータチェック
			if ( 16 < bitsize )
			{
				throw new ArgumentOutOfRangeException( "MyBitConverter.ToInt16()\n取得ビットサイズが16ビットを超えています。" );
			}
			if ( bytes.Length < byteindex + length )
			{
				throw new ArgumentOutOfRangeException( "MyBitConverter.ToInt16()\n取得位置がバイト配列の範囲外です。" );
			}

			return (Int16)BytesToUInt64( bytes, byteindex, bitindex, bitsize, length );
		}

		/// <summary>バイト配列から 開始バイト 開始ビット ビットサイズ を指定して UInt16値 を取得する</summary>
		/// <param name="bytes">バイト配列</param>
		/// <param name="byteindex">開始バイトインデクス</param>
		/// <param name="bitindex">開始ビットインデクス</param>
		/// <param name="bitsize">取得ビットサイズ</param>
		/// <returns>変換された値</returns>
		public static UInt16 ToUInt16( Byte[] bytes, UInt32 byteindex, UInt32 bitindex, UInt32 bitsize )
		{
			byteindex += bitindex / 8;
			bitindex %= 8;

			// データ取得に必要なバイト数
			var length = (UInt32)Math.Ceiling( ( bitindex + bitsize ) / 8.0D );

			// パラメータチェック
			if ( 16 < bitsize )
			{
				throw new ArgumentOutOfRangeException( "MyBitConverter.ToUInt16()\n取得ビットサイズが16ビットを超えています。" );
			}
			if ( bytes.Length < byteindex + length )
			{
				throw new ArgumentOutOfRangeException( "MyBitConverter.ToUInt16()\n取得位置がバイト配列の範囲外です。" );
			}

			return (UInt16)BytesToUInt64( bytes, byteindex, bitindex, bitsize, length );
		}

		/// <summary>バイト配列から 開始バイト 開始ビット ビットサイズ を指定して SByte値 を取得する</summary>
		/// <param name="bytes">バイト配列</param>
		/// <param name="byteindex">開始バイトインデクス</param>
		/// <param name="bitindex">開始ビットインデクス</param>
		/// <param name="bitsize">取得ビットサイズ</param>
		/// <returns>変換された値</returns>
		public static SByte ToSByte( Byte[] bytes, UInt32 byteindex, UInt32 bitindex, UInt32 bitsize )
		{
			byteindex += bitindex / 8;
			bitindex %= 8;

			// データ取得に必要なバイト数
			var length = (UInt32)Math.Ceiling( ( bitindex + bitsize ) / 8.0D );

			// パラメータチェック
			if ( 8 < bitsize )
			{
				throw new ArgumentOutOfRangeException( "MyBitConverter.ToSByte()\n取得ビットサイズが8ビットを超えています。" );
			}
			if ( bytes.Length < byteindex + length )
			{
				throw new ArgumentOutOfRangeException( "MyBitConverter.ToSByte()\n取得位置がバイト配列の範囲外です。" );
			}

			return (SByte)BytesToUInt64( bytes, byteindex, bitindex, bitsize, length );
		}

		/// <summary>バイト配列から 開始バイト 開始ビット ビットサイズ を指定して Byte値 を取得する</summary>
		/// <param name="bytes">バイト配列</param>
		/// <param name="byteindex">開始バイトインデクス</param>
		/// <param name="bitindex">開始ビットインデクス</param>
		/// <param name="bitsize">取得ビットサイズ</param>
		/// <returns>変換された値</returns>
		public static Byte ToByte( Byte[] bytes, UInt32 byteindex, UInt32 bitindex, UInt32 bitsize )
		{
			byteindex += bitindex / 8;
			bitindex %= 8;

			// データ取得に必要なバイト数
			var length = (UInt32)Math.Ceiling( ( bitindex + bitsize ) / 8.0D );

			// パラメータチェック
			if ( 8 < bitsize )
			{
				throw new ArgumentOutOfRangeException( "MyBitConverter.ToByte()\n取得ビットサイズが8ビットを超えています。" );
			}
			if ( bytes.Length < byteindex + length )
			{
				throw new ArgumentOutOfRangeException( "MyBitConverter.ToByte()\n取得位置がバイト配列の範囲外です。" );
			}

			return (Byte)BytesToUInt64( bytes, byteindex, bitindex, bitsize, length );
		}

		/// <summary>バイト配列から UInt64値 を取得する</summary>
		/// <param name="bytes">バイト配列</param>
		/// <param name="byteindex">開始バイトインデクス</param>
		/// <param name="bitindex">開始ビットインデクス</param>
		/// <param name="bitsize">取得ビットサイズ</param>
		/// <param name="length">データ取得に必要なバイト数</param>
		/// <returns>UInt64値</returns>
		private static UInt64 BytesToUInt64( Byte[] bytes, UInt32 byteindex, UInt32 bitindex, UInt32 bitsize, UInt32 length )
		{
			// ビットマスク設定
			UInt64 mask = 0;
			for ( var i = bitindex; i < bitindex + bitsize; i++ )
			{
				mask |= ( 1UL << (Int32)i );
			}

			// バイト配列から取得対象となるバイト配列を取り出し UInt64 へ変換
			UInt64 ret = 0;
			for ( var i = 0; i < length; i++ )
			{
				ret += ( (UInt64)bytes[byteindex + i] << 8 * i );
			}

			// マスク処理
			ret &= mask;
			ret >>= (Int32)bitindex;

			return ret;
		}

		/// <summary>開始バイト 開始ビット ビットサイズ を指定してバイト配列へ値を埋め込む</summary>
		/// <typeparam name="T">型パラメータ</typeparam>
		/// <param name="value">埋め込む値</param>
		/// <param name="bytes">埋め込み先のバイト配列</param>
		/// <param name="byteindex">開始バイト</param>
		/// <param name="bitindex">開始ビット</param>
		/// <param name="bitsize">ビットサイズ</param>
		public static void IntoBytes<T>( T value, Byte[] bytes, UInt32 byteindex, UInt32 bitindex, UInt32 bitsize = 1 )
			where T : struct
		{
			byteindex += bitindex / 8;
			bitindex %= 8;

			// データ埋め込みに必要なバイト数
			var length = (int)Math.Ceiling( ( bitindex + bitsize ) / 8.0D );

			// パラメータチェック
			if ( bitsize == 0 )
			{
				throw new ArgumentException( "MyBitConverter.IntoBytes()\n埋め込みビットサイズが 0 です。" );
			}
			if ( Marshal.SizeOf( typeof(T) ) * 8 < bitsize )
			{
				throw new ArgumentOutOfRangeException( "MyBitConverter.IntoBytes()\n埋め込みビットサイズが埋め込む値の型サイズを超えています。" );
			}
			if ( bytes.Length < byteindex + length )
			{
				throw new ArgumentOutOfRangeException( "MyBitConverter.IntoBytes()\n値を埋め込む位置がバイト配列の範囲外です。" );
			}

			// ビットマスク設定
			UInt64 mask = 0;
			for ( var i = bitindex; i < bitindex + bitsize; i++ )
			{
				mask |= ( 1UL << (Int32)i );
			}

			// マスク処理のため埋め込む値を UInt64 へ変換
			UInt64 ulongValue = 0;
			ulongValue = (UInt64)Convert.ToInt64( value );
			ulongValue <<= (Int32)bitindex;

			// 埋め込む値をマスク
			ulongValue &= mask;

			// 埋め込み先バイト配列から埋め込み対象となるバイト配列を取り出し UInt64 へ変換
			UInt64 source = 0;
			for ( var i = 0; i < length; i++ )
			{
				source += ( (uint)bytes[byteindex + i] << 8 * i );
			}

			// 埋め込み範囲のビットクリア
			source &= ~mask;

			// 値を埋め込む
			source |= ulongValue;

			// 埋め込まれた ulong 値をバイト配列へ変換
			var buff = BitConverter.GetBytes( source );

			// バイト配列へ戻す
			Array.Copy( buff, 0, bytes, byteindex, length );
		}
	}
}
