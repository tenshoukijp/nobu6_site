﻿// Win32API.cs

using System;
using System.Runtime.InteropServices;
using System.Text;

namespace N14PKLibrary.HelperClass
{
	/// <summary>Win32API</summary>
	class Win32API
	{
		// FormatMessage 入力元と処理方法のオプションフラグ
		[Flags]
		public enum FormatMessageFlags : uint
		{
			FORMAT_MESSAGE_ALLOCATE_BUFFER  = 0x00000100
			,FORMAT_MESSAGE_IGNORE_INSERTS  = 0x00000200
			,FORMAT_MESSAGE_FROM_STRING		= 0x00000400
			,FORMAT_MESSAGE_FROM_HMODULE	= 0x00000800
			,FORMAT_MESSAGE_FROM_SYSTEM		= 0x00001000
			,FORMAT_MESSAGE_ARGUMENT_ARRAY  = 0x00002000
			,FORMAT_MESSAGE_MAX_WIDTH_MASK  = 0x000000FF
		}

		// Win32API FormatMessage インポートライブラリ：Kernel32.lib を使用
		// メッセージ文字列を書式化します(書式を割り当てます)。
		// 関数が成功すると、バッファに格納された TCHAR 単位の文字数が返ります。終端の NULL 文字は、この数に含まれません。
		// 関数が失敗すると、0 が返ります。

		// DWORD FormatMessage(
		//     DWORD dwFlags		// 入力元と処理方法のオプション
		//     ,LPCVOID lpSource	// メッセージの入力元
		//     ,DWORD dwMessageId	// メッセージ識別子
		//     ,DWORD dwLanguageId	// 言語識別子
		//     ,LPTSTR lpBuffer		// メッセージバッファ
		//     ,DWORD nSize			// メッセージバッファの最大サイズ
		//     ,va_list* Arguments	// 複数のメッセージ挿入シーケンスからなる配列
		// );
		[DllImport( "kernel32.dll", SetLastError = true )]
		public static extern UInt32 FormatMessage(
			FormatMessageFlags dwFlags
			,IntPtr lpSource
			,UInt32 dwMessageId
			,UInt32 dwLanguageId
			,StringBuilder lpBuffer
			,Int32 nSize
			,IntPtr Arguments
		);

		// プロセスアクセスフラグ
		[Flags]
		public enum ProcessAccessFlags : uint
		{
			PROCESS_TERMINATE			= 0x00000001
			,PROCESS_CREATE_THREAD		= 0x00000002
			,PROCESS_SET_SESSIONID		= 0x00000004
			,PROCESS_VM_OPERATION		= 0x00000008
			,PROCESS_VM_READ			= 0x00000010
			,PROCESS_VM_WRITE			= 0x00000020
			,PROCESS_DUP_HANDLE			= 0x00000040
			,PROCESS_CREATE_PROCESS		= 0x00000080
			,PROCESS_SET_QUOTA			= 0x00000100
			,PROCESS_SET_INFORMATION	= 0x00000200
			,PROCESS_QUERY_INFORMATION  = 0x00000400
			,PROCESS_ALL_ACCESS			= 0x001F0FFF
			,SYNCHRONIZE				= 0x00100000
		}

		// Win32API OpenProcess インポートライブラリ：Kernel32.lib を使用
		// 既存のプロセスオブジェクトのハンドルを開きます。
		// 関数が成功すると、指定したプロセスの、既に開いているハンドルが返ります。
		// 関数が失敗すると、NULL が返ります。

		// HANDLE OpenProcess(
		//     DWORD dwDesiredAccess	// アクセスフラグ
		//     ,BOOL bInheritHandle		// ハンドルの継承オプション
		//     ,DWORD dwProcessId		// プロセス識別子
		// );
		[DllImport( "kernel32.dll", SetLastError = true )]
		public static extern IntPtr OpenProcess(
			ProcessAccessFlags dwDesiredAccess,
			[MarshalAs( UnmanagedType.Bool )] Boolean bInheritHandle,
			UInt32 dwProcessId
		);

		// Win32API GetExitCodeProcess インポートライブラリ：Kernel32.lib を使用
		// 指定されたプロセスの終了ステータスを取得します。
		// 関数が成功すると、0 以外の値が返ります。
		// 関数が失敗すると、0 が返ります。拡張エラー情報を取得するには、 関数を使います。
		// 指定したプロセスが終了していない場合、終了ステータスとして STILL_ACTIVE が格納されます。
		// プロセスが既に終了した場合は、終了ステータスとして次のいずれかが格納されます。
		//	ExitProcess または TerminateProcess 関数で指定した終了コード。
		//	ロセスの main または WinMain 関数の戻り値。
		//	ロセスを終了させた、まだ処理されていない例外の例外コード。

		// BOOL GetExitCodeProcess(
		//     HANDLE hProcess		// プロセスのハンドル
		//     ,LPDWORD lpExitCode  // 終了ステータス
		// );
		[DllImport( "kernel32.dll", SetLastError = true )]
		public static extern Boolean GetExitCodeProcess(
			IntPtr hProcess
			,out UInt32 lpExitCode
			);

		// スナップショットフラグ
		[Flags]
		public enum SnapshotFlags : uint
		{
			TH32CS_INHERIT			= 0x80000000	// スナップショットのハンドルが継承可能であることを意味します。
			,TH32CS_SNAPALL			= 0x0000000F	// TH32CS_SNAPHEAPLIST、TH32CS_SNAPMODULE、TH32CS_SNAPPROCESS、 TH32CS_SNAPTHREAD のすべてを指定したのと同じことを意味します。
			,TH32CS_SNAPHEAPLIST	= 0x00000001	// 指定されたプロセスのヒープリストを、スナップショットに含めます。
			,TH32CS_SNAPMODULE		= 0x00000008	// 指定されたプロセスのモジュールリストを、スナップショットに含めます。
			,TH32CS_SNAPMODULE32	= 0x00000010	// 指定されたプロセスのモジュールリストを、スナップショットに含めます。
			,TH32CS_SNAPPROCESS		= 0x00000002	// プロセスリストを、スナップショットに含めます。
			,TH32CS_SNAPTHREAD		= 0x00000004	// スレッドリストを、スナップショットに含めます。
		}

		// Win32API CreateToolhelp32Snapshot インポートライブラリ：Kernel32.lib を使用
		// プロセスと、プロセスが使っているヒープ、モジュール、スレッドのスナップショットを作成します。
		// 関数が成功すると、指定されたスナップショットのハンドルが返ります。
		// 関数が失敗すると、-1 が返ります。

		// HANDLE WINAPI CreateToolhelp32Snapshot(
		//     DWORD dwFlags				// システムのどの部分をスナップショットに含めたいかを指定します。
		//     ,DWORD th32ProcessID			// プロセス識別子を指定します。0 を指定すると、現在のプロセスが表せます。TH32CS_SNAPHEAPLIST、または TH32CS_SNAPMODULE フラグをセットしたときに、このパラメータが使われます。それ以外の場合は、このパラメータは無視されます。
		// );
		[DllImport( "kernel32.dll", SetLastError = true )]
		public static extern IntPtr CreateToolhelp32Snapshot(
			SnapshotFlags dwFlags
			,UInt32 th32ProcessID
		);

		// MODULEENTRY32 構造体
		[StructLayout( LayoutKind.Sequential )]
		public struct MODULEENTRY32
		{
			const int MAX_MODULE_NAME32 = 255;
			const int MAX_PATH = 260;
			internal UInt32 dwSize;
			internal UInt32 th32ModuleID;
			internal UInt32 th32ProcessID;
			internal UInt32 GlblcntUsage;
			internal UInt32 ProccntUsage;
			internal IntPtr modBaseAddr;
			internal UInt32 modBaseSize;
			internal IntPtr hModule;
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = MAX_MODULE_NAME32 + 1)]
			internal string szModule;
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = MAX_PATH)]
			internal string szExePath;
		}

		// HEAPLIST32 構造体
		[StructLayout( LayoutKind.Sequential )]
		public struct HEAPLIST32
		{
			internal UInt32 dwSize;
			internal UInt32 th32ProcessID;
			internal UInt32 th32HeapID;
			internal UInt32 dwFlags;
		}

		// HEAPENTRY32 構造体
		[StructLayout( LayoutKind.Sequential )]
		public struct HEAPENTRY32
		{
			internal UInt32 dwSize;
			internal IntPtr hHandle;
			internal UInt32 dwAddress;
			internal UInt32 dwBlockSize;
			internal UInt32 dwFlags;
			internal UInt32 dwLockCount;
			internal UInt32 dwResvd;
			internal UInt32 th32ProcessID;
			internal UInt32 th32HeapID;
		}

		// Win32API Module32First インポートライブラリ：Kernel32.lib を使用
		// プロセスに関連付けられている最初のモジュールに関する情報を取得します。
		// モジュールリストの最初のエントリがバッファへコピーされた場合は、TRUE が返ります。
		// それ以外の場合は、FALSE が返ります。

		// BOOL WINAPI Module32First(
		//     HANDLE hSnapshot			// 直前に CreateToolhelp32Snapshot 関数を呼び出したときに返された、スナップショットのハンドルを指定します。
		//     ,LPMODULEENTRY32 lpme	// 構造体のハンドルを指定します。
		// );
		[DllImport( "kernel32.dll", SetLastError = true )]
		[return: MarshalAs( UnmanagedType.Bool )]
		public static extern Boolean Module32First(
			IntPtr hSnapshot
			,ref MODULEENTRY32 lpme
		);

		[DllImport( "kernel32.dll", SetLastError = true )]
		[return: MarshalAs( UnmanagedType.Bool )]
		public static extern Boolean Module32Next(
			IntPtr hSnapshot
			,ref MODULEENTRY32 lpme
		);

		// Win32API Heap32ListFirst インポートライブラリ：Kernel32.lib を使用
		// 指定されたプロセスが割り当てた最初のヒープに関する情報を取得します。
		// ヒープリストの最初のエントリがバッファにコピーされた場合は、TRUE が返ります。
		// それ以外の場合は、FALSE が返ります。

		// BOOL WINAPI Heap32ListFirst(
		//     HANDLE hSnapshot			// 直前に CreateToolhelp32Snapshot 関数を呼び出したときに返された、スナップショットのハンドルを指定します。
		//     ,LPHEAPLIST32 lphl		// 構造体のハンドルを指定します。
		// );
		[DllImport( "kernel32.dll", SetLastError = true )]
		[return: MarshalAs( UnmanagedType.Bool )]
		public static extern Boolean Heap32ListFirst(
			IntPtr hSnapshot
			,ref HEAPLIST32 lphl
		);

		[DllImport( "kernel32.dll", SetLastError = true )]
		[return: MarshalAs( UnmanagedType.Bool )]
		public static extern Boolean Heap32ListNext(
			IntPtr hSnapshot
			,ref HEAPLIST32 lphl
		);

		// Win32API Heap32First インポートライブラリ：Kernel32.lib を使用
		// プロセスが割り当てたヒープの最初のブロックに関する情報を取得します。
		// 最初のヒープブロックがバッファにコピーされた場合は、TRUE が返ります。
		// それ以外の場合は、FALSE が返ります。

		// BOOL WINAPI Heap32First(
		//     LPHEAPENTRY32 lphe		// 構造体へのポインタを指定します。
		//     ,DWORD th32ProcessID		// ヒープを保持するプロセスコンテキストの識別子を指定します。
		//     ,DWORD th32HeapID		// 列挙したいヒープの識別子を指定します。
		// );
		[DllImport( "kernel32.dll", SetLastError = true )]
		[return: MarshalAs( UnmanagedType.Bool )]
		public static extern Boolean Heap32First(
			ref HEAPENTRY32 lphe
			,UInt32 th32ProcessID
			,UInt32 th32HeapID
		);

		[DllImport( "kernel32.dll", SetLastError = true )]
		[return: MarshalAs( UnmanagedType.Bool )]
		public static extern Boolean Heap32Next(
			ref HEAPENTRY32 lphe
		);

		// Win32API CloseHandle インポートライブラリ：Kernel32.lib を使用
		// 開いているオブジェクトのハンドルを指定します。関数から制御が返ると、このハンドルに、同じオブジェクトのハンドルが格納されますが、閉じることに成功した場合はカウンタが 1 減ります。
		// 関数が成功すると、0 以外の値が返ります。
		// 関数が失敗すると、0 が返ります。

		// BOOL CloseHandle(
		//     HANDLE hObject   // オブジェクトのハンドル
		// );
		[DllImport( "kernel32.dll", SetLastError = true )]
		[return: MarshalAs( UnmanagedType.Bool )]
		public static extern Boolean CloseHandle(
			IntPtr hObject
		);

		// Win32API ReadProcessMemory インポートライブラリ：Kernel32.lib を使用
		// 指定されたプロセスのメモリ領域からデータを読み取ります。読み取られる領域全体がアクセス可能でなければなりません。さもないと、関数は失敗します。
		// 関数が成功すると、0 以外の値が返ります。
		// 関数が失敗すると、0 が返ります。

		// BOOL ReadProcessMemory(
		//     HANDLE hProcess				// プロセスのハンドル このハンドルは、プロセスに対する PROCESS_VM_READ アクセス権を備えていなければなりません。
		//     ,LPCVOID lpBaseAddress		// 読み取り開始アドレス
		//     ,LPVOID lpBuffer				// データを格納するバッファ
		//     ,DWORD nSize					// 読み取りたいバイト数
		//     ,LPDWORD lpNumberOfBytesRead	// 実際に読み取ったバイト数
		// );
		[DllImport( "kernel32.dll", SetLastError = true )]
		[return: MarshalAs( UnmanagedType.Bool )]
		public static extern Boolean ReadProcessMemory(
			IntPtr hProcess
			,IntPtr lpBaseAddress
			,byte[] lpBuffer
			,UInt32 nSize
			,out UInt32 lpNumberOfBytesRead
		);

		// Win32API WriteProcessMemory インポートライブラリ：Kernel32.lib を使用
		// 指定されたプロセスのメモリ領域にデータを書き込みます。書き込みたい領域全体がアクセス可能でなければなりません。さもないと、関数は失敗します。
		// 関数が成功すると、0 以外の値が返ります。
		// 関数が失敗すると、0 が返ります。

		// BOOL WriteProcessMemory(
		//     HANDLE hProcess					// プロセスのハンドル このハンドルは、プロセスに対する PROCESS_VM_WRITE と PROCESS_VM_OPERATION の各アクセス権を備えていなければなりません。
		//     ,LPVOID lpBaseAddress			// 書き込み開始アドレス
		//     ,LPVOID lpBuffer					// データバッファ
		//     ,DWORD nSize						// 書き込みたいバイト数
		//     ,LPDWORD lpNumberOfBytesWritten	// 実際に書き込まれたバイト数
		// );
		[DllImport( "kernel32.dll", SetLastError = true )]
		[return: MarshalAs( UnmanagedType.Bool )]
		public static extern Boolean WriteProcessMemory(
			IntPtr hProcess
			,IntPtr lpBaseAddress
			,byte[] lpBuffer
			,UInt32 nSize
			,out UInt32 lpNumberOfBytesWritten
		);
	}
}
