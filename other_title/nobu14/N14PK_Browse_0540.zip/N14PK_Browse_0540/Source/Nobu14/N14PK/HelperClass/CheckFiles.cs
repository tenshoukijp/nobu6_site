﻿// CheckFiles.cs

using System;
using System.Collections.Generic;
using System.IO;

namespace N14PKLibrary.HelperClass
{
	/// <summary>ファイルチェック用クラス</summary>
	public static class CheckFiles
	{
		/// <summary>チェック</summary>
		/// <param name="process">対象プロセス</param>
		/// <param name="versionConfig">バージョン設定</param>
		public static void Check( HelperClass.ProcessMemory process, VersionConfig.IVersionConfig versionConfig )
		{
			var dirpath = process.Directrypath;
			var dirInfo =new DirectoryInfo( dirpath );	// ディレクトリ情報
			var filesinfo = new List<FileInfo>();		// ファイル情報
			bool existSteamApiDll = false;

			foreach ( var d in dirInfo.GetFileSystemInfos() )
			{
				if ( "steam_api.dll".ToLower() == d.Name.ToLower() )
				{
					existSteamApiDll = true;
					if ( !CheckCRC32( d.FullName, versionConfig.Steam_apiCrc32 ) )
					{
						// steam_api.dll CRC32チェックエラー
						throw new ApplicationException( "Unknown Error" );
					}
					break;
				}
			}

			if ( !existSteamApiDll )
			{
				// steam_api.dll が存在しない
				throw new ApplicationException( "Unknown Error" );
			}

			if ( !CheckCRC32( process.Fullpath, versionConfig.Nobu14pkCrc32 ) )
			{
				// NOBU14PK.EXE CRC32チェックエラー
				throw new ApplicationException( "Unknown Error" );
			}
		}

		/// <summary>ファイル名(フルパス) と CRC32値 を指定してチェック</summary>
		/// <param name="filename">ファイル名(フルパス)</param>
		/// <param name="crc32">CRC32値</param>
		/// <returns>チェックOKなら true、NGなら false を返す。</returns>
		private static bool CheckCRC32( String filename, UInt32 crc32 )
		{
			if ( crc32 == 0 )
			{
				// crc32が 0 なければチェックをスルーする
				return true;
			}

			using ( var fs = new FileStream( filename, FileMode.Open, FileAccess.Read ) )
			{
				var fileSize = (int)fs.Length;	// ファイルサイズ
				var buff = new byte[fileSize];	// データ格納用配列

				fs.Read( buff, 0, fileSize );

				return HelperClass.CRC32.Compute( buff ) == crc32;
			}
		}
	}
}
