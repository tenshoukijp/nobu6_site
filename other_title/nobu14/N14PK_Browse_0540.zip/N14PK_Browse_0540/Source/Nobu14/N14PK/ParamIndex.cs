﻿// ParamInfo.cs

using System;

namespace N14PKLibrary
{
	/// <summary>Paramデータ用インデクス</summary>
	public class ParamIndex
	{
		private static HelperClass.ProcessMemory _pm;

		/// <summary>Paramインデクステーブル開始アドレス</summary>
		/// ゲーム起動中は変わることが無いため、サーチ結果をスタティックで保持して次回検索をスルーする
		public static UInt32 ParamIndexAddress { get; private set; }

		/// <summary>Paramインデクステーブルをプロセスメモリから読み込んでセットする</summary>
		/// <remarks>引数 paramIndexAddress が0ならプロセスメモリをサーチする</remarks>
		/// <param name="process">プロセス管理</param>
		/// <param name="paramIndexAddress">Paramインデクステーブル開始アドレス</param>
		/// <exception cref="ApplicationException">Paramインデクステーブルが見つからない場合に発生する例外</exception>
		public static void SetParamIndexAddress( HelperClass.ProcessMemory process, UInt32 paramIndexAddress )
		{
			_pm = process;
			if ( ( ParamIndex.ParamIndexAddress == 0 ) && ( paramIndexAddress != 0 ) )
			{
				// ベースアドレスからのオフセットなので実際のアドレスを計算
				ParamIndex.ParamIndexAddress = _pm.BaseAddress + paramIndexAddress;
			}
#if DEBUG
			var sw = new System.Diagnostics.Stopwatch();
			sw.Start();
#endif
			while ( !CheckIndexData() )
			{
				// Paramインデクステーブル開始アドレスをサーチする。(ParamIndexAddress == 0(未知バージョン)か指定したアドレスで見つからない場合)
				// パラメータ名 "szSQUARE" を検索し、そのアドレスを参照しているポインタを探す
				// リードエラーを無視してプロセスメモリにアクセスするため、エラー時の読み取りサイズ範囲に目的のデータがあるとヒットしない
				// ヒープエントリを取得してブロックの状態を確認しながらやると、ものすご～く時間がかかって実用に耐えない。ベターな方法がわからない

				var szSQUAREAddress = SearchszSQUAREAddress();
				if ( szSQUAREAddress == 0 )
				{
					throw new ApplicationException( "Paramデータ(szSQUARE)が見つかりません。" );
				}

				ParamIndex.ParamIndexAddress = SearchParamIndexAddress( szSQUAREAddress );
				if ( ParamIndex.ParamIndexAddress == 0 )
				{
					throw new ApplicationException( "Paramインデクステーブルが見つかりません。" );
				}
			}
#if DEBUG
			sw.Stop();
			System.Diagnostics.Debug.WriteLine( "Param インデクスアドレスセット 処理時間:" + sw.ElapsedMilliseconds + " ms" );
			System.Diagnostics.Debug.WriteLine( "Param インデクスアドレス: " + ParamIndex.ParamIndexAddress.ToString( "X8" ) );
#endif
		}

		/// <summary>プロセスメモリからインデクスデータを読み込んでチェック</summary>
		/// <returns>データが想定している値なら true を返す</returns>
		private static bool CheckIndexData()
		{
			if ( ( ParamIndex.ParamIndexAddress == 0 ) || ( _pm.VirtualMemorySize < ParamIndex.ParamIndexAddress ) )
			{
				// 先頭インデクスデータへのポインタアドレスチェック
				return false;
			}

			// 先頭インデクスデータの一部を読み込み
			var buff = _pm.ReadMemory( ParamIndex.ParamIndexAddress - 1, 5, skipError: true );
			if ( buff == null )
			{
				return false;
			}

			var address = BitConverter.ToUInt32( buff, 1 );
			if ( ( address == 0 ) || ( _pm.VirtualMemorySize < address ) )
			{
				// 先頭インデクスデータ内のパラメータ名へのポインタアドレスチェック
				return false;
			}

			// パラメータ名へのポインタが格納されている直前のバイトに 0x68 が入っているのでこれをチェックに利用する
			return buff[0] == 0x68;
		}

		/// <summary>先頭パラメータ名 "szSQUARE" サーチ</summary>
		/// <returns>先頭パラメータ名アドレス</returns>
		private static uint SearchszSQUAREAddress()
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "Param 先頭パラメータ名(szSQUARE)サーチ" );
#endif
			var isHit = false;					// ヒットフラグ
			uint readSize = 0x00010000;			// 一度に読み込むサイズ 64KB
			byte[] pattern = new byte[]
			{
				0x73, 0x7A, 0x53, 0x51, 0x55, 0x41, 0x52, 0x45, 0x00	// szSQUARE
			};

			var address = _pm.BaseAddress;
			while ( !isHit && ( address < _pm.PrivateMemorySize ) )
			{
				// 予約・フリー領域等へのReadエラーを無視して読み込む
				var buff = _pm.ReadMemory( address, readSize, skipError: true );
				// サーチ
				var index = HelperClass.MyArray.QuickSearch( buff, pattern );
				if ( index != -1 )
				{
					return (UInt32)( address + index );
				}
				address += readSize - (UInt32)pattern.Length;
			}
			return 0;
		}

		/// <summary>先頭インデクスデータアドレスサーチ</summary>
		/// <param name="szSQUAREAddress">先頭パラメータ名 "szSQUARE" アドレス</param>
		/// <returns>先頭インデクスデータアドレス</returns>
		private static uint SearchParamIndexAddress( UInt32 szSQUAREAddress )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "Param 先頭インデクスデータアドレスサーチ" );
#endif
			var isHit = false;			// ヒットフラグ
			uint readSize = 0x00010000;				// 一度に読み込むサイズ 64KB
			byte[] pattern = BitConverter.GetBytes( szSQUAREAddress );

			var address = _pm.BaseAddress;
			while ( !isHit && ( address < _pm.PrivateMemorySize ) )
			{
				// 予約・フリー領域等へのReadエラーを無視して読み込む
				var buff = _pm.ReadMemory( address, readSize, skipError: true );
				// サーチ
				var index = HelperClass.MyArray.QuickSearch( buff, pattern );
				if ( index != -1 )
				{
					return (UInt32)( address + index );
				}
				address += readSize - (UInt32)pattern.Length;
			}
			return 0;
		}
	}
}
