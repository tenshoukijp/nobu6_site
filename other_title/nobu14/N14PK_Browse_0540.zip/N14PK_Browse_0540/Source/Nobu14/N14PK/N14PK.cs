﻿// N14PK.cs

using System;

using N14PKLibrary.HelperClass;
using N14PKLibrary.Table;
using N14PKLibrary.VersionConfig;

namespace N14PKLibrary
{
	/// <summary>ゲームプロセス管理クラス</summary>
	public class N14PK : IDisposable
	{
		/// <summary>プロセスメモリ</summary>
		private ProcessMemory _pm;

		/// <summary>バージョン別の設定情報(メモリアドレスや定数など)</summary>
		private IVersionConfig _config;

		/// <summary>ゲームバージョン</summary>
		public String GameVersion
		{ get { return this._pm.Version; } }

		/// <summary>ゲームバージョン(4桁整数)</summary>
		/// <remarks>メジャーパート以外の数値が2桁以上の場合は意味を成さない</remarks>
		public Int32 GameVersionInt
		{
			get { return this._pm.VersionInt; }
		}

		/// <summary>シナリオ名アドレス</summary>
		private UInt32 _scenarioNameAddress;

		/// <summary>シナリオ名</summary>
		public String ScenarioName { get; private set; }

		/// <summary>トランザクション開始時のゲーム内日時</summary>
		public DateTime TransactionDateTime { get; private set; }

		/// <summary>インデクステーブル</summary>
		public IndexTable Indextable { get; private set; }

		/// <summary>データテーブル配列</summary>
		public DataTable[] Datatables
		{
			get { return this._tables; }
		}
		private DataTable[] _tables;

		#region 各テーブル取得用プロパティ
		/// <summary>武将テーブル</summary>
		public BusyouTable Busyoutable 
		{ get { return this._tables[(int)DataKind.武将] as BusyouTable; } }

		/// <summary>城テーブル</summary>
		public ShiroTable Shirotable 
		{ get { return this._tables[(int)DataKind.城] as ShiroTable; } }

		/// <summary>勢力テーブル</summary>
		public SeiryokuTable Seiryokutable 
		{ get { return this._tables[(int)DataKind.勢力] as SeiryokuTable; } }

		/// <summary>軍団テーブル</summary>
		public GundanTable Gundantable 
		{ get { return this._tables[(int)DataKind.軍団] as GundanTable; } }

		/// <summary>部隊テーブル</summary>
		public ButaiTable Butaitable 
		{ get { return this._tables[(int)DataKind.部隊] as ButaiTable; } }

		/// <summary>建物テーブル</summary>
		public TatemonoTable Tatemonotable 
		{ get { return this._tables[(int)DataKind.建物] as TatemonoTable; } }

		/// <summary>家宝テーブル</summary>
		public KahouTable Kahoutable 
		{ get { return this._tables[(int)DataKind.家宝] as KahouTable; } }

		/// <summary>国人衆テーブル</summary>
		public KokujinTable Kokujintable 
		{ get { return this._tables[(int)DataKind.国人衆] as KokujinTable; } }

		/// <summary>要所テーブル</summary>
		public YousyoTable Yousyotable 
		{ get { return this._tables[(int)DataKind.要所] as YousyoTable; } }

		/// <summary>街道テーブル</summary>
		public KaidouTable Kaidoutable 
		{ get { return this._tables[(int)DataKind.街道] as KaidouTable; } }

		/// <summary>施設テーブル</summary>
		public ShisetsuTable Shisetsutable 
		{ get { return this._tables[(int)DataKind.施設] as ShisetsuTable; } }

		/// <summary>政策テーブル</summary>
		public SeisakuTable Seisakutable 
		{ get { return this._tables[(int)DataKind.政策] as SeisakuTable; } }

		/// <summary>戦法テーブル</summary>
		public SenpouTable Senpoutable 
		{ get { return this._tables[(int)DataKind.戦法] as SenpouTable; } }

		/// <summary>特性テーブル</summary>
		public TokuseiTable Tokuseitable 
		{ get { return this._tables[(int)DataKind.特性] as TokuseiTable; } }

		/// <summary>特性習得条件テーブル</summary>
		public TokuseiSyuutokuJoukenTable TokuseiSyuutokuJoukentable 
		{ get { return this._tables[(int)DataKind.習得条件] as TokuseiSyuutokuJoukenTable; } }

		/// <summary>成長型テーブル</summary>
		public SeichougataTable Seichougatatable 
		{ get { return this._tables[(int)DataKind.成長型] as SeichougataTable; } }

		/// <summary>地方テーブル</summary>
		public ChihouTable Chihoutable 
		{ get { return this._tables[(int)DataKind.地方] as ChihouTable; } }

		/// <summary>国テーブル</summary>
		public KuniTable Kunitable 
		{ get { return this._tables[(int)DataKind.国] as KuniTable; } }

		/// <summary>効果テーブル</summary>
		public KoukaTable Koukatable 
		{ get { return this._tables[(int)DataKind.効果] as KoukaTable; } }

		/// <summary>方針テーブル</summary>
		public HoushinTable Houshintable 
		{ get { return this._tables[(int)DataKind.方針] as HoushinTable; } }

		/// <summary>軍略テーブル</summary>
		public GunryakuTable Gunryakutable 
		{ get { return this._tables[(int)DataKind.軍略] as GunryakuTable; } }

		/// <summary>城郭テーブル</summary>
		public JoukakuTable Joukakutable 
		{ get { return this._tables[(int)DataKind.城郭] as JoukakuTable; } }

		/// <summary>城名テーブル</summary>
		public ShiroNameTable ShiroNametable 
		{ get { return this._tables[(int)DataKind.城名] as ShiroNameTable; } }

		/// <summary>Paramテーブル</summary>
		public ParamTable Paramtable { get; private set; }
		#endregion

		/// <summary>コンストラクタ</summary>
		/// <param name="config">バージョン別設定情報</param>
		public N14PK( IVersionConfig config )
		{
			// プロセス取得
			this._pm = new ProcessMemory( config.ProcessName );

			// バージョンチェック
			switch ( this._pm.Version )
			{
				#region バージョンチェック
				//case "1.0.0.1":
				//	this._config = new VersionConfig.V1001();
				//	break;
				//case "1.0.1.0":
				//	this._config = new VersionConfig.V1010();
				//	break;
				//case "1.0.2.0":
				//	this._config = new VersionConfig.V1020();
				//	break;
				//case "1.0.3.0":
				//	this._config = new VersionConfig.V1030();
				//	break;
				//case "1.0.3.1":
				//	this._config = new VersionConfig.V1031();
				//	break;
				//case "1.0.4.0":
				//	this._config = new VersionConfig.V1040();
				//	break;
				//case "1.0.4.1":
				//	this._config = new VersionConfig.V1041();
				//	break;
				case "1.0.5.0":
					this._config = new VersionConfig.V1050();
					break;

				default:
					if ( this._pm.VersionInt < 1050 )
					{
						throw new ApplicationException( "ゲームバージョン 1.0.5.0 未満には未対応です。" );
					}
					this._config = new VersionConfig.UnknownVersion();
					break;
				#endregion
			}

			// トランザクション開始
			this.Transaction();
		}

		/// <summary>インスタンスを破棄する</summary>
		public void Dispose()
		{
			if( this._pm != null )
			{
				this._pm.Dispose();
				this._pm = null;
			}
		}

		/// <summary>トランザクション処理を開始する</summary>
		private void Transaction()
		{
			// ファイルチェック
			//CheckFiles.Check( this._pm, this._config );

			// インデクステーブル取得
			this.Indextable = new IndexTable( this._pm, this._config );

			// Paramインデクステーブルサーチ
			try
			{
				ParamIndex.SetParamIndexAddress( this._pm, this._config.ParamIndexAddress );
			}
			catch
			{
				// サーチエラー
			}

			// シナリオ名アドレス、シナリオ名取得
			var address = IndexTable.Address - this._config.OffsetIndexTblAddress + this._config.OffsetScenarioNamePointerAddress;
			this._scenarioNameAddress = BitConverter.ToUInt32( this._pm.ReadMemory( address, sizeof( UInt32 ) ), 0 );
			// 先頭4バイトはマジックナンバーなので飛ばす。シナリオ名の最大長は分からないがこれ以上だとセーブ＆ロード時に年と表示がかぶる
			this.ScenarioName = MyTextConverter.BytesToString( this._pm.ReadMemory( this._scenarioNameAddress + 4, 18 ), 0, 18 );

			// トランザクション開始ゲーム内日時
			this.TransactionDateTime = this.GetCurrentDateTime();

			// 各データテーブル
			this._tables = new DataTable[this.Indextable.Count];
			this._tables[(int)DataKind.武将]		= new BusyouTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.城]			= new ShiroTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.勢力]		= new SeiryokuTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.軍団]		= new GundanTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.部隊]		= new ButaiTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.建物]		= new TatemonoTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.家宝]		= new KahouTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.国人衆]		= new KokujinTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.要所]		= new YousyoTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.街道]		= new KaidouTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.施設]		= new ShisetsuTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.政策]		= new SeisakuTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.戦法]		= new SenpouTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.特性]		= new TokuseiTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.習得条件]	= new TokuseiSyuutokuJoukenTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.成長型]		= new SeichougataTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.地方]		= new ChihouTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.国]			= new KuniTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.効果]		= new KoukaTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.方針]		= new HoushinTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.軍略]		= new GunryakuTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.城郭]		= new JoukakuTable( this._pm, this.Indextable );
			this._tables[(int)DataKind.城名]		= new ShiroNameTable( this._pm, this.Indextable );
			this.Paramtable							= new ParamTable( this._pm, this._config );
		}

		/// <summary>現在のゲーム内日時を取得する</summary>
		/// <returns>System.DateTime</returns>
		/// <exception cref="ApplicationException">取得した日時データを System.DateTime 形式に変換できない場合に発生する例外</exception>
		public DateTime GetCurrentDateTime()
		{
			// 補足)このアドレスから -6h にはシナリオ開始日時データ(2+1+1+2バイト)が格納されている
			var address	= this._scenarioNameAddress + this._config.OffsetDateTime;

			var year	= BitConverter.ToUInt16( this._pm.ReadMemory( address, 2 ), 0 );
			var month	= this._pm.ReadMemory( address + 2, 1 )[0];
			var day		= this._pm.ReadMemory( address + 3, 1 )[0];
			var hour	= BitConverter.ToUInt16( this._pm.ReadMemory( address + 4, 2 ), 0 );

			try
			{
				return new DateTime( (int)year, (int)month, (int)day, (int)hour, 0, 0 );
			}
			catch ( ArgumentOutOfRangeException )
			{
				throw new ApplicationException( "タイトル画面等ではデータを取得できません。" );
			}
		}

		/// <summary>データテーブルを取得する</summary>
		/// <param name="dataKind">データの種類</param>
		/// <returns>データテーブル</returns>
		public DataTable GetTable( DataKind dataKind ) { return this.GetTable( (int)dataKind ); }
		/// <summary>データテーブルを取得する</summary>
		/// <param name="n">データテーブル番号</param>
		/// <returns>データテーブル</returns>
		public DataTable GetTable( int n )
		{
			if ( n < 0 || this._tables.Length <= n )
			{
				return null;
			}

			return this._tables[n];
		}

		/// <summary>プロセスメモリ読み込み</summary>
		/// <param name="address">読み込み開始アドレス</param>
		/// <param name="size">読み込みサイズ</param>
		/// <param name="skipError">読み込みエラー無視フラグ</param>
		/// <returns>読み込んだデータ</returns>
		public byte[] ReadMemory( UInt32 address, UInt32 size, bool skipError = false )
		{
			// N14PKLibrary.ProcessMemory.ReadMemory 呼び出し
			return this._pm.ReadMemory( address, size, skipError );
		}

		/// <summary>プロセスメモリ書き込み</summary>
		/// <param name="address">書き込み開始アドレス</param>
		/// <param name="buff">書き込みデータ</param>
		/// <returns>書き込んだバイト数</returns>
		public uint WriteMemory( UInt32 address, Byte[] buff )
		{
			// N14PKLibrary.ProcessMemory.WriteMemory 呼び出し
			return this._pm.WriteMemory( address, buff );
		}
	}
}
