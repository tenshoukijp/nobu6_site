﻿// IVersionConfig.cs

using System;

namespace N14PKLibrary.VersionConfig
{
	/// <summary>バージョン別設定用インターフェイス</summary>
	public interface IVersionConfig
	{
		/// <summary>プロセス名</summary>
		String ProcessName { get; }

		/// <summary>NOBU14PK.EXE CRC32</summary>
		/// 0 の場合はCRC32チェックをしない
		UInt32 Nobu14pkCrc32 { get; }

		/// <summary>steam_api.dll CRC32</summary>
		/// 0 の場合はCRC32チェックをしない
		UInt32 Steam_apiCrc32 { get; }

		/// <summary>各データテーブルの構造情報が格納されているインデクステーブルへのポインタアドレス
		/// <para>(ベースアドレスからのオフセット)</para></summary>
		/// 0 の場合はプロセスメモリ内をサーチする
		UInt32 IndexTblPointerAddress { get; }

		/// <summary>インデクステーブルのレコードサイズ</summary>
		UInt32 IndexTblRecordSize { get; }

		/// <summary>インデクステーブルのレコード数</summary>
		UInt32 IndexTblRecordCount { get; }

		/// <summary>インデクステーブルアドレスから実際のインデクス情報の先頭レコードまでのオフセット</summary>
		UInt32 OffsetIndexTblAddress { get; }

		/// <summary>インデクステーブルアドレスからシナリオ名へのポインタアドレスまでのオフセット</summary>
		UInt32 OffsetScenarioNamePointerAddress { get; }

		/// <summary>シナリオ名アドレスからゲーム内日時データアドレスまでのオフセット</summary>
		UInt32 OffsetDateTime { get; }

		/// <summary>武将データ数</summary>
		/// <remarks>IndexTblPointerAddress で直接インデクステーブルを取得した場合の確認用に使用する</remarks>
		UInt32 BusyouDataCount { get; }

		/// <summary>武将データレコードサイズ</summary>
		/// <remarks>蠣崎サーチ時に武将データ内の名前でヒットしたかどうかを判断するのに使用する</remarks>
		UInt32 BusyouDataRecoedSize { get; }

		/// <summary>Paramデータインデクスの先頭アドレス
		/// <para>(ベースアドレスからのオフセット)</para></summary>
		/// 0 の場合はプロセスメモリ内をサーチする
		UInt32 ParamIndexAddress { get; }

		/// <summary>Paramデータ初期値配列</summary>
		Int32[] ParamDefaultValues { get; }
	}
}
