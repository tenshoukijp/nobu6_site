﻿using System;

namespace N14PKLibrary.VersionConfig
{
	/// <summary>未知バージョン用設定情報</summary>
	public class UnknownVersion : IVersionConfig
	{
		/// <summary>プロセス名</summary>
		public String ProcessName { get { return "NOBU14PK"; } }

		/// <summary>NOBU14PK.EXE のCRC32</summary>
		public UInt32 Nobu14pkCrc32 { get { return 0; } }

		/// <summary>steam_api.dll のCRC32</summary>
		public UInt32 Steam_apiCrc32 { get { return 0; } }

		/// <summary>各データテーブルの構造情報が格納されているインデクステーブルへのポインタアドレス</summary>
		public UInt32 IndexTblPointerAddress { get { return 0; } }

		/// <summary>インデクステーブルのレコードサイズ</summary>
		public UInt32 IndexTblRecordSize { get { return 0x10; } }

		/// <summary>インデクステーブルのレコード数</summary>
		public UInt32 IndexTblRecordCount { get { return 34; } }

		/// <summary>インデクステーブルアドレスから実際のインデクス情報の先頭レコードまでのオフセット</summary>
		public UInt32 OffsetIndexTblAddress { get { return 0xB0; } }

		/// <summary>インデクステーブルアドレスからシナリオ名へのポインタアドレスまでのオフセット</summary>
		public UInt32 OffsetScenarioNamePointerAddress { get { return 0x2D4; } }

		/// <summary>シナリオ名アドレスからゲーム内日時データアドレスまでのオフセット</summary>
		public UInt32 OffsetDateTime { get { return 0x1CC; } }

		/// <summary>武将データ数</summary>
		/// <remarks>IndexTblPointerAddress で直接インデクステーブルを取得した場合の確認用に使用する</remarks>
		public UInt32 BusyouDataCount { get { return 0xE26; } }

		/// <summary>武将データレコードサイズ</summary>
		/// <remarks>蠣崎サーチ時に武将データ内の名前でヒットしたかどうかを判断するのに使用する</remarks>
		public UInt32 BusyouDataRecoedSize { get { return 0x170; } }

		/// <summary>Paramデータインデクスの先頭アドレス</summary>
		public UInt32 ParamIndexAddress { get { return 0; } }

		/// <summary>Paramデータ初期値配列</summary>
		public Int32[] ParamDefaultValues { get { return null; } }
	}
}
