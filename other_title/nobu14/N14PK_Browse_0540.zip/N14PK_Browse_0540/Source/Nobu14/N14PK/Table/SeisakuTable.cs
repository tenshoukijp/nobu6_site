﻿// SeisakuTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>政策テーブルを管理するクラス</summary>
	public class SeisakuTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public SeisakuTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.政策] ) {}

		/// <summary>インデクサ データテーブルから政策データを読み書きする</summary>
		/// <param name="id">政策ID</param>
		/// <returns>政策データ</returns>
		public new SeisakuData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>政策データ</returns>
		public new IEnumerator<SeisakuData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで政策データにキャストして返す</summary>
		/// <param name="id">政策ID</param>
		/// <returns>政策データ</returns>
		public SeisakuData GetData( Int32 id )
		{
			return base.GetData<SeisakuData>( id );
		}

		/// <summary>政策データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">政策ID</param>
		/// <param name="data">政策データ</param>
		public void SetData( Int32 id, SeisakuData data )
		{
			base.SetData<SeisakuData>( id, data );
		}

		/// <summary>インデクサ データテーブルから政策データを読み書きする</summary>
		/// <param name="address">政策データアドレス</param>
		/// <returns>政策データ</returns>
		public SeisakuData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで政策データにキャストして返す</summary>
		/// <param name="address">政策データアドレス</param>
		/// <returns>政策データ</returns>
		public SeisakuData GetData( UInt32 address )
		{
			return base.GetData<SeisakuData>( address );
		}

		/// <summary>政策データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">政策データアドレス</param>
		/// <param name="data">政策データ</param>
		public void SetData( UInt32 address, SeisakuData data )
		{
			base.SetData<SeisakuData>( address, data );
		}
	}
}
