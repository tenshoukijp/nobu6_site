﻿// SeichougataTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>成長型テーブルを管理するクラス</summary>
	public class SeichougataTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public SeichougataTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.成長型] ) {}

		/// <summary>インデクサ データテーブルから成長型データを読み書きする</summary>
		/// <param name="id">成長型ID</param>
		/// <returns>成長型データ</returns>
		public new SeichougataData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>成長型データ</returns>
		public new IEnumerator<SeichougataData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで成長型データにキャストして返す</summary>
		/// <param name="id">成長型ID</param>
		/// <returns>成長型データ</returns>
		public SeichougataData GetData( Int32 id )
		{
			return base.GetData<SeichougataData>( id );
		}

		/// <summary>成長型データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">成長型ID</param>
		/// <param name="data">成長型データ</param>
		public void SetData( Int32 id, SeichougataData data )
		{
			base.SetData<SeichougataData>( id, data );
		}

		/// <summary>インデクサ データテーブルから成長型データを読み書きする</summary>
		/// <param name="address">成長型データアドレス</param>
		/// <returns>成長型データ</returns>
		public SeichougataData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで成長型データにキャストして返す</summary>
		/// <param name="address">成長型データアドレス</param>
		/// <returns>成長型データ</returns>
		public SeichougataData GetData( UInt32 address )
		{
			return base.GetData<SeichougataData>( address );
		}

		/// <summary>成長型データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">成長型データアドレス</param>
		/// <param name="data">成長型データ</param>
		public void SetData( UInt32 address, SeichougataData data )
		{
			base.SetData<SeichougataData>( address, data );
		}
	}
}
