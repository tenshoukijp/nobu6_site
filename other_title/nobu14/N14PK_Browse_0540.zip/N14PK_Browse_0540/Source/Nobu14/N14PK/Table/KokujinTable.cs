﻿// KokujinTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>国人衆テーブルを管理するクラス</summary>
	public class KokujinTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public KokujinTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.国人衆] ) {}

		/// <summary>インデクサ データテーブルから国人衆データを読み書きする</summary>
		/// <param name="id">国人衆ID</param>
		/// <returns>国人衆データ</returns>
		public new KokujinData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>国人衆データ</returns>
		public new IEnumerator<KokujinData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで国人衆データにキャストして返す</summary>
		/// <param name="id">国人衆ID</param>
		/// <returns>国人衆データ</returns>
		public KokujinData GetData( Int32 id )
		{
			return base.GetData<KokujinData>( id );
		}

		/// <summary>国人衆データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">国人衆ID</param>
		/// <param name="data">国人衆データ</param>
		public void SetData( Int32 id, KokujinData data )
		{
			base.SetData<KokujinData>( id, data );
		}

		/// <summary>インデクサ データテーブルから国人衆データを読み書きする</summary>
		/// <param name="address">国人衆データアドレス</param>
		/// <returns>国人衆データ</returns>
		public KokujinData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで国人衆データにキャストして返す</summary>
		/// <param name="address">国人衆データアドレス</param>
		/// <returns>国人衆データ</returns>
		public KokujinData GetData( UInt32 address )
		{
			return base.GetData<KokujinData>( address );
		}

		/// <summary>国人衆データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">国人衆データアドレス</param>
		/// <param name="data">国人衆データ</param>
		public void SetData( UInt32 address, KokujinData data )
		{
			base.SetData<KokujinData>( address, data );
		}
	}
}
