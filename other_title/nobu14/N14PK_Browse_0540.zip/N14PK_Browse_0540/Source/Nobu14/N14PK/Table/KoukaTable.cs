﻿// KoukaTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>効果テーブルを管理するクラス</summary>
	public class KoukaTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public KoukaTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.効果] ) {}

		/// <summary>インデクサ データテーブルから効果データを読み書きする</summary>
		/// <param name="id">効果ID</param>
		/// <returns>効果データ</returns>
		public new KoukaData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>効果データ</returns>
		public new IEnumerator<KoukaData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで効果データにキャストして返す</summary>
		/// <param name="id">効果ID</param>
		/// <returns>効果データ</returns>
		public KoukaData GetData( Int32 id )
		{
			return base.GetData<KoukaData>( id );
		}

		/// <summary>効果データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">効果ID</param>
		/// <param name="data">効果データ</param>
		public void SetData( Int32 id, KoukaData data )
		{
			base.SetData<KoukaData>( id, data );
		}

		/// <summary>インデクサ データテーブルから効果データを読み書きする</summary>
		/// <param name="address">効果データアドレス</param>
		/// <returns>効果データ</returns>
		public KoukaData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで効果データにキャストして返す</summary>
		/// <param name="address">効果データアドレス</param>
		/// <returns>効果データ</returns>
		public KoukaData GetData( UInt32 address )
		{
			return base.GetData<KoukaData>( address );
		}

		/// <summary>効果データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">効果データアドレス</param>
		/// <param name="data">効果データ</param>
		public void SetData( UInt32 address, KoukaData data )
		{
			base.SetData<KoukaData>( address, data );
		}
	}
}
