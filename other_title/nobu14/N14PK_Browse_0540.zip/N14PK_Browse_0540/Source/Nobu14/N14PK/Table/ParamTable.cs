﻿// ParamTable.cs

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using N14PKLibrary.HelperClass;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>Paramテーブルを管理するクラス</summary>
	public class ParamTable
	{
		/// <summary>各Paramのアドレス情報</summary>
		public class ParamInfo
		{
			/// <summary>パラメータ名</summary>
			public UInt32 PtrName { get; set; }

			/// <summary>パラメータ値</summary>
			public UInt32 PtrValue { get; set; }
		}

		/// <summary>レコード数</summary>
		public Int32 RecordCount
		{
			get { return ( this._items != null ) ? this._items.Length : 0; }
		}

		/// <summary>コミットするデータIDリスト</summary>
		public List<Int32> CommitIDList { get; private set; }

		private HelperClass.ProcessMemory _pm;
		private VersionConfig.IVersionConfig _config;

		private ParamInfo[] _paramsInfo;
		private ParamData[] _items;

		/// <summary>コンストラクタ</summary>
		/// <param name="pm">プロセス管理</param>
		/// <param name="config">バージョン別設定情報</param>
		public ParamTable( HelperClass.ProcessMemory pm, VersionConfig.IVersionConfig config )
		{
			this._pm = pm;
			this._config = config;
			this.SetParamInfo();
			this.SetParamItem();
			this.CommitIDList = new List<int>();
		}

		/// <summary>パラメータ名と値へのポインタアドレスをセットする</summary>
		private void SetParamInfo()
		{
			if ( ParamIndex.ParamIndexAddress == 0 ) { return; }
			// Paramのインデクスデータ構造はよくわからない
			byte[] buff;
			var list = new List<ParamInfo>();
			var address = ParamIndex.ParamIndexAddress;

			buff = this._pm.ReadMemory( address - 1, 1 );	// データのチェックに使うバイト値
			var checkdata = buff[0];

			buff = this._pm.ReadMemory( address, 0x27 );
			if ( buff[buff.Length - 1] != checkdata ) { return; }

			list.Add( new ParamInfo
			{
				PtrName = BitConverter.ToUInt32( buff, 0x00 ),
				PtrValue = BitConverter.ToUInt32( buff, 0x16 )
			} );

			address += 0x27;

			do
			{
				buff = this._pm.ReadMemory( address, 0x24 );
				if ( buff[buff.Length - 1] != checkdata ) { break; }
				list.Add( new ParamInfo
				{
					PtrName = BitConverter.ToUInt32( buff, 0x00 ),
					PtrValue = BitConverter.ToUInt32( buff, 0x13 )
				} );
				address += 0x24;
			}
			while ( buff[buff.Length - 1] == checkdata );

			buff = this._pm.ReadMemory( address, 0x1F );
			if ( buff[buff.Length - 1] != checkdata ) { return; }

			list.Add( new ParamInfo
			{
				PtrName = BitConverter.ToUInt32( buff, 0x00 ),
				PtrValue = BitConverter.ToUInt32( buff, 0x13 )
			} );

			address += 0x1F;

			do
			{
				buff = this._pm.ReadMemory( address, 0x1E );
				list.Add( new ParamInfo
				{
					PtrName = BitConverter.ToUInt32( buff, 0x00 ),
					PtrValue = BitConverter.ToUInt32( buff, 0x12 )
				} );
				if ( buff[buff.Length - 1] != checkdata ) { break; }
				address += 0x1E;
			}
			while ( buff[buff.Length - 1] == checkdata );

			this._paramsInfo = list.ToArray();
		}

		/// <summary>Paramの各データをセットする</summary>
		private void SetParamItem()
		{
			if ( this._paramsInfo == null ) { return; }
			var list = new List<ParamData>();
			for ( var i = 0; i < this._paramsInfo.Length; i++ )
			{
				int? defvalue = null;
				if ( this._config.ParamDefaultValues != null
					&& i < this._config.ParamDefaultValues.Length
					)
				{
					defvalue = this._config.ParamDefaultValues[i];
				}

				list.Add( new ParamData
				{
					ID = i,
					Address = this._paramsInfo[i].PtrValue,
					Value = BitConverter.ToInt32( this._pm.ReadMemory( this._paramsInfo[i].PtrValue, 4 ), 0 ),
					Name = HelperClass.MyTextConverter.BytesToString( this._pm.ReadMemory( this._paramsInfo[i].PtrName, 128 ), 0, 128 ),
					DefaultValue = defvalue
				} );
			}
			this._items = list.ToArray();
		}

		/// <summary>インデクサ</summary>
		/// <param name="id">ParamID</param>
		/// <returns>Paramデータ</returns>
		public ParamData this[Int32 id]
		{
			get
			{
				if ( this._items == null ) { return null; }
				return Array.Find( this._items, d => d.ID == id );
			}
		}

		/// <summary>インデクサ</summary>
		/// <param name="address">Param値アドレス</param>
		/// <returns>Paramデータ</returns>
		public ParamData this[UInt32 address]
		{
			get
			{
				if ( this._items == null ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ</summary>
		/// <param name="name">Param名</param>
		/// <returns>Paramデータ</returns>
		public ParamData this[String name]
		{
			get
			{
				if ( this._items == null ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}

		/// <summary>イテレータ</summary>
		/// <returns>Paramデータ</returns>
		public IEnumerator<ParamData> GetEnumerator()
		{
			if ( this._items == null ) { yield return null; }
			for ( var i = 0; i < this._items.Length; i++ )
			{
				yield return this._items[i];
			}
		}

		/// <summary>Param値をParamテーブルに書き込む。Commit メソッドを呼び出すまではプロセスメモリに反映しない</summary>
		/// <param name="id">ParamID</param>
		public void Write( Int32 id )
		{
			this.CommitIDList.Add( id );
		}

		/// <summary>Param値をParamテーブルに書き込む。Commit メソッドを呼び出すまではプロセスメモリに反映しない</summary>
		/// <param name="data">Paramデータ</param>
		public void Write( ParamData data )
		{
			this.CommitIDList.Add( data.ID );
		}

		/// <summary>Paramテーブルをプロセスメモリに書き込む</summary>
		public void Commit()
		{
			var list = new List<int>();
			foreach ( var d in this._items )
			{
				list.Add( d.ID );
			}
			this.Commit( list.ToArray() );
		}

		/// <summary>Paramテーブルをプロセスメモリに書き込む</summary>
		/// <param name="ids">書き込むParamIDの配列</param>
		public void Commit( params Int32[] ids )
		{
			foreach( var id in ids )
			{
				var address = this._items[id].Address;
				var buff = BitConverter.GetBytes( this._items[id].Value );
				this._pm.WriteMemory( address, buff );
			}
			this.CommitIDList.Clear();
		}
	}
}
