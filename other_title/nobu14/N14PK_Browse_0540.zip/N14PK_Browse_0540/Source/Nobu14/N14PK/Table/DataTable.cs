﻿// DataTable.cs

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>メモリ上のデータテーブルを管理する基底クラス</summary>
	public class DataTable : IDisposable
	{
		/// <summary>プロセス管理</summary>
		protected HelperClass.ProcessMemory _pm;

		/// <summary>データテーブル</summary>
		protected System.IO.MemoryStream _table;

		/// <summary>レコードへのポインタテーブル</summary>
		public PointerTable Pointertable { get; private set; }

		/// <summary>データテーブルアドレス</summary>
		public UInt32 Address
		{
			get { return ( this.Pointertable != null ) ? this.Pointertable[0] : 0; }
		}

		/// <summary>レコード数</summary>
		public Int32 RecordCount
		{
			get { return ( this.Pointertable != null ) ? this.Pointertable.Count : 0; }
		}

		/// <summary>レコードサイズ</summary>
		public UInt32 RecordSize
		{
			get { return ( this.Pointertable != null ) ? (uint)Math.Abs( this.Pointertable[1] - this.Pointertable[0] ) : 0; }
		}

		/// <summary>コミットするデータIDリスト
		/// <para>複数のデータをまとめてコミットするときに使用する<para>
		/// </para>Write()メソッド内でデータIDがリストに追加され、Commit()メソッド終了時にクリアされる</para></summary>
		public List<Int32> CommitIDList { get; private set; }

		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexData">データテーブル構造情報</param>
		public DataTable( HelperClass.ProcessMemory process, IndexTable.Index indexData )
		{
			this._pm = process;
			this.Pointertable = new PointerTable( process, indexData );
			this._table = new System.IO.MemoryStream( this.ReadMemory() );
			this.CommitIDList = new List<int>();
		}

		/// <summary>デストラクタ</summary>
		~DataTable()
		{
			this.Dispose();
		}

		/// <summary>インスタンスを破棄する</summary>
		public void Dispose()
		{
			if( this._table != null  )
			{
				this._table.Close();
				this._table = null;
			}
		}

		/// <summary>インデクサ データテーブルからレコードを読み書きする</summary>
		/// <param name="id">レコードID</param>
		/// <returns>レコード</returns>
		public Byte[] this[Int32 id]
		{
			get
			{
				return this.Read( id );
			}
			set
			{
				this.Write( id, value );
			}
		}

		/// <summary>イテレータ</summary>
		/// <returns>レコード</returns>
		public IEnumerator< byte[] > GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.Read( i );
			}
		}

		/// <summary>プロセスメモリから読み込み</summary>
		/// <returns>読み込んだメモリ</returns>
		protected byte[] ReadMemory()
		{
			var size = this.RecordSize * this.RecordCount;
			var address = this.Address;
			return this._pm.ReadMemory( address, (uint)size );
		}

		/// <summary>データテーブルからレコードを読み込み</summary>
		/// <param name="id">レコードID</param>
		/// <returns>レコード</returns>
		public byte[] Read( Int32 id )
		{
			var buff = new byte[this.RecordSize];
			this._table.Seek( this.Pointertable[id] - this.Address, System.IO.SeekOrigin.Begin );
			this._table.Read( buff, 0, (int)this.RecordSize );
			return buff;
		}

		/// <summary>レコードをデータテーブルに書き込む。Commit メソッドを呼び出すまではプロセスメモリに反映しない</summary>
		/// <param name="id">レコードID</param>
		/// <param name="record">レコード</param>
		/// <exception cref="ArgumentException">レコードサイズが当該テーブルのレコードサイズと異なる場合に発生する例外</exception>
		public void Write( Int32 id, Byte[] record )
		{
			if( record.Length != this.RecordSize )
			{
				throw new ArgumentException( "データサイズが異なります。要求サイズ: " + this.RecordSize.ToString() + " データサイズ: " + record.Length.ToString() );
			}
			this._table.Seek( this.Pointertable[id] - this.Address, System.IO.SeekOrigin.Begin );
			this._table.Write( record, 0, (int)this.RecordSize );
			this.CommitIDList.Add( id );
		}

		/// <summary>レコードをデータテーブルに書き込む。Commit メソッドを呼び出すまではプロセスメモリに反映しない</summary>
		/// <param name="data">データ</param>
		/// <exception cref="ArgumentException">データ内のレコードサイズが当該テーブルのレコードサイズと異なる場合に発生する例外</exception>
		public void Write( IData data )
		{
			var record = data.GetRecord();
			if( record.Length != this.RecordSize )
			{
				throw new ArgumentException( "データサイズが異なります。要求サイズ: " + this.RecordSize.ToString() + " データサイズ: " + record.Length.ToString() );
			}
			this._table.Seek( data.Address - this.Address, System.IO.SeekOrigin.Begin );
			this._table.Write( record, 0, (int)this.RecordSize );
			this.CommitIDList.Add( data.ID );
		}

		/// <summary>データテーブルをプロセスメモリに書き込む</summary>
		public void Commit()
		{
			this.WriteMemory();
			this.CommitIDList.Clear();
		}

		/// <summary>データテーブルをプロセスメモリに書き込む</summary>
		/// <param name="ids">書き込むレコードID配列</param>
		public void Commit( params Int32[] ids )
		{
			foreach( var id in ids )
			{
				this.WriteMemory( id );
			}
			this.CommitIDList.Clear();
		}

		/// <summary>データテーブル全体をプロセスメモリに書き込む</summary>
		protected void WriteMemory()
		{
			var address = this.Address;
			this._pm.WriteMemory( Address, this._table.ToArray() );
		}

		/// <summary>プロセスメモリに書き込む</summary>
		/// <param name="id">書き込むレコードID</param>
		protected void WriteMemory( Int32 id )
		{
			var address = this.Pointertable[id];
			var record = this.Read( id );
			this._pm.WriteMemory( address, record );
		}

		/// <summary>データテーブルからレコードを読み込んでデータ型にキャストして返す(ID指定)</summary>
		/// <typeparam name="T">型パラメータ</typeparam>
		/// <param name="id">レコードID</param>
		/// <returns>データ</returns>
		public T GetData<T>( Int32 id )
			where T: Data.IData, new()
		{
			var data = new T();
			data.ID = id;
			data.Address = this.Pointertable[id];
			data.SetRecord( this.Read( id ) );

			return data;
		}

		/// <summary>データテーブルからレコードを読み込んでデータ型にキャストして返す(アドレス指定)</summary>
		/// <typeparam name="T">型パラメータ</typeparam>
		/// <param name="address">レコードアドレス</param>
		/// <returns>データ</returns>
		public T GetData<T>( UInt32 address )
			where T: class, Data.IData, new()
		{
			var data = new T();
			var index = this.Pointertable[address];
			if ( index == -1 ) { return null; }
			data.ID = index;
			data.Address = address;
			data.SetRecord( this.Read( index ) );

			return data;
		}

		/// <summary>データ内のレコードをデータテーブルに書き込む</summary>
		/// <typeparam name="T">型パラメータ</typeparam>
		/// <param name="id">レコードID</param>
		/// <param name="data">データ</param>
		public void SetData<T>( Int32 id, T data )
			where T: Data.IData, new()
		{
			this.Write( id, data.GetRecord() );
		}

		/// <summary>データ内のレコードをデータテーブルに書き込む</summary>
		/// <typeparam name="T">型パラメータ</typeparam>
		/// <param name="address">レコードアドレス</param>
		/// <param name="data">データ</param>
		public void SetData<T>( UInt32 address, T data )
			where T: Data.IData, new()
		{
			this.Write( data.ID, data.GetRecord() );
		}
	}
}
