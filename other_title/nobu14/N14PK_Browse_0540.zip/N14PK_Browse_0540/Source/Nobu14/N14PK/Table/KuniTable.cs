﻿// KuniTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>国テーブルを管理するクラス</summary>
	public class KuniTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public KuniTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.国] ) {}

		/// <summary>インデクサ データテーブルから国データを読み書きする</summary>
		/// <param name="id">国ID</param>
		/// <returns>国データ</returns>
		public new KuniData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>国データ</returns>
		public new IEnumerator<KuniData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで国データにキャストして返す</summary>
		/// <param name="id">国ID</param>
		/// <returns>国データ</returns>
		public KuniData GetData( Int32 id )
		{
			return base.GetData<KuniData>( id );
		}

		/// <summary>国データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">国ID</param>
		/// <param name="data">国データ</param>
		public void SetData( Int32 id, KuniData data )
		{
			base.SetData<KuniData>( id, data );
		}

		/// <summary>インデクサ データテーブルから国データを読み書きする</summary>
		/// <param name="address">国データアドレス</param>
		/// <returns>国データ</returns>
		public KuniData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで国データにキャストして返す</summary>
		/// <param name="address">国データアドレス</param>
		/// <returns>国データ</returns>
		public KuniData GetData( UInt32 address )
		{
			return base.GetData<KuniData>( address );
		}

		/// <summary>国データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">国データアドレス</param>
		/// <param name="data">国データ</param>
		public void SetData( UInt32 address, KuniData data )
		{
			base.SetData<KuniData>( address, data );
		}
	}
}
