﻿// KaidouTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>街道テーブルを管理するクラス</summary>
	public class KaidouTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public KaidouTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.街道] ) {}

		/// <summary>インデクサ データテーブルから街道データを読み書きする</summary>
		/// <param name="id">街道ID</param>
		/// <returns>街道データ</returns>
		public new KaidouData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>街道データ</returns>
		public new IEnumerator<KaidouData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで街道データにキャストして返す</summary>
		/// <param name="id">街道ID</param>
		/// <returns>街道データ</returns>
		public KaidouData GetData( Int32 id )
		{
			return base.GetData<KaidouData>( id );
		}

		/// <summary>街道データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">街道ID</param>
		/// <param name="data">街道データ</param>
		public void SetData( Int32 id, KaidouData data )
		{
			base.SetData<KaidouData>( id, data );
		}

		/// <summary>インデクサ データテーブルから街道データを読み書きする</summary>
		/// <param name="address">街道データアドレス</param>
		/// <returns>街道データ</returns>
		public KaidouData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで街道データにキャストして返す</summary>
		/// <param name="address">街道データアドレス</param>
		/// <returns>街道データ</returns>
		public KaidouData GetData( UInt32 address )
		{
			return base.GetData<KaidouData>( address );
		}

		/// <summary>街道データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">街道データアドレス</param>
		/// <param name="data">街道データ</param>
		public void SetData( UInt32 address, KaidouData data )
		{
			base.SetData<KaidouData>( address, data );
		}
	}
}
