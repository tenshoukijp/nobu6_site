﻿// TokuseiTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>特性テーブルを管理するクラス</summary>
	public class TokuseiTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public TokuseiTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.特性] ) {}

		/// <summary>インデクサ データテーブルから特性データを読み書きする</summary>
		/// <param name="id">特性ID</param>
		/// <returns>特性データ</returns>
		public new TokuseiData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>特性データ</returns>
		public new IEnumerator<TokuseiData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで特性データにキャストして返す</summary>
		/// <param name="id">特性ID</param>
		/// <returns>特性データ</returns>
		public TokuseiData GetData( Int32 id )
		{
			return base.GetData<TokuseiData>( id );
		}

		/// <summary>特性データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">特性ID</param>
		/// <param name="data">特性データ</param>
		public void SetData( Int32 id, TokuseiData data )
		{
			base.SetData<TokuseiData>( id, data );
		}

		/// <summary>インデクサ データテーブルから特性データを読み書きする</summary>
		/// <param name="address">特性データアドレス</param>
		/// <returns>特性データ</returns>
		public TokuseiData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで特性データにキャストして返す</summary>
		/// <param name="address">特性データアドレス</param>
		/// <returns>特性データ</returns>
		public TokuseiData GetData( UInt32 address )
		{
			return base.GetData<TokuseiData>( address );
		}

		/// <summary>特性データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">特性データアドレス</param>
		/// <param name="data">特性データ</param>
		public void SetData( UInt32 address, TokuseiData data )
		{
			base.SetData<TokuseiData>( address, data );
		}
	}
}
