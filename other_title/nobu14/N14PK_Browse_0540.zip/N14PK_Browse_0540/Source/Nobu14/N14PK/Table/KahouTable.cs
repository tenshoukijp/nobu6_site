﻿// KahouTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>家宝テーブルを管理するクラス</summary>
	public class KahouTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public KahouTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.家宝] ) {}

		/// <summary>インデクサ データテーブルから家宝データを読み書きする</summary>
		/// <param name="id">家宝ID</param>
		/// <returns>家宝データ</returns>
		public new KahouData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>家宝データ</returns>
		public new IEnumerator<KahouData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで家宝データにキャストして返す</summary>
		/// <param name="id">家宝ID</param>
		/// <returns>家宝データ</returns>
		public KahouData GetData( Int32 id )
		{
			return base.GetData<KahouData>( id );
		}

		/// <summary>家宝データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">家宝ID</param>
		/// <param name="data">家宝データ</param>
		public void SetData( Int32 id, KahouData data )
		{
			base.SetData<KahouData>( id, data );
		}

		/// <summary>インデクサ データテーブルから家宝データを読み書きする</summary>
		/// <param name="address">家宝データアドレス</param>
		/// <returns>家宝データ</returns>
		public KahouData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで家宝データにキャストして返す</summary>
		/// <param name="address">家宝データアドレス</param>
		/// <returns>家宝データ</returns>
		public KahouData GetData( UInt32 address )
		{
			return base.GetData<KahouData>( address );
		}

		/// <summary>家宝データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">家宝データアドレス</param>
		/// <param name="data">家宝データ</param>
		public void SetData( UInt32 address, KahouData data )
		{
			base.SetData<KahouData>( address, data );
		}
	}
}
