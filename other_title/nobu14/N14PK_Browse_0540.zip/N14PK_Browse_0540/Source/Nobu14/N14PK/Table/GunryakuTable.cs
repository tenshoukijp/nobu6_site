﻿// GunryakuTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>軍略テーブルを管理するクラス</summary>
	public class GunryakuTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public GunryakuTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.軍略] ) {}

		/// <summary>インデクサ データテーブルから軍略データを読み書きする</summary>
		/// <param name="id">軍略ID</param>
		/// <returns>軍略データ</returns>
		public new GunryakuData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>軍略データ</returns>
		public new IEnumerator<GunryakuData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで軍略データにキャストして返す</summary>
		/// <param name="id">軍略ID</param>
		/// <returns>軍略データ</returns>
		public GunryakuData GetData( Int32 id )
		{
			return base.GetData<GunryakuData>( id );
		}

		/// <summary>軍略データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">軍略ID</param>
		/// <param name="data">軍略データ</param>
		public void SetData( Int32 id, GunryakuData data )
		{
			base.SetData<GunryakuData>( id, data );
		}

		/// <summary>インデクサ データテーブルから軍略データを読み書きする</summary>
		/// <param name="address">軍略データアドレス</param>
		/// <returns>軍略データ</returns>
		public GunryakuData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで軍略データにキャストして返す</summary>
		/// <param name="address">軍略データアドレス</param>
		/// <returns>軍略データ</returns>
		public GunryakuData GetData( UInt32 address )
		{
			return base.GetData<GunryakuData>( address );
		}

		/// <summary>軍略データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">軍略データアドレス</param>
		/// <param name="data">軍略データ</param>
		public void SetData( UInt32 address, GunryakuData data )
		{
			base.SetData<GunryakuData>( address, data );
		}
	}
}
