﻿// SeiryokuTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>勢力テーブルを管理するクラス</summary>
	public class SeiryokuTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public SeiryokuTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.勢力] ) {}

		/// <summary>インデクサ データテーブルから勢力データを読み書きする</summary>
		/// <param name="id">勢力ID</param>
		/// <returns>勢力データ</returns>
		public new SeiryokuData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>勢力データ</returns>
		public new IEnumerator<SeiryokuData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで勢力データにキャストして返す</summary>
		/// <param name="id">勢力ID</param>
		/// <returns>勢力データ</returns>
		public SeiryokuData GetData( Int32 id )
		{
			return base.GetData<SeiryokuData>( id );
		}

		/// <summary>勢力データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">勢力ID</param>
		/// <param name="data">勢力データ</param>
		public void SetData( Int32 id, SeiryokuData data )
		{
			base.SetData<SeiryokuData>( id, data );
		}

		/// <summary>インデクサ データテーブルから勢力データを読み書きする</summary>
		/// <param name="address">勢力データアドレス</param>
		/// <returns>勢力データ</returns>
		public SeiryokuData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで勢力データにキャストして返す</summary>
		/// <param name="address">勢力データアドレス</param>
		/// <returns>勢力データ</returns>
		public SeiryokuData GetData( UInt32 address )
		{
			return base.GetData<SeiryokuData>( address );
		}

		/// <summary>勢力データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">勢力データアドレス</param>
		/// <param name="data">勢力データ</param>
		public void SetData( UInt32 address, SeiryokuData data )
		{
			base.SetData<SeiryokuData>( address, data );
		}
	}
}
