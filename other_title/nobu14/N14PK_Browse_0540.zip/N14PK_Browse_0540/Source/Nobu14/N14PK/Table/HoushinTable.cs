﻿// HoushinTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>方針テーブルを管理するクラス</summary>
	public class HoushinTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public HoushinTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.方針] ) {}

		/// <summary>インデクサ データテーブルから方針データを読み書きする</summary>
		/// <param name="id">方針ID</param>
		/// <returns>方針データ</returns>
		public new HoushinData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>方針データ</returns>
		public new IEnumerator<HoushinData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで方針データにキャストして返す</summary>
		/// <param name="id">方針ID</param>
		/// <returns>方針データ</returns>
		public HoushinData GetData( Int32 id )
		{
			return base.GetData<HoushinData>( id );
		}

		/// <summary>方針データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">方針ID</param>
		/// <param name="data">方針データ</param>
		public void SetData( Int32 id, HoushinData data )
		{
			base.SetData<HoushinData>( id, data );
		}

		/// <summary>インデクサ データテーブルから方針データを読み書きする</summary>
		/// <param name="address">方針データアドレス</param>
		/// <returns>方針データ</returns>
		public HoushinData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで方針データにキャストして返す</summary>
		/// <param name="address">方針データアドレス</param>
		/// <returns>方針データ</returns>
		public HoushinData GetData( UInt32 address )
		{
			return base.GetData<HoushinData>( address );
		}

		/// <summary>方針データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">方針データアドレス</param>
		/// <param name="data">方針データ</param>
		public void SetData( UInt32 address, HoushinData data )
		{
			base.SetData<HoushinData>( address, data );
		}
	}
}
