﻿// SenpouTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>戦法テーブルを管理するクラス</summary>
	public class SenpouTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public SenpouTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.戦法] ) {}

		/// <summary>インデクサ データテーブルから戦法データを読み書きする</summary>
		/// <param name="id">戦法ID</param>
		/// <returns>戦法データ</returns>
		public new SenpouData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>戦法データ</returns>
		public new IEnumerator<SenpouData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで戦法データにキャストして返す</summary>
		/// <param name="id">戦法ID</param>
		/// <returns>戦法データ</returns>
		public SenpouData GetData( Int32 id )
		{
			return base.GetData<SenpouData>( id );
		}

		/// <summary>戦法データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">戦法ID</param>
		/// <param name="data">戦法データ</param>
		public void SetData( Int32 id, SenpouData data )
		{
			base.SetData<SenpouData>( id, data );
		}

		/// <summary>インデクサ データテーブルから戦法データを読み書きする</summary>
		/// <param name="address">戦法データアドレス</param>
		/// <returns>戦法データ</returns>
		public SenpouData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで戦法データにキャストして返す</summary>
		/// <param name="address">戦法データアドレス</param>
		/// <returns>戦法データ</returns>
		public SenpouData GetData( UInt32 address )
		{
			return base.GetData<SenpouData>( address );
		}

		/// <summary>戦法データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">戦法データアドレス</param>
		/// <param name="data">戦法データ</param>
		public void SetData( UInt32 address, SenpouData data )
		{
			base.SetData<SenpouData>( address, data );
		}
	}
}
