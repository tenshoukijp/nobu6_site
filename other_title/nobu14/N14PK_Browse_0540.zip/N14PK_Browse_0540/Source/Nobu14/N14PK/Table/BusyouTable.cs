﻿// BusyouTable.cs

using System;
using System.Collections.Generic;

using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>武将テーブルを管理するクラス</summary>
	public class BusyouTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public BusyouTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.武将] ) {}

		/// <summary>インデクサ データテーブルから武将データを読み書きする</summary>
		/// <param name="id">武将ID</param>
		/// <returns>武将データ</returns>
		public new BusyouData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>武将データ</returns>
		public new IEnumerator<BusyouData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで武将データにキャストして返す</summary>
		/// <param name="id">武将ID</param>
		/// <returns>武将データ</returns>
		public BusyouData GetData( Int32 id )
		{
			return base.GetData<BusyouData>( id );
		}

		/// <summary>武将データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">武将ID</param>
		/// <param name="data">武将データ</param>
		public void SetData( Int32 id, BusyouData data )
		{
			base.SetData<BusyouData>( id, data );
		}

		/// <summary>インデクサ データテーブルから武将データを読み書きする</summary>
		/// <param name="address">武将データアドレス</param>
		/// <returns>武将データ</returns>
		public BusyouData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで武将データにキャストして返す</summary>
		/// <param name="address">武将データアドレス</param>
		/// <returns>武将データ</returns>
		public BusyouData GetData( UInt32 address )
		{
			return base.GetData<BusyouData>( address );
		}

		/// <summary>武将データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">武将データアドレス</param>
		/// <param name="data">武将データ</param>
		public void SetData( UInt32 address, BusyouData data )
		{
			base.SetData<BusyouData>( address, data );
		}
	}
}
