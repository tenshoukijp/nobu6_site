﻿// ButaiTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>部隊テーブルを管理するクラス</summary>
	public class ButaiTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public ButaiTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.部隊] ) {}

		/// <summary>インデクサ データテーブルから部隊データを読み書きする</summary>
		/// <param name="id">部隊ID</param>
		/// <returns>部隊データ</returns>
		public new ButaiData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>部隊データ</returns>
		public new IEnumerator<ButaiData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで部隊データにキャストして返す</summary>
		/// <param name="id">部隊ID</param>
		/// <returns>部隊データ</returns>
		public ButaiData GetData( Int32 id )
		{
			return base.GetData<ButaiData>( id );
		}

		/// <summary>部隊データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">部隊ID</param>
		/// <param name="data">部隊データ</param>
		public void SetData( Int32 id, ButaiData data )
		{
			base.SetData<ButaiData>( id, data );
		}

		/// <summary>インデクサ データテーブルから部隊データを読み書きする</summary>
		/// <param name="address">部隊データアドレス</param>
		/// <returns>部隊データ</returns>
		public ButaiData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで部隊データにキャストして返す</summary>
		/// <param name="address">部隊データアドレス</param>
		/// <returns>部隊データ</returns>
		public ButaiData GetData( UInt32 address )
		{
			return base.GetData<ButaiData>( address );
		}

		/// <summary>部隊データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">部隊データアドレス</param>
		/// <param name="data">部隊データ</param>
		public void SetData( UInt32 address, ButaiData data )
		{
			base.SetData<ButaiData>( address, data );
		}
	}
}
