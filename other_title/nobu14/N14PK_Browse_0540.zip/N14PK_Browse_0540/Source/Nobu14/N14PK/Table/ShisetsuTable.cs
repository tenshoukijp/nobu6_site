﻿// ShisetsuTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>施設テーブルを管理するクラス</summary>
	public class ShisetsuTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public ShisetsuTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.施設] ) {}

		/// <summary>インデクサ データテーブルから施設データを読み書きする</summary>
		/// <param name="id">施設ID</param>
		/// <returns>施設データ</returns>
		public new ShisetsuData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>施設データ</returns>
		public new IEnumerator<ShisetsuData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで施設データにキャストして返す</summary>
		/// <param name="id">施設ID</param>
		/// <returns>施設データ</returns>
		public ShisetsuData GetData( Int32 id )
		{
			return base.GetData<ShisetsuData>( id );
		}

		/// <summary>施設データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">施設ID</param>
		/// <param name="data">施設データ</param>
		public void SetData( Int32 id, ShisetsuData data )
		{
			base.SetData<ShisetsuData>( id, data );
		}

		/// <summary>インデクサ データテーブルから施設データを読み書きする</summary>
		/// <param name="address">施設データアドレス</param>
		/// <returns>施設データ</returns>
		public ShisetsuData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで施設データにキャストして返す</summary>
		/// <param name="address">施設データアドレス</param>
		/// <returns>施設データ</returns>
		public ShisetsuData GetData( UInt32 address )
		{
			return base.GetData<ShisetsuData>( address );
		}

		/// <summary>施設データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">施設データアドレス</param>
		/// <param name="data">施設データ</param>
		public void SetData( UInt32 address, ShisetsuData data )
		{
			base.SetData<ShisetsuData>( address, data );
		}
	}
}
