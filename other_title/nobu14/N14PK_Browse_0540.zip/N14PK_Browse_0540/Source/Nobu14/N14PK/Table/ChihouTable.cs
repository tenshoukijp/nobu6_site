﻿// ChihouTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>地方テーブルを管理するクラス</summary>
	public class ChihouTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public ChihouTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.地方] ) {}

		/// <summary>インデクサ データテーブルから地方データを読み書きする</summary>
		/// <param name="id">地方ID</param>
		/// <returns>地方データ</returns>
		public new ChihouData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>地方データ</returns>
		public new IEnumerator<ChihouData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで地方データにキャストして返す</summary>
		/// <param name="id">地方ID</param>
		/// <returns>地方データ</returns>
		public ChihouData GetData( Int32 id )
		{
			return base.GetData<ChihouData>( id );
		}

		/// <summary>地方データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">地方ID</param>
		/// <param name="data">地方データ</param>
		public void SetData( Int32 id, ChihouData data )
		{
			base.SetData<ChihouData>( id, data );
		}

		/// <summary>インデクサ データテーブルから地方データを読み書きする</summary>
		/// <param name="address">地方データアドレス</param>
		/// <returns>地方データ</returns>
		public ChihouData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで地方データにキャストして返す</summary>
		/// <param name="address">地方データアドレス</param>
		/// <returns>地方データ</returns>
		public ChihouData GetData( UInt32 address )
		{
			return base.GetData<ChihouData>( address );
		}

		/// <summary>地方データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">地方データアドレス</param>
		/// <param name="data">地方データ</param>
		public void SetData( UInt32 address, ChihouData data )
		{
			base.SetData<ChihouData>( address, data );
		}
	}
}
