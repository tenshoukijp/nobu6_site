﻿// YousyoTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>要所テーブルを管理するクラス</summary>
	public class YousyoTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public YousyoTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.要所] ) {}

		/// <summary>インデクサ データテーブルから要所データを読み書きする</summary>
		/// <param name="id">要所ID</param>
		/// <returns>要所データ</returns>
		public new YousyoData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>要所データ</returns>
		public new IEnumerator<YousyoData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで要所データにキャストして返す</summary>
		/// <param name="id">要所ID</param>
		/// <returns>要所データ</returns>
		public YousyoData GetData( Int32 id )
		{
			return base.GetData<YousyoData>( id );
		}

		/// <summary>要所データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">要所ID</param>
		/// <param name="data">要所データ</param>
		public void SetData( Int32 id, YousyoData data )
		{
			base.SetData<YousyoData>( id, data );
		}

		/// <summary>インデクサ データテーブルから要所データを読み書きする</summary>
		/// <param name="address">要所データアドレス</param>
		/// <returns>要所データ</returns>
		public YousyoData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで要所データにキャストして返す</summary>
		/// <param name="address">要所データアドレス</param>
		/// <returns>要所データ</returns>
		public YousyoData GetData( UInt32 address )
		{
			return base.GetData<YousyoData>( address );
		}

		/// <summary>要所データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">要所データアドレス</param>
		/// <param name="data">要所データ</param>
		public void SetData( UInt32 address, YousyoData data )
		{
			base.SetData<YousyoData>( address, data );
		}
	}
}
