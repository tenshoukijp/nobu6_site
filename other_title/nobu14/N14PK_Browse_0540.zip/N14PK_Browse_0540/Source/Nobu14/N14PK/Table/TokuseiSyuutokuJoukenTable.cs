﻿// TokuseiSyuutokuJoukenTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>特性習得条件テーブルを管理するクラス</summary>
	public class TokuseiSyuutokuJoukenTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public TokuseiSyuutokuJoukenTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.習得条件] ) {}

		/// <summary>インデクサ データテーブルから習得条件データを読み書きする</summary>
		/// <param name="id">習得条件ID</param>
		/// <returns>習得条件データ</returns>
		public new TokuseiSyuutokuJoukenData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>習得条件データ</returns>
		public new IEnumerator<TokuseiSyuutokuJoukenData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで習得条件データにキャストして返す</summary>
		/// <param name="id">習得条件ID</param>
		/// <returns>習得条件データ</returns>
		public TokuseiSyuutokuJoukenData GetData( Int32 id )
		{
			return base.GetData<TokuseiSyuutokuJoukenData>( id );
		}

		/// <summary>習得条件データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">習得条件ID</param>
		/// <param name="data">習得条件データ</param>
		public void SetData( Int32 id, TokuseiSyuutokuJoukenData data )
		{
			base.SetData<TokuseiSyuutokuJoukenData>( id, data );
		}

		/// <summary>インデクサ データテーブルから習得条件データを読み書きする</summary>
		/// <param name="address">習得条件データアドレス</param>
		/// <returns>習得条件データ</returns>
		public TokuseiSyuutokuJoukenData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで習得条件データにキャストして返す</summary>
		/// <param name="address">習得条件データアドレス</param>
		/// <returns>習得条件データ</returns>
		public TokuseiSyuutokuJoukenData GetData( UInt32 address )
		{
			return base.GetData<TokuseiSyuutokuJoukenData>( address );
		}

		/// <summary>習得条件データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">習得条件データアドレス</param>
		/// <param name="data">習得条件データ</param>
		public void SetData( UInt32 address, TokuseiSyuutokuJoukenData data )
		{
			base.SetData<TokuseiSyuutokuJoukenData>( address, data );
		}
	}
}
