﻿// GundanTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>軍団テーブルを管理するクラス</summary>
	public class GundanTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public GundanTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.軍団] ) {}

		/// <summary>インデクサ データテーブルから軍団データを読み書きする</summary>
		/// <param name="id">軍団ID</param>
		/// <returns>軍団データ</returns>
		public new GundanData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>軍団データ</returns>
		public new IEnumerator<GundanData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで軍団データにキャストして返す</summary>
		/// <param name="id">軍団ID</param>
		/// <returns>軍団データ</returns>
		public GundanData GetData( Int32 id )
		{
			return base.GetData<GundanData>( id );
		}

		/// <summary>軍団データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">軍団ID</param>
		/// <param name="data">軍団データ</param>
		public void SetData( Int32 id, GundanData data )
		{
			base.SetData<GundanData>( id, data );
		}

		/// <summary>インデクサ データテーブルから軍団データを読み書きする</summary>
		/// <param name="address">軍団データアドレス</param>
		/// <returns>軍団データ</returns>
		public GundanData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで軍団データにキャストして返す</summary>
		/// <param name="address">軍団データアドレス</param>
		/// <returns>軍団データ</returns>
		public GundanData GetData( UInt32 address )
		{
			return base.GetData<GundanData>( address );
		}

		/// <summary>軍団データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">軍団データアドレス</param>
		/// <param name="data">軍団データ</param>
		public void SetData( UInt32 address, GundanData data )
		{
			base.SetData<GundanData>( address, data );
		}
	}
}
