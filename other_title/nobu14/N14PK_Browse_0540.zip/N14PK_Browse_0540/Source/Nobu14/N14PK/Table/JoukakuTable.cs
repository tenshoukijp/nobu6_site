﻿// JoukakuTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>城郭テーブルを管理するクラス</summary>
	public class JoukakuTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public JoukakuTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.城郭] ) {}

		/// <summary>インデクサ データテーブルから城郭データを読み書きする</summary>
		/// <param name="id">城郭ID</param>
		/// <returns>城郭データ</returns>
		public new JoukakuData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>城郭データ</returns>
		public new IEnumerator<JoukakuData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで城郭データにキャストして返す</summary>
		/// <param name="id">城郭ID</param>
		/// <returns>城郭データ</returns>
		public JoukakuData GetData( Int32 id )
		{
			return base.GetData<JoukakuData>( id );
		}

		/// <summary>城郭データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">城郭ID</param>
		/// <param name="data">城郭データ</param>
		public void SetData( Int32 id, JoukakuData data )
		{
			base.SetData<JoukakuData>( id, data );
		}

		/// <summary>インデクサ データテーブルから城郭データを読み書きする</summary>
		/// <param name="address">城郭データアドレス</param>
		/// <returns>城郭データ</returns>
		public JoukakuData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで城郭データにキャストして返す</summary>
		/// <param name="address">城郭データアドレス</param>
		/// <returns>城郭データ</returns>
		public JoukakuData GetData( UInt32 address )
		{
			return base.GetData<JoukakuData>( address );
		}

		/// <summary>城郭データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">城郭データアドレス</param>
		/// <param name="data">城郭データ</param>
		public void SetData( UInt32 address, JoukakuData data )
		{
			base.SetData<JoukakuData>( address, data );
		}
	}
}
