﻿// TatemonoTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>建物テーブルを管理するクラス</summary>
	public class TatemonoTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public TatemonoTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.建物] ) {}

		/// <summary>インデクサ データテーブルから建物データを読み書きする</summary>
		/// <param name="id">建物ID</param>
		/// <returns>建物データ</returns>
		public new TatemonoData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>建物データ</returns>
		public new IEnumerator<TatemonoData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで建物データにキャストして返す</summary>
		/// <param name="id">建物ID</param>
		/// <returns>建物データ</returns>
		public TatemonoData GetData( Int32 id )
		{
			return base.GetData<TatemonoData>( id );
		}

		/// <summary>建物データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">建物ID</param>
		/// <param name="data">建物データ</param>
		public void SetData( Int32 id, TatemonoData data )
		{
			base.SetData<TatemonoData>( id, data );
		}

		/// <summary>インデクサ データテーブルから建物データを読み書きする</summary>
		/// <param name="address">建物データアドレス</param>
		/// <returns>建物データ</returns>
		public TatemonoData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで建物データにキャストして返す</summary>
		/// <param name="address">建物データアドレス</param>
		/// <returns>建物データ</returns>
		public TatemonoData GetData( UInt32 address )
		{
			return base.GetData<TatemonoData>( address );
		}

		/// <summary>建物データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">建物データアドレス</param>
		/// <param name="data">建物データ</param>
		public void SetData( UInt32 address, TatemonoData data )
		{
			base.SetData<TatemonoData>( address, data );
		}
	}
}
