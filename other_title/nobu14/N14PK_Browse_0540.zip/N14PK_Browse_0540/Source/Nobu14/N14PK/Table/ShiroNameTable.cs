﻿// ShiroNameTable.cs

using System;
using System.Collections.Generic;
using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>城名テーブルを管理するクラス</summary>
	public class ShiroNameTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public ShiroNameTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.城名] ) {}

		/// <summary>インデクサ データテーブルから城名データを読み書きする</summary>
		/// <param name="id">城名ID</param>
		/// <returns>城名データ</returns>
		public new ShiroNameData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>城名データ</returns>
		public new IEnumerator<ShiroNameData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで城名データにキャストして返す</summary>
		/// <param name="id">城名ID</param>
		/// <returns>城名データ</returns>
		public ShiroNameData GetData( Int32 id )
		{
			return base.GetData<ShiroNameData>( id );
		}

		/// <summary>城名データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">城名ID</param>
		/// <param name="data">城名データ</param>
		public void SetData( Int32 id, ShiroNameData data )
		{
			base.SetData<ShiroNameData>( id, data );
		}

		/// <summary>インデクサ データテーブルから城名データを読み書きする</summary>
		/// <param name="address">城名データアドレス</param>
		/// <returns>城名データ</returns>
		public ShiroNameData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>データテーブルからレコードを読み込んで城名データにキャストして返す</summary>
		/// <param name="address">城名データアドレス</param>
		/// <returns>城名データ</returns>
		public ShiroNameData GetData( UInt32 address )
		{
			return base.GetData<ShiroNameData>( address );
		}

		/// <summary>城名データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">城名データアドレス</param>
		/// <param name="data">城名データ</param>
		public void SetData( UInt32 address, ShiroNameData data )
		{
			base.SetData<ShiroNameData>( address, data );
		}
	}
}
