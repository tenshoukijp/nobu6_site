﻿// ShiroTable.cs

using System;
using System.Collections.Generic;

using N14PKLibrary.Data;

namespace N14PKLibrary.Table
{
	/// <summary>城テーブルを管理するクラス</summary>
	public class ShiroTable : DataTable
	{
		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="indexTable">インデクステーブル</param>
		public ShiroTable( HelperClass.ProcessMemory process, IndexTable indexTable )
			: base( process, indexTable[(uint)DataKind.城] ) {}

		/// <summary>インデクサ データテーブルから城データを読み書きする</summary>
		/// <param name="id">城ID</param>
		/// <returns>城データ</returns>
		public new ShiroData this[Int32 id]
		{
			get { return this.GetData( id ); }
			set { this.SetData( id, value ); }
		}

		/// <summary>インデクサ データテーブルから城データを読み書きする</summary>
		/// <param name="address">城データアドレス</param>
		/// <returns>城データ</returns>
		public ShiroData this[UInt32 address]
		{
			get { return this.GetData( address ); }
			set { this.SetData( address, value ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>城データ</returns>
		public new IEnumerator<ShiroData> GetEnumerator()
		{
			for ( var i = 0; i < this.RecordCount; i++ )
			{
				yield return this.GetData( i );
			}
		}

		/// <summary>データテーブルからレコードを読み込んで城データにキャストして返す</summary>
		/// <param name="id">城ID</param>
		/// <returns>城データ</returns>
		public ShiroData GetData( Int32 id )
		{
			return base.GetData<ShiroData>( id );
		}

		/// <summary>城データのレコードをデータテーブルに書き込む</summary>
		/// <param name="id">城ID</param>
		/// <param name="data">城データ</param>
		public void SetData( Int32 id, ShiroData data )
		{
			base.SetData<ShiroData>( id, data );
		}

		/// <summary>データテーブルからレコードを読み込んで城データにキャストして返す</summary>
		/// <param name="address">城データアドレス</param>
		/// <returns>城データ</returns>
		public ShiroData GetData( UInt32 address )
		{
			return base.GetData<ShiroData>( address );
		}

		/// <summary>城データのレコードをデータテーブルに書き込む</summary>
		/// <param name="address">城データアドレス</param>
		/// <param name="data">城データ</param>
		public void SetData( UInt32 address, ShiroData data )
		{
			base.SetData<ShiroData>( address, data );
		}
	}
}
