﻿// PointerTable.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace N14PKLibrary.Table
{
	/// <summary>各データテーブル内レコードへのポインタリストを管理するクラス</summary>
	public class PointerTable
	{
		private UInt32[] _pointers;

		/// <summary>データ数</summary>
		public Int32 Count
		{
			get { return ( this._pointers != null ) ? this._pointers.Length : 0; }
		}

		/// <summary>コンストラクタ</summary>
		/// <param name="process">プロセス管理</param>
		/// <param name="index">インデクスデータ</param>
		public PointerTable( HelperClass.ProcessMemory process, IndexTable.Index index )
		{
			var address = index.PtrPointerTableBegin;
			var ptrEnd = index.PtrPointerTableEnd;
			var pointers = new List<UInt32>();
			if ( address == 0 )
			{
				this._pointers = null;
			}

			while ( address < ptrEnd )
			{
				pointers.Add( BitConverter.ToUInt32( process.ReadMemory( address, sizeof( UInt32 ) ), 0 ) );
				address += sizeof( Int32 );
			}
			this._pointers = pointers.ToArray();
		}

		/// <summary>インデクサ(配列インデクス指定)</summary>
		/// <param name="n">インデクス</param>
		/// <returns>アドレス</returns>
		/// <exception cref="ArgumentOutOfRangeException">インデクスが配列の範囲外の場合に発生する例外</exception>
		public UInt32 this[Int32 n]
		{
			get
			{
				if ( 0 <= n && n < this._pointers.Length )
				{
					return this._pointers[n];
				}
				else
				{
					throw new ArgumentOutOfRangeException( "Int32 n = " + n );
					//return 0;
				}
			}
		}

		/// <summary>インデクサ(ポインタアドレス指定)</summary>
		/// <param name="address">アドレス</param>
		/// <returns>インデクス</returns>
		public Int32 this[UInt32 address]
		{
			get { return Array.FindIndex( this._pointers, d => d == address ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>アドレス</returns>
		public IEnumerator<UInt32> GetEnumerator()
		{
			for ( var i = 0; i < this._pointers.Length; i++ )
			{
				yield return this._pointers[i];
			}
		}
	}
}
