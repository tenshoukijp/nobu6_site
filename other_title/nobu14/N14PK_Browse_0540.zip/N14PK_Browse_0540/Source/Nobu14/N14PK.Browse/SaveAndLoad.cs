﻿// SaveAndLoad.cs

using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using N14PKBrowse.Enums;

namespace N14PKBrowse
{
	// データセーブ＆ロード管理クラス
	public class SaveAndLoad
	{
		/// <summary>セーブデータファイル情報</summary>
		public class DataFileInfo
		{
			public string Headertext	{ get; set; }		// コンテキストメニューヘッダ名
			public string Filename		{ get; set; }		// ファイル名
			public bool Exists			{ get; set; }		// ファイルが存在するか
			public TabKind Tabname		{ get; set; }		// タブ名
		}

		/// <summary>セーブ可能数(MAX9)</summary>
		public static readonly int Count = 5;

		/// <summary>セーブフォルダ名</summary>
		private const string _Directoryname = "Save";

		/// <summary>セーブファイル名プリフィクス</summary>
		private const string _Prefix = "N14PKB_";

		/// <summary>セーブ＆ロードが可能なタブ</summary>
		public static readonly TabKind[] ValidTabNames =
		{
			TabKind.施設,
			TabKind.政策,
			TabKind.戦法,
			TabKind.特性,
			TabKind.習得条件,
			TabKind.成長型,
			TabKind.効果,
			TabKind.方針,
			TabKind.軍略,
			TabKind.城郭,
			TabKind.城名,
			TabKind.Param
		};

		/// <summary>ツール管理</summary>
		private N14PKB _n14pkb;

		/// <summary>タブ名</summary>
		private TabKind _tabname;

		/// <summary>セーブデータファイル情報</summary>
		public DataFileInfo[] DataFilesInfo { get; private set; }

		/// <summary>インデクサ</summary>
		public DataFileInfo this[int n]
		{
			get
			{
				if ( 0 <= n && (int) n < Count )
				{
					return DataFilesInfo[n];
				}
				return null;
			}
		}

		/// <summary>コンストラクタ</summary>
		public SaveAndLoad( N14PKB n14pkb, TabKind tabaname )
		{
			this._n14pkb = n14pkb;
			this._tabname = tabaname;
			this.DataFilesInfo = new DataFileInfo[Count];
			this.SetFileInfo();
		}

		/// <summary>セーブデータファイル情報セット</summary>
		private void SetFileInfo()
		{
			var path = Environment.CurrentDirectory + @"\" + _Directoryname;
			if ( !Directory.Exists( path ) )
			{
				Directory.CreateDirectory( path );
			}

			var dirinfo = new DirectoryInfo( path );
			var filesinfo = new List<FileInfo>();

			for ( int i = 0; i < Count; i++ )
			{
				// セーブデータファイル情報設定
				this.DataFilesInfo[i] = new DataFileInfo()
				{
					Filename = _Prefix + this._tabname + ( i + 1 ).ToString() + ".bin",
					Headertext = ( i + 1 ).ToString() + ": " + "なし",
					Exists = false,
					Tabname = this._tabname
				};

				foreach ( var d in dirinfo.GetFiles() )
				{
					// ファイルが存在していれば情報を保存
					if ( this.DataFilesInfo[i].Filename == d.Name )
					{
						this.DataFilesInfo[i].Exists = true;
						// 更新日時取得
						this.DataFilesInfo[i].Headertext = ( i + 1 ).ToString() + ": " + d.LastWriteTime.ToString();
						break;
					}
				}
			}
		}

		// データセーブ
		public void Save( int[] ids, int dataindex )
		{
			var path = Environment.CurrentDirectory + @"\" + _Directoryname;
			if ( !Directory.Exists( path ) )
			{
				Directory.CreateDirectory( path );
			}
			var filename = Environment.CurrentDirectory + @"\" + _Directoryname + @"\" + this.DataFilesInfo[dataindex].Filename;

			using ( BinaryWriter w = new BinaryWriter( File.Open( filename, FileMode.Create, FileAccess.Write ) ) )
			{
				w.Write( this._n14pkb.N14pk.GameVersionInt );	// ゲームバージョン書込
				w.Write( this._n14pkb.MyVersionInt );			// 自身のバージョン書込

				this._n14pkb.DataLists[(int)this._tabname].DataSave( w, ids );
			}
			this.SetFileInfo();
		}

		// データロード
		public void Load( int dataindex )
		{
			if ( !this.DataFilesInfo[dataindex].Exists )
			{
				return;
			}
			var filename = Environment.CurrentDirectory + @"\" + _Directoryname + @"\" + this.DataFilesInfo[dataindex].Filename;

			try
			{
				using ( FileStream fs = new FileStream( filename, FileMode.Open, FileAccess.Read ) )
				{
					var bytes = new byte[sizeof( UInt32 )];
					//bool isSizeError = false;

					// ゲームバージョン(4桁整数)
					fs.Read( bytes, 0, 4 );
					var gamever = BitConverter.ToInt32( bytes, 0 );

					//if ( gamever != this._n14pkb.N14pk.GameVersionInt )
					//{
					//	// 保存時とゲームバージョンが異なる
					//	var result = MessageBox.Show( "ゲームバージョンが異なる保存データです。\n読み込みを続けますか？",
					//		"Warning",
					//		MessageBoxButton.YesNo,
					//		MessageBoxImage.Warning,
					//		MessageBoxResult.No
					//		);
					//	if ( result == MessageBoxResult.No )
					//	{
					//		return;
					//	}
					//}

					// 自身のバージョン(整数4桁)
					fs.Read( bytes, 0, 4 );
					var myver = BitConverter.ToInt32( bytes, 0 );

					// 1レコードサイズ
					fs.Read( bytes, 0, 4 );
					var size = BitConverter.ToInt32( bytes, 0 );

					// 保存データ数
					fs.Read( bytes, 0, 4 );
					var count = BitConverter.ToInt32( bytes, 0 );

					this._n14pkb.DataLists[(int)this._tabname].DataLoad( fs, size, count );
				}
			}
			catch ( Exception ex )
			{
				System.Windows.MessageBox.Show( ex.Message, "データ読込", MessageBoxButton.OK, MessageBoxImage.Error );
			}
		}
	}
}
