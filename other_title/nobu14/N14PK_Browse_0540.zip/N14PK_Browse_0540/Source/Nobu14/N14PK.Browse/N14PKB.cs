﻿// N14PKB.cs

using System;
using System.Reflection;
using N14PKBrowse.Column;
using N14PKBrowse.Compare;
using N14PKBrowse.Enums;
using N14PKBrowse.Extension;
using N14PKBrowse.List;
using N14PKBrowse.Menu;
using N14PKBrowse.Sort;
using N14PKLibrary;
using N14PKLibrary.VersionConfig;

namespace N14PKBrowse
{
	/// <summary>ツールで使用するオブジェクトを管理するクラス</summary>
	public class N14PKB
	{
		public Setting.ProgramSetting SettingData { get; set; }

		/// <summary>コミットフラグ</summary>
		public bool NeedsCommit { get; set; }

		/// <summary>プレイヤー勢力ID</summary>
		///  勢力リスト作成時に プロパティIsPlayer が true の勢力IDをセットしているので、IsPlayer を変更したりCOM勢力にセットすると正しく動かない
		public int PlayerSeriyokuID { get; set; }

		/// <summary>ゲームバージョン</summary>
		public string GameVersion { get; private set; }

		/// <summary>ツールバージョン</summary>
		public string MyVersion
		{
			get
			{
				// ピリオド区切りを想定していたが、以前 Vista 32bit でカンマ+半角スペース区切り(Ex "1, 2, 3, 4") で文字列が返るらしいとレポがあったのでピリオド区切りに整形する
				// OSで本当に差異が出るのかどうかわからなかったが念のため
				var versionString = Assembly.GetExecutingAssembly().GetName().Version.ToString();
				versionString = versionString.Replace( " ", string.Empty );
				versionString = versionString.Replace( ',', '.' );
				return versionString;
			}
		}

		/// <summary>ツールバージョン(4桁整数)</summary>
		public int MyVersionInt
		{
			get
			{
				var v1 = Assembly.GetExecutingAssembly().GetName().Version.Major;
				var v2 = Assembly.GetExecutingAssembly().GetName().Version.Minor;
				var v3 = Assembly.GetExecutingAssembly().GetName().Version.Build;
				var v4 = Assembly.GetExecutingAssembly().GetName().Version.Revision;
				return ( v1 * 1000 ) + ( v2 * 100 ) + ( v3 * 10 ) + v4;
			}
		}

		/// <summary>メインウィンドウ操作用インターフェイス</summary>
		private IMainWindow _mainWindowInterface;
		/// <summary>メインウィンドウ操作用インターフェイス</summary>
		public IMainWindow MainWindowInterface
		{
			get { return this._mainWindowInterface; }
		}

		/// <summary>タブ数(=データグリッド数)</summary>
		public int TabCount
		{
			get { return this._mainWindowInterface.TabCount; }
		}

		/// <summary>ゲームプロセス管理</summary>
		private N14PK _n14pk;
		/// <summary>ゲームプロセス管理</summary>
		public N14PK N14pk
		{
			get { return this._n14pk; }
		}

		/// <summary>ビュー</summary>
		private N14PKBView _view;
		/// <summary>ビュー</summary>
		public N14PKBView View
		{
			get
			{
				if ( this._view == null )
				{
					this._view = new N14PKBView( this );
				}
				return this._view;
			}
		}

		/// <summary>ソート情報</summary>
		private SortHistory[] _sortHistories;
		/// <summary>ソート情報</summary>
		public SortHistory[] SortHistories
		{
			get
			{
				if ( this._sortHistories == null )
				{
					this._sortHistories = new SortHistory[this.TabCount];
					for ( var i = 0; i < this.TabCount; i++ )
					{
						this._sortHistories[i] = new SortHistory();
					}
				}
				return this._sortHistories;
			}
		}

		/// <summary>データ比較オブジェクト</summary>
		private AbstractComparer[] _comparers;
		/// <summary>データ比較オブジェクト</summary>
		public AbstractComparer[] Comparers
		{
			get
			{
				if ( this._comparers == null )
				{
#if DEBUG
					System.Diagnostics.Debug.WriteLine( "N14PKB.cs データ比較オブジェクト作成" );
#endif
					this._comparers = new AbstractComparer[this.TabCount];
					this._comparers[(int)TabKind.武将]		= new BusyouComparer();
					this._comparers[(int)TabKind.城]		= new ShiroComparer();
					this._comparers[(int)TabKind.区画]		= new KukakuComparer();
					this._comparers[(int)TabKind.勢力]		= new SeiryokuComparer();
					this._comparers[(int)TabKind.軍団]		= new GundanComparer();
					this._comparers[(int)TabKind.部隊]		= new ButaiComparer();
					this._comparers[(int)TabKind.建物]		= new TatemonoComparer();
					this._comparers[(int)TabKind.家宝]		= new KahouComparer();
					this._comparers[(int)TabKind.国人衆]	= new KokujinComparer();
					this._comparers[(int)TabKind.要所]		= new YousyoComparer();
					this._comparers[(int)TabKind.街道]		= new KaidouComparer();
					this._comparers[(int)TabKind.施設]		= new ShisetsuComparer();
					//this._comparers[(int)TabKind.政策]		= new SeisakuComparer();
					//this._comparers[(int)TabKind.戦法]		= new SenpouComparer();
					this._comparers[(int)TabKind.特性]		= new TokuseiComparer();
					this._comparers[(int)TabKind.習得条件]	= new TokuseiSyuutokuJoukenComparer();
					this._comparers[(int)TabKind.成長型]	= new SeichougataComparer();
					//this._comparers[(int)TabKind.地方]		= new ChihouComparer();
					//this._comparers[(int)TabKind.国]	= new KuniComparer();
					//this._comparers[(int)TabKind.効果]		= new KoukaComparer();
					//this._comparers[(int)TabKind.方針]		= new HoushinComparer();
					//this._comparers[(int)TabKind.軍略]		= new GunryakuComparer();
					//this._comparers[(int)TabKind.城郭]		= new JoukakuComparer();
					this._comparers[(int)TabKind.城名]		= new ShiroNameComparer();
					this._comparers[(int)TabKind.Param]		= new ParamComparer();

				}
				return this._comparers;
			}
		}

		/// <summary>コンテキストメニュー</summary>
		private DataMenu[] _cMenus;
		/// <summary>コンテキストメニュー</summary>
		public DataMenu[] CMenus
		{
			get
			{
				if ( this._cMenus == null )
				{
#if DEBUG
					System.Diagnostics.Debug.WriteLine( "N14PKB.cs コンテキストメニュー作成" );
#endif
					var functions = ScriptSetting.LoadExtensionsSettingFile();
					this._cMenus = new DataMenu[this.TabCount];
					this._cMenus[(int)TabKind.武将]		= new BusyouMenu( this, functions[(int)TabKind.武将] );
					this._cMenus[(int)TabKind.城]		= new ShiroMenu( this, functions[(int)TabKind.城] );
					this._cMenus[(int)TabKind.区画]		= new KukakuMenu( this, functions[(int)TabKind.区画] );
					this._cMenus[(int)TabKind.勢力]		= new SeiryokuMenu( this, functions[(int)TabKind.勢力] );
					this._cMenus[(int)TabKind.軍団]		= new GundanMenu( this, functions[(int)TabKind.軍団] );
					this._cMenus[(int)TabKind.部隊]		= new ButaiMenu( this, functions[(int)TabKind.部隊] );
					this._cMenus[(int)TabKind.建物]		= new TatemonoMenu( this, functions[(int)TabKind.建物] );
					this._cMenus[(int)TabKind.家宝]		= new KahouMenu( this, functions[(int)TabKind.家宝] );
					this._cMenus[(int)TabKind.国人衆]	= new KokujinMenu( this, functions[(int)TabKind.国人衆] );
					this._cMenus[(int)TabKind.要所]		= new YousyoMenu( this, functions[(int)TabKind.要所] );
					this._cMenus[(int)TabKind.街道]		= new KaidouMenu( this, functions[(int)TabKind.街道] );
					this._cMenus[(int)TabKind.施設]		= new ShisetsuMenu( this, functions[(int)TabKind.施設] );
					this._cMenus[(int)TabKind.政策]		= new SeisakuMenu( this, functions[(int)TabKind.政策] );
					this._cMenus[(int)TabKind.戦法]		= new SenpouMenu( this, functions[(int)TabKind.戦法] );
					this._cMenus[(int)TabKind.特性]		= new TokuseiMenu( this, functions[(int)TabKind.特性] );
					this._cMenus[(int)TabKind.習得条件]	= new TokuseiSyuutokuJoukenMenu( this, functions[(int)TabKind.習得条件] );
					this._cMenus[(int)TabKind.成長型]	= new SeichougataMenu( this, functions[(int)TabKind.成長型] );
					this._cMenus[(int)TabKind.地方]		= new ChihouMenu( this, functions[(int)TabKind.地方] );
					this._cMenus[(int)TabKind.国]		= new KuniMenu( this, functions[(int)TabKind.国] );
					this._cMenus[(int)TabKind.効果]		= new KoukaMenu( this, functions[(int)TabKind.効果] );
					this._cMenus[(int)TabKind.方針]		= new HoushinMenu( this, functions[(int)TabKind.方針] );
					this._cMenus[(int)TabKind.軍略]		= new GunryakuMenu( this, functions[(int)TabKind.軍略] );
					this._cMenus[(int)TabKind.城郭]		= new JoukakuMenu( this, functions[(int)TabKind.城郭] );
					this._cMenus[(int)TabKind.城名]		= new ShiroNameMenu( this, functions[(int)TabKind.城名] );
					this._cMenus[(int)TabKind.Param]	= new ParamMenu( this, functions[(int)TabKind.Param] );
				}
				return this._cMenus;
			}
		}

		/// <summary>列設定リスト</summary>
		private ColumnSetting[] _columnSettings;
		/// <summary>列設定リスト</summary>
		public ColumnSetting[] ColumnSettings
		{
			get
			{
				if ( this._columnSettings == null )
				{
#if DEBUG
					System.Diagnostics.Debug.WriteLine( "N14PKB.cs 列設定リスト作成" );
#endif
					this._columnSettings = new ColumnSetting[this.TabCount];
					this._columnSettings[(int)TabKind.武将]		= new BusyouColumnSetting( this );
					this._columnSettings[(int)TabKind.城]		= new ShiroColumnSetting( this );
					this._columnSettings[(int)TabKind.区画]		= new KukakuColumnSetting( this );
					this._columnSettings[(int)TabKind.勢力]		= new SeiryokuColumnSetting( this );
					this._columnSettings[(int)TabKind.軍団]		= new GundanColumnSetting( this );
					this._columnSettings[(int)TabKind.部隊]		= new ButaiColumnSetting( this );
					this._columnSettings[(int)TabKind.建物]		= new TatemonoColumnSetting( this );
					this._columnSettings[(int)TabKind.家宝]		= new KahouColumnSetting( this );
					this._columnSettings[(int)TabKind.国人衆]	= new KokujinColumnSetting( this );
					this._columnSettings[(int)TabKind.要所]		= new YousyoColumnSetting( this );
					this._columnSettings[(int)TabKind.街道]		= new KaidouColumnSetting( this );
					this._columnSettings[(int)TabKind.施設]		= new ShisetsuColumnSetting( this );
					this._columnSettings[(int)TabKind.政策]		= new SeisakuColumnSetting( this );
					this._columnSettings[(int)TabKind.戦法]		= new SenpouColumnSetting( this );
					this._columnSettings[(int)TabKind.特性]		= new TokuseiColumnSetting( this );
					this._columnSettings[(int)TabKind.習得条件]	= new TokuseiSyuutokuJoukenColumnSetting( this );
					this._columnSettings[(int)TabKind.成長型]	= new SeichougataColumnSetting( this );
					this._columnSettings[(int)TabKind.地方]		= new ChihouColumnSetting( this );
					this._columnSettings[(int)TabKind.国]		= new KuniColumnSetting( this );
					this._columnSettings[(int)TabKind.効果]		= new KoukaColumnSetting( this );
					this._columnSettings[(int)TabKind.方針]		= new HoushinColumnSetting( this );
					this._columnSettings[(int)TabKind.軍略]		= new GunryakuColumnSetting( this );
					this._columnSettings[(int)TabKind.城郭]		= new JoukakuColumnSetting( this );
					this._columnSettings[(int)TabKind.城名]		= new ShiroNameColumnSetting( this );
					this._columnSettings[(int)TabKind.Param]	= new ParamColumnSetting( this );


					if ( this.MainWindowInterface.SettingData.ColInfo != null )
					{
						for ( var i = 0; i < this.MainWindowInterface.SettingData.ColInfo.Length; i++ )
						{
							if ( this.MainWindowInterface.SettingData.ColInfo[i] != null )
							{
								this._columnSettings[(int)this.MainWindowInterface.SettingData.TabNames[i]].FromSetting( this.MainWindowInterface.SettingData.ColInfo[i] );
							}
						}
					}
				}
				return this._columnSettings;
			}
		}

		/// <summary>データリスト</summary>
		private DataList[] _dataLists;
		/// <summary>データリスト</summary>
		public DataList[] DataLists
		{
			get
			{
				if ( this._dataLists == null )
				{
#if DEBUG
					System.Diagnostics.Debug.WriteLine( "N14PKB.cs データリスト作成" );
#endif
					// リスト作成時に他のリストを参照する場合があるのでこの順番を変えてはいけない
					this._dataLists = new DataList[this.TabCount];
					this._dataLists[(int)TabKind.要所]		= new YousyoList( this );		// 勢力リスト作成他で参照
					this._dataLists[(int)TabKind.武将]		= new BusyouList( this );
					this._dataLists[(int)TabKind.城名]		= new ShiroNameList( this );	// 城リスト作成で参照
					this._dataLists[(int)TabKind.施設]		= new ShisetsuList( this );		// 城リスト作成で参照
					this._dataLists[(int)TabKind.建物]		= new TatemonoList( this );		// 城リスト作成で参照
					this._dataLists[(int)TabKind.城]		= new ShiroList( this );
					this._dataLists[(int)TabKind.区画]		= new KukakuList( this );
					this._dataLists[(int)TabKind.勢力]		= new SeiryokuList( this );		// 軍団リスト作成で参照
					this._dataLists[(int)TabKind.軍団]		= new GundanList( this );
					this._dataLists[(int)TabKind.部隊]		= new ButaiList( this );
					this._dataLists[(int)TabKind.家宝]		= new KahouList( this );
					this._dataLists[(int)TabKind.国人衆]	= new KokujinList( this );
					this._dataLists[(int)TabKind.街道]		= new KaidouList( this );
					this._dataLists[(int)TabKind.政策]		= new SeisakuList( this );
					this._dataLists[(int)TabKind.戦法]		= new SenpouList( this );
					this._dataLists[(int)TabKind.特性]		= new TokuseiList( this );
					this._dataLists[(int)TabKind.習得条件]	= new TokuseiSyuutokuJoukenList( this );
					this._dataLists[(int)TabKind.成長型]	= new SeichougataList( this );
					this._dataLists[(int)TabKind.地方]		= new ChihouList( this );
					this._dataLists[(int)TabKind.国]		= new KuniList( this );
					this._dataLists[(int)TabKind.効果]		= new KoukaList( this );
					this._dataLists[(int)TabKind.方針]		= new HoushinList( this );
					this._dataLists[(int)TabKind.軍略]		= new GunryakuList( this );
					this._dataLists[(int)TabKind.城郭]		= new JoukakuList( this );
					this._dataLists[(int)TabKind.Param]		= new ParamList( this );
					if ( this._dataLists[(int)TabKind.Param].Items == null )
					{
						// Paramデータの取得に失敗した場合は null にする
						this._dataLists[(int)TabKind.Param] = null;
					}
				}
				return this._dataLists;
			}
		}
		#region 各データリスト
		/// <summary>武将データリスト</summary>
		public BusyouList Busyoulist { get { return this.DataLists[(int)TabKind.武将] as BusyouList; } }

		/// <summary>城データリスト</summary>
		public ShiroList Shirolist { get { return this.DataLists[(int)TabKind.城] as ShiroList; } }

		/// <summary>区画データリスト</summary>
		public KukakuList Kukakulist { get { return this.DataLists[(int)TabKind.区画] as KukakuList; } }

		/// <summary>勢力データリスト</summary>
		public SeiryokuList Seiryokulist { get { return this.DataLists[(int)TabKind.勢力] as SeiryokuList; } }

		/// <summary>軍団データリスト</summary>
		public GundanList Gundanlist { get { return this.DataLists[(int)TabKind.軍団] as GundanList; } }

		/// <summary>部隊データリスト</summary>
		public ButaiList Butailist { get { return this.DataLists[(int)TabKind.部隊] as ButaiList; } }

		/// <summary>建物データリスト</summary>
		public TatemonoList Tatemonolist { get { return this.DataLists[(int)TabKind.建物] as TatemonoList; } }

		/// <summary>家宝データリスト</summary>
		public KahouList Kahoulist { get { return this.DataLists[(int)TabKind.家宝] as KahouList; } }

		/// <summary>国人衆データリスト</summary>
		public KokujinList Kokujinlist { get { return this.DataLists[(int)TabKind.国人衆] as KokujinList; } }

		/// <summary>要所データリスト</summary>
		public YousyoList Yousyolist { get { return this.DataLists[(int)TabKind.要所] as YousyoList; } }

		/// <summary>街道データリスト</summary>
		public KaidouList Kaidoulist { get { return this.DataLists[(int)TabKind.街道] as KaidouList; } }

		/// <summary>施設データリスト</summary>
		public ShisetsuList Shisetsulist { get { return this.DataLists[(int)TabKind.施設] as ShisetsuList; } }

		/// <summary>政策データリスト</summary>
		public SeisakuList Seisakulist { get { return this.DataLists[(int)TabKind.政策] as SeisakuList; } }

		/// <summary>戦法データリスト</summary>
		public SenpouList Senpoulist { get { return this.DataLists[(int)TabKind.戦法] as SenpouList; } }

		/// <summary>特性データリスト</summary>
		public TokuseiList Tokuseilist { get { return this.DataLists[(int)TabKind.特性] as TokuseiList; } }

		/// <summary>特性習得条件データリスト</summary>
		public TokuseiSyuutokuJoukenList TokuseiSyuutokuJoukenlist { get { return this.DataLists[(int)TabKind.習得条件] as TokuseiSyuutokuJoukenList; } }

		/// <summary>成長型データリスト</summary>
		public SeichougataList Seichougatalist { get { return this.DataLists[(int)TabKind.成長型] as SeichougataList; } }

		/// <summary>地方データリスト</summary>
		public ChihouList Chihoulist { get { return this.DataLists[(int)TabKind.地方] as ChihouList; } }

		/// <summary>国データリスト</summary>
		public KuniList Kunilist { get { return this.DataLists[(int)TabKind.国] as KuniList; } }

		/// <summary>効果データリスト</summary>
		public KoukaList Koukalist { get { return this.DataLists[(int)TabKind.効果] as KoukaList; } }

		/// <summary>方針データリスト</summary>
		public HoushinList Houshinlist { get { return this.DataLists[(int)TabKind.方針] as HoushinList; } }

		/// <summary>軍略データリスト</summary>
		public GunryakuList Gunryakulist { get { return this.DataLists[(int)TabKind.軍略] as GunryakuList; } }

		/// <summary>城郭データリスト</summary>
		public JoukakuList Joukakulist { get { return this.DataLists[(int)TabKind.城郭] as JoukakuList; } }

		/// <summary>城名データリスト</summary>
		public ShiroNameList ShiroNamelist { get { return this.DataLists[(int)TabKind.城名] as ShiroNameList; } }

		/// <summary>Paramデータリスト</summary>
		public ParamList Paramlist { get { return this.DataLists[(int)TabKind.Param] as ParamList; } }
		#endregion

		///// <summary>インデクサ</summary>
		///// <param name="n">リスト番号</param>
		///// <returns>データリスト</returns>
		//public DataList this[Int32 n]
		//{
		//	get { return this.DataLists[n]; }
		//}

		/////// <summary>イテレータ</summary>
		/////// <returns>データリスト</returns>
		////public IEnumerator<DataList> GetEnumerator()
		////{
		////	for ( var i = 0; i < this.DataLists.Length; i++ )
		////	{
		////		yield return this.DataLists[i];
		////	}
		////}

		/// <summary>コンストラクタ</summary>
		public N14PKB( IMainWindow mainWindowInterface )
		{
			this._mainWindowInterface = mainWindowInterface;
			this.PlayerSeriyokuID = 0;
			this.ReloadDataLists();
		}

		/// <summary>データをプロセスメモリから再読み込みする</summary>
		public void ReloadDataLists()
		{
			if ( this._n14pk != null )
			{
				this._n14pk.Dispose();
				this._n14pk = null;
			}

			// ゲームバージョン別設定情報
			var verConfig = new UnknownVersion();

			// ゲームプロセス
			this._n14pk = new N14PK( verConfig );
			this.GameVersion = this._n14pk.GameVersion;

			this._columnSettings = null;
			this._dataLists = null;
		}

		/// <summary>変更のあったデータをプロセスメモリに書き込む</summary>
		public void Commit()
		{
			if ( this.NeedsCommit )
			{
#if DEBUG
				System.Diagnostics.Debug.WriteLine( "Commit(N14PKB)" );
#endif
				this.NeedsCommit = false;
				for ( var i = 0; i < this.DataLists.Length; i++ )
				{
					if ( this.DataLists[i] != null )
					{
						this.DataLists[i].Commit();
					}
				}
			}
		}

	}

}
