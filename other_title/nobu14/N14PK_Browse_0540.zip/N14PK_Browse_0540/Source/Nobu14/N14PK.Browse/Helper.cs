﻿// Helper.cs

using System;
using System.Linq.Expressions;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;
namespace N14PKBrowse
{
	class Helper
	{

		/// <summary>プロパティ値を取得</summary>
		/// <typeparam name="T">プロパティを持つ型</typeparam>
		/// <param name="propertyName">プロパティ名</param>
		/// <param name="data">プロパティを持つインスタンス</param>
		private static object GetPropertyValue<T>( string propertyName, T data )
		{
			System.Reflection.PropertyInfo pi = data.GetType().GetProperty( propertyName );
			return ( pi != null ) ? pi.GetValue( data, null ) : null;
		}

		/// <summary>プロパティ名を文字列で取得</summary>
		/// <typeparam name="T">プロパティの型</typeparam>
		/// <param name="propertyName">プロパティ名を表すExpression。() => Name のように指定する</param>
		public static string GetName<T>( Expression<Func<T>> propaertyName )
		{
			var member = (MemberExpression)propaertyName.Body as MemberExpression;
			return member.Member.Name;
		}

		/// <summary>タブインデクスとデータIDの対応表</summary>
		private static readonly int[] DataKindInTabIndex =
		{
			01,		// TabIndex:00 DataID:01 武将
			04,		// 01 04 城
			04,		// 02 04 区画(城)
			02,		// 03 02 勢力
			03,		// 04 03 軍団
			06,		// 05 06 部隊
			00,		// 06 00 建物
			11,		// 07 11 家宝
			27,		// 08 27 国人衆
			08,		// 09 08 要所
			15,		// 10 15 街道
			10,		// 11 10 施設
			26,		// 12 26 政策
			23,		// 13 23 戦法
			18,		// 14 18 特性
			19,		// 15 19 特性習得条件
			20,		// 16 20 成長型
			14,		// 17 14 地方
			12,		// 18 12 国
			24,		// 19 24 効果
			07,		// 20 07 方針
			25,		// 21 25 軍略
			33,		// 22 33 城郭
			05,		// 23 05 城名
			-1		// 24 XX パラメータ
		};

		/// <summary>タブインデクスからデータテーブルIDを取得する。ミスを防ぐため引数を列挙型で渡す</summary>
		/// <param name="tabkind">タブの名前</param>
		/// <returns>タブインデクス</returns>
		public static int GetDataTableIDByTabKind( Enums.TabKind tabkind )
		{
			if ( 0 <= (int)tabkind && (int)tabkind < Helper.DataKindInTabIndex.Length )
			{
				return Helper.DataKindInTabIndex[(int)tabkind];
			}
			return -1;
		}

		/// <summary>データの種類からタブインデクスを取得する。ミスを防ぐため引数を列挙型で渡す</summary>
		/// <param name="tabNameKind"></param>
		/// <returns></returns>
		public static int GetTabIndexByDataKind( N14PKLibrary.DataKind datakind )
		{
			return Array.FindIndex( Helper.DataKindInTabIndex, d => d == (int)datakind );
		}


		/// <summary>特性 格付け</summary>
		public static readonly NameList<int> 特性格 = new NameList<int>
		{
			{ 0 , "E" },
			{ 1 , "D" },
			{ 2 , "C" },
			{ 3 , "B" },
			{ 4 , "A" },
			{ 5 , "S" }
		};

		/// <summary>特性 系統</summary>
		public static readonly NameList<int> 特性系統 = new NameList<int>
		{
			{ 0 , "統率" },
			{ 1 , "武勇" },
			{ 2 , "知略" },
			{ 3 , "政治" },
			{ 4 , "内政" },
			{ 5 , "合戦" },
			{ 6 , "役職" },
			{ 7 , "官位" },
			{ 8 , "8(未使用)" },
			{ 9 , "ダミー" }
		};

		/// <summary>武将 身分</summary>
		public static readonly NameList<int> 武将身分 = new NameList<int>
		{
			{ (int)MibunKind.生前,		"生前" },
			{ (int)MibunKind.成人前,	"成人前" },
			{ (int)MibunKind.未発見,	"未発見" },	// 創造では未使用？
			{ (int)MibunKind.浪人,		"浪人" },
			{ (int)MibunKind.捕虜,		"捕虜" },
			{ (int)MibunKind.人質,		"人質" },	// 創造では未使用？
			{ (int)MibunKind.姫,		"姫" },
			{ (int)MibunKind.通常,		"通常" },	// 大名/家臣/一門/隠居
			{ (int)MibunKind.他,		"他" },		// 死亡/非登場
			{ (int)MibunKind.なし,		"" }
		};

		/// <summary>武将 身分詳細</summary>
		public static readonly NameList<int> 武将身分詳細 = new NameList<int>
		{
			{ (int)MibunSyousaiKind.当主,			"大名" },
			{ (int)MibunSyousaiKind.軍団長姫,		"軍団長(姫)" },
			{ (int)MibunSyousaiKind.軍団長,			"軍団長" },
			{ (int)MibunSyousaiKind.軍団長直轄外姫,	"軍団長(直外)" },
			{ (int)MibunSyousaiKind.軍団長直轄外,	"軍団長(直外姫)" },
			{ (int)MibunSyousaiKind.家臣姫,			"家臣(姫)" },
			{ (int)MibunSyousaiKind.家臣,			"家臣" },
			{ (int)MibunSyousaiKind.姫,				"姫" },
			{ (int)MibunSyousaiKind.捕虜姫,			"捕虜(姫)" },
			{ (int)MibunSyousaiKind.捕虜,			"捕虜" },
			{ (int)MibunSyousaiKind.浪人,			"浪人" },
			{ (int)MibunSyousaiKind.成人前,			"成人前" },
			{ (int)MibunSyousaiKind.生前,			"生前" },
			{ (int)MibunSyousaiKind.謹慎中,			"謹慎中" },
			{ (int)MibunSyousaiKind.他,				"他" },
			{ (int)MibunSyousaiKind.国人衆,			"国人衆" },
			{ (int)MibunSyousaiKind.なし,			"なし" }
		};

		/// <summary>武将 信仰</summary>
		public static readonly NameList<int> 武将信仰 = new NameList<int>
		{
			{ 0, "なし" },
			{ 1, "仏教" },
			{ 2, "一向宗" },
			{ 3, "基督教" },
		};

		/// <summary>武将 出自</summary>
		public static readonly NameList<int> 武将出自 = new NameList<int>
		{
			{ 0, "武士" },
			{ 1, "高家" },
			{ 2, "僧侶" },
			{ 3, "商人" },
			{ 4, "海賊" },
			{ 5, "忍者" },
			{ 6, "剣豪" },
			{ 7, "庶民" }
		};

		/// <summary>武将 傷病</summary>
		public static readonly NameList<int>武将傷病 = new NameList<int>
		{
			{ 1, "負傷" },
			{ 2, "病気" },
			{ 0, "" }	// 健康
		};

		/// <summary>武将 声タイプ</summary>
		public static readonly NameList<int>武将声タイプ = new NameList<int>
		{
			{ 0, "若者:少年" },
			{ 1, "若者:まじめ" },
			{ 2, "若者:豪傑" },
			{ 3, "若者:策士" },
			{ 4, "若者:冷静" },
			{ 5, "若者:お人好し" },
			{ 6, "中年:まじめ" },
			{ 7, "中年:豪傑" },
			{ 8, "中年:熱血" },
			{ 9, "中年:お人好し" },
			{ 10, "中年:猛将" },
			{ 11, "中年:冷静" },
			{ 12, "中年:策士" },
			{ 13, "中年:威厳" },
			{ 14, "老人:百戦錬磨" },
			{ 15, "女性:勇壮" },
			{ 16, "女性:聡明" },
			// 以降PKで追加
			{ 17, "若者:勇将" },
			{ 18, "中年:軍師" },
			{ 19, "中年:文官" },
			{ 20, "女性:快活" },
			{ 21, "女性:柔和" }
		};

		/// <summary>武将 格付け</summary>
		public static readonly NameList<int>武将格 = new NameList<int>
		{
			{ 0, "C" },
			{ 1, "B" },
			{ 2, "A" },
			{ 3, "S" }
		};

		/// <summary>武将 士道</summary>
		public static readonly NameList<int>武将士道 = new NameList<int>
		{
			{ 0, "名" },
			{ 1, "家" },
			{ 2, "才" },
			{ 3, "利" },
			{ 4, "義" },
			{ 5, "創造" },
			// 以降PKで追加
			{ 6, "道" },
			{ 7, "志" }
		};

		/// <summary>家宝 種類</summary>
		public static readonly NameList<int>家宝種類 = new NameList<int>
		{
			{ 0, "茶器" },
			{ 1, "武具" },
			{ 2, "名馬" },
			{ 3, "書物" },
			{ 4, "絵画" },
			{ 5, "香木" },
			{ 6, "舶来" },
			{ 7, "唐物" }
		};

		/// <summary>家宝 等級</summary>
		public static readonly NameList<int>家宝等級 = new NameList<int>
		{
			{ 1, "十等" },
			{ 2, "九等" },
			{ 3, "八等" },
			{ 4, "七等" },
			{ 5, "六等" },
			{ 6, "五等" },
			{ 7, "四等" },
			{ 8, "三等" },
			{ 9, "二等" },
			{ 10, "一等" },
			{ 0, "" },
		};

		/// <summary>家宝 産地</summary>
		public static readonly NameList<int>家宝産地 = new NameList<int>
		{
			{ 0, "日本" },
			{ 1, "南蛮" },
			{ 2, "明" }
		};

		/// <summary>国人衆 特能</summary>
		public static readonly NameList<int>国人衆特能 = new NameList<int>
		{
			{ 0, "義勇" },
			{ 1, "銭納" },
			{ 2, "米納" },
			{ 3, "傭兵" },
			{ 4, "番匠" },
			{ 5, "鉄砲" },
			{ 6, "軍馬" },
			{ 7, "土竜" },
			{ 8, "剣豪" },
			{ 9, "水軍" },
			{ 10, "寺社" },
			{ 11, "隠密" },
			{ -1, "" }
		};

		/// <summary>街道 地形タイプ</summary>
		public static readonly NameList<int>街道地形タイプ = new NameList<int>
		{
			{ 0, "平地" },
			{ 1, "山地" },
			{ 2, "平地(川)" },
			{ 3, "近海" },
			{ 4, "遠海" }
		};

		/// <summary>政策 タイプ</summary>
		public static readonly NameList<int>政策タイプ = new NameList<int>
		{
			{ 0, "惣無事令" },
			{ 1, "専用" },
			{ 2, "創造" },
			{ 3, "中道" },
			{ 4, "保守" },
			{ 5, "共通" },
			{ -1, "" },
		};

		/// <summary>戦法 系統</summary>
		public static readonly NameList<int>戦法系統 = new NameList<int>
		{
			{ 0, "強化" },
			{ 1, "回復" },
			{ 2, "妨害" },
			{ 3, "特性" },
			{ 4, "突撃" },
			{ 5, "斉射" },
			{ -1, "" },
		};

		/// <summary>城郭 タイプ</summary>
		public static readonly NameList<int>城郭タイプ = new NameList<int>
		{
			{ 0, "天守" },
			{ 1, "城門" },
			{ 2, "塀" },
			{ 3, "出丸" },
			{ 4, "矢倉" },
			{ 5, "曲輪" },
			{ 6, "施設" },
		};

		/// <summary>施設 タイプ</summary>
		public static readonly NameList<int>施設タイプ = new NameList<int>
		{
			{ 0, "城" },
			{ 1, "資源" },
			{ 2, "内政" },
			{ 3, "3(未使用)" },
			{ 4, "4(未使用)" },
			{ 5, "国人衆" },
			{ 6, "港・鉱山" },
			{ 7, "神社仏閣" },
			{ 8, "整備中" }
		};
	}
}
