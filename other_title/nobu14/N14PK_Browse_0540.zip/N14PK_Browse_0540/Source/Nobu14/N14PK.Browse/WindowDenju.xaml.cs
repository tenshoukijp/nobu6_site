﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

using N14PKBrowse.Data;
using N14PKBrowse.HelperClass;

namespace N14PKBrowse
{
	/// <summary>
	/// WindowDenju.xaml の相互作用ロジック
	/// </summary>
	public partial class WindowDenju : Window
	{
		private TextBox[] TextBoxArray	{ get; set; }	// コントロールの配列
		private Label[] LabelArray		{ get; set; }	// コントロールの配列
		public N14PKB N14pkb			{ get; set; }	// ツール管理
		public Seiryoku Seiryoku		{ get; set; }	// 選択中の勢力データ
		private sbyte UndoValue			{ get; set; }	// 編集前の値

		public WindowDenju()
		{
			InitializeComponent();
		}
		private void Window_Loaded( object sender, RoutedEventArgs e )
		{
			// コントロール配列を作成
			this.TextBoxArray = (TextBox[])MyControlArray.GetControlArrayByName( this, "TextBox" );
			this.LabelArray = (Label[])MyControlArray.GetControlArrayByName( this, "Label" );

			// テクストボックス＆ラベル設定
			for ( int i = 0; i < this.LabelArray.Length; i++ )
			{
				this.LabelArray[i].Content = " " + N14pkb.Tokuseilist.GetDataBySortID( i ).Name;	// ラベルテキスト
				ToolTipService.SetInitialShowDelay( LabelArray[i], 0 );								// ツールチップ表示ディレイ
				this.LabelArray[i].ToolTip = N14pkb.Tokuseilist.GetDataBySortID( i ).HelpText1;		// ツールチップテキスト

				this.TextBoxArray[i].Text = this.Seiryoku.DenjuTokuseiArray[N14pkb.Tokuseilist.GetIDBySortID(i)].ToString();		// 編集画面の並びはソートIDでソートしたもの
				//this.TextBoxArray[i].Text = this.Seiryoku.DenjuTokuseiArray[i].ToString();		// 編集画面の並びはソートIDでソートしたもの
				this.TextBoxArray[i].KeyDown += new KeyEventHandler( TextBox_KeyDown );								// イベントデリゲート エンターチェック
				this.TextBoxArray[i].LostFocus += new RoutedEventHandler( TextBox_LostFocus );						// イベントデリゲート フォーカス移動チェック※このタイミングで書き込み
				this.TextBoxArray[i].GotFocus += new RoutedEventHandler( TextBox_GotFocus );						// イベントデリゲート フォーカスチェック(テキスト全選択)
				this.TextBoxArray[i].PreviewMouseDown += new MouseButtonEventHandler( TextBox_PreviewMouseDown );	// イベントデリゲート マウスダウン(テキスト全選択)

				if ( 0 < this.Seiryoku.DenjuTokuseiArray[N14pkb.Tokuseilist.GetIDBySortID(i)] )
				{
					this.LabelArray[i].Foreground = System.Windows.Media.Brushes.Red;					// 文字色
				}
			}

			// ステータスバー更新
			this.StatusBarItem1.Content = string.Format( "編集勢力:" + this.Seiryoku.Name + " ※役職は値を設定しても意味なさそう。官位は授与画面で確認できないが複数所持可能(関白/左大臣/右大臣は授与不可)" );
		}

		// 閉じるボタン
		private void ButtonClose_Click( object sender, RoutedEventArgs e )
		{
			this.Close();
		}

		// キー入力判定(フォーカス移動や入力キャンセル)
		private void TextBox_KeyDown( object sender, KeyEventArgs e )
		{
			if ( e.Key == Key.Return )
			{
				FocusNavigationDirection focusDirection = FocusNavigationDirection.Next;
				TraversalRequest request = new TraversalRequest( focusDirection );
				UIElement elementWithFocus = Keyboard.FocusedElement as UIElement;

				if ( elementWithFocus != null )
				{
					elementWithFocus.MoveFocus( request );
				}
			}

			if ( e.Key == Key.Escape )
			{
				var tb = ( sender as TextBox );
				if ( null == tb )
				{
					return;
				}
				tb.Text = this.UndoValue.ToString();
				tb.SelectAll();
			}
		}

		// フォーカスを失ったタイミングでデータのチェック＆書き込み
		private void TextBox_LostFocus( object sender, RoutedEventArgs e )
		{
			var tb = ( sender as TextBox );

			if ( null == tb )
			{
				return;
			}

			// テキストボックスのインデクスを取得する
			int index = -1;
			for ( int i = 0; i < this.TextBoxArray.Length; i++ )
			{
				if ( this.TextBoxArray[i].Equals( sender ) )
				{
					index = i;
					break;
				}
			}

			this.WriteData( tb, index );

			// テキストボックス表示更新
			tb.Text = this.Seiryoku.DenjuTokuseiArray[N14pkb.Tokuseilist.GetIDBySortID( index )].ToString();	// 編集画面の並びはソートIDでソートしたもの
			if ( 0 < this.Seiryoku.DenjuTokuseiArray[N14pkb.Tokuseilist.GetIDBySortID( index )] )
			{
				this.LabelArray[index].Foreground = System.Windows.Media.Brushes.Red;					// 文字色
			}
			else
			{
				this.LabelArray[index].Foreground = System.Windows.Media.Brushes.Black;					// 文字色
			}
		}

		private void WriteData( TextBox tb, int index )
		{
			long num;
			if ( !long.TryParse( tb.Text, out num ) )
			{
				// 入力されたテキストが数値変換できない場合
				return;
			}

			if ( num < 0 )
			{
				// データ自体は sbyte だが、負の値は意味が無いので 0 に補正
				num = 0;
			}
			else if ( 127 < num )
			{
				num = 127;
			}

			// SeiryokuData.DenjuTokuseiArray のコピーに対して操作し、終了時に戻す
			// DenjuTokuseiArray を直接変更しても参照時にgetプロパティで配列ごと new されるため意味が無い
			var array = this.Seiryoku.DenjuTokuseiArray;
			array[N14pkb.Tokuseilist.GetIDBySortID( index )] = (sbyte)num;
			this.Seiryoku.DenjuTokuseiArray = array;
			this.N14pkb.Seiryokulist.Commit();
		}

		// タブやエンターでフォーカスを得た際にテキストボックス内のテキストを全選択する
		private void TextBox_GotFocus( object sender, RoutedEventArgs e )
		{
			var tb = ( sender as TextBox );

			if ( null == tb )
			{
				return;
			}

			// 編集前の値を保存
			sbyte num;
			if ( SByte.TryParse( tb.Text, out num ) )
			{
				this.UndoValue = num;
			}

			tb.SelectAll();
			e.Handled = true;
		}

		// マウスクリックでフォーカスを得た際にテキストボックス内のテキストを全選択する
		public void TextBox_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			var tb = ( sender as TextBox );

			if ( null == tb )
				return;

			tb.SelectAll();
			tb.Focus();
			e.Handled = true;
		}
	}
}
