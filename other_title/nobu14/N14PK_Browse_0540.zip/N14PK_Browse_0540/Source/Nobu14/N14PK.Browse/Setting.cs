﻿using System;
using System.IO;
using System.Windows;
using System.Xml.Serialization;

namespace N14PKBrowse
{
	/// <summary>ツールの設定情報管理</summary>
	public class Setting
	{
		public class Miscellany
		{
			public string GameVersion		{ get; set; }
			public string MyVersion			{ get; set; }
			public uint ParamIndexAddress	{ get; set; }
		}
		public class WindowInformation
		{
			public int Top				{ get; set; }
			public int Left				{ get; set; }
			public int Width			{ get; set; }
			public int Height			{ get; set; }
		}
		public class ColumnInformation
		{
			public string PropertyName		{ get; set; }
			public int Width				{ get; set; }
			public int DisplayIndex			{ get; set; }
			public bool IsHidden			{ get; set; }
		}

		public class ProgramSetting
		{
			public Miscellany Misc					{ get; set; }
			public WindowInformation WinInfo		{ get; set; }
			public Enums.TabKind[] TabNames			{ get; set; }
			public ColumnInformation[][] ColInfo	{ get; set; }
		}

		/// <summary>設定ファイル名</summary>
		public static readonly string Filename = "N14PK_Browse.Setting.xml";

		/// <summary>設定をファイルから読み込む</summary>
		public static ProgramSetting LoadSettingFile()
		{
			var filepath = Environment.CurrentDirectory + @"\" + Filename;
			if ( !File.Exists( filepath ) )
			{
				return Setting.DefaultSetting;
			}

			var serializer = new XmlSerializer( typeof( ProgramSetting ) );

			using ( var fs = new FileStream( filepath, FileMode.Open ) )
			{
				try
				{
					var setting = (ProgramSetting)serializer.Deserialize( fs );
					return setting;
				}
				catch ( Exception ex )
				{
					var message = Filename + Environment.NewLine
								+ ex.Message + Environment.NewLine
								+ "初期設定で起動します。";

					MessageBox.Show( message, "設定ファイル読み込み", MessageBoxButton.OK, MessageBoxImage.Error );
					return Setting.DefaultSetting;
				}
			}
		}

		/// <summary>設定をファイルに書き出す</summary>
		/// <param name="functions">出力する設定</param>
		public static void SaveSettingFile( ProgramSetting setting )
		{
			var serializer = new XmlSerializer( typeof( ProgramSetting ) );
			var filepath = Environment.CurrentDirectory + @"\" + Filename;

			using( var fs = new FileStream( filepath, FileMode.Create ) )
			{
				serializer.Serialize( fs, setting );
			}
		}

		/// <summary>デフォルト設定</summary>
		public static ProgramSetting DefaultSetting
		{
			get
			{
				return new ProgramSetting()
					{
						WinInfo = new WindowInformation()
						{
							Left = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Width / 2 - 1024 / 2,
							Top = System.Windows.Forms.Screen.PrimaryScreen.Bounds.Height / 2 - 550 / 2,
							Width = 1024,
							Height = 550
						}
					};
			}
		}
	}
}
