﻿// N14PKBView.cs

using System;
using System.ComponentModel;
using System.Windows.Controls;
using System.Windows.Data;
using N14PKBrowse.Column;
using N14PKBrowse.Compare;
using N14PKBrowse.Sort;
using N14PKBrowse.Menu;
using N14PKLibrary;
using N14PKLibrary.VersionConfig;
using N14PKBrowse.Enums;
using N14PKBrowse.List;
using N14PKBrowse.Data;

using N14PKBrowse.HelperClass;
namespace N14PKBrowse
{
	/// <summary>ビュー用オブジェクト</summary>
	public class N14PKBView : INotifyPropertyChanged
	{
		/// <summary>ビューで使用するフラグ</summary>
		public class ViewFlags
		{
			/// <summary>データ取得後の初回処理フラグ</summary>
			public bool IsFirst { get; set; }
			/// <summary>フィルタ処理フラグ</summary>
			public bool NeedsFilter { get; set; }
			/// <summary>リフレッシュフラグ</summary>
			public bool NeedsRefresh { get; set; }
		}

		/// <summary>ツール管理</summary>
		private N14PKB _n14pkb;

		/// <summary>データ再取得フラグ</summary>
		public bool NeedsRegetData { get; set; }

		/// <summary>メインウィンドウ操作用インターフェイス</summary>
		private IMainWindow _mainWindowInterface;
		/// <summary>メインウィンドウ操作用インターフェイス</summary>
		public IMainWindow MainWindowInterface
		{
			get { return this._mainWindowInterface; }
		}

		/// <summary>ステータスバー表示エリア2</summary>
		public string Status2 { get; set; }

		/// <summary>ステータスバー表示エリア3</summary>
		private string _status3;
		/// <summary>ステータスバー表示エリア3</summary>
		public string Status3
		{
			get { return this._status3; }
			set
			{
				if ( value == this._status3 ) { return; }
				this._status3 = value;
				this.PropertyChanged.Raise( () => this.Status3 );
			}
		}

		private NameList<uint> _seiryokuNamelist;
		public NameList<uint> SeiryokuNamelist
		{
			get
			{
				if ( this._seiryokuNamelist == null )
				{
					return this._n14pkb.Seiryokulist.SeiryokuAndTousyunamelist;
				}
				return this._seiryokuNamelist;
			}
			set
			{
				this._seiryokuNamelist = value;
				this.PropertyChanged.Raise( () => this.SeiryokuNamelist );
				this.PropertyChanged.Raise( () => this.SelectedSeiryokuAddress );
			}
		}

		/// <summary>コンボボックス勢力選択</summary>
		private uint _selectedSeiryokuAddress;
		/// <summary>コンボボックス勢力選択</summary>
		public uint SelectedSeiryokuAddress
		{
			get
			{
				if ( this._selectedSeiryokuAddress == 0 )
				{
					if ( this._n14pkb.PlayerSeriyokuID == -1 )
					{
						// シナリオロード前でプレイヤー勢力が未設定
						return 0;
					}

					this._selectedSeiryokuAddress = this._n14pkb.Seiryokulist[this._n14pkb.PlayerSeriyokuID].Address;
				}
				return this._selectedSeiryokuAddress;
			}
			set
			{
				if ( value == SelectedSeiryokuAddress ) { return; }
#if DEBUG
				System.Diagnostics.Debug.WriteLine( "SelectedSeiryokuAddress:" + value.ToString( "X8" ) );
#endif
				this._selectedSeiryokuAddress = value;
				this.PropertyChanged.Raise( () => this.SelectedSeiryokuAddress );

				this.Flags[(int)TabKind.武将].NeedsFilter = true;
				this.Flags[(int)TabKind.城].NeedsFilter = true;
				this.Flags[(int)TabKind.区画].NeedsFilter = true;
				//this.Flags[(int)TabKind.軍団].NeedsFilter = true;
				this.Flags[(int)TabKind.建物].NeedsFilter = true;
				this.Flags[(int)TabKind.部隊].NeedsFilter = true;
				this.Flags[(int)TabKind.国人衆].NeedsFilter = true;
				this.Flags[(int)TabKind.要所].NeedsFilter = true;
				this.Flags[(int)TabKind.街道].NeedsFilter = true;
				this.Filtering( this._mainWindowInterface.SelectedTabIndex );

			}
		} // コンボボックス勢力選択

		/// <summary>ラジオボタン勢力条件</summary>
		private Enums.RadioSeiryoku _selectedSeiryoku;
		/// <summary>ラジオボタン勢力条件</summary>
		public Enums.RadioSeiryoku SelectedSeiryoku
		{
			get { return _selectedSeiryoku; }
			set
			{
				if ( value == this._selectedSeiryoku ) { return; }
#if DEBUG
				System.Diagnostics.Debug.WriteLine( "SelectedSeiryoku:" + value );
#endif
				this._selectedSeiryoku = value;
				this.PropertyChanged.Raise( () => this.SelectedSeiryoku );

				this.Flags[(int)TabKind.武将].NeedsFilter = true;
				this.Flags[(int)TabKind.城].NeedsFilter = true;
				this.Flags[(int)TabKind.区画].NeedsFilter = true;
				//this.Flags[(int)TabKind.軍団].NeedsFilter = true;
				this.Flags[(int)TabKind.建物].NeedsFilter = true;
				this.Flags[(int)TabKind.部隊].NeedsFilter = true;
				this.Flags[(int)TabKind.国人衆].NeedsFilter = true;
				this.Flags[(int)TabKind.要所].NeedsFilter = true;
				this.Flags[(int)TabKind.街道].NeedsFilter = true;
				this.Filtering( this._mainWindowInterface.SelectedTabIndex );
			}
		}

		/// <summary>ラジオボタン身分条件</summary>
		private Enums.RadioMibun _selectedMibun;
		/// <summary>ラジオボタン身分条件</summary>
		public Enums.RadioMibun SelectedMibun
		{
			get { return _selectedMibun; }
			set
			{
				if ( value == this._selectedMibun ) { return; }
#if DEBUG
				System.Diagnostics.Debug.WriteLine( "SelectedMibun:" + value );
#endif
				this._selectedMibun = value;
				this.PropertyChanged.Raise( () => this.SelectedMibun );

				this.Flags[(int)TabKind.武将].NeedsFilter = true;
				this.Filtering( this._mainWindowInterface.SelectedTabIndex );
			}
		}

		/// <summary>フィルタ処理</summary>
		public void Filtering( int gridIndex )
		{
			if ( this.NeedsRegetData )
			{
				this.NeedsRegetData = false;
				this.MainWindowInterface.GetData();
				return;
			}

			if ( this.ListCollectionViews[gridIndex] == null )
			{
				this.Status3 = string.Empty;
				return;
			}

			if ( this.Flags[gridIndex].NeedsFilter )
			{
				this.Flags[gridIndex].NeedsFilter = false;
				if ( this._n14pkb.DataLists[gridIndex].FilterCallback != null )
				{
#if DEBUG
					System.Diagnostics.Debug.WriteLine( "Filtering:" + (TabKind)gridIndex );
#endif
					this.ListCollectionViews[gridIndex].Filter = this._n14pkb.DataLists[gridIndex].FilterCallback;
				}
			}
			this.Status3 = "表示データ数:" + this.ListCollectionViews[gridIndex].Count;
		}

		/// <summary>ビューリスト</summary>
		private ListCollectionView[] _listCollectionViews;
		/// <summary>ビューリスト</summary>
		public ListCollectionView[] ListCollectionViews
		{
			get
			{
				if ( this._listCollectionViews == null )
				{
					this._listCollectionViews = new ListCollectionView[this._mainWindowInterface.TabCount];
					for ( var i = 0; i < this._mainWindowInterface.TabCount; i++ )
					{
						if ( this._n14pkb.DataLists[i] != null )
						{
							this._listCollectionViews[i] = new ListCollectionView( this._n14pkb.DataLists[i].Items );
						}
					}
				}
				return this._listCollectionViews;
			}
		}


		/// <summary>フラグ</summary>
		private ViewFlags[] _flags;
		/// <summary>フラグ</summary>
		public ViewFlags[] Flags
		{
			get
			{
				if ( this._flags == null )
				{
					this._flags = new ViewFlags[this._mainWindowInterface.TabCount];
					for ( var i = 0; i < this._mainWindowInterface.TabCount; i++ )
					{
						this._flags[i] = new ViewFlags();
					}
				}
				return this._flags;
			}
		}


		/// <summary>ビューをリフレッシュする</summary>
		public void Refresh()
		{
			for ( var i = 0; i < this.ListCollectionViews.Length; i++ )
			{
				this.Refresh( i );
			}
		}
		/// <summary>ビューをリフレッシュする</summary>
		public void Refresh( int gridIndex )
		{
			if ( this.NeedsRegetData )
			{
				this.NeedsRegetData = false;
				this.MainWindowInterface.GetData();
				return;
			}

			if ( this.ListCollectionViews[gridIndex] == null )
			{
				return;
			}
			if ( this.Flags[gridIndex].NeedsRefresh )
			{
#if DEBUG
				System.Diagnostics.Debug.WriteLine( "Refresh:" + (TabKind)gridIndex );
#endif
				this.Flags[gridIndex].NeedsRefresh = false;
				this.ListCollectionViews[gridIndex].Refresh();
			}
		}

		/// <summary>コンストラクタ</summary>
		public N14PKBView( N14PKB n14pkb )
		{
			this._n14pkb = n14pkb;
			this._mainWindowInterface = n14pkb.MainWindowInterface;
			this.ResetListCollectionViews();
		}

		/// <summary>ListCollectionView をリセットする</summary>
		public void ResetListCollectionViews()
		{
			this._listCollectionViews = null;

			// フラグセット
			for ( var i = 0; i < this.MainWindowInterface.TabCount; i++ )
			{
				if ( this.ListCollectionViews[i] != null )
				{
					this.Flags[i].IsFirst = true;
					this.Flags[i].NeedsFilter = true;
				}
			}

			// ステータスバー更新
			this.Status2 = this._n14pkb.N14pk.ScenarioName + " " + this._n14pkb.N14pk.TransactionDateTime.ToString( "yyyy年M月d日 h時" );
			this.Status3 = "test";
		}

		/// <summary>フィルタ処理 勢力チェック</summary>
		public bool CheckSeiryoku( uint address1, uint address2 = 0 )
		{
			if ( this.SelectedSeiryokuAddress == 0 ) { return false; }

			switch ( this.SelectedSeiryoku )
			{
				case RadioSeiryoku.選:
					if ( address2 != 0 )
						return ( address1 == this.SelectedSeiryokuAddress ) || ( address2 == this.SelectedSeiryokuAddress );
					else
						return address1 == this.SelectedSeiryokuAddress;

				case RadioSeiryoku.他:
					if ( address2 != 0 )
						return ( address1 != 0 ) && ( address1 != this.SelectedSeiryokuAddress ) && ( address2 != this.SelectedSeiryokuAddress );
					else
						return ( address1 != 0 ) && ( address1 != this.SelectedSeiryokuAddress );

				case RadioSeiryoku.無:
					if ( address2 != 0 )
						return ( address1 == 0 ) && ( address2 == 0 );
					else
						return address1 == 0;

				case RadioSeiryoku.全:
					return true;

				default:
					return false;
			}
		}

		/// <summary>フィルタ処理 身分チェック</summary>
		public bool CheckMibun( Busyou busyou )
		{
			switch ( this.SelectedMibun )
			{
				case Enums.RadioMibun.生前:
					return busyou.MibunID == (int)MibunKind.生前;

				case Enums.RadioMibun.成人前:
					return busyou.MibunID ==  (int)MibunKind.成人前;

				case Enums.RadioMibun.浪人:
					return busyou.MibunID ==  (int)MibunKind.浪人;

				case Enums.RadioMibun.捕虜:
					return busyou.MibunID ==  (int)MibunKind.捕虜;

				case Enums.RadioMibun.姫:
					return busyou.MibunID == (int)MibunKind.姫 || busyou.IsHime;

				case Enums.RadioMibun.通常:
					return ( busyou.MibunID ==  (int)MibunKind.通常 ) || ( busyou.MibunSyousaiID == (int)MibunSyousaiKind.謹慎中 );

				case Enums.RadioMibun.他:
					return busyou.MibunID ==  (int)MibunKind.他;

				case Enums.RadioMibun.全:
					return true;

				default:
					return false;
			}
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>

		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:N14PKView e:" + e.PropertyName );
		}
	}
}
