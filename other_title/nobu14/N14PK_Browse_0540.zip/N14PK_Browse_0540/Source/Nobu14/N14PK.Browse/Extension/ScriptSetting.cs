﻿// Extensions.cs

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Xml.Serialization;
using N14PKBrowse.Enums;

namespace N14PKBrowse.Extension
{
	/// <summary>拡張機能設定を管理するクラス</summary>
	public class ScriptSetting
	{
		/// <summary>拡張機能の種類</summary>
		public enum FunctionKind
		{
			BUTTON,	// クリックすることで拡張機能を実行
			MENU,	// 他の拡張機能の親メニュー
		}

		/// <summary>拡張機能の設定情報クラス</summary>
		public class Function
		{
			public FunctionKind Kind	{ set; get; }	// 拡張機能の種類 MENUなら他の機能の親メニュー
			public TabKind Tabkind		{ set; get; }	// 機能を追加するタブ名
			public string Title			{ set; get; }	// タイトル
			public string Tooltip		{ set; get; }	// ボタンマウスオーバーで表示するヒント
			public string Comment		{ set; get; }	// コメント
			public string Filename		{ set; get; }	// スクリプトファイル名
			public string ParentTitle	{ set; get; }	// 親メニューのタイトル
		}

		/// <summary>拡張機能フォルダ名</summary>
		public static readonly string Directoryname = "Scripts";

		/// <summary>拡張機能設定ファイル名</summary>
		public static readonly string Filename = "FunctionSetting.xml";

		/// <summary>拡張機能設定をファイルから読み込む</summary>
		public static Function[][] LoadExtensionsSettingFile()
		{
			var tabcount = Enum.GetNames( typeof( Enums.TabKind ) ).Length;
			var functions = new Function[tabcount][];

			var filepath = Environment.CurrentDirectory + @"\" + Directoryname + @"\" + Filename;
			if( !File.Exists( filepath ) )
			{
				return functions;
			}

			Function[] f = null;
			var serializer = new XmlSerializer( typeof( Function[] ) );

			try
			{
				using ( var fs = new FileStream( filepath, FileMode.Open ) )
				{
					f = (Function[])serializer.Deserialize( fs );
					if ( functions == null || functions.Length == 0 )
					{
						return functions;
					}
				}
			}
			catch ( Exception ex )
			{
				var message = Directoryname + @"\" + Filename + Environment.NewLine
								+ ex.Message + Environment.NewLine
								+ "拡張機能設定を中止します。";

				MessageBox.Show( message, "拡張機能設定ファイル読み込み", MessageBoxButton.OK, MessageBoxImage.Error );
				return functions;
			}

			// 拡張機能設定の整合性が取れないデータを削除する
			var funclist = f.ToList();
			var index = 0;
			while ( index < funclist.Count )
			{
				var needsDelete = false;
				if ( string.IsNullOrEmpty( funclist[index].Title ) )
				{
					// タイトルがない → 削除
					needsDelete = true;
				}

				if ( funclist[index].Kind == FunctionKind.BUTTON && string.IsNullOrEmpty( funclist[index].Filename ) )
				{
					// メニュータイプがボタンなのにスクリプトファイルが指定されていない → 削除
					needsDelete = true;
				}

				if ( funclist[index].Kind == FunctionKind.MENU )
				{
					// メニュータイプがメニュー
					if ( -1 == funclist.FindIndex( d => ( d.ParentTitle == funclist[index].Title ) && ( d.Tabkind == funclist[index].Tabkind ) ) )
					{
						// 子メニューが存在しない(『当該タイトルを親タイトルに持つ ＆ タブ名が同じ』を満たすデータがない) → 削除
						needsDelete = true;
					}
				}

				if ( !string.IsNullOrEmpty( funclist[index].ParentTitle ) )
				{
					// 親タイトルが設定されている
					if ( -1 == funclist.FindIndex( d => ( d.Kind == FunctionKind.MENU ) && ( d.Title == funclist[index].ParentTitle ) && ( d.Tabkind == funclist[index].Tabkind ) ) )
					{
						// 親メニューが存在しない(『メニュータイプがメニュー ＆ 当該タイトルを持つ ＆ タブ名が同じ』を満たすデータがない) → 削除
						needsDelete = true;
					}
				}

				if ( needsDelete )
				{
					funclist.RemoveAt( index );
				}
				else
				{
					index++;
				}
			}

			// 拡張機能設定をタブ別に振り分け
			var templist = new List<Function>[tabcount];

			for ( var i = 0; i < tabcount; i++ )
			{
				templist[i] = new List<Function>();
			}

			for ( var i = 0; i < funclist.Count; i++ )
			{
				templist[(int)funclist[i].Tabkind].Add( funclist[i] );
			}

			for ( var i = 0; i < tabcount; i++ )
			{
				functions[i] = templist[i].ToArray();
			}

			return functions;
		}

#if DEBUG
		/// <summary>設定をファイルに書き出す</summary>
		/// <param name="functions">出力する設定</param>
		public static void SaveExtensionsSettingFile( Function[] functions )
		{
			var serializer = new XmlSerializer( functions.GetType() );
			var filepath = Environment.CurrentDirectory + @"\" + Directoryname + @"\" + Filename;

			using( var fs = new FileStream( filepath, FileMode.Create ) )
			{
				serializer.Serialize( fs, functions );
			}
		}
#endif
	}
}
