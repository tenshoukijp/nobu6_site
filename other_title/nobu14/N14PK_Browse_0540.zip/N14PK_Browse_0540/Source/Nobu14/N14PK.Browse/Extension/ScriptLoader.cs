﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using Microsoft.CSharp;

namespace N14PKBrowse.Extension
{
	/// <summary>スクリプトオブジェクト</summary>
	public class Script
	{
		/// <summary>拡張機能クラス名</summary>
		private const string _Classname = "N14PKBrowseExtension";

		/// <summary>拡張機能メソッド名</summary>
		private const string _Methodname = "Function";

		private CompilerResults _results = null;
		private string _filename;

		/// <summary>ロードするアセンブリ</summary>
		private static readonly string[] _assemblyNames =
		{
			"System.dll",
			"System.Data.dll",
			"System.Deployment.dll",
			"System.Drawing.dll",
			"System.Windows.Forms.dll",
			"System.Xml.dll",
			"mscorlib.dll",
			"N14PK.dll"
		};

		/// <summary>スクリプトファイルをコンパイルする</summary>
		/// <param name="scriptSource">スクリプトファイル</param>
		public void CompileFile( string filename )
		{
			this._filename = filename.Replace( Environment.CurrentDirectory, string.Empty );
			this._filename = this._filename.Replace( Extension.ScriptSetting.Directoryname, string.Empty );
			this._filename = this._filename.Replace( @"\", string.Empty );

			//using ( var sr = new StreamReader( filename, Encoding.UTF8 ) )
			using ( var sr = new StreamReader( filename, Encoding.Default ) )
			{
				var source = sr.ReadToEnd();
				this.CompileSource( source );
			}
		}

		/// <summary>スクリプトをコンパイルする</summary>
		/// <param name="scriptSource">スクリプトソース</param>
		public void CompileSource( string scriptSource )
		{
			// コンパイルオプション設定
			var options = new CompilerParameters( _assemblyNames );
			options.GenerateInMemory = true;			// メモリ内で生成
			options.IncludeDebugInformation = false;	// デバッグ情報を含めない
			options.WarningLevel = 4;					// 警告レベル
			options.TreatWarningsAsErrors = true;		// 警告をエラーとして扱う

			// コンパイルする
			var compiler = new CSharpCodeProvider( new Dictionary<string, string>(){ { "CompilerVersion", "v4.0" } } );
			this._results = compiler.CompileAssemblyFromSource( options, scriptSource );
			compiler.Dispose();

			if ( 0 < this._results.Errors.Count )
			{
				throw new ApplicationException( this.ErrorMessage() );
			}
		}

		/// <summary>直前のコンパイルで生じたエラーメッセージを返す</summary>
		private string ErrorMessage()
		{
			if ( this._results == null )
			{
				return string.Empty;
			}

			var message = new StringBuilder();
			message.Append( "スクリプトコンパイルエラー" + Environment.NewLine );
			for ( var i = 0; i < this._results.Errors.Count; i++ )
			{
				message.Append( "行:" + this._results.Errors[i].Line );
				message.Append( " " + this._results.Errors[i].ErrorText + Environment.NewLine );
			}
			return message.ToString();
		}

		/// <summary>クラス取得</summary>
		private Type GetClassReference( String classname )
		{
			Type classType = null;
			classType = this._results.CompiledAssembly.GetType( classname );
			if ( classType == null )
			{
				throw new ApplicationException( this._filename + Environment.NewLine + classname + " クラスがありません。" );
			}

			return classType;
		}

		/// <summary>メソッドを呼び出す</summary>
		/// <param name="classname">クラス名</param>
		/// <param name="methodname">メソッド名</param>
		/// <param name="parameters">メソッドに渡す引数</param>
		public void InvokeMethod( string classname, string methodname, params object[] parameters )
		{
			// 渡された引数の型チェック
			Type[] argumentTypes = new Type[parameters.Length];
			for ( int i = 0; i < parameters.Length; i++ )
			{
				argumentTypes[i] = parameters[i].GetType();
			}
			// クラス取得
			Type type = GetClassReference( classname );

			// メソッド取得
			var mi= type.GetMethod(
				methodname,									// メソッド名
				BindingFlags.Public | BindingFlags.Static,	// フラグ
				null,
				argumentTypes,								// 引数の型
				null
				);

			if ( mi == null )
			{
				string str = string.Empty;
				foreach ( var d in argumentTypes )
				{
					str += d + ", ";
				}
				if ( 2 <= str.Length )
				{
					str = str.TrimEnd( new[] { ',', ' ' } );
				}
				throw new ApplicationException( this._filename + Environment.NewLine + methodname + "( " + str + " )" + Environment.NewLine + "メソッドがありません。" );
			}

			try
			{
				// 呼び出し
				mi.Invoke( null, parameters );
			}
			catch ( System.Reflection.TargetInvocationException ex )
			{
				string message = this._filename + Environment.NewLine + "スクリプト内で例外が発生しました。" + Environment.NewLine + "エラー内容:" + Environment.NewLine;
				message += ex.InnerException.Message + Environment.NewLine;
				//message += ex.InnerException.StackTrace + Environment.NewLine;
				if ( 0 < ex.InnerException.Data.Keys.Count )
				{
					message += "追加データ：" + Environment.NewLine;
					System.Collections.IEnumerator i = ex.InnerException.Data.Keys.GetEnumerator();
					while ( i.MoveNext() )
					{
						message += i.Current.ToString() + " : " + ex.InnerException.Data[i.Current] + Environment.NewLine;
					}
				}
				throw new ApplicationException( message );
			}
		}

		/// <summary>メソッドを呼び出す</summary>
		/// <param name="parameters">メソッドに渡す引数</param>
		public void InvokeMethod( params object[] parameters )
		{
			this.InvokeMethod( _Classname, _Methodname, parameters );
		}
	}
}
