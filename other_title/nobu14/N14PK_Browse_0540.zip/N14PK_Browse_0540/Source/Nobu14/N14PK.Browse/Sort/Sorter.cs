﻿// Sorter.cs

using System;
using N14PKBrowse.Data;

namespace N14PKBrowse.Sort
{
	/// <summary>比較モード</summary>
	public enum CompMode
	{
		UNKNOWN,	// 不明(未設定)
		NUM,		// 数値
		NUM0,		// 数値(0を常に後方)
		NUM1,		// 数値(-1を常に後方)
		STR,		// 文字列
		PLIST,		// ポインタリスト
		FLAG,		// フラグ
		HEX			// 16進文字列
	};

	/// <summary>ソートモード</summary>
	public enum SortMode
	{
		NORMAL,		// 通常
		FIRST		// 初回(履歴があれば参照して複数キーでソート)
	}

	/// <summary>マージソート</summary>
	class Sorter
	{
		// 状況によっては ListCollectionView.CustomSort より遅くなる
		// コールバックを使えない場合は、比較対象のプロパティ取得にコストがかかるため遅くなる

		/// <summary>マージソートから挿入ソートに切り替える閾値</summary>
		private const int Threshold = 4;

		/// <summary>ソート情報</summary>
		private static SortHistory _history;

		/// <summary>ソートモード</summary>
		private static SortMode _sortMode;

		private static bool _isAsc;
		/// <summary>ソート</summary>
		/// <typeparam name="T">対象の配列の型</typeparam>
		/// <param name="clone">対象の配列</param>
		/// <param name="history">ソート情報</param>
		/// <param name="sortMode">ソートモード</param>
		public static void Sort<T>( T[] array, SortHistory history, SortMode sortMode )
			where T : class
		{
			// 比較時にプロパティの値を取得して使う場合、自身の配列を参照するプロパティがある
			// マージ中に作業領域に退避したデータが元の配列に存在しない場合があり、そのタイミングでそのデータを参照すると値を取得できない
			// なので配列のクローンに対してソートし、終了後に格要素をコピーして戻す
			var clone = (T[])array.Clone();
			
			_history = history;
			_sortMode = sortMode;
			_isAsc = history[0].IsAsc;

			var work = new T[clone.Length / 2];
			MergeSort( clone, 0, clone.Length, work );

			for ( var i = 0; i < clone.Length; i++ )
			{
				array[i] = clone[i];
			}
		}

		/// <summary>範囲指定挿入ソート</summary>
		/// <param name="clone">対象のリスト</param>
		/// <param name="begin">ソート対象の先頭インデクス</param>
		/// <param name="end">ソート対象の末尾インデクス</param>
		private static void InsertSort<T>( T[] clone, int begin, int end )
		{
			for ( var i = begin + 1; i <= end; i++ )
			{
				for ( var j = i; begin < j && Compare( clone[j - 1], clone[j] ) > 0; --j )
				{
					// スワップ
					var temp = clone[j];
					clone[j] = clone[j - 1];
					clone[j - 1] = temp;
				}
			}
		}

		/// <summary>範囲指定マージソート</summary>
		/// <param name="clone">対象のリスト</param>
		/// <param name="begin">ソート対象部分の先頭インデクス</param>
		/// <param name="end">ソート対象部分の末尾インデクス +1</param>
		/// <param name="work">作業領域</param>
		private static void MergeSort<T>( T[] clone, int begin, int end, T[] work )
		{
			if ( end - begin < Threshold )
			{
				InsertSort( clone, begin, end - 1 );
				return;
			}

			int mid = ( begin + end ) / 2;

			MergeSort( clone, begin, mid, work );
			MergeSort( clone, mid, end, work );
			Merge( clone, begin, mid, end, work );
		}

		/// <summary>マージ</summary>
		/// <param name="clone">マージ対象のリスト</param>
		/// <param name="begin">clone の先頭</param>
		/// <param name="mid">clone の分割点</param>
		/// <param name="end">clone の末尾+1</param>
		/// <param name="work">作業領域</param>
		private static void Merge<T>( T[] clone, int begin, int mid, int end, T[] work )
		{
			int i, j, k;

			for ( i = begin, j = 0; i != mid; ++i, ++j )
			{
				work[j] = clone[i];
			}

			mid -= begin;

			for ( j = 0, k = begin; i != end && j != mid; ++k )
			{
				if ( Compare( clone[i], work[j] ) < 0 )		// break i == 0x21 && j == 0 && k == 3
				{
					clone[k] = clone[i];
					++i;
				}
				else
				{
					clone[k] = work[j];
					++j;
				}
			}

			for ( ; i < end; ++i, ++k )
			{
				clone[k] = clone[i];
			}

			for ( ; j < mid; ++j, ++k )
			{
				clone[k] = work[j];
			}
		}

		/// <summary>データ比較</summary>
		private static int Compare<T>( T x, T y )
		{
			int ret = 0;

			foreach ( var d in _history )
			{
				if ( d.Callback != null )
				{
					// コールバック使用
					ret = d.Callback( x, y, d.IsAsc );
				}
				else
				{
					// 汎用(プロパティ名取得のコストが大きい。キャッシュしてもたいして速度は変わらない)
					ret = GenericCompare( GetPropertyValue( d.PropertyName, x ) , GetPropertyValue( d.PropertyName, y ) , d.Mode, d.IsAsc );
				}

				// 初回は履歴があれば次のキーで比較
				if ( !( _sortMode == SortMode.FIRST && ret == 0 ) )
				{
					// 同値でないならこれ以上比較する必要はない
					if ( !d.IsAsc )
					{
						ret = -ret;
					}
					break;
				}
			}
			return ret;
		}

		/// <summary>プロパティ値を取得</summary>
		private static object GetPropertyValue<T>( string propertyName, T data )
		{
			System.Reflection.PropertyInfo pi = data.GetType().GetProperty( propertyName );
			return ( pi != null ) ? pi.GetValue( data, null ) : null;
		}

		/// <summary>データ比較(汎用)</summary>
		private static int GenericCompare( object x, object y, CompMode mode, bool isAsc )
		{
			var ret = 0;

			switch ( mode )
			{
				case CompMode.NUM:
					ret = Convert.ToInt32( x ) - Convert.ToInt32( y );
					break;

				case CompMode.NUM0:
					// 0 は常に後方へ
					ret = ( Convert.ToInt32( x ) - Convert.ToInt32( y ) == 0 ) ? 0
						: ( Convert.ToInt32( x ) == 0 ) ? isAsc ? 1 : -1
						: ( Convert.ToInt32( y ) == 0 ) ? isAsc ? -1 : 1
						: Convert.ToInt32( x ) - Convert.ToInt32( y );
					break;

				case CompMode.NUM1:
					// -1 は常に後方へ
					ret = ( Convert.ToInt32( x ) - Convert.ToInt32( y ) == 0 ) ? 0
						: ( Convert.ToInt32( x ) == -1 ) ? isAsc ? 1 : -1
						: ( Convert.ToInt32( y ) == -1 ) ? isAsc ? -1 : 1
						: Convert.ToInt32( x ) - Convert.ToInt32( y );
					break;

				case CompMode.STR:
					// 空白は常に後方へ
					ret = ( (string)x ).Equals( (string)y ) ? 0
						: ( (string)x == string.Empty ) ? isAsc ? 1 : -1
						: ( (string)y == string.Empty ) ? isAsc ? -1 : 1
						: ( (string)x ).CompareTo( (string)y );
					break;

				case CompMode.PLIST:
					// 空白は常に後方へ
					ret = ( x.ToString() ).Equals( y.ToString() ) ? 0
						: ( x.ToString() == string.Empty ) ? isAsc ? 1 : -1
						: ( y.ToString() == string.Empty ) ? isAsc ? -1 : 1
						: ( x.ToString() ).CompareTo( y.ToString() );
					break;

				case CompMode.FLAG:
					ret = ( (bool)x ? 1 : 0 ) - ( (bool)y ? 1 : 0 );
					break;

				case CompMode.HEX:
					ret = Int32.Parse( (string)x, System.Globalization.NumberStyles.HexNumber ) - Int32.Parse( (string)y, System.Globalization.NumberStyles.HexNumber );
					break;

				default:
					break;
			}

			return ret;
		}
	}
}
