﻿// YousyoMenu.cs

using System;
using System.Windows;
using System.Windows.Controls;
using N14PKBrowse.Enums;
using N14PKBrowse.Extension;
using N14PKBrowse.Data;

namespace N14PKBrowse.Menu
{
	/// <summary>要所タブ 右クリックメニュー</summary>
	public class YousyoMenu : DataMenu
	{
		
		/// <summary>コンストラクタ</summary>
		public YousyoMenu( N14PKB n14pkb, ScriptSetting.Function[] functions )
			: base ( n14pkb, TabKind.要所, functions )
		{
			this.SetMenu();
			this.SetExtensionsMenu();
		}

		/// <summary>タブ固有のコンテキストメニューをセット</summary>
		private void SetMenu()
		{
			this.CMenu.Items.Add( new Separator() );

			MenuItem mi;
			mi = new MenuItem() { Header = "陣設営", };
			mi.ToolTip = "選択中勢力の陣を設営する";
			mi.Click += new RoutedEventHandler( JinSetsuei );
			this.CMenu.Items.Add( mi );

			mi = new MenuItem() { Header = "陣消去", };
			mi.ToolTip = "陣を消去する";
			mi.Click += new RoutedEventHandler( JinSyoukyo );
			this.CMenu.Items.Add( mi );
		}

		// 陣設営
		private void JinSetsuei( object sender, RoutedEventArgs e )
		{
			var grid = this._n14pkb.MainWindowInterface.DataGrids[this._n14pkb.MainWindowInterface.SelectedTabIndex];
			if ( grid.SelectedItems.Count == 0 ) { return; }

			foreach ( var d in grid.SelectedItems )
			{
				var yousyo = d as Yousyo;
				yousyo.JinLevel = 2;
				yousyo.PtrJinSetsueiSeiryoku = this._n14pkb.View.SelectedSeiryokuAddress;
			}
			// コミット
			this._n14pkb.Commit();
			// リフレッシュ
			this._n14pkb.View.Refresh( this._n14pkb.MainWindowInterface.SelectedTabIndex );
		}

		// 陣消去
		private void JinSyoukyo( object sender, RoutedEventArgs e )
		{
			var grid = this._n14pkb.MainWindowInterface.DataGrids[this._n14pkb.MainWindowInterface.SelectedTabIndex];
			if ( grid.SelectedItems.Count == 0 ) { return; }

			foreach ( var d in grid.SelectedItems )
			{
				var yousyo = d as Yousyo;
				yousyo.JinLevel = 0;
				yousyo.PtrJinSetsueiSeiryoku = 0;
			}
			// コミット
			this._n14pkb.Commit();
			// リフレッシュ
			this._n14pkb.View.Refresh( this._n14pkb.MainWindowInterface.SelectedTabIndex );
		}
	}
}
