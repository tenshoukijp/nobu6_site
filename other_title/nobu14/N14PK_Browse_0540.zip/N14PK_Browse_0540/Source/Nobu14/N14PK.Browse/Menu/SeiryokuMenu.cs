﻿// SeiryokuMenu.cs

using System;
using System.Windows;
using System.Windows.Controls;
using N14PKBrowse.Enums;
using N14PKBrowse.Extension;

namespace N14PKBrowse.Menu
{
	/// <summary>勢力タブ 右クリックメニュー</summary>
	public class SeiryokuMenu : DataMenu
	{
		
		/// <summary>コンストラクタ</summary>
		public SeiryokuMenu( N14PKB n14pkb, ScriptSetting.Function[] functions )
			: base ( n14pkb, TabKind.勢力, functions )
		{
			this.SetMenu();
			this.SetExtensionsMenu();
		}

		/// <summary>タブ固有のコンテキストメニューをセット</summary>
		private void SetMenu()
		{
			this.CMenu.Items.Add( new Separator() );

			MenuItem mi;
			mi = new MenuItem() { Header = "伝授編集", };
			mi.Click += new RoutedEventHandler( DenjuHensyuu );
			this.CMenu.Items.Add( mi );
		}

		// 伝授編集ウィンドウ表示
		void DenjuHensyuu( object sender, RoutedEventArgs e )
		{
			if ( !Funcs.CheckDate( this._n14pkb.N14pk ) )
			{
				return;
			}
			var grid = this._n14pkb.MainWindowInterface.DataGrids[this._n14pkb.MainWindowInterface.SelectedTabIndex];
			if ( grid.SelectedItems.Count == 0 ) { return; }

			var w = new WindowDenju();
			w.N14pkb = this._n14pkb;
			w.Seiryoku = grid.SelectedItem as Data.Seiryoku;
			w.Owner = this._n14pkb.MainWindowInterface as Window;
			w.ShowDialog();
		}
	}
}
