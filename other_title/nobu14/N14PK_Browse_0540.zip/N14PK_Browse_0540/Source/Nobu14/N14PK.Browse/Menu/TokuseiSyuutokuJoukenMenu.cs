﻿// TokuseiSyuutokuJoukenMenu.cs

using System;
using N14PKBrowse.Enums;
using N14PKBrowse.Extension;

namespace N14PKBrowse.Menu
{
	/// <summary>特性習得条件タブ 右クリックメニュー</summary>
	public class TokuseiSyuutokuJoukenMenu : DataMenu
	{
		
		/// <summary>コンストラクタ</summary>
		public TokuseiSyuutokuJoukenMenu( N14PKB n14pkb, ScriptSetting.Function[] functions )
			: base ( n14pkb, TabKind.習得条件, functions )
		{
			//this.SetMenu();
			this.SetExtensionsMenu();
		}

		/// <summary>タブ固有のコンテキストメニューをセット</summary>
		private void SetMenu()
		{
			throw new NotImplementedException();
		}
	}
}
