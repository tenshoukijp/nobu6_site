﻿// BusyouMenu.cs

using System;
using System.Windows;
using System.Windows.Controls;

using N14PKBrowse.Enums;
using N14PKBrowse.Extension;

namespace N14PKBrowse.Menu
{
	/// <summary>武将タブ 右クリックメニュー</summary>
	public class BusyouMenu : DataMenu
	{
		
		/// <summary>コンストラクタ</summary>
		public BusyouMenu( N14PKB n14pkb, ScriptSetting.Function[] functions )
			: base ( n14pkb, TabKind.武将, functions )
		{
			this.SetMenu();
			this.SetExtensionsMenu();
		}

		/// <summary>タブ固有のコンテキストメニューをセット</summary>
		private void SetMenu()
		{
			this.CMenu.Items.Add( new Separator() );

			MenuItem mi;
			mi = new MenuItem() { Header = "特性編集", };
			mi.Click += new RoutedEventHandler( TokuseiHensyuu );
			this.CMenu.Items.Add( mi );

			mi = new MenuItem() { Header = "忠誠編集", };
			mi.Click += new RoutedEventHandler( ChuuseiHensyuu );
			this.CMenu.Items.Add( mi );

			mi = new MenuItem() { Header = "当主変更", };
			mi.Click += new RoutedEventHandler( TousyuHenkou );
			this.CMenu.Items.Add( mi );
		}

		// 特性編集ウィンドウ表示
		private void TokuseiHensyuu( object sender, RoutedEventArgs e )
		{
			if ( !Funcs.CheckDate( this._n14pkb.N14pk ) )
			{
				return;
			}
			var grid = this._n14pkb.MainWindowInterface.DataGrids[this._n14pkb.MainWindowInterface.SelectedTabIndex];
			if ( grid.SelectedItems.Count == 0 ) { return; }

			var w = new WindowTokusei();
			w.N14pkb = this._n14pkb;
			w.Busyou = grid.SelectedItem as Data.Busyou;
			w.Owner = this._n14pkb.MainWindowInterface as Window;
			w.ShowDialog();
		}

		// 忠誠編集ウィンドウ表示
		private void ChuuseiHensyuu( object sender, RoutedEventArgs e )
		{
			if ( !Funcs.CheckDate( this._n14pkb.N14pk ) )
			{
				return;
			}
			var grid = this._n14pkb.MainWindowInterface.DataGrids[this._n14pkb.MainWindowInterface.SelectedTabIndex];
			if ( grid.SelectedItems.Count == 0 ) { return; }

			var w = new WindowChuuseiHosei();
			w.N14pkb = this._n14pkb;
			w.Busyou = grid.SelectedItem as Data.Busyou;
			w.Owner = this._n14pkb.MainWindowInterface as Window;
			w.ShowDialog();
		}

		// 当主変更
		private void TousyuHenkou( object sender, RoutedEventArgs e )
		{
			if ( !Funcs.CheckDate( this._n14pkb.N14pk ) )
			{
				return;
			}
			var grid = this._n14pkb.MainWindowInterface.DataGrids[this._n14pkb.MainWindowInterface.SelectedTabIndex];
			if ( grid.SelectedItems.Count == 0 ) { return; }

			var busyou = grid.SelectedItem as Data.Busyou;
			busyou.IsTousyu = true;

			// コミット
			this._n14pkb.Commit();
			// リフレッシュ
			this._n14pkb.View.Refresh( this._n14pkb.MainWindowInterface.SelectedTabIndex );
		}

		/// <summary>メニューオープン</summary>
		public override void ContextMenuOpening()
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "busyou ContextMenuOpening()" );
#endif
			var grid = this._n14pkb.MainWindowInterface.DataGrids[this._n14pkb.MainWindowInterface.SelectedTabIndex];
			var busyou = grid.SelectedItem as Data.Busyou;
			if ( busyou == null ) { return; }
			var isEnabled = false;

			if ( !busyou.IsTousyu
				&& ( busyou.Seiryoku != null )
				&& ( ( busyou.MibunID == (int)MibunKind.通常 ) || ( busyou.MibunID == (int)MibunKind.成人前 ) || ( busyou.MibunID == (int)MibunKind.姫 ) )
				)
			{
				isEnabled = true;
			}

			foreach ( var d in this.CMenu.Items )
			{
				var mi = d as MenuItem;
				if ( mi != null )
				{
					if ( (String)mi.Header == "当主変更" )
					{
						mi.IsEnabled = isEnabled;
						break;
					}
				}
			}
		}
	}
}
