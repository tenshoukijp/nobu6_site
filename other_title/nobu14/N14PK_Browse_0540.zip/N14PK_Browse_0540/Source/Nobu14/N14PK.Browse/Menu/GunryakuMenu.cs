﻿// GunryakuMenu.cs

using System;
using N14PKBrowse.Enums;
using N14PKBrowse.Extension;

namespace N14PKBrowse.Menu
{
	/// <summary>軍略タブ 右クリックメニュー</summary>
	public class GunryakuMenu : DataMenu
	{
		
		/// <summary>コンストラクタ</summary>
		public GunryakuMenu( N14PKB n14pkb, ScriptSetting.Function[] functions )
			: base ( n14pkb, TabKind.軍略, functions )
		{
			//this.SetMenu();
			this.SetExtensionsMenu();
		}

		/// <summary>タブ固有のコンテキストメニューをセット</summary>
		private void SetMenu()
		{
			throw new NotImplementedException();
		}
	}
}
