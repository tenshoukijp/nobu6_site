﻿// KuniMenu.cs

using System;
using N14PKBrowse.Enums;
using N14PKBrowse.Extension;

namespace N14PKBrowse.Menu
{
	/// <summary>国タブ 右クリックメニュー</summary>
	public class KuniMenu : DataMenu
	{
		
		/// <summary>コンストラクタ</summary>
		public KuniMenu( N14PKB n14pkb, ScriptSetting.Function[] functions )
			: base ( n14pkb, TabKind.国, functions )
		{
			//this.SetMenu();
			this.SetExtensionsMenu();
		}

		/// <summary>タブ固有のコンテキストメニューをセット</summary>
		private void SetMenu()
		{
			throw new NotImplementedException();
		}
	}
}
