﻿// ParamMenu.cs

using System;
using N14PKBrowse.Enums;
using N14PKBrowse.Extension;

namespace N14PKBrowse.Menu
{
	/// <summary>Paramタブ 右クリックメニュー</summary>
	public class ParamMenu : DataMenu
	{
		
		/// <summary>コンストラクタ</summary>
		public ParamMenu( N14PKB n14pkb, ScriptSetting.Function[] functions )
			: base ( n14pkb, TabKind.Param, functions )
		{
			//this.SetMenu();
			this.SetExtensionsMenu();
		}

		/// <summary>タブ固有のコンテキストメニューをセット</summary>
		private void SetMenu()
		{
			throw new NotImplementedException();
		}
	}
}
