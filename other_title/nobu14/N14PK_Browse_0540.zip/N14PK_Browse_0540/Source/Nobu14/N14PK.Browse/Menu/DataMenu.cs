﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;

using N14PKBrowse.Enums;
using N14PKBrowse.Extension;
//using N14PKBrowse.List;
using N14PKBrowse.Data;

namespace N14PKBrowse.Menu
{
	/// <summary>右クリックコンテキストメニュー管理用基底クラス</summary>
	public class DataMenu
	{
		/// <summary>ツール管理</summary>
		protected N14PKB _n14pkb;

		/// <summary>タブ名</summary>
		protected TabKind _tabname;

		/// <summary>データセーブ＆ロード</summary>
		protected SaveAndLoad _saveAndLoad;

		/// <summary>拡張機能設定リスト</summary>
		protected  ScriptSetting.Function[] _functions;

		/// <summary>コンテキストメニュー</summary>
		protected ContextMenu _cMenu;
		/// <summary>コンテキストメニュー</summary>
		public ContextMenu CMenu
		{
			get
			{
				if ( this._cMenu == null )
				{
					this._cMenu = new ContextMenu();
				}
				return this._cMenu;
			}
		}

		/// <summary>コンストラクタ</summary>
		public DataMenu( N14PKB n14pkb, TabKind tabname, ScriptSetting.Function[] functions )
		{
			this._n14pkb = n14pkb;
			this._functions = functions;
			this._tabname = tabname;
			this.SetDefaultMenu();
		}

		private void SetDefaultMenu()
		{
			MenuItem mi;
			mi = new MenuItem() { Header = "クリップボードにコピー(Ctrl+C)", };
			mi.Click += new RoutedEventHandler( CopyToClipboard );
			this.CMenu.Items.Add( mi );
			this.SetSaveAndLoadMenuItem();
		}

		/// <summary>データセーブ＆ロードメニューをセットする</summary>
		public void SetSaveAndLoadMenuItem()
		{
			if ( -1 == Array.FindIndex( SaveAndLoad.ValidTabNames, d => d == this._tabname ) )
			{
				return;
			}

			// 既存の保存＆読み込みメニューがあれば削除
			this._saveAndLoad = new SaveAndLoad( this._n14pkb, this._tabname );
			int index = 0;
			for ( ; index < this.CMenu.Items.Count; index++ )
			{
				if ( (string)( this.CMenu.Items[index] as MenuItem ).Header == "データ保存" )
				{
					this.CMenu.Items.RemoveAt( index );	// System.Windows.ResourceDictionary Warning: 9 : Resource not found; ResourceKey='ŧ' が発生する キー値が謎
					this.CMenu.Items.RemoveAt( index );	// System.Windows.ResourceDictionary Warning: 9 : Resource not found; ResourceKey='ŧ' が発生する
					break;
				}
			}

			// データ読み込みメニュー作成
			var menuLoad = new MenuItem() { Header = "データ読込" };
			var menuLoadSub = new MenuItem[SaveAndLoad.Count];
			for ( var i = 0; i < SaveAndLoad.Count; i++ )
			{
				menuLoadSub[i] = new MenuItem()
				{
					Header = this._saveAndLoad.DataFilesInfo[i].Headertext,
					IsEnabled = this._saveAndLoad.DataFilesInfo[i].Exists,
					Tag = i
				};
				menuLoadSub[i].Click += new RoutedEventHandler( Load_Click );	// クリック時のイベントハンドラ
				menuLoad.Items.Add( menuLoadSub[i] );
			}
			this.CMenu.Items.Insert( index, menuLoad );

			// データ保存メニュー作成
			var menuSave = new MenuItem() { Header = "データ保存" };
			var menuSaveSub = new MenuItem[SaveAndLoad.Count];
			for ( var i = 0; i < SaveAndLoad.Count; i++ )
			{
				menuSaveSub[i] = new MenuItem()
				{
					Header = this._saveAndLoad.DataFilesInfo[i].Headertext,
					ToolTip = "選択中のデータを保存します",
					Tag = i
				};
				menuSaveSub[i].Click += new RoutedEventHandler( Save_Click );	// クリック時のイベントハンドラ
				menuSave.Items.Add( menuSaveSub[i] );
			}
			this.CMenu.Items.Insert( index, menuSave );
		}

		/// <summary>データ保存クリック</summary>
		private void Save_Click( object sender, RoutedEventArgs e )
		{
			var tabIndex = this._n14pkb.MainWindowInterface.SelectedTabIndex;
			var grid = this._n14pkb.MainWindowInterface.DataGrids[tabIndex];
			var dataIndex = (int)( sender as MenuItem ).Tag;
			if ( grid.SelectedItems.Count == 0 ) { return; }

			// 選択中のデータIDを配列化
			var ids = new List<int>();
			foreach ( var d in grid.SelectedItems )
			{
				ids.Add( ( d as IBrowseData ).ID );
			}
			this._saveAndLoad.Save( ids.ToArray(), (int)( sender as MenuItem ).Tag );
			this.SetSaveAndLoadMenuItem();
		}

		/// <summary>データ読み込みクリック</summary>
		private void Load_Click( object sender, RoutedEventArgs e )
		{
			this._saveAndLoad.Load( (int)( ( sender as MenuItem ).Tag ) );

			foreach ( var f in this._n14pkb.View.Flags )
			{
				f.NeedsRefresh = true;
			}
			this._n14pkb.View.Refresh( (int)this._tabname );
		}

		/// <summary>拡張機能メニューをセットする</summary>
		protected void SetExtensionsMenu()
		{
			if ( this._functions == null || this._functions.Length == 0 )
			{
				return;
			}

			this._cMenu.Items.Add( new Separator() );

			var menuItemList = new List<MenuItem>();
			var functionList = this._functions.ToList();

			while ( 0 < functionList.Count )
			{
				menuItemList.Add( MakeExtensionsMenuItem( this.FindRootFunction( functionList[0], functionList ), functionList ) );
				functionList.Remove( functionList[0] );
			}
			foreach ( var d in menuItemList )
			{
				this._cMenu.Items.Add( d );
			}
		}

		/// <summary>ルートとなる拡張機能設定を検索する</summary>
		/// <param name="function">拡張機能設定</param>
		/// <param name="list">拡張機能設定リスト</param>
		/// <returns></returns>
		private ScriptSetting.Function FindRootFunction( ScriptSetting.Function function, List<ScriptSetting.Function> list )
		{
			// 親が設定されいる場合、親項目で再帰処理
			if ( !string.IsNullOrEmpty( function.ParentTitle ) )
			{
				var f = list.Find( d => d.Title == function.ParentTitle );
				function = this.FindRootFunction( f, list );
			}
			return function;
		}

		/// <summary>拡張機能メニューアイテムを作成する</summary>
		/// <param name="function">拡張機能設定</param>
		/// <param name="list">拡張機能設定リスト</param>
		/// <returns>メニューアイテム</returns>
		private MenuItem MakeExtensionsMenuItem( ScriptSetting.Function function, List<ScriptSetting.Function> list )
		{
			var mi = new MenuItem()
			{
				Header = function.Title,
				ToolTip = ( !string.IsNullOrEmpty( function.Tooltip ) ? function.Tooltip : null ),
				Tag = function.Filename
			};

			if ( function.Kind == ScriptSetting.FunctionKind.BUTTON )
			{
				// クリック時のイベントハンドラ
				mi.Click += new System.Windows.RoutedEventHandler( ExecuteFunction );
			}

			// 子項目が存在する場合、子項目で再帰処理
			var result = list.FindAll( f => f.ParentTitle == function.Title );
			if ( 0 < result.Count )
			{
				foreach ( var f in result )
				{
					mi.Items.Add( MakeExtensionsMenuItem( f, list ) );
					list.Remove( f );
				}
			}
			return mi;
		}

		/// <summary>拡張機能を実行する</summary>
		protected void ExecuteFunction( object sender, System.Windows.RoutedEventArgs e )
		{
			if ( !Funcs.CheckDate( this._n14pkb.N14pk ) )
			{
				return;
			}

			var tabIndex = this._n14pkb.MainWindowInterface.SelectedTabIndex;
			var grid = this._n14pkb.MainWindowInterface.DataGrids[tabIndex];
			if ( grid.SelectedItems.Count == 0 ) { return; }

			var filename = (string)( sender as MenuItem ).Tag;
			try
			{
				// スクリプトファイルをコンパイル
				var script = CompileScript( filename );

				// 選択中のデータ
				foreach ( var d in grid.SelectedItems )
				{
					N14PKLibrary.Data.IData data = null;

					#region 選択中タブによる分岐処理
					switch ( (TabKind)tabIndex )
					{
						case TabKind.武将:
							data = ( d as Busyou ).Data;
							break;
						case TabKind.城:
							data = ( d as Shiro ).Data;
							break;
						case TabKind.区画:
							data = ( d as Kukaku ).Data;
							break;
						case TabKind.勢力:
							data = ( d as Seiryoku ).Data;
							break;
						case TabKind.軍団:
							data = ( d as Gundan ).Data;
							break;
						case TabKind.部隊:
							data = ( d as Butai ).Data;
							break;
						case TabKind.建物:
							data = ( d as Tatemono ).Data;
							break;
						case TabKind.家宝:
							data = ( d as Kahou ).Data;
							break;
						case TabKind.国人衆:
							data = ( d as Kokujin ).Data;
							break;
						case TabKind.要所:
							data = ( d as Yousyo ).Data;
							break;
						case TabKind.街道:
							data = ( d as Kaidou ).Data;
							break;
						case TabKind.施設:
							data = ( d as Shisetsu ).Data;
							break;
						case TabKind.政策:
							data = ( d as Seisaku ).Data;
							break;
						case TabKind.戦法:
							data = ( d as Senpou ).Data;
							break;
						case TabKind.特性:
							data = ( d as Tokusei ).Data;
							break;
						case TabKind.習得条件:
							data = ( d as TokuseiSyuutokuJouken ).Data;
							break;
						case TabKind.成長型:
							data = ( d as Seichougata ).Data;
							break;
						case TabKind.地方:
							data = ( d as Chihou ).Data;
							break;
						case TabKind.国:
							data = ( d as Kuni ).Data;
							break;
						case TabKind.効果:
							data = ( d as Kouka ).Data;
							break;
						case TabKind.方針:
							data = ( d as Houshin ).Data;
							break;
						case TabKind.軍略:
							data = ( d as Gunryaku ).Data;
							break;
						case TabKind.城郭:
							data = ( d as Joukaku ).Data;
							break;
						case TabKind.城名:
							data = ( d as ShiroName ).Data;
							break;
						case TabKind.Param:
							data = ( d as Param ).Data;
							break;
						default:
							break;
					}
					#endregion

					// スクリプト実行
					script.InvokeMethod( this._n14pkb.N14pk, data.ID, data );
				}

//				// スクリプト内でどのデータが変更されたのかわからないので全テーブルをコミットする
//				foreach ( var table in this._n14pkb.N14pk.Datatables )
//				{
//					if ( table != null )
//					{
//#if DEBUG
//						System.Diagnostics.Debug.WriteLine( "Commit" );
//#endif
//						table.Commit();
//					}
//				}
//				// Paramテーブルは独立しているので別個処理
//				this._n14pkb.N14pk.Paramtable.Commit();

				// スクリプト内でどのデータが変更されたのかわからないので全テーブルをチェックして必要なテーブルだけコミットする
				foreach ( var table in this._n14pkb.N14pk.Datatables )
				{
					if ( ( table != null ) && ( table.CommitIDList.Count != 0 ) )
					{
#if DEBUG
						System.Diagnostics.Debug.WriteLine( "Commit" );
#endif
						table.Commit( table.CommitIDList.ToArray() );
					}
				}
				// Paramテーブルは独立しているので別個処理
				if ( this._n14pkb.N14pk.Paramtable.CommitIDList.Count != 0 )
				{
					this._n14pkb.N14pk.Paramtable.Commit( this._n14pkb.N14pk.Paramtable.CommitIDList.ToArray() );
				}

				// データ再取得する
				this._n14pkb.MainWindowInterface.GetData();

			}
			catch ( Exception ex )
			{
				System.Windows.MessageBox.Show( ex.Message, "拡張機能エラー", MessageBoxButton.OK, MessageBoxImage.Error );
			}
		}

		/// <summary>拡張機能スクリプトファイルをコンパイルする</summary>
		/// <typeparam name="T">型パラメータ</typeparam>
		/// <param name="filename">スクリプトファイル名</param>
		private Extension.Script CompileScript( string filename )
		{
			var fullpath = Environment.CurrentDirectory + @"\" + Extension.ScriptSetting.Directoryname + @"\" + filename + ".cs";
			var script = new Extension.Script();
			script.CompileFile( fullpath );
			return script;
		}

		/// <summary>選択中のデータをクリップボードにコピーする(TAB区切り)</summary>
		void CopyToClipboard( object sender, RoutedEventArgs e )
		{
			// Form.DataGridView の GetClipboardContent() に相当するメソッドがない？
			// なのでリフレクションを使ってゴリゴリとやる
			// わざわざメニューからやらなくても Ctrl + C すれば勝手にやってくれる

			var str = new StringBuilder( 0x10000 );
			var tabIndex = this._n14pkb.MainWindowInterface.SelectedTabIndex;
			var grid = this._n14pkb.MainWindowInterface.DataGrids[tabIndex];
			if ( grid.SelectedItems.Count == 0 ) { return; }

			// 表示設定されている列を取得して表示順にソート
			var columns = new List<DataGridColumn>();
			foreach ( var c in grid.Columns )
			{
				if ( c.Visibility == System.Windows.Visibility.Visible )
				{
					columns.Add( c );
				}
			}
			columns.Sort( ( x, y ) => x.DisplayIndex - y.DisplayIndex );

			// ヘッダ名を含める
			foreach ( var c in columns )
			{
				str.Append( (string)c.Header + "\t" );
			}
			str.Remove( str.Length - 1, 1 );
			str.Append( Environment.NewLine );

			// 選択中のデータを取得して各値を取得する
			foreach ( var d in grid.SelectedItems )
			{
				foreach ( var c in columns )
				{
					// プロパティ名は SortMemberPath から取得
					System.Reflection.PropertyInfo pi = d.GetType().GetProperty( c.SortMemberPath );
					var value = ( pi != null ) ? pi.GetValue( d, null ) : null;
					str.Append( ( value ?? string.Empty ) + "\t" );
				}
				str.Remove( str.Length - 1, 1 );
				str.Append( Environment.NewLine );
			}
			Clipboard.SetText( str.ToString() );
		}

		/// <summary>メニューオープン</summary>
		public virtual void ContextMenuOpening()
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "base ContextMenuOpening()" );
#endif
		}
	}
}
