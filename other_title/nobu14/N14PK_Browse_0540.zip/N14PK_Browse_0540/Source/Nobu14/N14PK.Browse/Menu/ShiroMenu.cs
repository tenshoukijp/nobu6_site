﻿// ShiroMenu.cs

using System;
using N14PKBrowse.Enums;
using N14PKBrowse.Extension;

namespace N14PKBrowse.Menu
{
	/// <summary>城タブ 右クリックメニュー</summary>
	public class ShiroMenu : DataMenu
	{
		
		/// <summary>コンストラクタ</summary>
		public ShiroMenu( N14PKB n14pkb, ScriptSetting.Function[] functions )
			: base ( n14pkb, TabKind.城, functions )
		{
			//this.SetMenu();
			this.SetExtensionsMenu();
		}

		/// <summary>タブ固有のコンテキストメニューをセット</summary>
		private void SetMenu()
		{
			throw new NotImplementedException();
		}
	}
}
