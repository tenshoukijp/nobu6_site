﻿// PointerlistType3.cs

using System;
using System.Collections.Generic;
using System.Text;

using N14PKLibrary;

namespace N14PKBrowse
{
	/// <summary>データ内で使用されている3ポインタタイプのリストデータ操作用クラス</summary>
	/// 3つあるポインタがそれぞれどういう意味を持つのかわからない。ポインタが管理用データを指していなければ、そのポインタが指すポインタデータは有効なデータとする。
	/// ポインタデータ間のつながりがわからないので、かぶらないポインタデータをリスト化して目標データアドレスリストを取得するのが精一杯。
	public class PointerlistType3
	{
		/// <summary>リストを構成するポインタデータ</summary>
		public class PointerData
		{
			private const uint _Size = 0x18;
			public byte[] Record { get; set; }
			public UInt32 Address { get; set; }

			public UInt32 PtrPointerData1 { get { return BitConverter.ToUInt32( this.Record, 0x00 ); } }	// ポインタデータへのポインタ1
			public UInt32 PtrPointerData2 { get { return BitConverter.ToUInt32( this.Record, 0x04 ); } }	// ポインタデータへのポインタ2
			public UInt32 PtrPointerData3 { get { return BitConverter.ToUInt32( this.Record, 0x08 ); } }	// ポインタデータへのポインタ3
			public UInt32 PtrTargetData { get { return BitConverter.ToUInt32( this.Record, 0x0C ); } }		// 目的のデータポインタ
			public Int32 Value1				// 数値データ1 Ex.)同盟データの場合残り月数が入っている
			{
				get { return BitConverter.ToInt32( this.Record, 0x10 ); }
				set
				{
					if ( value == this.Value1 ) { return; }
					BitConverter.GetBytes( value ).CopyTo( this.Record, 0x10 );
					//this.NeedsWrite = true;
				}
			}
			public Int32 Value2				// 数値データ2
			{
				get { return BitConverter.ToInt32( this.Record, 0x14 ); }
				set
				{
					if ( value == this.Value2 ) { return; }
					BitConverter.GetBytes( value ).CopyTo( this.Record, 0x14 );
					//this.NeedsWrite = true;
				}
			}

			// リスト解析用のデータ(Ptr1～3がそれぞれリストの何番目のポインタデータを指しているか)
			public int Ptr1Index { get; set; }
			public int Ptr2Index { get; set; }
			public int Ptr3Index { get; set; }

			// コンストラクタ
			public PointerData( N14PKB n14pkb, UInt32 address )
			{
				if ( address == 0 ) { return; }

				this.Address = address;
				this.Record = n14pkb.N14pk.ReadMemory( this.Address, PointerlistType3._Size );
			}
		}

		private const uint _Size = 0x18;	// ポインタデータサイズ
		private N14PKB _n14pkb;				// ツール管理
		private PointerData _indexItem;		// 管理用データ
		private DataKind _datakind;			// データの種類

		public int Count					// リスト内のポインタデータ数
		{
			get { return ( null != this.Items ) ? this.Items.Count : 0; }
		}
		public UInt32 Address { get; private set; }

		public UInt32 Ptr1 { get { return this._indexItem.PtrPointerData1; } }
		public UInt32 Ptr2 { get { return this._indexItem.PtrPointerData2; } }
		public UInt32 Ptr3 { get { return this._indexItem.PtrPointerData3; } }

		public List<PointerData> Items { get; set; }

		/// <summary>コンストラクタ</summary>
		/// コンストラクタ 生成時に失敗した場合に null を返したいので private にして外部からアクセス不可にする
		/// <param name="address">ポインタリストアドレス</param>
		/// <param name="datakind">データの種類</param>
		private PointerlistType3( N14PKB n14pkb, UInt32 address, DataKind datakind )
		{
			this._n14pkb = n14pkb;
			this._datakind = datakind;
			this.Address = address;
			this.SetItems();
		}

		/// <summary>3ポインタタイプのポインタリスト生成</summary>
		/// 外部からはこのメソッドを使ってインスタンス生成する
		/// <param name="address">ポインタリストアドレス</param>
		/// <param name="datakind">データの種類</param>
		public static PointerlistType3 Create( N14PKB n14pkb, UInt32 address, DataKind datakind = DataKind.UNKNOWN )
		{
			if ( address == 0 ) { return null; }
			return new PointerlistType3( n14pkb, address, datakind );
		}

		private void SetItems()
		{
			// 管理用データ読み込み
			this._indexItem = new PointerData( this._n14pkb, this.Address );
			if ( this.Address == this.Ptr1 && this.Address == this.Ptr2 && this.Address == this.Ptr3 )
			{
				// ポインタデータなし
				return;
			}

			this.Items = new List<PointerData>();

			if ( this.Address != this.Ptr1 )
			{
				this.Items.Add( new PointerData( this._n14pkb, this.Ptr1 ) );
			}
			else if ( this.Address != this.Ptr2 )
			{
				this.Items.Add( new PointerData( this._n14pkb, this.Ptr2 ) );
			}
			else if ( this.Address != this.Ptr3 )
			{
				this.Items.Add( new PointerData( this._n14pkb, this.Ptr3 ) );
			}

			for ( int i = 0; i < this.Items.Count; i++ )
			{
				if ( this.Address != Items[i].PtrPointerData1 )
				{
					// Ptr1が管理データを指していない(ポインタデータアドレス)
					var	index = this.Items.FindIndex( d => d.Address == this.Items[i].PtrPointerData1 );
					if ( index < 0 )
					{
						// 未登録のポインタデータアドレス→追加
						this.Items.Add( new PointerData( this._n14pkb, this.Items[i].PtrPointerData1 ) );
					}
				}
				if ( this.Address != Items[i].PtrPointerData2 )
				{
					// Ptr2が管理データを指していない(ポインタデータアドレス)
					var	index = this.Items.FindIndex( d => d.Address == this.Items[i].PtrPointerData2 );
					if ( index < 0 )
					{
						// 未登録のポインタデータアドレス→追加
						this.Items.Add( new PointerData( this._n14pkb, this.Items[i].PtrPointerData2 ) );
					}
				}
				if ( this.Address != Items[i].PtrPointerData3 )
				{
					// Ptr3が管理データを指していない(ポインタデータアドレス)
					var	index = this.Items.FindIndex( d => d.Address == this.Items[i].PtrPointerData3 );
					if ( index < 0 )
					{
						// 未登録のポインタデータアドレス→追加
						this.Items.Add( new PointerData( this._n14pkb, this.Items[i].PtrPointerData3 ) );
					}
				}
			}

			// リスト解析用のデータ作成
			for ( int i = 0; i < this.Items.Count; i++ )
			{
				// Ptr1～3がそれぞれリストの何番目のポインタデータを指しているか
				if ( this.Ptr1 == this.Items[i].Address )
				{
					this._indexItem.Ptr1Index = i + 1;
				}
				if ( this.Ptr2 == this.Items[i].Address )
				{
					this._indexItem.Ptr2Index = i + 1;
				}
				if ( this.Ptr3 == this.Items[i].Address )
				{
					this._indexItem.Ptr3Index = i + 1;
				}
				// ヒットしない場合は管理データを指している
				int index;
				index = this.Items.FindIndex( a => a.Address == this.Items[i].PtrPointerData1 );
				this.Items[i].Ptr1Index = ( index < 0 ) ? index : index + 1;

				index = this.Items.FindIndex( a => a.Address == this.Items[i].PtrPointerData2 );
				this.Items[i].Ptr2Index = ( index < 0 ) ? index : index + 1;

				index = this.Items.FindIndex( a => a.Address == this.Items[i].PtrPointerData3 );
				this.Items[i].Ptr3Index = ( index < 0 ) ? index : index + 1;
			}
		}

		/// <summary>ポインタリスト内のデータアドレスを16進表記の文字列として返す</summary>
		/// <returns>アドレスリスト</returns>
		public string GetTargetDataAddresslistHexString()
		{
			if ( this.Items == null ) { return string.Empty; }

			var sb = new StringBuilder( 256 );
			foreach ( var d in this.Items )
			{
				sb.Append( d.PtrTargetData.ToString( "X8" ) + ", " );
			}
			return sb.ToString().TrimEnd( new[] { ',', ' ' } );
		}

		/// <summary>データの種類とポインタデータインデクスを指定して目標データの名称を取得する</summary>
		/// <param name="datakind">データの種類 pointerdataindex 省略時は省略可</param>
		/// <param name="index">ポインタデータのインデクス 省略した場合はリスト内の全データ</param>
		/// <returns></returns>
		public string GetTargetDataName( DataKind datakind = DataKind.UNKNOWN, int index = -1 )
		{
			if ( this.Count == 0 ) { return string.Empty; }
			var items = new PointerData[1];
			if ( -1 == index )
			{
				items = this.Items.ToArray();
			}
			else
			{
				this.Items.CopyTo( index, items, 0, 1 );
			}
			// インデックス指定なし(全リスト)
			var str = string.Empty;

			var sb = new StringBuilder( 256 );
			foreach ( var d in items )
			{
				var s = Funcs.GetNameByAddress( this._n14pkb, d.PtrTargetData, datakind );
				if ( !string.IsNullOrEmpty( s ) )
				{
					sb.Append( s.Trim() );
					if ( d.Value1 != 0 )
					{
						// ポインタデータサイズが 0x10(数値データを含む)
						sb.Append( "(" );
						sb.Append( d.Value1 );
						sb.Append( ")" );
					}
					sb.Append( ", " );
				}
			}
			return sb.ToString().TrimEnd( new[] { ',', ' ' } );
		}

		/// <summary>ToString</summary>
		public override string ToString()
		{
			return this.GetTargetDataName( this._datakind );
		}


		// 解析用にリストの詳細データを作成
		public string Report( int id, DataKind datakind = DataKind.UNKNOWN ) { return Report( id.ToString(), datakind ); }
		public string Report( string name, DataKind datakind = DataKind.UNKNOWN )
		{
			char tab = '\t';
			var sb = new StringBuilder( 1024 );

			sb.Append( "Idx" + tab );
			sb.Append( this.Address.ToString( "X8" ) + tab );
			sb.Append( this.Ptr1.ToString( "X8" ) + tab );
			sb.Append( this.Ptr2.ToString( "X8" ) + tab );
			sb.Append( this.Ptr3.ToString( "X8" ) + tab );
			sb.Append( this._indexItem.Ptr1Index + tab );
			sb.Append( this._indexItem.Ptr2Index + tab );
			sb.Append( this._indexItem.Ptr3Index + tab );
			sb.Append( this._indexItem.PtrTargetData.ToString( "X8" ) + tab );
			sb.Append( this._indexItem.Value1.ToString( "X8" ) + tab );
			sb.Append( this._indexItem.Value2.ToString( "X8" )	+ Environment.NewLine );

			if ( this.Count == 0 ) { return sb.ToString(); }

			int i = 1;
			foreach ( var d in this.Items )
			{
				sb.Append( name + ":" + i++.ToString( "D2" ) + tab );
				sb.Append( d.Address.ToString( "X8" ) + tab );
				sb.Append( d.PtrPointerData1.ToString( "X8" ) + tab );
				sb.Append( d.PtrPointerData2.ToString( "X8" ) + tab );
				sb.Append( d.PtrPointerData3.ToString( "X8" ) + tab );
				sb.Append( d.Ptr1Index + tab );
				sb.Append( d.Ptr2Index + tab );
				sb.Append( d.Ptr3Index + tab );
				sb.Append( Funcs.GetNameByAddress( this._n14pkb, d.PtrTargetData, datakind ) + tab );
				sb.Append( d.Value1.ToString() + tab );
				sb.Append( d.Value2.ToString() + System.Environment.NewLine );
			}
			return sb.ToString();
		}
	}
}
