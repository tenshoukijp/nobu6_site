﻿// Funcs.cs

using System;
using System.Collections.Generic;
using System.Windows;

using N14PKBrowse.Data;
using N14PKBrowse.Enums;
using N14PKLibrary;

namespace N14PKBrowse
{
	/// <summary>ツールで使用する関数群</summary>
	public class Funcs
	{
		/// <summary>データ取得からゲーム内時間が変更しているかチェックする。変更がなければ true を返す</summary>
		/// <param name="n14pk">ゲームプロセス</param>
		/// <returns>変更がなければ true を返す</returns>
		public static bool CheckDate( N14PK n14pk )
		{
			if ( n14pk.GetCurrentDateTime() != n14pk.TransactionDateTime )
			{
				var message = "データ取得から日時が変化しています。\n("
					+ n14pk.TransactionDateTime.ToString( "yyyy年M月d日h時" ) + "→" + n14pk.GetCurrentDateTime().ToString( "yyyy年M月d日h時" )
					+ ")\n安全のためデータを再取得してください。";
				System.Windows.MessageBox.Show( message, "コマンド中止", MessageBoxButton.OK, MessageBoxImage.Warning );
				return false;
			}
			return true;
		}

		/// <summary>データアドレスからデータの種類を取得する</summary>
		/// <param name="n14pk">ゲームプロセス管理</param>
		/// <param name="address">データアドレス</param>
		/// <returns>データの種類</returns>
		public static DataKind GetDataKindByAddress( N14PKB n14pkb, UInt32 address )
		{
			if ( address == 0 ) { return DataKind.UNKNOWN; }
			// 各データのポインタテーブルがアドレス順に並んでいることが前提
			for ( var i = 0; i < n14pkb.N14pk.Datatables.Length; i++ )
			{
				if ( n14pkb.N14pk.Datatables[i] == null ) { continue; }
				var ptable = n14pkb.N14pk.Datatables[i].Pointertable;
				if ( ptable[0] <= address && address <= ptable[ptable.Count - 1] )
				{
					return (DataKind)i;
				}
			}
			return DataKind.UNKNOWN;
		}

		/// <summary>データアドレスから名称を取得する</summary>
		/// <param name="n14pk">ゲームプロセス管理</param>
		/// <param name="address">データアドレス</param>
		/// <param name="datakind">データの種類 省略可</param>
		/// <returns>名称(名称取得できない場合はデータアドレス16進)</returns>
		public static string GetNameByAddress( N14PKB n14pkb, UInt32 address, DataKind datakind = DataKind.UNKNOWN )
		{
			if ( address == 0 ) { return string.Empty; }

			if ( datakind == DataKind.UNKNOWN )
			{
				datakind = Funcs.GetDataKindByAddress( n14pkb, address );
			}

			if ( datakind == DataKind.UNKNOWN ) { return address.ToString( "X8" ); }

			if ( n14pkb.DataLists[Helper.GetTabIndexByDataKind( datakind )] == null ) { return address.ToString( "X8" ); }

			var datalist = n14pkb.DataLists[Helper.GetTabIndexByDataKind( datakind )].Items;
			foreach ( var d in datalist )
			{
				if ( d.Address == address )
				{
					return d.Name;
				}
			}

			if ( datakind == DataKind.城 )
			{
				// 城データで見つからない場合は、区画データアドレスの可能性がある
				var Shirodatalist = datalist as N14PKBrowse.Data.Shiro[];
				foreach ( var Shiro in Shirodatalist )
				{
					foreach ( var kukaku in Shiro.Kukakulist )
					{
						if ( kukaku.Address == address )
						{
							return kukaku.Name;
						}
					}
				}
			}

			// データリスト作成時にフィルタでハブられたデータを参照している場合があるので string.Empty を返す
			return string.Empty;
			//return address.ToString( "X8" );
		}

		/// <summary>武将データ 能力経験値を加味した文字列を返す Ex.)74(5)</summary>
		/// <param name="value">能力値</param>
		/// <param name="exp">経験値</param>
		/// <returns></returns>
		public static string GetNouryokuAndExp( byte value, ushort exp )
		{
			var hosei = exp / 100;
			string str = string.Empty;

			str = ( value + hosei ).ToString().PadLeft( 3 );
			if ( hosei != 0 )
			{
				str += " (" + hosei.ToString() + ")";
				//str += "(+" + hosei.ToString() + ")";
			}
			return str;
		}

		/// <summary>武将データ 忠誠補正をセットする</summary>
		/// <param name="busyou">武将データ</param>
		/// <param name="index">インデクス</param>
		/// <param name="value">補正値</param>
		public static void SetChuuseihosei( Busyou busyou, int index, int value )
		{
			var list = busyou.ChuuseiHoseiList;
			list[index] = (sbyte)value;
			busyou.ChuuseiHoseiList = list;
		}

		/// <summary>武将データ 忠誠補正をクリアする</summary>
		/// <param name="busyou">武将データ</param>
		public static void ClearChuuseihosei( Busyou busyou )
		{
			// busyou.ChuuseiHoseiList = new sbyte[busyou.ChuuseiHoseiList.Length]; これでもいいが意味が薄い
			var list = busyou.ChuuseiHoseiList;
			for ( var i = 0; i < list.Length; i++ )
			{
				list[i] = 0;
			}
			busyou.ChuuseiHoseiList = list;
		}

		/// <summary>武将データ 勢力を指定して一門チェック ※忠誠補正 "一門" も設定する</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="busyou">武将データ</param>
		/// <param name="seiryoku">勢力データ</param>
		/// <returns></returns>
		public static bool IsIchimon( N14PKB n14pkb, Busyou busyou, Seiryoku seiryoku )
		{
			if ( busyou == null || seiryoku == null )
			{
				return false;
			}

			if ( busyou.Seiryoku == null || busyou.KetsuzokuID == -1 )
			{
				return false;
			}

			// 配偶者の血族ID
			var haigusyaKetsuzokuID = ( busyou.PtrHaigusya != 0 ) ? n14pkb.Busyoulist[busyou.PtrHaigusya].KetsuzokuID : -1;
			// 養父アドレス
			var haigusyaYoufuAddress = ( busyou.PtrHaigusya != 0 ) ? n14pkb.Busyoulist[busyou.PtrHaigusya].PtrYoufu : 0;

			if (
				busyou.KetsuzokuID  == seiryoku.TousyuKetsuzokuID
				|| haigusyaKetsuzokuID == seiryoku.TousyuKetsuzokuID
				|| busyou.KetsuzokuID == seiryoku.TousyuHaigusyaKetsuzokuID
				|| busyou.KetsuzokuID == seiryoku.TousyuYoufuKetsuzokuID
				|| busyou.PtrYoufu == seiryoku.PtrTousyu
				|| haigusyaYoufuAddress == seiryoku.PtrTousyu
				)
			{
				// 1:当主の血族
				// 2:当主の血族を配偶者に持つ者(配偶者の血族IDが当主と同じ)
				// 3:当主の配偶者の血族
				// 4:当主の養父の血族
				// 5:当主を養父に持つ者
				// 6:当主を養父に持つ者の配偶者(配偶者の養父が当主)

				if ( busyou.ChuuseiHoseiList[(int)ChuuseihoseiKind.一門] == 0 )
				{
					// 忠誠補正 "一門" がゼロなら
					Funcs.SetChuuseihosei( busyou, (int)ChuuseihoseiKind.一門, 3 );	// なんとなく 3 くらいかな
				}

				return true;
			}
			else if ( busyou.ChuuseiHoseiList[(int)ChuuseihoseiKind.一門] != 0 )
			{
				// 一門じゃないのに補正値があるならクリア
				Funcs.SetChuuseihosei( busyou, (int)ChuuseihoseiKind.一門, 0 );
			}

			return false;
		}

		/// <summary>指定したデータアドレスを含むポインタデータをリスト間でコピーする</summary>
		/// <param name="ptrData">データアドレス</param>
		/// <param name="ptrFromlist">コピー元リストのアドレス</param>
		/// <param name="ptrTolist">コピー先リストのアドレス</param>
		public static bool CopyPointerData( N14PKB n14pkb, uint ptrData, uint ptrFromlist, uint ptrTolist )
		{
			var from = PointerlistType2.Create( n14pkb, ptrFromlist );
			var to = PointerlistType2.Create( n14pkb, ptrTolist );
			return CopyPointerData( n14pkb, ptrData, from, to );
		}
		/// <summary>指定したデータアドレスを含むポインタデータをリスト間でコピーする</summary>
		/// <param name="ptrData">データアドレス</param>
		/// <param name="fromlist">コピー元リスト</param>
		/// <param name="tolist">コピー先リスト</param>
		public static bool CopyPointerData( N14PKB n14pkb, uint ptrData, PointerlistType2 fromlist, PointerlistType2 tolist )
		{
			if ( fromlist == null || tolist == null )
			{
				throw new ApplicationException( "CopyPointerData/ fromlist == null || tolist == null" );
			}

			if ( fromlist == tolist )
			{
				throw new ApplicationException( "CopyPointerData/ fromlist == tolist" );
			}

			var pdata = fromlist.GetPointerDataByTargetDataAddress( ptrData );
			if ( pdata == null )
			{
				// 移動元リストに当該データアドレスを含むポインタデータがない
				return false;
			}

			if ( !tolist.AddLast( pdata ) )
			{
				// 移動先リストに当該データアドレスを含むポインタデータ追加失敗
				return false;
			}

			return true;
		}

		/// <summary>指定したデータアドレスを含むポインタデータをリスト間で移動する</summary>
		/// <param name="ptrData">データアドレス</param>
		/// <param name="ptrFromlist">移動元リストのアドレス</param>
		/// <param name="ptrTolist">移動先リストのアドレス</param>
		public static bool MovePointerData( N14PKB n14pkb, uint ptrData, uint ptrFromlist, uint ptrTolist )
		{
			var from = PointerlistType2.Create( n14pkb, ptrFromlist );
			var to = PointerlistType2.Create( n14pkb, ptrTolist );
			return MovePointerData( n14pkb, ptrData, from, to );
		}
		/// <summary>指定したデータアドレスを含むポインタデータをリスト間で移動する</summary>
		/// <param name="ptrData">データアドレス</param>
		/// <param name="fromlist">移動元リスト</param>
		/// <param name="tolist">移動先リスト</param>
		public static bool MovePointerData( N14PKB n14pkb, uint ptrData, PointerlistType2 fromlist, PointerlistType2 tolist )
		{
			Funcs.CopyPointerData( n14pkb, ptrData, fromlist, tolist );

			if ( !fromlist.RemoveByTargetDataAddress( ptrData ) )
			{
				// 移動元リストから当該データアドレスを含むポインタデータ削除失敗
				return false;
			}

			return true;
		}

		/// <summary>武将データ 当主変更</summary>
		/// あまり検証していない
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="ptrBusyou">新当主アドレス</param>
		public static bool ChangeTousyu( N14PKB n14pkb, uint ptrBusyou )
		{
			// 新当主
			var b = n14pkb.Busyoulist[ptrBusyou];
			if ( b == null || b.Seiryoku == null || b.IsTousyu )
			{
				return false;
			}

			// 旧当主
			var old = b.Seiryoku.Tousyu;

			if ( ( b.MibunID == (int)MibunKind.通常 )		// 身分"通常"
				&& !b.Gundan.IsChokkatsu					// 非直轄軍団
				&& ( b.Gundan.CntShihaiShiroList == 1 )		// 支配城数1
				)
			{
				// 非直轄軍団 ＆ 唯一の支配城(当主変更で城を直轄化すると軍団が消滅する)
				System.Windows.MessageBox.Show(
					b.Name + " が所属する " + b.Shiro.Name.TrimStart( new[] { '*', ' ' } ) + " は " + b.Gundan.Name + " 軍団唯一の拠点です。\n当主変更で城を直轄化すると軍団が消滅するので変更を中止します。",
					"コマンド中止", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
					);
				return false;
			}

			if ( !b.Gundan.IsChokkatsu							// 非直轄軍団
				&& b.Gundan.Gundanchou.PtrKyoten == b.PtrKyoten	// 軍団長の居城
				)
			{
				// 新当主の居城が配下軍団長の居城(新当主が配下軍団長の場合も含む)だった場合、配下軍団長変更
				var ptr = Funcs.GetPtrShinGundanchou( n14pkb, b.PtrGundan, b.PtrKyoten );

				if ( ptr == 0 )
				{
					System.Windows.MessageBox.Show(
						b.Gundan.Name + " 軍団の新軍団長候補がいないため変更を中止します。",
						"コマンド中止", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
						);
					return false;
				}
				else
				{
					var gundanchou = n14pkb.Busyoulist[ptr];
#if DEBUG
					System.Diagnostics.Debug.WriteLine( "軍団長変更:" + b.Gundan.Gundanchouname + " → " + gundanchou.Name );
#endif
					gundanchou.IsGundanchou = true;
				}
			}

			// 旧当主の当主フラグOFF
			old.IsTousyu = false;

			// 幕府役職、朝廷官位があれば引き継ぐ
			var oldflags = old.TokuseiFlags;
			var newflags = b.TokuseiFlags;
			for ( int i = 0; i < oldflags.Length; i++ )
			{
				if ( oldflags[i]
					&& (( Helper.特性系統[b.N14pkb.Tokuseilist[i].KeitouID] == "役職" ) || ( Helper.特性系統[b.N14pkb.Tokuseilist[i].KeitouID] == "官位" ))
					)
				{
					oldflags[i] = false;
					newflags[i] = true;
				}
			}
			b.TokuseiFlags = newflags;
			old.TokuseiFlags = oldflags;

			// 隠居フラグクリア
			b.IsInkyo = false;
			// 忠誠補正クリア
			Funcs.ClearChuuseihosei( b );
			// 当主ポインタを新当主に変更
			b.Seiryoku.PtrTousyu = b.Address;
			// 新当主の軍団を直轄軍団に変更
			b.Data.PtrGundan = old.PtrGundan;
			// 軍団長フラグON
			b.IsGundanchou = true;
			// 姫武将の場合姫リストから削除
			if ( b.IsHime )
			{
				b.Seiryoku.HimeList.RemoveByTargetDataAddress( b.Address );
			}

			// 姫がもったいない？ ので姫リストをチェックして新当主の一門でなければ養父に設定する
			var ptrHimelist = b.Seiryoku.HimeList.GetPtrTargetDataArray();
			foreach ( var ptrHime in ptrHimelist )
			{
				var hime = b.N14pkb.Busyoulist[ptrHime];
				if ( !hime.IsIchimon )
				{
					hime.PtrYoufu = b.Address;
				}
			}
			// 拠点直轄化
			b.Shiro.PtrGundan = b.Gundan.Address;
			b.IsJousyu = true;

			return true;
		}

		/// <summary>城データ 所属軍団を変更する</summary>
		/// あまり検証していない
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="ptrShiro">城アドレス</param>
		/// <param name="ptrNewGgundan">軍団アドレス</param>
		public static bool ChangeKyotenGundan( N14PKB n14pkb, uint ptrShiro, uint ptrNewGgundan )
		{
			if ( ptrShiro == 0  || ptrNewGgundan == 0 )
			{
				return false;
			}

			var shiro = n14pkb.Shirolist[ptrShiro];
			var oldaddress = shiro.PtrGundan;

			if ( oldaddress == ptrNewGgundan )
			{
				// 変更なし
				return false;
			}

			var oldGundan = n14pkb.Gundanlist[oldaddress];							// 旧軍団
			var newGundan = n14pkb.Gundanlist[ptrNewGgundan];						// 新軍団
			var oldSeiryoku = ( oldGundan != null ) ? oldGundan.Seiryoku : null;	// 旧勢力
			var newSeiryoku = ( newGundan != null ) ? newGundan.Seiryoku : null;	// 新勢力

			// 軍団データ 軍団所属拠点リスト間移動
			if ( !Funcs.MovePointerData( n14pkb, ptrShiro, oldGundan.ShihaiShiroList, newGundan.ShihaiShiroList ) )
			{
				return false;
			}
			oldGundan.CntShihaiShiroList = oldGundan.ShihaiShiroList.Count;		// 旧軍団支配拠点数
			newGundan.CntShihaiShiroList = newGundan.ShihaiShiroList.Count;		// 新軍団支配拠点数

			// 軍団ポインタ変更
			shiro.Data.PtrGundan = ptrNewGgundan;

			// 所属武将の軍団変更
			if ( shiro.KoudoukanouList != null )
			{
				// 行動可能武将
				foreach ( var ptr in shiro.KoudoukanouList.GetPtrTargetDataArray() )
				{
					var busyou = n14pkb.Busyoulist[ptr];
					if ( busyou != null )
					{
						busyou.PtrGundan = ptrNewGgundan;
					}
				}
			}
			// 出陣部隊＆部隊編成武将の所属変更
			if ( shiro.SyutsujinButaiList != null )
			{
				foreach ( var ptrButai in shiro.SyutsujinButaiList.GetPtrTargetDataArray() )
				{
					// 出陣中部隊の所属軍団変更
					var butai = n14pkb.Butailist[ptrButai];
					if ( butai != null )
					{
						butai.PtrGundan = ptrNewGgundan;

						foreach ( var ptrBusyou in n14pkb.Butailist[ptrButai].HenseiList.GetPtrTargetDataArray() )
						{
							// 出陣中部隊編成武将の所属軍団変更
							var busyou = n14pkb.Busyoulist[ptrBusyou];
							if ( busyou != null )
							{
								busyou.PtrGundan = ptrNewGgundan;	// 出陣中部隊編成武将
							}
						}
					}
				}
			}

			// 本拠設定
			if ( oldGundan.PtrHonkyo == shiro.Address )
			{
				oldGundan.PtrHonkyo = oldGundan.Gundanchou.PtrKyoten;
			}

			// 国人衆影響力チェック
			n14pkb.Kokujinlist.CheckSyozokuSeiryoku( ptrShiro, newGundan.Data.PtrSeiryoku );

			return true;
		}

		/// <summary>武将データ 軍団ポインタと除外城を指定して新軍団長を選出する</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="ptrGundan">対象となる軍団ポインタ</param>
		/// <param name="ptrJogaiShiro">選出対象から除外する城</param>
		/// <returns>新軍団長ポインタ 候補なしなら 0 を返す</returns>
		public static uint GetPtrShinGundanchou( N14PKB n14pkb, uint ptrGundan, uint ptrJogaiShiro = 0 )
		{
			if ( ptrGundan == 0 ) { return 0; }
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "軍団長/当主選出" );
#endif

			var gundan = n14pkb.Gundanlist[ptrGundan];	// 対象となる軍団
			Busyou old = gundan.Gundanchou;				// 現軍団長
			Busyou gundanchou = null;					// 選出した軍団長
			var ptrlist = new List<uint>();				// 候補武将ポインタリスト

			foreach ( var kouho in n14pkb.Busyoulist )
			{
				// 武将リストから 当該軍団所属 ＆ 身分「通常」 ＆ 現軍団長ではない 武将をピックアップ
				if ( ( kouho.PtrGundan == ptrGundan )
					&& ( kouho.MibunID == (int)MibunKind.通常 )
					&& ( kouho.Address != old.Address )
					&& ( kouho.PtrKyoten != ptrJogaiShiro )
					)
				{
					ptrlist.Add( kouho.Address );
				}
			}

			if ( old.IsTousyu )
			{
				// 現軍団長が当主の場合は当主候補選出となる、候補に成人前の一門、姫を追加
				var seiryoku = gundan.Seiryoku;
				foreach ( var ptr in seiryoku.SeijinmaeList.GetPtrTargetDataArray() )
				{
					var seijinmae = n14pkb.Busyoulist[ptr];

					// 一門チェック
					if ( seijinmae.IsIchimon )
					{
						ptrlist.Add( ptr );
					}
				}

				foreach ( var ptr in seiryoku.HimeList.GetPtrTargetDataArray() )
				{
					var hime = n14pkb.Busyoulist[ptr];

					if ( hime.IsIchimon )
					{
						// 姫だから一門のはずだが念のため
						ptrlist.Add( ptr );
					}
				}
			}

			if ( ptrlist.Count == 0 ) { return 0; }

			// 候補をチェック
			foreach ( var ptr in ptrlist )
			{
				var kouho =  n14pkb.Busyoulist[ptr];

				if ( gundanchou == null )
				{
					gundanchou = kouho;
				}

				if ( gundanchou.IsIchimon )
				{
					// 仮軍団長が一門
					if ( kouho.IsIchimon )
					{
						// 候補も一門
						if ( gundanchou.IsJosei && !kouho.IsJosei )
						{
							// 男子優先
							gundanchou = kouho;
						}
						else if ( gundanchou.IsJosei == kouho.IsJosei )
						{
							// 性別が一緒なら能力比較
							if ( ( gundanchou.TousotsuStdScore + gundanchou.BuyuuStdScore + gundanchou.ChiryakuStdScore + gundanchou.SeijiStdScore ) / 4
								< ( kouho.TousotsuStdScore + kouho.BuyuuStdScore + kouho.ChiryakuStdScore + kouho.SeijiStdScore ) / 4
							)
							{
								// 統率・武勇・知略・政治 4能力の偏差値平均が上なら交代
								gundanchou = kouho;
							}
						}
					}
				}
				else
				{
					// 仮軍団長が一門ではない
					if ( kouho.IsIchimon )
					{
						// 候補武将が一門なら無条件交代
						gundanchou = kouho;
					}
					else if ( ( gundanchou.TousotsuStdScore + gundanchou.BuyuuStdScore + gundanchou.ChiryakuStdScore + gundanchou.SeijiStdScore ) / 4
							< ( kouho.TousotsuStdScore + kouho.BuyuuStdScore + kouho.ChiryakuStdScore + kouho.SeijiStdScore ) / 4
					)
					{
						// 統率・武勇・知略・政治 4能力の偏差値平均が上なら交代
						gundanchou = kouho;
					}
				}
			}
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "候補:" + gundanchou.Name );
#endif
			return gundanchou.Address;
		}

		/// <summary>武将データ 武将移動</summary>
		/// あまり検証していない
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="ptrBusyou">武将アドレス</param>
		/// <param name="ptrChange">変更データアドレス</param>
		/// <param name="kind">移動トリガー</param>
		public static bool BusyouIdou( N14PKB n14pkb, uint ptrBusyou )
		{
			// 事前に Funcs.SetBusyouIdouData() で必要なデータをセットしておく
			if ( 0 == ptrBusyou ) { return false; }

			// 移動武将
			var b = n14pkb.Busyoulist[ptrBusyou];

			// 移動前 城・軍団・勢力
			uint oldPtrShiro = b.PtrShiro;
			Shiro oldShiro = b.Shiro;
			uint oldPtrGundan = b.PtrGundan;
			Gundan oldGundan = b.Gundan;
			uint oldPtrSeiryoku = b.PtrSeiryoku;
			Seiryoku oldSeiryoku = b.Seiryoku;

			// 移動後 城・軍団・勢力
			uint newPtrShiro = b.ToPtrShiro;
			Shiro newShiro = b.ToShiro;
			uint newPtrGundan = b.ToPtrGundan;
			Gundan newGundan = b.ToGundan;
			uint newPtrSeiryoku = b.ToPtrSeiryoku;
			Seiryoku newSeiryoku = b.ToSeiryoku;

			var isChangeSeiryoku = ( oldPtrSeiryoku != newPtrSeiryoku );	// 勢力変更フラグ
			var isChangeGundan = ( oldPtrGundan != newPtrGundan );			// 軍団変更フラグ
			var isChangeShiro = ( oldPtrShiro != newPtrShiro );				// 拠点変更フラグ
			//var isChangeTousyu = false;									// 当主変更フラグ

			// 各リストの更新他
			switch ( b.MibunID )
			{
				case (int)MibunKind.成人前:
					#region 成人前
#if DEBUG
					System.Diagnostics.Debug.WriteLine( "身分:成人前" );
#endif
					if ( isChangeGundan && newPtrGundan != 0 && oldPtrGundan != 0 )
					{
						// 軍団変更 ※ "軍団なし" から、または "軍団なし" への変更は不可
						if ( Funcs.MovePointerData( n14pkb, ptrBusyou, oldSeiryoku.SeijinmaeList, newSeiryoku.SeijinmaeList ) )
						{
							// 成人前リスト → 成人前リスト
							oldSeiryoku.CntSeijinmaeList = oldSeiryoku.SeijinmaeList.Count;
							newSeiryoku.CntSeijinmaeList = newSeiryoku.SeijinmaeList.Count;
#if DEBUG
							System.Diagnostics.Debug.WriteLine( "勢力移動 成人前リスト → 成人前リスト" );
#endif
						}
						else { throw new ApplicationException( "武将移動/成人前/勢力移動 成人前リスト → 成人前リスト 変更エラー" ); }
					}
					else { throw new ApplicationException( "武将移動/成人前/軍団なしから、または軍団なしへの変更" ); }
					#endregion
					break;

				case (int)MibunKind.浪人:
					#region 浪人
#if DEBUG
					System.Diagnostics.Debug.WriteLine( "身分:浪人" );
#endif
					if ( isChangeGundan )
					{
						// 軍団変更(家臣化)
						if ( Funcs.MovePointerData( n14pkb, ptrBusyou, oldShiro.RouninList, newShiro.KoudoukanouList ))
						{
							// 浪人リスト → 行動可能武将リスト
							oldShiro.CntRouninList = oldShiro.RouninList.Count;
							newShiro.CntKoudoukanouList = newShiro.KoudoukanouList.Count;
							b.MibunID = (int)MibunKind.通常;

							// 仕官日付リセット
							b.DateYearShikan		= (ushort)n14pkb.N14pk.TransactionDateTime.Year;
							b.Data.DateMonthShikan	= (byte)n14pkb.N14pk.TransactionDateTime.Month;
							b.Data.DateDayShikan	= (byte)n14pkb.N14pk.TransactionDateTime.Day;
							b.Data.DateHourShikan	= (ushort)n14pkb.N14pk.TransactionDateTime.Hour;
#if DEBUG
							System.Diagnostics.Debug.WriteLine( "家臣化 浪人リスト → 行動可能武将リスト  仕官日付セット" );
#endif
						}
						else { throw new ApplicationException( "武将移動/浪人/家臣化 浪人リスト → 行動可能武将リスト 変更エラー" ); }
					}
					else if ( isChangeShiro )
					{
						// 拠点のみ変更
						if ( Funcs.MovePointerData( n14pkb, ptrBusyou, oldShiro.RouninList, newShiro.RouninList ) )
						{
							// 浪人リスト → 浪人リスト
							oldShiro.CntRouninList = oldShiro.RouninList.Count;
							newShiro.CntRouninList = newShiro.RouninList.Count;
#if DEBUG
							System.Diagnostics.Debug.WriteLine( "拠点変更 浪人リスト → 浪人リスト" );
#endif
						}
						else { throw new ApplicationException( "武将移動/浪人/拠点変更 浪人リスト → 浪人リスト 変更エラー" ); }
					}
					else { throw new ApplicationException( "武将移動/浪人/" ); }
					#endregion
					break;

				case (int)MibunKind.通常:
					#region 通常
#if DEBUG
					System.Diagnostics.Debug.WriteLine( "身分:通常" );
#endif
					if ( isChangeShiro && newPtrShiro != 0 )
					{
						// 拠点変更
						if ( Funcs.MovePointerData( n14pkb, ptrBusyou, oldShiro.KoudoukanouList, newShiro.KoudoukanouList ) )
						{
							// 行動可能武将リスト → 行動可能武将リスト
							oldShiro.CntKoudoukanouList = oldShiro.KoudoukanouList.Count;
							newShiro.CntKoudoukanouList = newShiro.KoudoukanouList.Count;
#if DEBUG
							System.Diagnostics.Debug.WriteLine( "拠点変更 行動可能武将リスト → 行動可能武将リスト" );
#endif
						}
						else { throw new ApplicationException( "武将移動/通常/拠点変更 行動可能武将リスト → 行動可能武将リスト 変更エラー" ); }
					}

					if ( isChangeSeiryoku )
					{
						// 勢力変更
#if DEBUG
						System.Diagnostics.Debug.WriteLine( "勢力移動:"
							+ (( null != oldSeiryoku ) ? oldSeiryoku.Name : "なし") + " → " + (( null != newSeiryoku ) ? newSeiryoku.Name : "なし") );
#endif
						if ( newPtrSeiryoku == 0 )
						{
							// 勢力なしに変更(浪人化)
							if ( Funcs.MovePointerData( n14pkb, ptrBusyou, oldShiro.KoudoukanouList, newShiro.RouninList ) )
							{
								// 行動可能武将リスト → 浪人リスト
								oldShiro.CntKoudoukanouList = oldShiro.KoudoukanouList.Count;
								newShiro.CntRouninList = newShiro.RouninList.Count;
								b.MibunID = (int)MibunKind.浪人;

								// 仕官日付クリア
								b.DateYearShikan		= 0;	// 初期値
								b.Data.DateMonthShikan	= 1;	// 初期値
								b.Data.DateDayShikan	= 1;	// 初期値
								b.Data.DateHourShikan	= 0;	// 初期値
#if DEBUG
								System.Diagnostics.Debug.WriteLine( "浪人化 行動可能武将リスト → 浪人リスト 仕官日付クリア" );
#endif
							}
							else { throw new ApplicationException( "武将移動/通常/浪人化 行動可能武将リスト → 浪人リスト 変更エラー" ); }

							if ( b.IsHime )
							{
								// 姫武将
								if ( oldSeiryoku.HimeList.RemoveByTargetDataAddress( ptrBusyou ) )
								{
									// 勢力姫リストから削除
									oldSeiryoku.CntHimeList = oldSeiryoku.HimeList.Count;
#if DEBUG
									System.Diagnostics.Debug.WriteLine( "※ 姫武将 勢力姫リスト削除" );
#endif
								}
								else { throw new ApplicationException( "武将移動/通常/浪人化 姫リスト 削除エラー" ); }
							}
						}
						else
						{
							// 勢力間移動

							// 仕官日付リセット
							b.DateYearShikan		= (ushort)n14pkb.N14pk.TransactionDateTime.Year;
							b.Data.DateMonthShikan	= (byte)n14pkb.N14pk.TransactionDateTime.Month;
							b.Data.DateDayShikan	= (byte)n14pkb.N14pk.TransactionDateTime.Day;
							b.Data.DateHourShikan	= (ushort)n14pkb.N14pk.TransactionDateTime.Hour;

							if ( b.IsHime )
							{
								// 姫武将
								if ( Funcs.MovePointerData( n14pkb, ptrBusyou, oldSeiryoku.HimeList, newSeiryoku.HimeList ) )
								{
									// 勢力姫リスト → 勢力姫リスト
									oldSeiryoku.CntHimeList = oldSeiryoku.HimeList.Count;
									newSeiryoku.CntHimeList = newSeiryoku.HimeList.Count;

									// 養父設定をしないと家臣との婚姻や婚姻同盟で一門扱いにはならない
									// 好みの問題だが新勢力で一門でなければ当主を養父とする
									if ( !Funcs.IsIchimon( n14pkb, b, newSeiryoku ) )
									{
										b.PtrYoufu = newSeiryoku.PtrTousyu;
									}
#if DEBUG
									System.Diagnostics.Debug.WriteLine( "※ 姫武将 勢力間移動 勢力姫リスト → 勢力姫リスト" );
#endif
								}
								else { throw new ApplicationException( "武将移動/通常/姫武将/勢力間移動 勢力姫リスト → 勢力姫リスト 変更エラー" ); }
							}
						}

						// 家宝と官位以外の忠誠補正クリア
						var chuuseiHoseiKahou = b.ChuuseiHoseiList[(int)ChuuseihoseiKind.家宝];
						var chuuseiHoseiKani = b.ChuuseiHoseiList[(int)ChuuseihoseiKind.官位];
						Funcs.ClearChuuseihosei( b );
						if ( chuuseiHoseiKahou != 0 ) { Funcs.SetChuuseihosei( b, (int)ChuuseihoseiKind.家宝, chuuseiHoseiKahou ); }
						if ( chuuseiHoseiKani != 0 ) { Funcs.SetChuuseihosei( b, (int)ChuuseihoseiKind.官位, chuuseiHoseiKani ); }
#if DEBUG
						System.Diagnostics.Debug.WriteLine( "勢力変更 忠誠補正クリア" );
#endif
						// 成人前血縁武将移動
						Funcs.SeijinmaeKetsuenIdou( n14pkb, ptrBusyou, newPtrShiro );
					}
					#endregion
					break;

				case (int)MibunKind.姫:
					#region 姫
#if DEBUG
					System.Diagnostics.Debug.WriteLine( "身分:姫" );
#endif
					if ( isChangeSeiryoku && newPtrSeiryoku != 0 )
					{
						// 勢力変更
						if ( Funcs.MovePointerData( n14pkb, ptrBusyou, oldSeiryoku.HimeList, newSeiryoku.HimeList ) )
						{
							// 勢力姫リスト → 勢力姫リスト
							oldSeiryoku.CntHimeList = oldSeiryoku.HimeList.Count;
							newSeiryoku.CntHimeList = newSeiryoku.HimeList.Count;

							// 養父設定をしないと家臣との婚姻や婚姻同盟で一門扱いにはならない
							// 好みの問題だが新勢力で一門でなければ当主を養父とする
							if ( !Funcs.IsIchimon( n14pkb, b, newSeiryoku ) )
							{
								b.PtrYoufu = newSeiryoku.PtrTousyu;
							}
#if DEBUG
							System.Diagnostics.Debug.WriteLine( "勢力間移動 姫リスト → 姫リスト" );
#endif
						}
						else { throw new ApplicationException( "武将移動/姫/勢力変更 勢力姫リスト → 勢力姫リスト 変更エラー" ); }
					}
					else { throw new ApplicationException( "武将移動/姫/" ); }
					#endregion
					break;

				case (int)MibunKind.捕虜:
					#region 捕虜
#if DEBUG
					System.Diagnostics.Debug.WriteLine( "身分:捕虜" );
#endif
					// 当該武将を捕縛している部隊
					var butai = n14pkb.Butailist[b.PtrSyozai];

					if ( newPtrSeiryoku == 0 )
					{
						// 所属無しへ(浪人化)
						if ( Funcs.MovePointerData( n14pkb, ptrBusyou, butai.HoryoList, newShiro.RouninList ) )
						{
							// 部隊捕虜リスト → 浪人リスト
							butai.CntHoryoList = butai.HoryoList.Count;
							newShiro.CntRouninList = newShiro.RouninList.Count;
							b.MibunID = (int)MibunKind.浪人;

							// 仕官日付クリア
							b.DateYearShikan		= 0;	// 初期値
							b.Data.DateMonthShikan	= 1;	// 初期値
							b.Data.DateDayShikan	= 1;	// 初期値
							b.Data.DateHourShikan	= 0;	// 初期値

							// 成人前血縁武将移動(残しておくべきか？)
							Funcs.SeijinmaeKetsuenIdou( n14pkb, ptrBusyou, newPtrShiro );
#if DEBUG
							System.Diagnostics.Debug.WriteLine( "身分:捕虜 浪人化 部隊捕虜リスト → 浪人リスト 仕官日付クリア" );
#endif
						}
						else { throw new ApplicationException( "武将移動/捕虜/浪人化 部隊捕虜リスト → 浪人リスト 変更エラー" ); }

						if ( b.IsHime )
						{
							// 姫武将
							if ( oldSeiryoku.HimeList.RemoveByTargetDataAddress( ptrBusyou ) )
							{
								// 勢力姫リストから削除
								oldSeiryoku.CntHimeList = oldSeiryoku.HimeList.Count;
#if DEBUG
								System.Diagnostics.Debug.WriteLine( "※ 姫武将 勢力姫リスト削除" );
#endif
							}
							else { throw new ApplicationException( "武将移動/捕虜/姫武将/浪人化 姫リスト 削除エラー" ); }
						}
					}
					else
					{
						// 家臣化
						if ( Funcs.MovePointerData( n14pkb, ptrBusyou, butai.HoryoList, newShiro.KoudoukanouList ) )
						{
							// 部隊捕虜リスト → 行動可能武将リスト
							butai.CntHoryoList = butai.HoryoList.Count;
							newShiro.CntKoudoukanouList = newShiro.KoudoukanouList.Count;
							b.MibunID = (int)MibunKind.通常;
#if DEBUG
							System.Diagnostics.Debug.WriteLine( "身分:捕虜 家臣化 部隊捕虜リスト → 行動可能武将リスト" );
#endif
						}
						else { throw new ApplicationException( "武将移動/捕虜/家臣化 部隊捕虜リスト → 行動可能武将リスト 変更エラー" ); }

						if ( isChangeSeiryoku )
						{
							if ( b.IsHime )
							{
								// 姫武将
								if ( Funcs.MovePointerData( n14pkb, ptrBusyou, oldSeiryoku.HimeList, newSeiryoku.HimeList ) )
								{
									// 勢力姫リスト → 勢力姫リスト
									oldSeiryoku.CntHimeList = oldSeiryoku.HimeList.Count;
									newSeiryoku.CntHimeList = newSeiryoku.HimeList.Count;
#if DEBUG
								System.Diagnostics.Debug.WriteLine( "※ 姫武将 勢力間移動 勢力姫リスト → 勢力姫リスト" );
#endif
								}
								else { throw new ApplicationException( "武将移動/捕虜/姫武将/勢力変更 勢力姫リスト → 勢力姫リスト 変更エラー" ); }

								// 養父設定をしないと家臣との婚姻や婚姻同盟で一門扱いにはならない
								// 好みの問題だが新勢力で一門でなければ当主を養父とする
								if ( !Funcs.IsIchimon( n14pkb, b, newSeiryoku ) )
								{
									b.PtrYoufu = newSeiryoku.PtrTousyu;
								}
							}

							if ( b.IsInkyo ) { b.IsInkyo = false; }

							// 家宝と官位以外の忠誠補正クリア
							var chuuseiHoseiKahou = b.ChuuseiHoseiList[(int)ChuuseihoseiKind.家宝];
							var chuuseiHoseiKani = b.ChuuseiHoseiList[(int)ChuuseihoseiKind.官位];
							Funcs.ClearChuuseihosei( b );
							if ( chuuseiHoseiKahou != 0 ) { Funcs.SetChuuseihosei( b, (int)ChuuseihoseiKind.家宝, chuuseiHoseiKahou ); }
							if ( chuuseiHoseiKani != 0 ) { Funcs.SetChuuseihosei( b, (int)ChuuseihoseiKind.官位, chuuseiHoseiKani ); }

							// 仕官日付リセット
							b.DateYearShikan		= (ushort)n14pkb.N14pk.TransactionDateTime.Year;
							b.Data.DateMonthShikan	= (byte)n14pkb.N14pk.TransactionDateTime.Month;
							b.Data.DateDayShikan	= (byte)n14pkb.N14pk.TransactionDateTime.Day;
							b.Data.DateHourShikan	= (ushort)n14pkb.N14pk.TransactionDateTime.Hour;
#if DEBUG
							System.Diagnostics.Debug.WriteLine( "勢力変更 忠誠補正クリア 仕官日付リセット" );
#endif
						}
					}

					if ( b.Data.PtrSeiryoku != 0 )
					{
						// 滅亡勢力の当主が捕虜の場合に値を持っている(捕縛している勢力のアドレス)
						b.Data.PtrSeiryoku = 0;
#if DEBUG
						System.Diagnostics.Debug.WriteLine( "勢力ポインタクリア" );
#endif
					}
					//isChangeShiro = true;	// 捕虜の場合、拠点変化しないが所在ポインタをセットするため true を入れておく
					break;
					#endregion

				default:
					break;
			}

			#region 変更前拠点 城主・奉行チェック
			if ( b.MibunID == (int)MibunKind.通常
				|| b.MibunID == (int)MibunKind.浪人
				)
			{
				if ( b.IsBugyou && isChangeShiro )
				{
					// 奉行だった場合
					var kouho = Funcs.GetPtrNewJousyuOrBugyou( n14pkb, oldPtrShiro, JousyuOrBugyouKind.奉行 );
					if ( kouho != 0 )
					{
						// 変更前拠点 新奉行
						n14pkb.Busyoulist[kouho].IsBugyou = true;
					}
					else
					{
						b.IsBugyou = false;
					}
#if DEBUG
					System.Diagnostics.Debug.WriteLine( oldShiro.Name.TrimStart() + ":奉行交代 " + b.Name + " → " + ( ( kouho != 0 ) ? n14pkb.Busyoulist[kouho].Name : "なし" ) );
#endif
				}

				if ( b.IsJousyu && isChangeShiro )
				{
					// 城主だった場合
					var kouho = Funcs.GetPtrNewJousyuOrBugyou( n14pkb, oldPtrShiro, JousyuOrBugyouKind.城主 );
					if ( kouho != 0 )
					{
						// 変更前拠点 新城主
						n14pkb.Busyoulist[kouho].IsJousyu = true;
					}
					else
					{
						b.IsJousyu = false;
					}
#if DEBUG
					System.Diagnostics.Debug.WriteLine( oldShiro.Name.TrimStart() + ":城主交代 " + b.Name + " → " + ( ( kouho != 0 ) ? n14pkb.Busyoulist[kouho].Name : "なし" ) );
#endif
				}
			}
			#endregion

			#region 軍団長移動チェック
			if ( isChangeSeiryoku )
			{
				// 勢力変更
				if ( b.IsTousyu )
				{
					// 当主 → 新当主選出
					var kouho = Funcs.GetPtrShinGundanchou( n14pkb, oldPtrGundan );
					if ( kouho != 0 )
					{
						n14pkb.Busyoulist[kouho].IsGundanchou = true;
						//isChangeTousyu = true;
#if DEBUG
						System.Diagnostics.Debug.WriteLine( "当主変更: " + b.Name + " → " + n14pkb.Busyoulist[kouho].Name );
#endif
					}
				}
				else if ( b.IsGundanchou )
				{
					// 軍団長の勢力外移動 軍団長の変更が必要
					var kouho = Funcs.GetPtrShinGundanchou( n14pkb, oldPtrGundan );
					if ( 0 != kouho )
					{
						n14pkb.Busyoulist[kouho].IsGundanchou = true;
#if DEBUG
						System.Diagnostics.Debug.WriteLine( "軍団長変更: " + b.Name + " → " + n14pkb.Busyoulist[kouho].Name );
#endif
					}
				}
			}
			else if ( isChangeGundan )
			{
				// 軍団変更
				if ( b.IsTousyu )
				{
					// 同一勢力で当主なら軍団変更なし ＆ 変更後拠点と所属武将と出陣中武将の直轄化 軍団支配拠点リスト更新
					// 他に何が必要かいまいちわからない
					if ( newGundan.Gundanchou != null && newGundan.Gundanchou.PtrKyoten == newPtrShiro )
					{
						// 当主の変更後城が配下軍団長の居城だった場合、配下軍団長変更
						var kouho = Funcs.GetPtrShinGundanchou( n14pkb, newPtrGundan, newPtrShiro );
						if ( kouho != 0 )
						{
							n14pkb.Busyoulist[kouho].IsGundanchou = true;
#if DEBUG
							System.Diagnostics.Debug.WriteLine( "軍団長変更: " + newGundan.Gundanchouname + " → " + n14pkb.Busyoulist[kouho].Name );
#endif
						}
					}
					// 拠点直轄化
					newShiro.PtrGundan = oldPtrGundan;
				}
				else if ( b.IsGundanchou )
				{
					// 軍団長の軍団外移動 軍団長の変更が必要
					var kouho = Funcs.GetPtrShinGundanchou( n14pkb, oldPtrGundan );
					if ( kouho != 0 )
					{
						n14pkb.Busyoulist[kouho].IsGundanchou = true;
#if DEBUG
						System.Diagnostics.Debug.WriteLine( "軍団長変更: " + b.Name + " → " + n14pkb.Busyoulist[kouho].Name );
#endif
					}
				}
			}
			#endregion

			// 所在ポインタセット
			if ( isChangeShiro || (DataAddressKind)b.Data.PtrSyozai == DataAddressKind.部隊 )
			{
				// 捕虜の場合、城の変化がなくても所在ポインタを変更する必要があるので所在タイプIDをチェックする
				b.PtrSyozai = newPtrShiro;
				b.Data.SyozaiType = (int)DataAddressKind.城;
#if DEBUG
				System.Diagnostics.Debug.WriteLine( "所在ポインタセット:" + ( ( newShiro != null ) ? newShiro.Name : "なし" ) );
#endif
			}

			#region 変更後拠点 城主・奉行チェック
			if ( ( b.MibunID == (int)MibunKind.通常 )
				&& ( newPtrGundan != 0 )
				)
			{
				// 変更後に軍団に所属している身分「通常」の武将
				if ( ( newShiro.PtrJousyu == 0 )				// 城主がいない
					|| ( !isChangeGundan && b.IsGundanchou )	// 変更前後で軍団が同じ ＆ 変更武将が軍団長(当主)
					|| ( !isChangeSeiryoku && b.IsTousyu )		// 変更前後で勢力が同じ ＆ 変更武将が当主
					)
				{
#if DEBUG
					System.Diagnostics.Debug.WriteLine( newShiro.Name.TrimStart() + ":城主交代 " + ( ( 0 != newShiro.PtrJousyu ) ? n14pkb.Busyoulist[newShiro.PtrJousyu].Name : "なし" ) + " → " + b.Name );
#endif
					b.IsJousyu = true;
				}

				if ( newShiro.PtrBugyou == 0 )
				{
					// 奉行がいない
#if DEBUG
					System.Diagnostics.Debug.WriteLine( newShiro.Name.TrimStart() + ":奉行交代 " + ( ( 0 != newShiro.PtrBugyou ) ? n14pkb.Busyoulist[newShiro.PtrBugyou].Name : "なし" ) + " → " + b.Name );
#endif
					b.IsBugyou = true;
				}
			}
			#endregion

			// 軍団ポインタセット
			if ( isChangeGundan )
			{
				if ( !isChangeSeiryoku && b.IsTousyu )
				{
					// 勢力内当主移動の場合、軍団は変更前(直轄)のまま
					b.Data.PtrGundan = oldPtrGundan;
#if DEBUG
					System.Diagnostics.Debug.WriteLine( "軍団ポインタセット:" + ( ( oldGundan != null ) ? oldGundan.Name : "なし" ) );
#endif
				}
				else
				{
					b.Data.PtrGundan = newPtrGundan;
#if DEBUG
					System.Diagnostics.Debug.WriteLine( "軍団ポインタセット:" + ( ( newGundan != null ) ? newGundan.Name : "なし" ) );
#endif
				}
			}

			return true;
		}

		/// <summary>武将データに武将移動前後の城・軍団ポインタをセットする</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="ptrBusyou">武将ポインタ</param>
		/// <param name="ptrChange">変更データポインタ</param>
		/// <param name="kind">変更データの種類</param>
		public static void SetBusyouIdouData( N14PKB n14pkb, uint ptrBusyou, uint ptrChange, BusyouIdouKind kind )
		{
			// 武将移動
			var b = n14pkb.Busyoulist[ptrBusyou];
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "武将移動:" + b.Name );
#endif
			// 旧城ポインタ
			var oldPtrShiro = b.PtrKyoten;
			var oldShiro = b.Shiro;
			// 旧軍団ポインタ
			var oldPtrGundan = b.PtrGundan;
			var oldGundan = b.Gundan;

			// 新城ポインタ
			uint newPtrShiro = 0;
			Shiro newShiro = null;
			// 新軍団ポインタ
			uint newPtrGundan = 0;
			Gundan newGundan = null;

			#region 変更前後の 軍団・城 設定
			switch ( kind )
			{
				case BusyouIdouKind.軍団:
					newPtrGundan = ptrChange;
					newGundan = n14pkb.Gundanlist[ptrChange];
					newPtrShiro = oldPtrShiro;
					newShiro = n14pkb.Shirolist[oldPtrShiro];

					if ( b.MibunID == (int)MibunKind.姫
						|| b.MibunID == (int)MibunKind.成人前 )
					{
						// 姫と成人前の軍団(勢力)移動は、自勢力の場合配下軍団が選択されても直轄軍団にする
						if ( ( newGundan != null ) && !newGundan.IsChokkatsu )
						{
							// 非直轄
							newPtrGundan = n14pkb.Gundanlist.GetChokkatsuGundanAddressBySeiryokuAddress( newGundan.Data.PtrSeiryoku );
							newGundan = n14pkb.Gundanlist[newPtrGundan];
						}
					}

					if ( ( newGundan != null )
						&& !( newGundan.ShihaiShiroList.IsContainTargetDataAddress( oldPtrShiro ) )
						&& ( b.MibunID != (int)MibunKind.姫 )
						)
					{
						// 居城が変更軍団に属していない。姫(姫武将を除く)は城ポインタゼロ。
						if ( newPtrGundan != 0 )
						{
							// 城変更の必要あり
							// 城支配軍団の本拠(本拠がない場合は軍団長の居城)を新城とする
							newPtrShiro = ( newGundan.PtrHonkyo != 0 ) ? newGundan.PtrHonkyo : newGundan.Gundanchou.PtrKyoten;
							newShiro = n14pkb.Shirolist[newPtrShiro];
						}
					}
					break;

				case BusyouIdouKind.城:
					newPtrGundan = oldPtrGundan;
					newGundan = n14pkb.Gundanlist[oldPtrGundan];
					newPtrShiro = ptrChange;
					newShiro = n14pkb.Shirolist[ptrChange];

					if ( ( oldGundan != null )
						&& !( oldGundan.ShihaiShiroList.IsContainTargetDataAddress( newPtrShiro ) )
						)
					{
						// 変更城が現軍団に属していない
						if ( 0 != oldPtrGundan )
						{
							// 軍団変更の必要あり
							// 新城の支配軍団を新軍団とする
							newPtrGundan = ( newShiro != null ) ? newShiro.PtrGundan : 0;
							newGundan =n14pkb.Gundanlist[newPtrGundan];
						}
					}
					break;

				default:
					break;
			}

			// 武将データに武将移動用データをセット
			b.ToPtrShiro = newPtrShiro;
			b.ToPtrGundan = newPtrGundan;

#if DEBUG
			System.Diagnostics.Debug.Write( "所属:" + ( ( null != oldGundan ) ? oldGundan.Name : "なし" ) );
			if ( oldPtrGundan != newPtrGundan )
			{
				System.Diagnostics.Debug.Write( " → " + ( ( null != newGundan ) ? newGundan.Name : "なし" ) );
			}
			else
			{
				System.Diagnostics.Debug.Write( "(変更なし)" );
			}

			System.Diagnostics.Debug.Write( "／城:" + ( ( null != oldShiro ) ? oldShiro.Name.TrimStart() : "なし" ) );
			if ( oldPtrShiro != newPtrShiro )
			{
				System.Diagnostics.Debug.WriteLine( " → " + ( ( null != newShiro ) ? newShiro.Name.TrimStart() : "なし" ) );
			}
			else
			{
				System.Diagnostics.Debug.WriteLine( "(変更なし)" );
			}
#endif
			#endregion
		}

		/// <summary>武将データ 武将移動に伴う成人前血縁武将の移動</summary>
		/// 保護者だけいなくなるのは忍びない？ ので成人前血縁も一緒に移動させる
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="ptrBusyou">武将ポインタ</param>
		/// <param name="toPtrShiro">移動先の城ポインタ</param>
		public static void SeijinmaeKetsuenIdou( N14PKB n14pkb, uint ptrBusyou, uint toPtrShiro )
		{
			if ( ptrBusyou == 0 )
			{
				return;
			}

			// 移動武将
			var b = n14pkb.Busyoulist[ptrBusyou];
			// 移動先城
			var toShiro = n14pkb.Shirolist[toPtrShiro];
			// 移動先軍団
			var toPtrGundan = ( toShiro != null ) ? toShiro.PtrGundan : 0;
			var toGundan = n14pkb.Gundanlist[toPtrGundan];

			if ( b.Seiryoku == null || b.Seiryoku.Address == toGundan.Data.PtrSeiryoku )
			{
				// 呼ばれる時点で 勢力変更＆変更前所属勢力あり が前提
				return;
			}


			if ( b.IsTousyu )
			{
				// 移動武将が当主の場合、成人前の一族ごっそり連れて行ってお家断絶しちゃうので単身移動するようにする
				return;
			}

			var toSeiryoku = toGundan.Seiryoku;
			var fromSeijinmaelist = b.Seiryoku.SeijinmaeList;
			var toSeijinmaelist = toSeiryoku.SeijinmaeList;
			var ptrlist = new List<UInt32>();	// 移動する成人前血縁武将のポインタリスト

			foreach ( var d in fromSeijinmaelist.GetPtrTargetDataArray() )
			{
				// 血縁武将の抽出
				var busyou = n14pkb.Busyoulist[d];

				if ( busyou.PtrChichi == ptrBusyou			// 移動武将が父
					|| busyou.PtrYoufu == ptrBusyou			// 移動武将が養父
					//|| busyou.Data.PtrHaha == ptrBusyou			// 移動武将が母
					|| busyou.PtrHaigusya == ptrBusyou 		// 移動武将が配偶者
					)
				{
					ptrlist.Add( d );
				}
			}

			foreach ( var d in ptrlist )
			{
				var busyou = n14pkb.Busyoulist[d];

				// 軍団アドレス
				busyou.Data.PtrGundan = toPtrGundan;

				// 所在アドレス(どこにいても所属軍団に登場する？)
				n14pkb.Busyoulist[d].PtrSyozai = toPtrShiro;

				if ( toPtrGundan == 0 )
				{
					// 無所属化なら仕官日付クリア
					busyou.DateYearShikan		= 0;
					busyou.Data.DateMonthShikan	= 1;
					busyou.Data.DateDayShikan	= 1;
					busyou.Data.DateHourShikan	= 0;
				}
				else
				{
					// 勢力変更なら仕官日付リセット
					busyou.DateYearShikan		= (ushort)n14pkb.N14pk.TransactionDateTime.Year;
					busyou.Data.DateMonthShikan	= (byte)n14pkb.N14pk.TransactionDateTime.Month;
					busyou.Data.DateDayShikan	= (byte)n14pkb.N14pk.TransactionDateTime.Day;
					busyou.Data.DateHourShikan	= (ushort)n14pkb.N14pk.TransactionDateTime.Hour;
				}

				// 家宝と官位以外の忠誠補正クリア
				var chuuseiHoseiKahou = busyou.ChuuseiHoseiList[(int)ChuuseihoseiKind.家宝];
				var chuuseiHoseiKani = busyou.ChuuseiHoseiList[(int)ChuuseihoseiKind.官位];
				Funcs.ClearChuuseihosei( busyou );
				if ( chuuseiHoseiKahou != 0 ) { Funcs.SetChuuseihosei( busyou, (int)ChuuseihoseiKind.家宝, chuuseiHoseiKahou ); }
				if ( chuuseiHoseiKani != 0 ) { Funcs.SetChuuseihosei( busyou, (int)ChuuseihoseiKind.官位, chuuseiHoseiKani ); }
			}

			// 成人前リスト更新
			if ( toPtrGundan == 0 )
			{
				foreach ( var d in ptrlist )
				{
					fromSeijinmaelist.RemoveByTargetDataAddress( d );
				}
				b.Seiryoku.CntSeijinmaeList = fromSeijinmaelist.Count;
			}
			else
			{
				foreach ( var d in ptrlist )
				{
					Funcs.MovePointerData( n14pkb, d, fromSeijinmaelist, toSeijinmaelist );
				}
				b.Seiryoku.CntSeijinmaeList = fromSeijinmaelist.Count;
				toSeiryoku.CntSeijinmaeList = toSeijinmaelist.Count;
			}
#if DEBUG
			for ( int i = 0; i < ptrlist.Count; i++ )
			{
				System.Diagnostics.Debug.WriteLine( "付随成人前血縁武将 " + ( i + 1 ) + ": " + n14pkb.Busyoulist[ptrlist[i]].Name );
			}
#endif
		}

		/// <summary>拠点ポインタと城主、または奉行を指定して新城主／新奉行ポインタを取得</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="ptrShiro">城ポインタ</param>
		/// <param name="kind">城主／奉行</param>
		/// <returns>新城主／新奉行ポインタ 候補がいない時は 0 を返す</returns>
		public static uint GetPtrNewJousyuOrBugyou( N14PKB n14pkb, uint ptrShiro, JousyuOrBugyouKind kind )
		{
			if ( ptrShiro == 0  )
			{
				return 0;
			}

			// 対象となる拠点
			var shiro = n14pkb.Shirolist[ptrShiro];

			var oldbusyou = ( kind == JousyuOrBugyouKind.城主 ) ? shiro.Jousyu : shiro.Bugyou;
			Busyou shinbusyou = null;

			// 候補武将ポインタリスト
			var ptrlist = new List<UInt32>();

			foreach ( var kouho in n14pkb.Busyoulist )
			{
				// 当該軍団所属 ＆ 身分「通常」 ＆ 現城主/奉行ではない 武将をピックアップ
				if ( ( kouho.PtrKyoten == ptrShiro )
					&& ( kouho.MibunID == (int)MibunKind.通常 )
					&& ( kouho.Address != oldbusyou.Address )
					)
				{
					ptrlist.Add( kouho.Address );
				}
			}

			if ( 0 == ptrlist.Count )
			{
				// 候補なし
				return 0;
			}

			// 候補をチェック
			foreach ( var ptr in ptrlist )
			{
				var kouho = n14pkb.Busyoulist[ptr];
				if ( shinbusyou == null )
				{
					// 仮候補
					shinbusyou = kouho;
				}

				if ( kind == JousyuOrBugyouKind.城主 )
				{
					// 城主選出
					if ( shinbusyou.TousotsuStdScore < kouho.TousotsuStdScore )
					{
						// 統率偏差値が上なら候補変更
						shinbusyou = kouho;
					}
				}
				else
				{
					// 奉行選出
					if ( shinbusyou.SeijiStdScore < kouho.SeijiStdScore )
					{
						// 政治偏差値が上なら候補変更
						shinbusyou = kouho;
					}
				}
			}

#if DEBUG
			if ( kind == JousyuOrBugyouKind.城主 )
				System.Diagnostics.Debug.WriteLine( shiro.Name.TrimStart() + ":城主候補 " + ( ( null != shinbusyou ) ? shinbusyou.Name : "なし" ) );
			else
				System.Diagnostics.Debug.WriteLine( shiro.Name.TrimStart() + ":奉行候補 " + ( ( null != shinbusyou ) ? shinbusyou.Name : "なし" ) );
#endif
			return shinbusyou.Address;
		}

		/// <summary>武将データ 軍団・城変更不可条件チェック</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="ptrBusyou">武将ポインタ</param>
		/// <returns></returns>
		public static bool CheckBusyouIdou( N14PKB n14pkb, uint ptrBusyou )
		{
			if ( 0 == ptrBusyou )
			{
				return false;
			}

			var b = n14pkb.Busyoulist[ptrBusyou];

			if ( ( b.MibunID == (int)MibunKind.なし )
				|| ( b.MibunID == (int)MibunKind.未発見 )
				|| ( b.MibunID == (int)MibunKind.人質 )
				|| ( b.MibunID == (int)MibunKind.他 )
				)
			{
				// リスト用のデータがどこにあるのかわからないので上記条件は現状変更不可
				System.Windows.MessageBox.Show(
					"変更中止！\n身分「" + (MibunKind)b.MibunID + "」の武将は軍団・城変更できません。",
					"軍団・城変更: " + b.Name, System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
					);
				return false;
			}

			if ( ( b.Data.SyozaiType == (int)DataAddressKind.なし )
				&& ( b.MibunID != (int)MibunKind.姫 )
				)
			{
				// 身分「姫」以外の所在ポインタを持たない(所属城がない)データ
				System.Windows.MessageBox.Show(
					"変更中止！\n所在「" + (DataAddressKind)b.Data.SyozaiType + "」(身分「姫」を除く)の武将は軍団・城変更できません。",
					"軍団・城変更: " + b.Name, System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
					);
				return false;
			}

			if ( ( b.Data.SyozaiType == (int)DataAddressKind.部隊 )
				&& ( b.PtrGundan == n14pkb.Butailist[b.PtrSyozai].PtrGundan )
				&& ( b.MibunID != (int)MibunKind.捕虜 )
				)
			{
				// 所在ID 処理が煩雑になるので部隊所属(出陣中)の捕虜以外は変更不可 ※城の所属軍団変更処理時、出陣中武将の所属軍団を変更する場合はある
				System.Windows.MessageBox.Show(
					"変更中止！\n所在「" + (DataAddressKind)b.Data.SyozaiType + "」(身分「捕虜」を除く)の武将は軍団・城変更できません。",
					"軍団・城変更: " + b.Name, System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
					);
				return false;
			}

			if ( ( b.Data.SyozaiType == (int)DataAddressKind.任務 )
				|| ( b.Data.SyozaiType == (int)DataAddressKind.国人 )
				)
			{
				System.Windows.MessageBox.Show(
					"変更中止！\n所在「" + (DataAddressKind)b.Data.SyozaiType + "」の武将は軍団・城変更できません。",
					"軍団・城変更: " + b.Name, System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
					);
				return false;
			}

			if ( ( b.ToPtrShiro == 0 )
				&& ( b.MibunID != (int)MibunKind.姫 )
				)
			{
				// 城なし
				System.Windows.MessageBox.Show(
					"変更中止！\n「城なし」にはできません。",
					"軍団・城変更: " + b.Name, System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
					);
				return false;
			}

			if ( b.MibunID == (int)MibunKind.姫 )
			{
				if ( b.PtrSeiryoku == b.ToPtrSeiryoku )
				{
					// 変更前後が同一勢力 スルー
					return false;
				}

				if ( b.PtrShiro != b.ToPtrShiro )
				{
					// 城変更
					System.Windows.MessageBox.Show(
						"変更中止！\n姫は城を変更できません。",
						"軍団・城変更: " + b.Name, System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
						);
					return false;
				}

				if ( b.ToPtrGundan == 0 )
				{
					// 無所属へ
					System.Windows.MessageBox.Show(
						"変更中止！\n姫は「軍団未所属」への変更はできません。",
						"軍団・城変更: " + b.Name, System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
						);
					return false;
				}

				if ( b.PtrGundan == 0 || b.PtrHaigusya != 0 )
				{
					// 無所属 または 既婚
					System.Windows.MessageBox.Show(
						"変更中止！\n「軍団未所属」 や 「既婚」 の姫は所属変更できません。",
						"軍団・城変更: " + b.Name, System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
						);
					return false;
				}
			}

			if ( ( b.PtrGundan != b.ToPtrGundan )
				&& ( b.PtrSeiryoku == b.ToPtrSeiryoku )
				&& b.IsTousyu
				&& b.ToGundan.CntShihaiShiroList == 1
				)
			{
				// 当主の勢力内軍団移動
				// 移動先の城(後に直轄化される)がその軍団唯一の城だった場合変更不可とする
				System.Windows.MessageBox.Show(
					"変更中止！\n当主移動後の城は直轄化されます。\n「"
					+ b.ToShiro.Name.TrimStart() + "」 は 「" + b.ToGundan.Name + "」 軍団唯一の城です。\n軍団が消滅するので変更はできません。",
					"軍団・城変更: " + b.Name, System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
					);
				return false;
			}

			if ( ( b.PtrGundan != b.ToPtrGundan )
				&& ( b.PtrSeiryoku == b.ToPtrSeiryoku )
				&& b.IsTousyu
				)
			{
				// 当主の勢力内軍団移動
				// 移動先の城(後に直轄化される)に配下軍団長がおり、その城以外に新軍団長候補となる武将がいない
				var ptr = Funcs.GetPtrShinGundanchou( n14pkb, b.ToPtrGundan, b.ToPtrShiro );
				if ( ptr == 0 )
				{
					System.Windows.MessageBox.Show(
					"変更中止！\n当主移動後の城は直轄化されます。\n「"
					+ b.ToShiro.Name.TrimStart() + "」 以外に 「" + b.ToGundan.Name + "」 軍団の武将がいません。\n軍団が消滅するので変更はできません。",
					"軍団・城変更: " + b.Name, System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
						);
					return false;
				}
			}

			if ( ( b.PtrGundan != b.ToPtrGundan )
				&& b.IsGundanchou
				&& !b.IsTousyu
				)
			{
				// 軍団長の軍団間移動
				// 新たに軍団長となる人物がいなければ(軍団に他の武将がいない場合)不可とする
				var ptr = Funcs.GetPtrShinGundanchou( n14pkb, b.PtrGundan );
				if ( ptr == 0 )
				{
					System.Windows.MessageBox.Show(
						"変更中止！\n「" + b.Gundan.Name + "」 軍団に他の武将がいません。\n軍団が消滅するので変更はできません。",
						"軍団・城変更: " + b.Name, System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
						);
					return false;
				}
			}
			return true;
		}

		/// <summary>拠点データ 所属軍団変更不可条件チェック</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="ptrShiro">城ポインタ</param>
		/// <param name="ptrGundan">変更後軍団ポインタ</param>
		/// <returns></returns>
		public static bool CheckSyozokuGundanHenkou( N14PKB n14pkb, uint ptrShiro, uint ptrGundan )
		{
			if ( ptrShiro == 0 || ptrGundan == 0 )
			{
				return false;
			}

			var shiro = n14pkb.Shirolist[ptrShiro];
			var oldGundan = shiro.Gundan;
			var oldGundanchou = oldGundan.Gundanchou;
			var newGundan = n14pkb.Gundanlist[ptrGundan];

			if ( 0 < shiro.CntNinmuList )
			{
				// 任務
				System.Windows.MessageBox.Show(
					"変更中止！\n任務中の武将がいるため変更を中止します。",
					"所属軍団変更: " + shiro.Name.TrimStart(), System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
					);
				return false;
			}

			if ( oldGundan == null || newGundan == null )
			{
				// 無所属
				System.Windows.MessageBox.Show(
					"変更中止！\n所属軍団「なし」から ／ 「なし」への変更はできません。",
					"所属軍団変更: " + shiro.Name.TrimStart(), System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
					);
				return false;
			}

			if ( oldGundan.CntShihaiShiroList == 1 )
			{
				// 軍団唯一の拠点を変更
				System.Windows.MessageBox.Show(
					"変更中止！\n「"
					+ shiro.Name.TrimStart() + "」 は 「" + oldGundan.Name + "」 軍団唯一の拠点です。\n軍団が消滅するため変更はできません。",
					"所属軍団変更: " + shiro.Name.TrimStart(), System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
					);
				return false;
			}

			if ( ptrShiro == oldGundanchou.PtrKyoten )
			{
				// 軍団長の拠点
				var ptr = Funcs.GetPtrShinGundanchou( n14pkb, shiro.PtrGundan, ptrShiro );
				if ( ptr == 0 )
				{
					System.Windows.MessageBox.Show(
					"変更中止！\n「" + shiro.Name.TrimStart() + "」 以外に 「" + oldGundan.Name + "」 軍団の武将がいません。\n軍団が消滅するため変更はできません。",
					"所属軍団変更: " + shiro.Name.TrimStart(), System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning
						);
					return false;
				}
			}
			return true;
		}

		/// <summary>区画データ 隣接フラグチェック</summary>
		public static void CheckRinsetsuKukaku( N14PKB n14pkb, Kukaku k, bool isChecked, int changedKukakuID )
		{
			// 隣接先の区画
			var pairk = k.Shiro.Kukakulist[changedKukakuID - 1];

			switch ( k.Data.KukakuID )	// Data.KukakuID は +1 していない素の値
			{
				case 0:
					if ( !isChecked.Equals( pairk.Rinsetsu1 ) )
					{
						pairk.Rinsetsu1 = isChecked;
					}
					break;
				case 1:
					if ( !isChecked.Equals( pairk.Rinsetsu2 ) )
					{
						pairk.Rinsetsu2 = isChecked;
					}
					break;
				case 2:
					if ( !isChecked.Equals( pairk.Rinsetsu3 ) )
					{
						pairk.Rinsetsu3 = isChecked;
					}
					break;
				case 3:
					if ( !isChecked.Equals( pairk.Rinsetsu4 ) )
					{
						pairk.Rinsetsu4 = isChecked;
					}
					break;
				case 4:
					if ( !isChecked.Equals( pairk.Rinsetsu5 ) )
					{
						pairk.Rinsetsu5 = isChecked;
					}
					break;
				case 5:
					if ( !isChecked.Equals( pairk.Rinsetsu6 ) )
					{
						pairk.Rinsetsu6 = isChecked;
					}
					break;
				case 6:
					if ( !isChecked.Equals( pairk.Rinsetsu7 ) )
					{
						pairk.Rinsetsu7 = isChecked;
					}
					break;
				case 7:
					if ( !isChecked.Equals( pairk.Rinsetsu8 ) )
					{
						pairk.Rinsetsu8 = isChecked;
					}
					break;
				case 8:
					if ( !isChecked.Equals( pairk.Rinsetsu9 ) )
					{
						pairk.Rinsetsu9 = isChecked;
					}
					break;
				case 9:
					if ( !isChecked.Equals( pairk.Rinsetsu10 ) )
					{
						pairk.Rinsetsu10 = isChecked;
					}
					break;
				default:
					break;
			}
			Funcs.CheckKukakuHosei( n14pkb, pairk );
		}

		/// <summary>武将データ 配偶者設定処理フラグ</summary>
		private static bool _isInSetHaigusya = false;
		/// <summary>武将データ 配偶者設定</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="b">武将データ</param>
		/// <param name="ptrHaigusya">配偶者ポインタ</param>
		public static void SetHaigusya( N14PKB n14pkb, Busyou b, uint ptrHaigusya )
		{
			if ( Funcs._isInSetHaigusya ) { return; }

			Funcs._isInSetHaigusya = true;

			// 自身の既婚チェック
			var oldPtrHaigusya = b.PtrHaigusya;
			if ( oldPtrHaigusya != 0 )
			{
				// 既婚！ 離婚手続き
				n14pkb.Busyoulist[oldPtrHaigusya].PtrHaigusya = 0;
			}

			// 配偶者の既婚チェック
			var ptrHaigusyanoHaigusya = n14pkb.Busyoulist[ptrHaigusya].PtrHaigusya;
			if ( ptrHaigusyanoHaigusya != 0 )
			{

				// 既婚！ 離婚手続き
				n14pkb.Busyoulist[ptrHaigusyanoHaigusya].PtrHaigusya = 0;
			}

			// 配偶者の配偶者(つまり自分)設定
			n14pkb.Busyoulist[ptrHaigusya].PtrHaigusya = b.Address;

			if ( b.IsTousyu
				|| ( ( n14pkb.Busyoulist[ptrHaigusya] != null ) ? n14pkb.Busyoulist[ptrHaigusya].IsTousyu : false )
				|| ( ( n14pkb.Busyoulist[oldPtrHaigusya] != null ) ? n14pkb.Busyoulist[oldPtrHaigusya].IsTousyu : false )
				|| ( ( n14pkb.Busyoulist[ptrHaigusyanoHaigusya] != null ) ? n14pkb.Busyoulist[ptrHaigusyanoHaigusya].IsTousyu : false )
				)
			{
				// 登場人物の誰かが当主なら当事者以外にも一門チェックする必要がある
				n14pkb.View.Flags[(int)TabKind.武将].NeedsRefresh = true;
			}

			Funcs._isInSetHaigusya = false;
		}

		/// <summary>区画データ ランク補正チェックメソッド</summary>
		/// <param name="n14pkb"></param>
		/// <param name="k"></param>
		public static void CheckKukakuHosei( N14PKB n14pkb, Kukaku k )
		{
			for ( int i = 0; i < k.Shiro.Kukakulist.Length; i++ )
			{
				byte kokudakaHosei = 0;
				byte syougyouHosei = 0;
				byte heisyaHosei = 0;
				var shisetsu = n14pkb.Shisetsulist[k.Shiro.Kukakulist[i].ShisetsuID];

				if ( shisetsu != null )
				{
					kokudakaHosei = shisetsu.UpRankNougyou;		// 自区画施設の石高補正
					syougyouHosei = shisetsu.UpRankSyougyou;	// 自区画施設の商業補正
					heisyaHosei = shisetsu.UpRankHeisya;		// 自区画施設の兵舎補正
				}

				for ( int j = 0; j < k.Data.IsRinsetsu.Length; j++ )
				{
					if ( k.Shiro.Kukakulist[i].Data.IsRinsetsu[j] )
					{
						shisetsu = n14pkb.Shisetsulist[k.Shiro.Kukakulist[i].Shiro.Kukakulist[j].ShisetsuID];
						if ( null != shisetsu )
						{
							kokudakaHosei += shisetsu.UpRankNougyouRinsetsu;	// 隣接区画から受ける石高補正
							syougyouHosei += shisetsu.UpRankSyougyouRinsetsu;	// 隣接区画から受ける商業補正
							heisyaHosei += shisetsu.UpRankHeisyaRinsetsu;		// 隣接区画から受ける兵舎補正
						}
					}
				}
				k.Shiro.Kukakulist[i].KokudakaRankHosei = kokudakaHosei;
				k.Shiro.Kukakulist[i].SyougyouRankHosei = syougyouHosei;
				k.Shiro.Kukakulist[i].HeisyaRankHosei = heisyaHosei;
			}

			Funcs.CheckKukakuMaxValue( n14pkb, k );
		}

		/// <summary>区画データ 石高・商業・兵舎最大値計算メソッド(セーブ&ロードすれば勝手に再計算され書き換わる？)</summary>
		/// <param name="n14pkb"></param>
		/// <param name="k"></param>
		public static void CheckKukakuMaxValue( N14PKB n14pkb, Kukaku k )
		{
			var kokudakaMax = 0;
			var syougyouMax = 0;
			var heisyaMax = 0;

			var kType = n14pkb.Shisetsulist.GetKukakuTypeByID( k.ShisetsuID );
			switch ( kType )
			{
				case 0:	// 石高
					kokudakaMax = k.KukakuBase * 3 * ( ( ( k.KokudakaRankBase + k.KokudakaRankHosei ) <= 18 ) ? ( k.KokudakaRankBase + k.KokudakaRankHosei + 1 ) : 18 + 1 );
					break;
				case 1:	// 商業
					syougyouMax = k.KukakuBase * 3 * ( ( ( k.SyougyouRankBase + k.SyougyouRankHosei ) <= 18 ) ? ( k.SyougyouRankBase + k.SyougyouRankHosei + 1 ) : 18 + 1 );
					break;
				case 2:	// 兵舎
					heisyaMax = k.KukakuBase * 3 * ( ( ( k.HeisyaRankBase + k.HeisyaRankHosei ) <= 18 ) ? ( k.HeisyaRankBase + k.HeisyaRankHosei + 1 ) : 18 + 1 );
					break;
				default:
					if ( 0 != k.KokudakaMax )
					{
						kokudakaMax = k.KukakuBase * 3 * ( ( ( k.KokudakaRankBase + k.KokudakaRankHosei ) <= 18 ) ? ( k.KokudakaRankBase + k.KokudakaRankHosei + 1 ) : 18 + 1 );
					}
					else if ( 0 != k.SyougyouMax )
					{
						syougyouMax = k.KukakuBase * 3 * ( ( ( k.SyougyouRankBase + k.SyougyouRankHosei ) <= 18 ) ? ( k.SyougyouRankBase + k.SyougyouRankHosei + 1 ) : 18 + 1 );
					}
					else if ( 0 != k.HeisyaMax )
					{
						heisyaMax = k.KukakuBase * 3 * ( ( ( k.HeisyaRankBase + k.HeisyaRankHosei ) <= 18 ) ? ( k.HeisyaRankBase + k.HeisyaRankHosei + 1 ) : 18 + 1 );
					}
					break;
			}
			k.KokudakaMax = (short)kokudakaMax;
			k.SyougyouMax = (short)syougyouMax;
			k.HeisyaMax = (short)heisyaMax;
		}

		/// <summary>家宝設定処理フラグ</summary>
		private static bool _isInSetKahou = false;
		/// <summary>家宝設定</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="busyou">武将データ</param>
		/// <param name="kahou">家宝データ</param>
		public static void SetKahou( N14PKB n14pkb, Busyou busyou, Kahou kahou )
		{
			if ( Funcs._isInSetKahou ) { return; }
			Funcs._isInSetKahou = true;

			// 武将データに現在設定されている保有家宝ポインタ
			var oldPtrKahou = ( busyou != null ) ? busyou.PtrKahou : 0;

			// 家宝データに現在設定されている保有武将ポインタ
			var oldPtrBusyou = ( kahou != null ) ? kahou.PtrHoyuuBusyou : 0;

			if ( oldPtrKahou != 0 )
			{
				// 現在保有している家宝の保有武将クリア
				n14pkb.Kahoulist[oldPtrKahou].PtrHoyuuBusyou = 0;
				n14pkb.Kahoulist[oldPtrKahou].h44_b0 = false;
			}

			if ( oldPtrBusyou != 0 )
			{
				// 現在保有している武将の保有家宝クリア
				n14pkb.Busyoulist[oldPtrBusyou].PtrKahou = 0;
				kahou.h44_b0 = false;
			}

			if ( busyou != null && kahou != null )
			{
				// これをONにしないとゲーム内の情報一覧で表示されない(イベント関連のフラグ Bt1_44 もあるがよくわからないので触らない)
				kahou.h44_b0 = true;

				// 家宝データのチェック
				if ( kahou.PtrHoyuuSeiryoku != 0 )
				{
					// 保有勢力が設定されている家宝
					var seiryoku = n14pkb.Seiryokulist[kahou.PtrHoyuuSeiryoku];

					// 勢力クリアと勢力の保有家宝リストから削除
					kahou.PtrHoyuuSeiryoku = 0;
					seiryoku.KahouList.RemoveByTargetDataAddress( kahou.Address );
					seiryoku.CntKahouList = seiryoku.KahouList.Count;
				}

				// 設定する保有家宝保有武将に自身をセット
				kahou.PtrHoyuuBusyou = busyou.Address;

				// 設定する保有武将の保有家宝に自身(家宝)をセット
				busyou.PtrKahou = kahou.Address;
			}

			Funcs._isInSetKahou = false;
		}
		/// <summary>家宝設定 オーバーロード(武将データからの呼び出し用)</summary>
		public static void SetKahou( N14PKB n14pkb, Busyou busyou, uint ptrKahou ) { SetKahou( n14pkb, busyou, n14pkb.Kahoulist[ptrKahou] ); }
		/// <summary>家宝設定 オーバーロード(家宝データからの呼び出し用)</summary>
		public static void SetKahou( N14PKB n14pkb, Kahou kahou, uint ptrBusyou ) { SetKahou( n14pkb, n14pkb.Busyoulist[ptrBusyou], kahou ); }
	}
}
