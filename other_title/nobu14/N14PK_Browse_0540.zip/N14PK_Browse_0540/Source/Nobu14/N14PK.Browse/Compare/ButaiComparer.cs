﻿// ButaiComparer.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using N14PKBrowse.Data;

namespace N14PKBrowse.Compare
{
	// 比較オブジェクト 部隊
	public class ButaiComparer : AbstractComparer
	{
		/// <summary>比較用コールバックデリゲート 部隊</summary>
		private delegate int SubCallback( Butai x, Butai y, bool isAsc );

		/// <summary>比較用コールバックデリゲート 部隊</summary>
		private SubCallback _subCallback;


		/// <summary>コールバックデリゲートを取得する</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <returns>コールバックデリゲート</returns>
		public override CompareCallback GetCallback( string propertyName )
		{
			var type = this.GetType();
			// メソッド情報取得
			var mi = type.GetMethod( _CallbackPrefix + propertyName, BindingFlags.NonPublic | BindingFlags.Instance );
			if ( mi == null )
			{
				return null;
			}
			// デリゲート作成
			this._subCallback = (SubCallback)Delegate.CreateDelegate( typeof( SubCallback ), this, mi );
			this._callback = this.CompareCallback;
			return ( this._subCallback != null ) ? this._callback : null;
		}

		/// <summary>コールバックデリゲートを設定する(ICompare を使用するカスタムソート用)</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <param name="isAsc">ソートオーダー</param>
		/// <returns>デリゲートが取得できたら true を返す</returns>
		public override bool SetCallback( string propertyName, bool isAsc )
		{
			this._isAsc = isAsc;
			this._callback = this.GetCallback( propertyName );
			return ( this._callback != null ) ? true : false;
		}

		/// <summary>ソート時に使用するコールバック</summary>
		private int CompareCallback( object x, object y, bool isAsc )
		{
			return this._subCallback( x as Butai, y as Butai, isAsc );
		}

		#region コールバックメソッド
		private int CmpSeiryokuname( Butai x, Butai y, bool isAsc )			// 勢力
		{
			var x_id = x.SortID;
			var y_id = y.SortID;
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}

		private int CmpSyozokuKyoten( Butai x, Butai y, bool isAsc )		// 拠点
		{
			var x_id = x.N14pkb.Yousyolist.GetSortIDByKyotenAddress( x.Data.PtrKyoten );
			var y_id = y.N14pkb.Yousyolist.GetSortIDByKyotenAddress( y.Data.PtrKyoten );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}

		private int CmpName( Butai x, Butai y, bool isAsc )		// 部隊名
		{
			var x_busyou = x.N14pkb.Busyoulist[x.Name.Replace( "隊", string.Empty )];
			var y_busyou = y.N14pkb.Busyoulist[y.Name.Replace( "隊", string.Empty )];
			var x_yomi = ( x_busyou != null ) ? x_busyou.Yomi : string.Empty;
			var y_yomi = ( y_busyou != null ) ? y_busyou.Yomi : string.Empty;
			return x_yomi.Equals( y_yomi ) ? 0
				: ( x_yomi == string.Empty ) ? isAsc ? 1 : -1
				: ( y_yomi == string.Empty ) ? isAsc ? -1 : 1
				: x_yomi.CompareTo( y_yomi );
		}
		#endregion
	}
}
