﻿// BusyouComparer.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using N14PKBrowse.Data;

namespace N14PKBrowse.Compare
{
	// 比較オブジェクト 武将
	public class BusyouComparer : AbstractComparer
	{
		/// <summary>比較用コールバックデリゲート 武将</summary>
		private delegate int SubCallback( Busyou x, Busyou y, bool isAsc );

		/// <summary>比較用コールバックデリゲート 武将</summary>
		private SubCallback _subCallback;


		/// <summary>コールバックデリゲートを取得する</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <returns>コールバックデリゲート</returns>
		public override CompareCallback GetCallback( string propertyName )
		{
			var type = this.GetType();
			// メソッド情報取得
			var mi = type.GetMethod( _CallbackPrefix + propertyName, BindingFlags.NonPublic | BindingFlags.Instance );
			if ( mi == null )
			{
				return null;
			}
			// デリゲート作成
			this._subCallback = (SubCallback)Delegate.CreateDelegate( typeof( SubCallback ), this, mi );
			this._callback = this.CompareCallback;
			return ( this._subCallback != null ) ? this._callback : null;
		}

		/// <summary>コールバックデリゲートを設定する(ICompare を使用するカスタムソート用)</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <param name="isAsc">ソートオーダー</param>
		/// <returns>デリゲートが取得できたら true を返す</returns>
		public override bool SetCallback( string propertyName, bool isAsc )
		{
			this._isAsc = isAsc;
			this._callback = this.GetCallback( propertyName );
			return ( this._callback != null ) ? true : false;
		}

		/// <summary>ソート時に使用するコールバック</summary>
		private int CompareCallback( object x, object y, bool isAsc )
		{
			return this._subCallback( x as Busyou, y as Busyou, isAsc );
		}

		#region コールバックメソッド
		private int CmpName( Busyou x, Busyou y, bool isAsc )			// 武将名称
		{
			return x.Yomi.Equals( y.Yomi ) ? 0
				: ( x.Yomi == string.Empty ) ? isAsc ? 1 : -1
				: ( y.Yomi == string.Empty ) ? isAsc ? -1 : 1
				: x.Yomi.CompareTo( y.Yomi );
		}
		private int CmpChichi( Busyou x, Busyou y, bool isAsc )			// 実父
		{
			var x_yomi = ( x.N14pkb.Busyoulist[x.Data.PtrChichi] != null ) ? x.N14pkb.Busyoulist[x.Data.PtrChichi].Yomi : string.Empty;
			var y_yomi = ( y.N14pkb.Busyoulist[y.Data.PtrChichi] != null ) ? y.N14pkb.Busyoulist[y.Data.PtrChichi].Yomi : string.Empty;

			return x_yomi.Equals( y_yomi ) ? 0
				: ( x_yomi == string.Empty ) ? isAsc ? 1 : -1
				: ( y_yomi == string.Empty ) ? isAsc ? -1 : 1
				: x_yomi.CompareTo( y_yomi );
		}
		private int CmpYoufu( Busyou x, Busyou y, bool isAsc )			// 養父
		{
			var x_yomi = ( x.N14pkb.Busyoulist[x.Data.PtrYoufu] != null ) ? x.N14pkb.Busyoulist[x.Data.PtrYoufu].Yomi : string.Empty;
			var y_yomi = ( y.N14pkb.Busyoulist[y.Data.PtrYoufu] != null ) ? y.N14pkb.Busyoulist[y.Data.PtrYoufu].Yomi : string.Empty;

			return x_yomi.Equals( y_yomi ) ? 0
				: ( x_yomi == string.Empty ) ? isAsc ? 1 : -1
				: ( y_yomi == string.Empty ) ? isAsc ? -1 : 1
				: x_yomi.CompareTo( y_yomi );
		}
		private int CmpHaigusya( Busyou x, Busyou y, bool isAsc )		// 配偶者
		{
			var x_yomi = ( x.N14pkb.Busyoulist[x.Data.PtrHaigusya] != null ) ? x.N14pkb.Busyoulist[x.Data.PtrHaigusya].Yomi : string.Empty;
			var y_yomi = ( y.N14pkb.Busyoulist[y.Data.PtrHaigusya] != null ) ? y.N14pkb.Busyoulist[y.Data.PtrHaigusya].Yomi : string.Empty;

			return x_yomi.Equals( y_yomi ) ? 0
				: ( x_yomi == string.Empty ) ? isAsc ? 1 : -1
				: ( y_yomi == string.Empty ) ? isAsc ? -1 : 1
				: x_yomi.CompareTo( y_yomi );
		}
		private int CmpHaha( Busyou x, Busyou y, bool isAsc )			// 母
		{
			var x_yomi = ( x.N14pkb.Busyoulist[x.Data.PtrHaha] != null ) ? x.N14pkb.Busyoulist[x.Data.PtrHaha].Yomi : string.Empty;
			var y_yomi = ( y.N14pkb.Busyoulist[y.Data.PtrHaha] != null ) ? y.N14pkb.Busyoulist[y.Data.PtrHaha].Yomi : string.Empty;

			return x_yomi.Equals( y_yomi ) ? 0
				: ( x_yomi == string.Empty ) ? isAsc ? 1 : -1
				: ( y_yomi == string.Empty ) ? isAsc ? -1 : 1
				: x_yomi.CompareTo( y_yomi );
		}
		private int CmpPtrKyoten( Busyou x, Busyou y, bool isAsc )		// 拠点
		{
			var x_id = x.N14pkb.Shirolist.GetSortIDByAddress( x.PtrKyoten );
			var y_id = y.N14pkb.Shirolist.GetSortIDByAddress( y.PtrKyoten );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}
		private int CmpPtrGundan( Busyou x, Busyou y, bool isAsc )		// 軍団
		{
			var x_id = x.N14pkb.Gundanlist.GetSortIDByAddress( x.Data.PtrGundan );
			var y_id = y.N14pkb.Gundanlist.GetSortIDByAddress( y.Data.PtrGundan );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}
		private int CmpSeichougataID( Busyou x, Busyou y, bool isAsc )		// 成長型
		{
			var x_id = ( x.N14pkb.Seichougatalist[x.Data.SeichougataID] != null ) ? x.N14pkb.Seichougatalist[x.Data.SeichougataID].SortID : -1;
			var y_id = ( y.N14pkb.Seichougatalist[y.Data.SeichougataID] != null ) ? y.N14pkb.Seichougatalist[y.Data.SeichougataID].SortID : -1;
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}
		private int CmpSouzou( Busyou x, Busyou y, bool isAsc )		// 主義(創造)
		{
			return ( x.Data.Souzou == y.Data.Souzou ) ? 0
				: ( x.Data.Souzou == 0 ) ? isAsc ? 1 : -1
				: ( y.Data.Souzou == 0 ) ? isAsc ? -1 : 1
				: x.Data.Souzou - y.Data.Souzou;
		}
		private int CmpTousotsu( Busyou x, Busyou y, bool isAsc )		// 統率
		{
			return ( x.Data.Tousotsu + x.Data.TousotsuExp / 100 != y.Data.Tousotsu + y.Data.TousotsuExp / 100 ) ? ( x.Data.Tousotsu + x.Data.TousotsuExp / 100 ) - ( y.Data.Tousotsu + y.Data.TousotsuExp / 100 )
				: ( x.Data.Tousotsu - y.Data.Tousotsu );
		}
		private int CmpBuyuu( Busyou x, Busyou y, bool isAsc )			// 武勇
		{
			return ( x.Data.Buyuu + x.Data.BuyuuExp / 100 != y.Data.Buyuu + y.Data.BuyuuExp / 100 ) ? ( x.Data.Buyuu + x.Data.BuyuuExp / 100 ) - ( y.Data.Buyuu + y.Data.BuyuuExp / 100 )
				: ( x.Data.Buyuu - y.Data.Buyuu );
		}
		private int CmpChiryaku( Busyou x, Busyou y, bool isAsc )		// 知略
		{
			return ( x.Data.Chiryaku + x.Data.ChiryakuExp / 100 != y.Data.Chiryaku + y.Data.ChiryakuExp / 100 ) ? ( x.Data.Chiryaku + x.Data.ChiryakuExp / 100 ) - ( y.Data.Chiryaku + y.Data.ChiryakuExp / 100 )
				: ( x.Data.Chiryaku - y.Data.Chiryaku );
		}
		private int CmpSeiji( Busyou x, Busyou y, bool isAsc )			// 政治
		{
			return ( x.Data.Seiji + x.Data.SeijiExp / 100 != y.Data.Seiji + y.Data.SeijiExp / 100 ) ? ( x.Data.Seiji + x.Data.SeijiExp / 100 ) - ( y.Data.Seiji + y.Data.SeijiExp / 100 )
				: ( x.Data.Seiji - y.Data.Seiji );
		}
		#endregion
	}
}
