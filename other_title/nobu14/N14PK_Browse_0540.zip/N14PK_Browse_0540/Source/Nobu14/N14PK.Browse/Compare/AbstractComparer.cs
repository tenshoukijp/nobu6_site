﻿// AbstractComparer.cs

using System.Collections;

namespace N14PKBrowse.Compare
{
	/// <summary>比較用コールバックデリゲート</summary>
	public delegate int CompareCallback( object x, object y, bool isAsc );

	/// <summary>比較用オブジェクト ※コールバック用メソッドは派生クラスで実装する</summary>
	public abstract class AbstractComparer : IComparer
	{
		/// <summary>コールバックメソッド名に付けるプレフィクス ※メソッド呼び出し時に "プレフィクス+プロパティ名" で呼ぶ</summary>
		protected const string _CallbackPrefix = "Cmp";

		/// <summary>比較結果</summary>
		protected int _result;

		/// <summary>オーダー</summary>
		protected bool _isAsc;

		/// <summary>コールバックデリゲート</summary>
		protected CompareCallback _callback;

		/// <summary>コールバックデリゲート</summary>
		public CompareCallback Callback
		{
			get { return this._callback; }
		}

		/// <summary>コールバックデリゲートを取得する</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <returns>コールバックデリゲート</returns>
		public abstract CompareCallback GetCallback( string propertyName );

		/// <summary>コールバックデリゲートを設定する(ICompare を使用するカスタムソート用)</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <param name="isAsc">ソートオーダー</param>
		/// <returns>デリゲートが取得できたら true を返す</returns>
		public abstract bool SetCallback( string propertyName, bool isAsc );

		// IComparer メンバ実装
		public int Compare( object x, object y )
		{
			//// null が最も小さいとする
			//if ( null == x && null == y ) { return 0; }
			//if ( null == x ) { return -1; }
			//if ( null == y ) { return 1; }
			this._result = this._callback( x, y, this._isAsc );
			return this._isAsc ? this._result : -this._result;
		}
	}
}
