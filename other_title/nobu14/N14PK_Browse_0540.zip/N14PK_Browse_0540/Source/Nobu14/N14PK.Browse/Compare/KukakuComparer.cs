﻿// KukakuComparer.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using N14PKBrowse.Data;

namespace N14PKBrowse.Compare
{
	// 比較オブジェクト 区画
	public class KukakuComparer : AbstractComparer
	{
		/// <summary>比較用コールバックデリゲート 区画</summary>
		private delegate int SubCallback( Kukaku x, Kukaku y, bool isAsc );

		/// <summary>比較用コールバックデリゲート 区画</summary>
		private SubCallback _subCallback;


		/// <summary>コールバックデリゲートを取得する</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <returns>コールバックデリゲート</returns>
		public override CompareCallback GetCallback( string propertyName )
		{
			var type = this.GetType();
			// メソッド情報取得
			var mi = type.GetMethod( _CallbackPrefix + propertyName, BindingFlags.NonPublic | BindingFlags.Instance );
			if ( mi == null )
			{
				return null;
			}
			// デリゲート作成
			this._subCallback = (SubCallback)Delegate.CreateDelegate( typeof( SubCallback ), this, mi );
			this._callback = this.CompareCallback;
			return ( this._subCallback != null ) ? this._callback : null;
		}

		/// <summary>コールバックデリゲートを設定する(ICompare を使用するカスタムソート用)</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <param name="isAsc">ソートオーダー</param>
		/// <returns>デリゲートが取得できたら true を返す</returns>
		public override bool SetCallback( string propertyName, bool isAsc )
		{
			this._isAsc = isAsc;
			this._callback = this.GetCallback( propertyName );
			return ( this._callback != null ) ? true : false;
		}

		/// <summary>ソート時に使用するコールバック</summary>
		private int CompareCallback( object x, object y, bool isAsc )
		{
			return this._subCallback( x as Kukaku, y as Kukaku, isAsc );
		}

		#region コールバックメソッド
		private int CmpGundanname( Kukaku x, Kukaku y, bool isAsc )			// 所属
		{
			var x_id = ( x.Gundan != null ) ? x.Gundan.SortID : -1;
			var y_id = ( y.Gundan != null ) ? y.Gundan.SortID : -1;
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}

		private int CmpKuni( Kukaku x, Kukaku y, bool isAsc )		// 国
		{
			var x_id = (int)x.N14pkb.Kunilist.GetAddressByName( x.Kuni );
			var y_id = (int)y.N14pkb.Kunilist.GetAddressByName( y.Kuni );
			return ( x_id == y_id ) ? 0
				: ( x_id == 0 ) ? isAsc ? 1 : -1
				: ( y_id == 0 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}

		private int CmpShironame( Kukaku x, Kukaku y, bool isAsc )		// 城
		{
			var x_id = x.N14pkb.Shirolist.GetSortIDByAddress( x.Data.PtrShiro1 );
			var y_id = y.N14pkb.Shirolist.GetSortIDByAddress( y.Data.PtrShiro1 );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}
		#endregion
	}
}
