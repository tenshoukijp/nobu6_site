﻿// GundanComparer.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using N14PKBrowse.Data;

namespace N14PKBrowse.Compare
{
	// 比較オブジェクト 軍団
	public class GundanComparer : AbstractComparer
	{
		/// <summary>比較用コールバックデリゲート 軍団</summary>
		private delegate int SubCallback( Gundan x, Gundan y, bool isAsc );

		/// <summary>比較用コールバックデリゲート 軍団</summary>
		private SubCallback _subCallback;


		/// <summary>コールバックデリゲートを取得する</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <returns>コールバックデリゲート</returns>
		public override CompareCallback GetCallback( string propertyName )
		{
			var type = this.GetType();
			// メソッド情報取得
			var mi = type.GetMethod( _CallbackPrefix + propertyName, BindingFlags.NonPublic | BindingFlags.Instance );
			if ( mi == null )
			{
				return null;
			}
			// デリゲート作成
			this._subCallback = (SubCallback)Delegate.CreateDelegate( typeof( SubCallback ), this, mi );
			this._callback = this.CompareCallback;
			return ( this._subCallback != null ) ? this._callback : null;
		}

		/// <summary>コールバックデリゲートを設定する(ICompare を使用するカスタムソート用)</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <param name="isAsc">ソートオーダー</param>
		/// <returns>デリゲートが取得できたら true を返す</returns>
		public override bool SetCallback( string propertyName, bool isAsc )
		{
			this._isAsc = isAsc;
			this._callback = this.GetCallback( propertyName );
			return ( this._callback != null ) ? true : false;
		}

		/// <summary>ソート時に使用するコールバック</summary>
		private int CompareCallback( object x, object y, bool isAsc )
		{
			return this._subCallback( x as Gundan, y as Gundan, isAsc );
		}

		#region コールバックメソッド
		private int CmpSeiryokuname( Gundan x, Gundan y, bool isAsc )			// 勢力
		{
			return x.SortID - y.SortID;
		}
		private int CmpGundanchouname( Gundan x, Gundan y, bool isAsc )			// 軍団長
		{
			return x.N14pkb.Busyoulist[x.Data.PtrGundanchou].Yomi.Equals( y.N14pkb.Busyoulist[y.Data.PtrGundanchou].Yomi ) ? 0
				: ( x.N14pkb.Busyoulist[x.Data.PtrGundanchou].Yomi == string.Empty ) ? isAsc ? 1 : -1
				: ( y.N14pkb.Busyoulist[y.Data.PtrGundanchou].Yomi == string.Empty ) ? isAsc ? -1 : 1
				: x.N14pkb.Busyoulist[x.Data.PtrGundanchou].Yomi.CompareTo( y.N14pkb.Busyoulist[y.Data.PtrGundanchou].Yomi );
		}
		#endregion
	}
}
