﻿// TokuseiSyuutokuJouken.cs

using System;
using System.Reflection;
using N14PKBrowse.Data;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Compare
{
	// 比較オブジェクト 特性習得条件
	public class TokuseiSyuutokuJoukenComparer : AbstractComparer
	{
		/// <summary>比較用コールバックデリゲート 特性習得条件</summary>
		private delegate int SubCallback( Seichougata x, Seichougata y, bool isAsc );

		/// <summary>比較用コールバックデリゲート 特性習得条件</summary>
		private SubCallback _subCallback;


		/// <summary>コールバックデリゲートを取得する</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <returns>コールバックデリゲート</returns>
		public override CompareCallback GetCallback( string propertyName )
		{
			var type = this.GetType();
			// メソッド情報取得
			var mi = type.GetMethod( _CallbackPrefix + propertyName, BindingFlags.NonPublic | BindingFlags.Instance );
			if ( mi == null )
			{
				return null;
			}
			// デリゲート作成
			this._subCallback = (SubCallback)Delegate.CreateDelegate( typeof( SubCallback ), this, mi );
			this._callback = this.CompareCallback;
			return ( this._subCallback != null ) ? this._callback : null;
		}

		/// <summary>コールバックデリゲートを設定する(ICompare を使用するカスタムソート用)</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <param name="isAsc">ソートオーダー</param>
		/// <returns>デリゲートが取得できたら true を返す</returns>
		public override bool SetCallback( string propertyName, bool isAsc )
		{
			this._isAsc = isAsc;
			this._callback = this.GetCallback( propertyName );
			return ( this._callback != null ) ? true : false;
		}

		/// <summary>ソート時に使用するコールバック</summary>
		private int CompareCallback( object x, object y, bool isAsc )
		{
			return this._subCallback( x as Seichougata, y as Seichougata, isAsc );
		}

		#region コールバックメソッド
		//private int CmpName( Seichougata x, Seichougata y, bool isAsc )
		//{
		//	return x.Name.Equals( y.Name ) ? 0
		//		: ( x.Name == string.Empty ) ? isAsc ? 1 : -1
		//		: ( y.Name == string.Empty ) ? isAsc ? -1 : 1
		//		: x.Name.CompareTo( y.Name );
		//}
		//private int CmpTokusei001( Seichougata x, Seichougata y, bool isAsc )		// 特性001
		//{
		//	return ( x.Data.TokuseiSyuutokuJoukenIDList[000] - y.Data.TokuseiSyuutokuJoukenIDList[000] == 0 ) ? 0
		//		: ( x.Data.TokuseiSyuutokuJoukenIDList[000] == -1 ) ? isAsc ? 1 : -1
		//		: ( y.Data.TokuseiSyuutokuJoukenIDList[000] == -1 ) ? isAsc ? -1 : 1
		//		: x.Data.TokuseiSyuutokuJoukenIDList[000] - y.Data.TokuseiSyuutokuJoukenIDList[000];
		//}
		#endregion
	}
}
