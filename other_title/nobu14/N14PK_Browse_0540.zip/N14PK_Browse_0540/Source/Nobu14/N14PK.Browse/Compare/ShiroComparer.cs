﻿// ShiroComparer.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using N14PKBrowse.Data;

namespace N14PKBrowse.Compare
{
	// 比較オブジェクト 城
	public class ShiroComparer : AbstractComparer
	{
		/// <summary>比較用コールバックデリゲート 城</summary>
		private delegate int SubCallback( Shiro x, Shiro y, bool isAsc );

		/// <summary>比較用コールバックデリゲート 城</summary>
		private SubCallback _subCallback;


		/// <summary>コールバックデリゲートを取得する</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <returns>コールバックデリゲート</returns>
		public override CompareCallback GetCallback( string propertyName )
		{
			var type = this.GetType();
			// メソッド情報取得
			var mi = type.GetMethod( _CallbackPrefix + propertyName, BindingFlags.NonPublic | BindingFlags.Instance );
			if ( mi == null )
			{
				return null;
			}
			// デリゲート作成
			this._subCallback = (SubCallback)Delegate.CreateDelegate( typeof( SubCallback ), this, mi );
			this._callback = this.CompareCallback;
			return ( this._subCallback != null ) ? this._callback : null;
		}

		/// <summary>コールバックデリゲートを設定する(ICompare を使用するカスタムソート用)</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <param name="isAsc">ソートオーダー</param>
		/// <returns>デリゲートが取得できたら true を返す</returns>
		public override bool SetCallback( string propertyName, bool isAsc )
		{
			this._isAsc = isAsc;
			this._callback = this.GetCallback( propertyName );
			return ( this._callback != null ) ? true : false;
		}

		/// <summary>ソート時に使用するコールバック</summary>
		private int CompareCallback( object x, object y, bool isAsc )
		{
			return this._subCallback( x as Shiro, y as Shiro, isAsc );
		}

		#region コールバックメソッド
		//private int CmpName( Shiro x, Shiro y, bool isAsc )			// 城名称
		//{
		//	return x.Yomi.Equals( y.Yomi ) ? 0
		//		: ( x.Yomi == string.Empty ) ? isAsc ? 1 : -1
		//		: ( y.Yomi == string.Empty ) ? isAsc ? -1 : 1
		//		: x.Yomi.CompareTo( y.Yomi );
		//}
		private int CmpName( Shiro x, Shiro y, bool isAsc )		// 城名称
		{
			var x_id = x.SortID;
			var y_id = y.SortID;
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}
		private int CmpPtrGundan( Shiro x, Shiro y, bool isAsc )		// 軍団
		{
			var x_id = x.N14pkb.Gundanlist.GetSortIDByAddress( x.Data.PtrGundan );
			var y_id = y.N14pkb.Gundanlist.GetSortIDByAddress( y.Data.PtrGundan );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}
		private int CmpYouchiInfo( Shiro x, Shiro y, bool isAsc )		// 用地情報
		{
			return ( x.YouchiSizeMax == y.YouchiSizeMax ) ? x.YouchiSizeUsed- y.YouchiSizeUsed
				: x.YouchiSizeMax - y.YouchiSizeMax;
		}
		private int CmpKukakuInfo( Shiro x, Shiro y, bool isAsc )		// 区画情報
		{

			return ( x.KukakuUsed - x.KukakuCountKakuchou == y.KukakuUsed - y.KukakuCountKakuchou ) ?
				( x.Data.KukakuMax == y.Data.KukakuMax ) ? x.KukakuCountKakuchou- y.KukakuCountKakuchou
				: x.Data.KukakuMax - y.Data.KukakuMax
				: ( x.KukakuUsed - x.KukakuCountKakuchou ) - ( y.KukakuUsed - y.KukakuCountKakuchou );
		}
		#endregion
	}
}
