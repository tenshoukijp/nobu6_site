﻿// KokujinComparer.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using N14PKBrowse.Data;

namespace N14PKBrowse.Compare
{
	// 比較オブジェクト 国人衆
	public class KokujinComparer : AbstractComparer
	{
		/// <summary>比較用コールバックデリゲート 国人衆</summary>
		private delegate int SubCallback( Kokujin x, Kokujin y, bool isAsc );

		/// <summary>比較用コールバックデリゲート 国人衆</summary>
		private SubCallback _subCallback;


		/// <summary>コールバックデリゲートを取得する</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <returns>コールバックデリゲート</returns>
		public override CompareCallback GetCallback( string propertyName )
		{
			var type = this.GetType();
			// メソッド情報取得
			var mi = type.GetMethod( _CallbackPrefix + propertyName, BindingFlags.NonPublic | BindingFlags.Instance );
			if ( mi == null )
			{
				return null;
			}
			// デリゲート作成
			this._subCallback = (SubCallback)Delegate.CreateDelegate( typeof( SubCallback ), this, mi );
			this._callback = this.CompareCallback;
			return ( this._subCallback != null ) ? this._callback : null;
		}

		/// <summary>コールバックデリゲートを設定する(ICompare を使用するカスタムソート用)</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <param name="isAsc">ソートオーダー</param>
		/// <returns>デリゲートが取得できたら true を返す</returns>
		public override bool SetCallback( string propertyName, bool isAsc )
		{
			this._isAsc = isAsc;
			this._callback = this.GetCallback( propertyName );
			return ( this._callback != null ) ? true : false;
		}

		/// <summary>ソート時に使用するコールバック</summary>
		private int CompareCallback( object x, object y, bool isAsc )
		{
			return this._subCallback( x as Kokujin, y as Kokujin, isAsc );
		}

		#region コールバックメソッド
		private int CmpName( Kokujin x, Kokujin y, bool isAsc )			// 国人衆名称
		{
			return x.Yomi.Equals( y.Yomi ) ? 0
				: ( x.Yomi == string.Empty ) ? isAsc ? 1 : -1
				: ( y.Yomi == string.Empty ) ? isAsc ? -1 : 1
				: x.Yomi.CompareTo( y.Yomi );
		}

		private int CmpKuni( Kokujin x, Kokujin y, bool isAsc )			// 国
		{
			return x.Yousyo.SortID - y.Yousyo.SortID;
		}

		private int CmpYousyoname( Kokujin x, Kokujin y, bool isAsc )			// 要所
		{
			return x.Yousyo.Yomi.Equals( y.Yousyo.Yomi ) ? 0
				: ( x.Yousyo.Yomi == string.Empty ) ? isAsc ? 1 : -1
				: ( y.Yousyo.Yomi == string.Empty ) ? isAsc ? -1 : 1
				: x.Yousyo.Yomi.CompareTo( y.Yousyo.Yomi );
		}
		private int CmpTorikomiBusyou( Kokujin x, Kokujin y, bool isAsc )		// 取込武将
		{
			var x_yomi = ( x.N14pkb.Busyoulist[x.Data.PtrTorikomiBusyou] != null ) ? x.N14pkb.Busyoulist[x.Data.PtrTorikomiBusyou].Yomi : string.Empty;
			var y_yomi = ( y.N14pkb.Busyoulist[y.Data.PtrTorikomiBusyou] != null ) ? y.N14pkb.Busyoulist[y.Data.PtrTorikomiBusyou].Yomi : string.Empty;

			return x_yomi.Equals( y_yomi ) ? 0
				: ( x_yomi == string.Empty ) ? isAsc ? 1 : -1
				: ( y_yomi == string.Empty ) ? isAsc ? -1 : 1
				: x_yomi.CompareTo( y_yomi );
		}
		private int CmpPtrSyozokuSeiryoku( Kokujin x, Kokujin y, bool isAsc )		// 所属勢力
		{
			var x_id = x.N14pkb.Seiryokulist.GetSortIDByAddress( x.PtrSyozokuSeiryoku );
			var y_id = y.N14pkb.Seiryokulist.GetSortIDByAddress( y.PtrSyozokuSeiryoku );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}

		private int CmpPtrShijiSeiryoku1( Kokujin x, Kokujin y, bool isAsc )		// 勢力1
		{
			var x_id = x.N14pkb.Seiryokulist.GetSortIDByAddress( x.PtrShijiSeiryoku1 );
			var y_id = y.N14pkb.Seiryokulist.GetSortIDByAddress( y.PtrShijiSeiryoku1 );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}

		private int CmpPtrShijiSeiryoku2( Kokujin x, Kokujin y, bool isAsc )		// 勢力2
		{
			var x_id = x.N14pkb.Seiryokulist.GetSortIDByAddress( x.PtrShijiSeiryoku2 );
			var y_id = y.N14pkb.Seiryokulist.GetSortIDByAddress( y.PtrShijiSeiryoku2 );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}

		private int CmpPtrShijiSeiryoku3( Kokujin x, Kokujin y, bool isAsc )		// 勢力3
		{
			var x_id = x.N14pkb.Seiryokulist.GetSortIDByAddress( x.PtrShijiSeiryoku3 );
			var y_id = y.N14pkb.Seiryokulist.GetSortIDByAddress( y.PtrShijiSeiryoku3 );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}

		private int CmpPtrShijiSeiryoku4( Kokujin x, Kokujin y, bool isAsc )		// 勢力4
		{
			var x_id = x.N14pkb.Seiryokulist.GetSortIDByAddress( x.PtrShijiSeiryoku4 );
			var y_id = y.N14pkb.Seiryokulist.GetSortIDByAddress( y.PtrShijiSeiryoku4 );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}

		private int CmpPtrShijiSeiryoku5( Kokujin x, Kokujin y, bool isAsc )		// 勢力5
		{
			var x_id = x.N14pkb.Seiryokulist.GetSortIDByAddress( x.PtrShijiSeiryoku5 );
			var y_id = y.N14pkb.Seiryokulist.GetSortIDByAddress( y.PtrShijiSeiryoku5 );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}

		private int CmpPtrShijiSeiryoku6( Kokujin x, Kokujin y, bool isAsc )		// 勢力6
		{
			var x_id = x.N14pkb.Seiryokulist.GetSortIDByAddress( x.PtrShijiSeiryoku6 );
			var y_id = y.N14pkb.Seiryokulist.GetSortIDByAddress( y.PtrShijiSeiryoku6 );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}

		#endregion
	}
}
