﻿// KaidouComparer.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using N14PKBrowse.Data;

namespace N14PKBrowse.Compare
{
	// 比較オブジェクト 街道
	public class KaidouComparer : AbstractComparer
	{
		/// <summary>比較用コールバックデリゲート 街道</summary>
		private delegate int SubCallback( Kaidou x, Kaidou y, bool isAsc );

		/// <summary>比較用コールバックデリゲート 街道</summary>
		private SubCallback _subCallback;


		/// <summary>コールバックデリゲートを取得する</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <returns>コールバックデリゲート</returns>
		public override CompareCallback GetCallback( string propertyName )
		{
			var type = this.GetType();
			// メソッド情報取得
			var mi = type.GetMethod( _CallbackPrefix + propertyName, BindingFlags.NonPublic | BindingFlags.Instance );
			if ( mi == null )
			{
				return null;
			}
			// デリゲート作成
			this._subCallback = (SubCallback)Delegate.CreateDelegate( typeof( SubCallback ), this, mi );
			this._callback = this.CompareCallback;
			return ( this._subCallback != null ) ? this._callback : null;
		}

		/// <summary>コールバックデリゲートを設定する(ICompare を使用するカスタムソート用)</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <param name="isAsc">ソートオーダー</param>
		/// <returns>デリゲートが取得できたら true を返す</returns>
		public override bool SetCallback( string propertyName, bool isAsc )
		{
			this._isAsc = isAsc;
			this._callback = this.GetCallback( propertyName );
			return ( this._callback != null ) ? true : false;
		}

		/// <summary>ソート時に使用するコールバック</summary>
		private int CompareCallback( object x, object y, bool isAsc )
		{
			return this._subCallback( x as Kaidou, y as Kaidou, isAsc );
		}

		#region コールバックメソッド
		private int CmpName( Kaidou x, Kaidou y, bool isAsc )			// 街道名
		{
			var x_yomi = x.N14pkb.Yousyolist[x.Data.PtrYousyo1].Yomi + ":" + x.N14pkb.Yousyolist[x.Data.PtrYousyo2].Yomi;
			var y_yomi = y.N14pkb.Yousyolist[y.Data.PtrYousyo1].Yomi + ":" + y.N14pkb.Yousyolist[y.Data.PtrYousyo2].Yomi;
			return x_yomi.Equals( y_yomi ) ? 0
				: ( x_yomi == string.Empty ) ? _isAsc ? 1 : -1
				: ( y_yomi == string.Empty ) ? _isAsc ? -1 : 1
				: x_yomi.CompareTo( y_yomi );
		}

		private int CmpYousyo1Kuni( Kaidou x, Kaidou y, bool isAsc )		// 国1
		{
			return (int)( x.Yousyo1.Data.PtrKuni - y.Yousyo1.Data.PtrKuni );
		}

		private int CmpYousyo2Kuni( Kaidou x, Kaidou y, bool isAsc )		// 国2
		{
			return (int)( x.Yousyo2.Data.PtrKuni - y.Yousyo2.Data.PtrKuni );
		}

		private int CmpYousyo1Kyoten( Kaidou x, Kaidou y, bool isAsc )		// 拠点1
		{
			var x_id = x.N14pkb.Yousyolist.GetSortIDByKyotenAddress( x.Yousyo1.Data.PtrKyoten );
			var y_id = y.N14pkb.Yousyolist.GetSortIDByKyotenAddress( y.Yousyo1.Data.PtrKyoten );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}

		private int CmpYousyo2Kyoten( Kaidou x, Kaidou y, bool isAsc )		// 拠点2
		{
			var x_id = x.N14pkb.Yousyolist.GetSortIDByKyotenAddress( x.Yousyo2.Data.PtrKyoten );
			var y_id = y.N14pkb.Yousyolist.GetSortIDByKyotenAddress( y.Yousyo2.Data.PtrKyoten );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}

		private int CmpYousyo1KyotenSeiryoku( Kaidou x, Kaidou y, bool isAsc )		// 勢力1
		{
			var x_id = x.N14pkb.Seiryokulist.GetSortIDByAddress( x.Yousyo1.PtrSeiryoku );
			var y_id = y.N14pkb.Seiryokulist.GetSortIDByAddress( y.Yousyo1.PtrSeiryoku );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}
		private int CmpYousyo2KyotenSeiryoku( Kaidou x, Kaidou y, bool isAsc )		// 勢力2
		{
			var x_id = x.N14pkb.Seiryokulist.GetSortIDByAddress( x.Yousyo2.PtrSeiryoku );
			var y_id = y.N14pkb.Seiryokulist.GetSortIDByAddress( y.Yousyo2.PtrSeiryoku );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}
		#endregion
	}
}
