﻿// ShiroNameComparer.cs

using System;
using System.Reflection;
using N14PKBrowse.Data;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Compare
{
	// 比較オブジェクト 城名
	public class ShiroNameComparer : AbstractComparer
	{
		/// <summary>比較用コールバックデリゲート 城名</summary>
		private delegate int SubCallback( ShiroName x, ShiroName y, bool isAsc );

		/// <summary>比較用コールバックデリゲート 城名</summary>
		private SubCallback _subCallback;


		/// <summary>コールバックデリゲートを取得する</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <returns>コールバックデリゲート</returns>
		public override CompareCallback GetCallback( string propertyName )
		{
			var type = this.GetType();
			// メソッド情報取得
			var mi = type.GetMethod( _CallbackPrefix + propertyName, BindingFlags.NonPublic | BindingFlags.Instance );
			if ( mi == null )
			{
				return null;
			}
			// デリゲート作成
			this._subCallback = (SubCallback)Delegate.CreateDelegate( typeof( SubCallback ), this, mi );
			this._callback = this.CompareCallback;
			return ( this._subCallback != null ) ? this._callback : null;
		}

		/// <summary>コールバックデリゲートを設定する(ICompare を使用するカスタムソート用)</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <param name="isAsc">ソートオーダー</param>
		/// <returns>デリゲートが取得できたら true を返す</returns>
		public override bool SetCallback( string propertyName, bool isAsc )
		{
			this._isAsc = isAsc;
			this._callback = this.GetCallback( propertyName );
			return ( this._callback != null ) ? true : false;
		}

		/// <summary>ソート時に使用するコールバック</summary>
		private int CompareCallback( object x, object y, bool isAsc )
		{
			return this._subCallback( x as ShiroName, y as ShiroName, isAsc );
		}

		#region コールバックメソッド
		private int CmpName( ShiroName x, ShiroName y, bool isAsc )
		{
			return x.Yomi.Equals( y.Yomi ) ? 0
				: ( x.Yomi == string.Empty ) ? isAsc ? 1 : -1
				: ( y.Yomi == string.Empty ) ? isAsc ? -1 : 1
				: x.Yomi.CompareTo( y.Yomi );
		}
		#endregion
	}
}
