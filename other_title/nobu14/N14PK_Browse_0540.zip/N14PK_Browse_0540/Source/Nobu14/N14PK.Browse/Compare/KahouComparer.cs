﻿// KahouComparer.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using N14PKBrowse.Data;

namespace N14PKBrowse.Compare
{
	// 比較オブジェクト 家宝
	public class KahouComparer : AbstractComparer
	{
		/// <summary>比較用コールバックデリゲート 家宝</summary>
		private delegate int SubCallback( Kahou x, Kahou y, bool isAsc );

		/// <summary>比較用コールバックデリゲート 家宝</summary>
		private SubCallback _subCallback;


		/// <summary>コールバックデリゲートを取得する</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <returns>コールバックデリゲート</returns>
		public override CompareCallback GetCallback( string propertyName )
		{
			var type = this.GetType();
			// メソッド情報取得
			var mi = type.GetMethod( _CallbackPrefix + propertyName, BindingFlags.NonPublic | BindingFlags.Instance );
			if ( mi == null )
			{
				return null;
			}
			// デリゲート作成
			this._subCallback = (SubCallback)Delegate.CreateDelegate( typeof( SubCallback ), this, mi );
			this._callback = this.CompareCallback;
			return ( this._subCallback != null ) ? this._callback : null;
		}

		/// <summary>コールバックデリゲートを設定する(ICompare を使用するカスタムソート用)</summary>
		/// <param name="propertyName">プロパティ名</param>
		/// <param name="isAsc">ソートオーダー</param>
		/// <returns>デリゲートが取得できたら true を返す</returns>
		public override bool SetCallback( string propertyName, bool isAsc )
		{
			this._isAsc = isAsc;
			this._callback = this.GetCallback( propertyName );
			return ( this._callback != null ) ? true : false;
		}

		/// <summary>ソート時に使用するコールバック</summary>
		private int CompareCallback( object x, object y, bool isAsc )
		{
			return this._subCallback( x as Kahou, y as Kahou, isAsc );
		}

		#region コールバックメソッド
		private int CmpName( Kahou x, Kahou y, bool isAsc )			// 家宝名称
		{
			return x.Yomi.Equals( y.Yomi ) ? 0
				: ( x.Yomi == string.Empty ) ? isAsc ? 1 : -1
				: ( y.Yomi == string.Empty ) ? isAsc ? -1 : 1
				: x.Yomi.CompareTo( y.Yomi );
		}

		private int CmpPtrHoyuuSeiryoku( Kahou x, Kahou y, bool isAsc )		// 保有勢力
		{
			var x_id = x.N14pkb.Seiryokulist.GetSortIDByAddress( x.PtrHoyuuSeiryoku );
			var y_id = y.N14pkb.Seiryokulist.GetSortIDByAddress( y.PtrHoyuuSeiryoku );
			return ( x_id == y_id ) ? 0
				: ( x_id == -1 ) ? isAsc ? 1 : -1
				: ( y_id == -1 ) ? isAsc ? -1 : 1
				: x_id - y_id;
		}

		private int CmpHoyuuBusyou( Kahou x, Kahou y, bool isAsc )		// 保有武将
		{
			var x_yomi = ( x.N14pkb.Busyoulist[x.Data.PtrHoyuuBusyou] != null ) ? x.N14pkb.Busyoulist[x.Data.PtrHoyuuBusyou].Yomi : string.Empty;
			var y_yomi = ( y.N14pkb.Busyoulist[y.Data.PtrHoyuuBusyou] != null ) ? y.N14pkb.Busyoulist[y.Data.PtrHoyuuBusyou].Yomi : string.Empty;

			return x_yomi.Equals( y_yomi ) ? 0
				: ( x_yomi == string.Empty ) ? isAsc ? 1 : -1
				: ( y_yomi == string.Empty ) ? isAsc ? -1 : 1
				: x_yomi.CompareTo( y_yomi );
		}
		#endregion
	}
}
