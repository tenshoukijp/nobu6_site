﻿using System;
using System.Windows;
using System.Windows.Threading;

namespace N14PKBrowse
{
	/// <summary>
	/// App.xaml の相互作用ロジック
	/// </summary>
	public partial class App : Application
	{
		/// <summary>
		/// アプリケーション開始時のイベントハンドラ
		/// </summary>
		private void Application_Startup(object sender, StartupEventArgs e)
		{
			this.DispatcherUnhandledException += Application_DispatcherUnhandledException;
			AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
		}

		/// <summary>
		/// アプリケーション終了時のイベントハンドラ
		/// </summary>
		private void Application_Exit(object sender, ExitEventArgs e)
		{
			this.DispatcherUnhandledException -= Application_DispatcherUnhandledException;
			AppDomain.CurrentDomain.UnhandledException -= CurrentDomain_UnhandledException;
		}

		/// <summary>
		/// WPF UIスレッドでの未処理例外スロー時のイベントハンドラ
		/// </summary>
		private void Application_DispatcherUnhandledException(
			object sender, DispatcherUnhandledExceptionEventArgs e)
		{
			e.Handled = true;
			this.ReportUnhandledException(e.Exception);
		}

		/// <summary>
		/// UIスレッド以外の未処理例外スロー時のイベントハンドラ
		/// </summary>
		private void CurrentDomain_UnhandledException(
			object sender, UnhandledExceptionEventArgs e)
		{
			this.ReportUnhandledException(e.ExceptionObject as Exception);
		}

		/// <summary>
		/// 未処理例外をイベントログに出力します。
		/// </summary>
		private void ReportUnhandledException(Exception ex)
		{
			System.Windows.MessageBox.Show( ex.Message + System.Environment.NewLine + "N14PK_Browse を終了します"
				, "ハンドルされていない例外の発生", MessageBoxButton.OK, MessageBoxImage.Error );
			var fileName = @"errorlog.txt";
			using ( var streamWriter = new System.IO.StreamWriter( fileName, false, System.Text.Encoding.GetEncoding( "shift_jis" ) ) )
			{
				streamWriter.WriteLine( ex.ToString() );
			}

			this.Shutdown();
		}

	}
}
