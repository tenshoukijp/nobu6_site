﻿using System.Windows;
using System.Windows.Controls;

using N14PKBrowse.Data;
using N14PKBrowse.HelperClass;

namespace N14PKBrowse
{
	/// <summary>
	/// WindowTokusei.xaml の相互作用ロジック
	/// </summary>
	public partial class WindowTokusei : Window
	{
		public CheckBox[] CheckBoxTokuseiArray	{ get; private set; }	// チェックボックスコントロールの配列
		public N14PKB N14pkb					{ get; set; }			// ツール管理
		public Busyou Busyou					{ get; set; }			// 選択中の武将データ

		public WindowTokusei()
		{
			InitializeComponent();
		}


		private void Window_Loaded( object sender, RoutedEventArgs e )
		{
			// チェックボックス配列を作成
			this.CheckBoxTokuseiArray = (CheckBox[])MyControlArray.GetControlArrayByName( this, "CheckBoxTokusei" );

			// チェックボックス設定 ソートID順に表示する
			for ( int i = 0; i < this.CheckBoxTokuseiArray.Length; i++ )
			{
				var tokusei = this.N14pkb.Tokuseilist.GetDataBySortID( i );

				// ボタンテキスト
				this.CheckBoxTokuseiArray[i].Content = tokusei.Name;
				// ツールチップ表示ディレイ
				ToolTipService.SetInitialShowDelay( CheckBoxTokuseiArray[i], 0 );
				// ツールチップテキスト
				this.CheckBoxTokuseiArray[i].ToolTip = tokusei.HelpText1;
				// クリックイベントデリゲート
				this.CheckBoxTokuseiArray[i].Click += new RoutedEventHandler( CheckBoxTokusei_Checked );

				var tokuseiFlag = this.Busyou.TokuseiFlags[tokusei.ID];
				if ( tokuseiFlag )
				{
					// 特性習得済み
					this.CheckBoxTokuseiArray[i].IsChecked = true;												// チェック状態設定
					this.CheckBoxTokuseiArray[i].Foreground = System.Windows.Media.Brushes.Red;					// 文字色
				}
			}
			// ステータスバー更新
			this.StatusBarItem1.Content = string.Format( this.Busyou.Sei + this.Busyou.Mei + "  " + "特性所持数:" + this.Busyou.Tokuseisuu );
		}

		// 閉じるボタン
		private void ButtonClose_Click( object sender, RoutedEventArgs e )
		{
			this.Close();
		}

		// 特性チェックボタン
		private void CheckBoxTokusei_Checked( object sender, RoutedEventArgs e )
		{
			// クリックされたボタンのインデックスを取得する
			var index = -1;
			for ( var i = 0; i < this.CheckBoxTokuseiArray.Length; i++ )
			{
				if ( this.CheckBoxTokuseiArray[i].Equals( sender ) )
				{
					index = i;
					break;
				}
			}

			if ( !this.CheckBoxTokuseiArray[index].IsChecked.HasValue )
			{
				// チェックボックスが値を持たいない
				return;
			}

			// Busyou.TokuseiFlags のコピーに対して操作し、終了時に戻す
			// TokuseiFlags を直接変更しても添字を変えるたびにgetプロパティで new されるため意味が無い
			var flags = this.Busyou.TokuseiFlags;
			var tokusei = this.N14pkb.Tokuseilist.GetDataBySortID( index );				// 変更された特性データ

			if ( (bool)this.CheckBoxTokuseiArray[index].IsChecked )
			{
				// チェックONの場合
				flags[tokusei.ID] = true;															// 特性データフラグON
				this.CheckBoxTokuseiArray[index].Foreground = System.Windows.Media.Brushes.Red;		// 文字色

				// 下位特性が存在する場合は下位特性データのフラグを消去にする
				// 役職・官位のダブリについてはチェックしていない
				var kaiTokuseiID = this.N14pkb.Tokuseilist.GetIDByAddress( tokusei.PtrKaiTokusei );
				while ( 0 <= kaiTokuseiID )
				{
					var sortid = this.N14pkb.Tokuseilist.GetSortIDByID( kaiTokuseiID );
					this.CheckBoxTokuseiArray[sortid].IsChecked = false;									// 下位特性のチェック消去
					this.CheckBoxTokuseiArray[sortid].Foreground = System.Windows.Media.Brushes.Black;		// 文字色
					flags[kaiTokuseiID] = false;															// 下位特性の特性フラグOFF
					// 下位特性の下位特性ID
					kaiTokuseiID = this.N14pkb.Tokuseilist.GetIDByAddress( this.N14pkb.Tokuseilist[kaiTokuseiID].PtrKaiTokusei );
				}

				// 上位特性(自身を下位特性に持つデータ)が存在する場合は上位特性データのフラグをOFF
				var kaiTokuseiAddress = tokusei.Address;
				var hit = false;
				while ( kaiTokuseiAddress != 0 )
				{
					foreach ( var d in this.N14pkb.Tokuseilist )
					{
						if ( d.PtrKaiTokusei == kaiTokuseiAddress )
						{
							this.CheckBoxTokuseiArray[d.SortID].IsChecked = false;									// 上位特性のチェック消去
							this.CheckBoxTokuseiArray[d.SortID].Foreground = System.Windows.Media.Brushes.Black;	// 文字色
							flags[d.ID] = false;																	// 上位特性の特性フラグOFF
							kaiTokuseiAddress = d.Address;
							hit = true;
							break;
						}
					}

					if ( hit )
					{
						hit = false;
						continue;
					}

					kaiTokuseiAddress = 0;
				}

				if ( tokusei.PtrHanTokusei != 0 )
				{
					// 反特性が存在する場合は反特性データのフラグをOFF
					var hanTokuseiID = this.N14pkb.Tokuseilist.GetIDByAddress( tokusei.PtrHanTokusei );
					var rsortid = this.N14pkb.Tokuseilist.GetSortIDByID( hanTokuseiID );
					this.CheckBoxTokuseiArray[rsortid].IsChecked = false;									// 反特性のチェック消去
					this.CheckBoxTokuseiArray[rsortid].Foreground = System.Windows.Media.Brushes.Black;		// 文字色
					flags[hanTokuseiID] = false;															// 反特性の特性フラグOFF
				}
			}
			else
			{
				// チェックOFFの場合
				flags[tokusei.ID] = false;				// 特性データのフラグをOFF
				this.CheckBoxTokuseiArray[index].Foreground = System.Windows.Media.Brushes.Black;	// 文字色
			}

			this.Busyou.TokuseiFlags = flags;		// 特性フラグセット
			this.N14pkb.Busyoulist.Commit();

			// ステータスバー更新
			this.StatusBarItem1.Content = string.Format( this.Busyou.Sei + this.Busyou.Mei + "  " + "特性所持数:" + this.Busyou.Tokuseisuu );
		}

	}
}
