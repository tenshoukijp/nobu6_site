﻿// MyControlArray.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace N14PKBrowse.HelperClass
{
	public class MyControlArray
	{
		/// <summary>連番で配置されているコントロールの配列を取得する</summary>
		/// <param name="obj">コントロールが配置されているウィンドウオブジェクト</param>
		/// <param name="controlName">コントロール識別名(連番の数字を除く)</param>
		/// <param name="startIndex">開始ID</param>
		/// <param name="endIndex">終了ID</param>
		/// <returns>コントロール配列</returns>
		public static object GetControlArrayByName( object obj, string controlName, int startIndex, int endIndex )
		{
			var controls = new System.Collections.ArrayList();
			object controlObject;
			for ( int i = startIndex;
					(controlObject = FindControlByFieldName( obj, controlName + i.ToString() )) != null && i <= endIndex;
					i++
					)
				controls.Add( controlObject );

			if ( controls.Count == 0 )
				return null;
			else
				return controls.ToArray( controls[0].GetType() );
		}

		// オーバーロード(startIndex endIndex 省略版)
		public static object GetControlArrayByName( object obj, string controlName )
		{
			return GetControlArrayByName( obj, controlName, 1, 256 );
		}

		// オーバーロード(startIndex 省略版)
		public static object GetControlArrayByName( object obj, string controlName, int endIndex )
		{
			return GetControlArrayByName( obj, controlName, 1, endIndex );
		}


		// 配置されているコントロールを名前で探す
		public static object FindControlByFieldName( object obj, string controlName )
		{
			System.Type t = obj.GetType();
			System.Reflection.FieldInfo fieldInfo = t.GetField(
				controlName,
				System.Reflection.BindingFlags.Public
				| System.Reflection.BindingFlags.NonPublic
				| System.Reflection.BindingFlags.Instance
				| System.Reflection.BindingFlags.DeclaredOnly
			);

			if ( fieldInfo == null )
				return null;
			else
				return fieldInfo.GetValue( obj );
		}
	}
}
