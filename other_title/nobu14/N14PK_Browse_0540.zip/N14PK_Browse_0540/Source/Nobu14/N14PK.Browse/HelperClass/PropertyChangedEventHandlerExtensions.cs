﻿// PropertyChangedEventHandlerExtensions.cs

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq.Expressions;

namespace N14PKBrowse.HelperClass
{
	// プロパティをそのまま使ってプロパティチェンジイベントを起こせるように拡張する
	// プロパティ名を文字列で渡すのはプロパティ名を変更した際に修正ミスが多発する
	public static class PropertyChangedEventHandlerExtensions
	{
		/// <summary>イベント発行</summary>
		/// <typeparam name="T">プロパティの型</typeparam>
		/// <param name="_this">イベントハンドラ</param>
		/// <param name="propertyName">プロパティ名を表すExpression。() => Name のように指定する。</param>
		public static void Raise<T>( this PropertyChangedEventHandler _this, Expression<Func<T>> propertyName )
		{
			// イベントハンドラに何も登録されていない場合は何もしない
			if ( _this == null )
			{
				return;
			}

			// ラムダ式のBodyを取得
			var memberEx = propertyName.Body as MemberExpression;
			if ( memberEx == null )
			{
				// MemberExpressionじゃなければエラー
				throw new ArgumentException();
			}

			// "() => Name" のNameの左側に暗黙的に存在しているオブジェクトを取得する式を取得
			var senderExpression = memberEx.Expression as ConstantExpression;
			if ( senderExpression == null )
			{
				// ConstraintExpressionじゃなければエラー
				throw new ArgumentException();
			}

			// 定数なのでValueプロパティからsender用のインスタンスを取得
			var sender = senderExpression.Value;

			// イベント発行
			_this( sender, new PropertyChangedEventArgs( memberEx.Member.Name ) );
		}
	}
}