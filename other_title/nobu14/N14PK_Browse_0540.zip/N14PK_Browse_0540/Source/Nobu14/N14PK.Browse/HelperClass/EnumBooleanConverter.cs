﻿// EnumBooleanConverter.cs

using System;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace N14PKBrowse.HelperClass
{
	/// <summary>enum と bool の相互変換</summary>
	public class EnumBooleanConverter : IValueConverter
	{
		/// <summary>enum を bool に変換</summary>
		public object Convert( object value, Type targetType, object parameter, CultureInfo culture )
		{
			// バインドする列挙値の文字列表記がパラメータに渡されているか
			string parameterString = parameter as string;
			if ( parameterString == null )
			{
				return DependencyProperty.UnsetValue;
			}

			// パラメータが enum として正しいか
			if ( Enum.IsDefined( value.GetType(), value ) == false )
			{
				return DependencyProperty.UnsetValue;
			}

			// パラメータを enum に変換
			object parameterValue = Enum.Parse( value.GetType(), parameterString );

			// 値が一致すれば true を返す
			return (int)parameterValue == (int)value;
		}

		/// <summary>bool を enum に変換</summary>
		public object ConvertBack( object value, Type targetType, object parameter, CultureInfo culture )
		{
			// バインドする列挙値の文字列表記がパラメータに渡されているか
			string parameterString = parameter as string;
			if ( parameterString == null || value.Equals( false ) )
			{
				return DependencyProperty.UnsetValue;
			}

			// 列挙型にパースして返す
			return Enum.Parse( targetType, parameterString );
		}
	}
}