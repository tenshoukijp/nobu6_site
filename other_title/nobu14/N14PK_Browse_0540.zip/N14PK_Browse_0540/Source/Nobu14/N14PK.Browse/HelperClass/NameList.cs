﻿// NameList.cs

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace N14PKBrowse.HelperClass
{
	/// <summary>名前リスト</summary>
	public class NameList<T1> : IEnumerable
	{
		/// <summary>コンボソース等に使用するIDと名称のペア</summary>
		public class Data<T2>
		{
			public T2 Key { get; set; }
			public string Value { get; set; }

			/// <summary>コンストラクタ</summary>
			public Data() { }
			public Data( T2 id, string name )
			{
				this.Key = id;
				this.Value = name;
			}
		}

		public List<Data<T1>> Items { get; private set; }


		/// <summary>コンストラクタ</summary>
		public NameList() { }
		public NameList( Data<T1>[] itemlist )
		{
			this.Items = itemlist.ToList();
		}


		/// <summary>インデクサ ID</summary>
		/// <param name="id">ID</param>
		/// <returns>名前</returns>
		public string this[T1 id]
		{
			get
			{
				var data = this.Items.Find( d => d.Key.Equals( id ) );
				return ( data != null ) ? data.Value : string.Empty;
			}
			set
			{
				var data = this.Items.Find( d => d.Key.Equals( id ) );
				if ( data != null )
				{
					data.Value = value;
				}
				else
				{
					var index = this.Items.FindLastIndex( d => d.Value == string.Empty );
					if ( index != -1 )
					{
						this.Items.Insert( index, new Data<T1> { Key = id, Value = value } );
					}
					else
					{
						this.Items.Add( new Data<T1> { Key = id, Value = value } );
					}
				}
			}
		}

		///// <summary>インデクサ 名前</summary>
		///// <param name="name">名前</param>
		///// <returns>ID</returns>
		//public int this[string name]
		//{
		//	get
		//	{
		//		var data = this.Items.Find( d => d.Value == name );
		//		return ( data != null ) ? data.Key : -1;
		//	}
		//}

		public int Count
		{
			get { return ( this.Items != null ) ? this.Items.Count : 0; }
		}

		public void Clear()
		{
			if ( this.Items != null )
			{
				this.Items.Clear();
			}
		}
		// IEnumerable メンバ実装
		public void Add( T1 key, string value )
		{
			if ( this.Items == null )
			{
				this.Items = new List<Data<T1>>();
			}
			this.Items.Add( new Data<T1>( key, value ) );
		}

		IEnumerator IEnumerable.GetEnumerator()
		{
			foreach ( var item in this.Items )
			{
				yield return item;
			}
		}
	}
}
