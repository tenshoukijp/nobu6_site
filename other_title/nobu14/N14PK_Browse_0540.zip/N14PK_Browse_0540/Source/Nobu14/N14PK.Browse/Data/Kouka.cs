﻿// Kouka.cs

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>効果ビューで使用するデータクラス</summary>
	public class Kouka : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の効果データ</summary>
		public KoukaData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID				// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address			// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex	// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}
		public string Name			// 名称
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Name );
				this.UpdateNamelist();
			}
		}
		public string HelpText		// ヘルプ
		{
			get { return this.Data.HelpText; }
			set
			{
				if ( value == this.HelpText ) { return; }
				this.Data.HelpText = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HelpText );
			}
		}
		public byte h3C			// 3Ch 1バイト
		{
			get { return this.Data.h3C; }
			set
			{
				if ( value == this.h3C ) { return; }
				this.Data.h3C = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h3C );
			}
		}
		public byte h3D			// 3Dh 1バイト
		{
			get { return this.Data.h3D; }
			set
			{
				if ( value == this.h3D ) { return; }
				this.Data.h3D = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h3D );
			}
		}
		public byte h3E			// 3Eh 1バイト
		{
			get { return this.Data.h3E; }
			set
			{
				if ( value == this.h3E ) { return; }
				this.Data.h3E = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h3E );
			}
		}
		public byte h3F			// 3Fh 1バイト
		{
			get { return this.Data.h3F; }
			set
			{
				if ( value == this.h3F ) { return; }
				this.Data.h3F = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h3F );
			}
		}


		/// <summary>コンストラクタ 効果</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Kouka( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Koukatable[id];
		}

		/// <summary>効果名リストを更新する</summary>
		private void UpdateNamelist()
		{
			var list = this.N14pkb.Koukalist.Namelist;
			if ( list[this.ID] == this.Name ) { return; }

			var oldname = list[this.ID];
			list[this.ID] = this.Name;

			// 戦法ビューカラムヘッダ名変更
			var columns = this.N14pkb.MainWindowInterface.DataGrids[(int)Enums.TabKind.戦法].Columns;
			for ( var i = 0; i < columns.Count; i++ )
			{
				if ( (string)( columns[i].Header ) == oldname )
				{
					columns[i].Header = this.Name;

					// ビューリフレッシュフラグ
					this.N14pkb.View.Flags[(int)Enums.TabKind.戦法].NeedsRefresh = true;
					break;
				}
			}
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			var record = (byte[])this.Data.GetRecord().Clone();
			return record;
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			var record = (byte[])buff.Clone();
			// 先頭4バイトの MagicNumber はゲーム起動毎に変わるため、現在の値を使用する
			BitConverter.GetBytes( this.Data.MagicNumber ).CopyTo( record, 0x00 );

			this.Data.SetRecord( record );
			this.Write();

			this.UpdateNamelist();

			// ビュー更新フラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.効果].NeedsRefresh = true;
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Koukatable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Koukalist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:効果:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
