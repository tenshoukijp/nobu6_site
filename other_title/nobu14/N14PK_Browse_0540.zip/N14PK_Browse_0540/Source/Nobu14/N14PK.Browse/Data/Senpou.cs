﻿// Senpou.cs

using System;
using System.ComponentModel;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>戦法ビューで使用するデータクラス</summary>
	public class Senpou : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の戦法データ</summary>
		public SenpouData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID				// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address			// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex	// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}
		public string Name			// 戦法名
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Name );
				this.UpdateNamelist();
			}
		}
		public string Yomi			// 戦法名読み
		{
			get { return this.Data.Yomi; }
			set
			{
				if ( value == this.Yomi ) { return; }
				this.Data.Yomi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Yomi );
			}
		}
		public string HelpText		// ヘルプ
		{
			get { return this.Data.HelpText; }
			set
			{
				if ( value == this.HelpText ) { return; }
				this.Data.HelpText = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HelpText );
			}
		}
		public sbyte h47			// 47h 1バイト
		{
			get { return this.Data.h47; }
			set
			{
				if ( value == this.h47 ) { return; }
				this.Data.h47 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h47 );
			}
		}
		public int KeitouID		// 系統ID -1:未使用？、0:強化、1:回復、2:妨害、3:特性、4:突撃、5:斉射
		{
			get { return this.Data.KeitouID; }
			set
			{
				if ( value == this.KeitouID ) { return; }
				this.Data.KeitouID = (sbyte)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KeitouID );
			}
		}
		public sbyte h49			// 49
		{
			get { return this.Data.h49; }
			set
			{
				if ( value == this.h49 ) { return; }
				this.Data.h49 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h49 );
			}
		}
		public sbyte koukaHanni		// 効果範囲？ 円の中心位置？ 15以上フリーズ、強化系は12、妨害系は13で全範囲
		{
			get { return this.Data.koukaHanni; }
			set
			{
				if ( value == this.koukaHanni ) { return; }
				this.Data.koukaHanni = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.koukaHanni );
			}
		}
		public sbyte Koukasuu		// 効果数？
		{
			get { return this.Data.Koukasuu; }
			set
			{
				if ( value == this.Koukasuu ) { return; }
				this.Data.Koukasuu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Koukasuu );
			}
		}
		public short SaihaiOrTokuseiID	// 采配/特性ID
		{
			get { return this.Data.SaihaiOrTokuseiID; }
			set
			{
				if ( value == this.SaihaiOrTokuseiID ) { return; }
				this.Data.SaihaiOrTokuseiID = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SaihaiOrTokuseiID );
			}
		}
		public short h4E_2			// 4Eh 2バイト
		{
			get { return this.Data.h4E_2; }
			set
			{
				if ( value == this.h4E_2 ) { return; }
				this.Data.h4E_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h4E_2 );
			}
		}

		// 50hからの64バイト(1データ2バイト * 1効果4データ * 8効果) 効果に関する詳細データ
		public int Kouka1ID			// 効果1
		{
			get { return this.Data.Kouka1ID; }
			set
			{
				if ( value == this.Kouka1ID ) { return; }
				this.Data.Kouka1ID = (short)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka1ID );
			}
		}
		public short Kouka1Value1	// 効果1 値1 効果時間
		{
			get { return this.Data.Kouka1Value1; }
			set
			{
				if ( value == this.Kouka1Value1 ) { return; }
				this.Data.Kouka1Value1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka1Value1 );
			}
		}
		public short Kouka1Value2	// 効果1 値2 対象？ 0自分 1自中心範囲 2敵
		{
			get { return this.Data.Kouka1Value2; }
			set
			{
				if ( value == this.Kouka1Value2 ) { return; }
				this.Data.Kouka1Value2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka1Value2 );
			}
		}
		public short Kouka1Value3	// 効果1 値3 増減量(%) 最大250(効果値？)
		{
			get { return this.Data.Kouka1Value3; }
			set
			{
				if ( value == this.Kouka1Value3 ) { return; }
				this.Data.Kouka1Value3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka1Value3 );
			}
		}

		public int Kouka2ID			// 効果2
		{
			get { return this.Data.Kouka2ID; }
			set
			{
				if ( value == this.Kouka2ID ) { return; }
				this.Data.Kouka2ID = (short)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka2ID );
			}
		}
		public short Kouka2Value1	// 効果2 値1
		{
			get { return this.Data.Kouka2Value1; }
			set
			{
				if ( value == this.Kouka2Value1 ) { return; }
				this.Data.Kouka2Value1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka2Value1 );
			}
		}
		public short Kouka2Value2	// 効果2 値2
		{
			get { return this.Data.Kouka2Value2; }
			set
			{
				if ( value == this.Kouka2Value2 ) { return; }
				this.Data.Kouka2Value2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka2Value2 );
			}
		}
		public short Kouka2Value3	// 効果2 値3
		{
			get { return this.Data.Kouka2Value3; }
			set
			{
				if ( value == this.Kouka2Value3 ) { return; }
				this.Data.Kouka2Value3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka2Value3 );
			}
		}

		public int Kouka3ID			// 効果3
		{
			get { return this.Data.Kouka3ID; }
			set
			{
				if ( value == this.Kouka3ID ) { return; }
				this.Data.Kouka3ID = (short)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka3ID );
			}
		}
		public short Kouka3Value1	// 効果3 値1
		{
			get { return this.Data.Kouka3Value1; }
			set
			{
				if ( value == this.Kouka3Value1 ) { return; }
				this.Data.Kouka3Value1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka3Value1 );
			}
		}
		public short Kouka3Value2	// 効果3 値2
		{
			get { return this.Data.Kouka3Value2; }
			set
			{
				if ( value == this.Kouka3Value2 ) { return; }
				this.Data.Kouka3Value2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka3Value2 );
			}
		}
		public short Kouka3Value3	// 効果3 値3
		{
			get { return this.Data.Kouka3Value3; }
			set
			{
				if ( value == this.Kouka3Value3 ) { return; }
				this.Data.Kouka3Value3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka3Value3 );
			}
		}

		public int Kouka4ID			// 効果4
		{
			get { return this.Data.Kouka4ID; }
			set
			{
				if ( value == this.Kouka4ID ) { return; }
				this.Data.Kouka4ID = (short)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka4ID );
			}
		}
		public short Kouka4Value1	// 効果4 値1
		{
			get { return this.Data.Kouka4Value1; }
			set
			{
				if ( value == this.Kouka4Value1 ) { return; }
				this.Data.Kouka4Value1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka4Value1 );
			}
		}
		public short Kouka4Value2	// 効果4 値2
		{
			get { return this.Data.Kouka4Value2; }
			set
			{
				if ( value == this.Kouka4Value2 ) { return; }
				this.Data.Kouka4Value2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka4Value2 );
			}
		}
		public short Kouka4Value3	// 効果4 値3
		{
			get { return this.Data.Kouka4Value3; }
			set
			{
				if ( value == this.Kouka4Value3 ) { return; }
				this.Data.Kouka4Value3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka4Value3 );
			}
		}

		public int Kouka5ID			// 効果5
		{
			get { return this.Data.Kouka5ID; }
			set
			{
				if ( value == this.Kouka5ID ) { return; }
				this.Data.Kouka5ID = (short)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka5ID );
			}
		}
		public short Kouka5Value1	// 効果5 値1
		{
			get { return this.Data.Kouka5Value1; }
			set
			{
				if ( value == this.Kouka5Value1 ) { return; }
				this.Data.Kouka5Value1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka5Value1 );
			}
		}
		public short Kouka5Value2	// 効果5 値2
		{
			get { return this.Data.Kouka5Value2; }
			set
			{
				if ( value == this.Kouka5Value2 ) { return; }
				this.Data.Kouka5Value2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka5Value2 );
			}
		}
		public short Kouka5Value3	// 効果5 値3
		{
			get { return this.Data.Kouka5Value3; }
			set
			{
				if ( value == this.Kouka5Value3 ) { return; }
				this.Data.Kouka5Value3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka5Value3 );
			}
		}

		public int Kouka6ID			// 効果6
		{
			get { return this.Data.Kouka6ID; }
			set
			{
				if ( value == this.Kouka6ID ) { return; }
				this.Data.Kouka6ID = (short)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka6ID );
			}
		}
		public short Kouka6Value1	// 効果6 値1
		{
			get { return this.Data.Kouka6Value1; }
			set
			{
				if ( value == this.Kouka6Value1 ) { return; }
				this.Data.Kouka6Value1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka6Value1 );
			}
		}
		public short Kouka6Value2	// 効果6 値2
		{
			get { return this.Data.Kouka6Value2; }
			set
			{
				if ( value == this.Kouka6Value2 ) { return; }
				this.Data.Kouka6Value2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka6Value2 );
			}
		}
		public short Kouka6Value3	// 効果6 値3
		{
			get { return this.Data.Kouka6Value3; }
			set
			{
				if ( value == this.Kouka6Value3 ) { return; }
				this.Data.Kouka6Value3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka6Value3 );
			}
		}

		public int Kouka7ID			// 効果7
		{
			get { return this.Data.Kouka7ID; }
			set
			{
				if ( value == this.Kouka7ID ) { return; }
				this.Data.Kouka7ID = (short)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka7ID );
			}
		}
		public short Kouka7Value1	// 効果7 値1
		{
			get { return this.Data.Kouka7Value1; }
			set
			{
				if ( value == this.Kouka7Value1 ) { return; }
				this.Data.Kouka7Value1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka7Value1 );
			}
		}
		public short Kouka7Value2	// 効果7 値2
		{
			get { return this.Data.Kouka7Value2; }
			set
			{
				if ( value == this.Kouka7Value2 ) { return; }
				this.Data.Kouka7Value2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka7Value2 );
			}
		}
		public short Kouka7Value3	// 効果7 値3
		{
			get { return this.Data.Kouka7Value3; }
			set
			{
				if ( value == this.Kouka7Value3 ) { return; }
				this.Data.Kouka7Value3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka7Value3 );
			}
		}

		public int Kouka8ID			// 効果8
		{
			get { return this.Data.Kouka8ID; }
			set
			{
				if ( value == this.Kouka8ID ) { return; }
				this.Data.Kouka8ID = (short)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka8ID );
			}
		}
		public short Kouka8Value1	// 効果8 値1
		{
			get { return this.Data.Kouka8Value1; }
			set
			{
				if ( value == this.Kouka8Value1 ) { return; }
				this.Data.Kouka8Value1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka8Value1 );
			}
		}
		public short Kouka8Value2	// 効果8 値2
		{
			get { return this.Data.Kouka8Value2; }
			set
			{
				if ( value == this.Kouka8Value2 ) { return; }
				this.Data.Kouka8Value2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka8Value2 );
			}
		}
		public short Kouka8Value3	// 効果8 値3
		{
			get { return this.Data.Kouka8Value3; }
			set
			{
				if ( value == this.Kouka8Value3 ) { return; }
				this.Data.Kouka8Value3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka8Value3 );
			}
		}

		// 90hからの4バイトはビットフラグになっていて効果データに対応している
		public bool Kouka01			// 90h bit00
		{
			get { return this.Data.Kouka01; }
			set
			{
				if ( value == this.Kouka01 ) { return; }
				this.Data.Kouka01 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka01 );
			}
		}
		public bool Kouka02			// 90h bit01
		{
			get { return this.Data.Kouka02; }
			set
			{
				if ( value == this.Kouka02 ) { return; }
				this.Data.Kouka02 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka02 );
			}
		}
		public bool Kouka03			// 90h bit02
		{
			get { return this.Data.Kouka03; }
			set
			{
				if ( value == this.Kouka03 ) { return; }
				this.Data.Kouka03 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka03 );
			}
		}
		public bool Kouka04			// 90h bit03
		{
			get { return this.Data.Kouka04; }
			set
			{
				if ( value == this.Kouka04 ) { return; }
				this.Data.Kouka04 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka04 );
			}
		}
		public bool Kouka05			// 90h bit04
		{
			get { return this.Data.Kouka05; }
			set
			{
				if ( value == this.Kouka05 ) { return; }
				this.Data.Kouka05 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka05 );
			}
		}
		public bool Kouka06			// 90h bit05
		{
			get { return this.Data.Kouka06; }
			set
			{
				if ( value == this.Kouka06 ) { return; }
				this.Data.Kouka06 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka06 );
			}
		}
		public bool Kouka07			// 90h bit06
		{
			get { return this.Data.Kouka07; }
			set
			{
				if ( value == this.Kouka07 ) { return; }
				this.Data.Kouka07 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka07 );
			}
		}
		public bool Kouka08			// 90h bit07
		{
			get { return this.Data.Kouka08; }
			set
			{
				if ( value == this.Kouka08 ) { return; }
				this.Data.Kouka08 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka08 );
			}
		}
		public bool Kouka09			// 90h bit08
		{
			get { return this.Data.Kouka09; }
			set
			{
				if ( value == this.Kouka09 ) { return; }
				this.Data.Kouka09 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka09 );
			}
		}
		public bool Kouka10			// 90h bit09
		{
			get { return this.Data.Kouka10; }
			set
			{
				if ( value == this.Kouka10 ) { return; }
				this.Data.Kouka10 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka10 );
			}
		}
		public bool Kouka11			// 90h bit10
		{
			get { return this.Data.Kouka11; }
			set
			{
				if ( value == this.Kouka11 ) { return; }
				this.Data.Kouka11 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka11 );
			}
		}
		public bool Kouka12			// 90h bit11
		{
			get { return this.Data.Kouka12; }
			set
			{
				if ( value == this.Kouka12 ) { return; }
				this.Data.Kouka12 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka12 );
			}
		}
		public bool Kouka13			// 90h bit12
		{
			get { return this.Data.Kouka13; }
			set
			{
				if ( value == this.Kouka13 ) { return; }
				this.Data.Kouka13 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka13 );
			}
		}
		public bool Kouka14			// 90h bit13
		{
			get { return this.Data.Kouka14; }
			set
			{
				if ( value == this.Kouka14 ) { return; }
				this.Data.Kouka14 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka14 );
			}
		}
		public bool Kouka15			// 90h bit14
		{
			get { return this.Data.Kouka15; }
			set
			{
				if ( value == this.Kouka15 ) { return; }
				this.Data.Kouka15 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka15 );
			}
		}
		public bool Kouka16			// 90h bit15
		{
			get { return this.Data.Kouka16; }
			set
			{
				if ( value == this.Kouka16 ) { return; }
				this.Data.Kouka16 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka16 );
			}
		}
		public bool Kouka17			// 90h bit16
		{
			get { return this.Data.Kouka17; }
			set
			{
				if ( value == this.Kouka17 ) { return; }
				this.Data.Kouka17 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka17 );
			}
		}
		public bool Kouka18			// 90h bit17
		{
			get { return this.Data.Kouka18; }
			set
			{
				if ( value == this.Kouka18 ) { return; }
				this.Data.Kouka18 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka18 );
			}
		}
		public bool Kouka19			// 90h bit18
		{
			get { return this.Data.Kouka19; }
			set
			{
				if ( value == this.Kouka19 ) { return; }
				this.Data.Kouka19 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka19 );
			}
		}
		public bool Kouka20			// 90h bit19
		{
			get { return this.Data.Kouka20; }
			set
			{
				if ( value == this.Kouka20 ) { return; }
				this.Data.Kouka20 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka20 );
			}
		}
		public bool Kouka21			// 90h bit20
		{
			get { return this.Data.Kouka21; }
			set
			{
				if ( value == this.Kouka21 ) { return; }
				this.Data.Kouka21 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka21 );
			}
		}
		public bool Kouka22			// 90h bit21
		{
			get { return this.Data.Kouka22; }
			set
			{
				if ( value == this.Kouka22 ) { return; }
				this.Data.Kouka22 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka22 );
			}
		}
		public bool Kouka23			// 90h bit22
		{
			get { return this.Data.Kouka23; }
			set
			{
				if ( value == this.Kouka23 ) { return; }
				this.Data.Kouka23 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka23 );
			}
		}
		public bool Kouka24			// 90h bit23
		{
			get { return this.Data.Kouka24; }
			set
			{
				if ( value == this.Kouka24 ) { return; }
				this.Data.Kouka24 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka24 );
			}
		}
		public bool Kouka25			// 90h bit24
		{
			get { return this.Data.Kouka25; }
			set
			{
				if ( value == this.Kouka25 ) { return; }
				this.Data.Kouka25 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka25 );
			}
		}
		public bool Kouka26			// 90h bit25
		{
			get { return this.Data.Kouka26; }
			set
			{
				if ( value == this.Kouka26 ) { return; }
				this.Data.Kouka26 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka26 );
			}
		}
		public bool Kouka27			// 90h bit26
		{
			get { return this.Data.Kouka27; }
			set
			{
				if ( value == this.Kouka27 ) { return; }
				this.Data.Kouka27 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka27 );
			}
		}
		public bool Kouka28			// 90h bit27
		{
			get { return this.Data.Kouka28; }
			set
			{
				if ( value == this.Kouka28 ) { return; }
				this.Data.Kouka28 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka28 );
			}
		}
		public bool Kouka29			// 90h bit28
		{
			get { return this.Data.Kouka29; }
			set
			{
				if ( value == this.Kouka29 ) { return; }
				this.Data.Kouka29 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka29 );
			}
		}
		public bool Kouka30			// 90h bit29
		{
			get { return this.Data.Kouka30; }
			set
			{
				if ( value == this.Kouka30 ) { return; }
				this.Data.Kouka30 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka30 );
			}
		}
		public bool Kouka31			// 90h bit30
		{
			get { return this.Data.Kouka31; }
			set
			{
				if ( value == this.Kouka31 ) { return; }
				this.Data.Kouka31 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka31 );
			}
		}
		public bool Kouka32			// 90h bit31
		{
			get { return this.Data.Kouka32; }
			set
			{
				if ( value == this.Kouka32 ) { return; }
				this.Data.Kouka32 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kouka32 );
			}
		}


		/// <summary>コンストラクタ 戦法</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Senpou( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Senpoutable[id];
		}

		/// <summary>戦法名リストを更新する</summary>
		private void UpdateNamelist()
		{
			var list = this.N14pkb.Senpoulist.Namelist;
			if ( list[this.Address] == this.Name ) { return; }

			list[this.Address] = this.Name;

			// ビューリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.戦法].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.武将].NeedsRefresh = true;

			this.N14pkb.View.NeedsRegetData = true;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			var record = (byte[])this.Data.GetRecord().Clone();
			return record;
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			var record = (byte[])buff.Clone();
			// 先頭4バイトの MagicNumber はゲーム起動毎に変わるため、現在の値を使用する
			BitConverter.GetBytes( this.Data.MagicNumber ).CopyTo( record, 0x00 );

			this.Data.SetRecord( record );
			this.Write();

			this.UpdateNamelist();
			// ビューリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.戦法].NeedsRefresh = true;
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Senpoutable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Senpoulist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:戦法:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
