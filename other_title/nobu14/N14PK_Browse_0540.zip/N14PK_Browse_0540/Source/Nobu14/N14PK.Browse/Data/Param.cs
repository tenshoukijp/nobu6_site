﻿// Paramw.cs

using System;
using System.ComponentModel;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>Paramビューで使用するデータクラス</summary>
	public class Param : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工のParamデータ</summary>
		public ParamData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID					// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address				// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex		// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}
		public string Name				// パラメータ名
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Name );
			}
		}
		public int Value				// 値
		{
			get { return this.Data.Value; }
			set
			{
				if ( value == this.Value ) { return; }
				this.Data.Value = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Value );
				this.PropertyChanged.Raise( () => this.IsNotDefault );
			}
		}
		public string DefaultValue		// 初期値
		{
			get { return ( this.Data.DefaultValue != null ) ? this.Data.DefaultValue.ToString() : "N/A"; }
		}
		public bool IsNotDefault		// 変更フラグ
		{
			get
			{
				if ( this.Data.DefaultValue != null
					&& this.Value != this.Data.DefaultValue
					)
				{
					return true;
				}
				return false;
			}
			set { }
		}


		/// <summary>コンストラクタ Param</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Param( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Paramtable[id];
		}

		///// <summary>Paramリストを更新する</summary>
		//private void UpdateParamNameList()
		//{
		//	var namelist = this.N14pkb.Paramlist.Namelist;
		//	var oldname = namelist[this.SortID];
		//	namelist[this.SortID] = this.Name;
		//	// 成長型ビューカラムヘッダ名変更
		//	var columns = this.N14pkb.MainWindowInterface.DataGrids[(int)Enums.TabKind.成長型].Columns;
		//	for ( var i = 0; i < columns.Count; i++ )
		//	{
		//		if ( (string)( columns[i].Header ) == oldname )
		//		{
		//			columns[i].Header = this.Name;
		//			// 成長型ビュー更新
		//			this.N14pkb.View.Flags[(int)Enums.TabKind.成長型].NeedsRefresh = true;
		//			break;
		//		}
		//	}
		//}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			var record = BitConverter.GetBytes( this.Data.Value );
			return record;
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			var record = (byte[])buff.Clone();
			this.Data.Value = BitConverter.ToInt32( record, 0 );
			this.Write();

			// ビュー更新フラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.Param].NeedsRefresh = true;
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.Paramlist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:Param:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
