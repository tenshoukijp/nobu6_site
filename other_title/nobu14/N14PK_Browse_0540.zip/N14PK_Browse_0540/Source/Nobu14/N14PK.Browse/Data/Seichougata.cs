﻿// Seichougata.cs

using System;
using System.ComponentModel;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>成長型ビューで使用するデータクラス</summary>
	public class Seichougata : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の成長型データ</summary>
		public SeichougataData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID				// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address			// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex	// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}
		public string Name			// 成長型名
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => Name );
				this.UpdateNamelist();
			}
		}
		public string Tokusei001	// 特性習得条件001
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[000] ); }
			set
			{
				if ( value == this.Tokusei001 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[000] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei001 );
			}
		}
		public string Tokusei002	// 特性習得条件002
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[001] ); }
			set
			{
				if ( value == this.Tokusei002 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[001] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei002 );
			}
		}
		public string Tokusei003	// 特性習得条件003
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[002] ); }
			set
			{
				if ( value == this.Tokusei003 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[002] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei003 );
			}
		}
		public string Tokusei004	// 特性習得条件004
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[003] ); }
			set
			{
				if ( value == this.Tokusei004 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[003] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei004 );
			}
		}
		public string Tokusei005	// 特性習得条件005
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[004] ); }
			set
			{
				if ( value == this.Tokusei005 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[004] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei005 );
			}
		}
		public string Tokusei006	// 特性習得条件006
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[005] ); }
			set
			{
				if ( value == this.Tokusei006 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[005] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei006 );
			}
		}
		public string Tokusei007	// 特性習得条件007
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[006] ); }
			set
			{
				if ( value == this.Tokusei007 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[006] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei007 );
			}
		}
		public string Tokusei008	// 特性習得条件008
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[007] ); }
			set
			{
				if ( value == this.Tokusei008 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[007] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei008 );
			}
		}
		public string Tokusei009	// 特性習得条件009
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[008] ); }
			set
			{
				if ( value == this.Tokusei009 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[008] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei009 );
			}
		}
		public string Tokusei010	// 特性習得条件010
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[009] ); }
			set
			{
				if ( value == this.Tokusei010 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[009] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei010 );
			}
		}
		public string Tokusei011	// 特性習得条件011
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[010] ); }
			set
			{
				if ( value == this.Tokusei011 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[010] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei011 );
			}
		}
		public string Tokusei012	// 特性習得条件012
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[011] ); }
			set
			{
				if ( value == this.Tokusei012 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[011] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei012 );
			}
		}
		public string Tokusei013	// 特性習得条件013
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[012] ); }
			set
			{
				if ( value == this.Tokusei013 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[012] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei013 );
			}
		}
		public string Tokusei014	// 特性習得条件014
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[013] ); }
			set
			{
				if ( value == this.Tokusei014 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[013] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei014 );
			}
		}
		public string Tokusei015	// 特性習得条件015
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[014] ); }
			set
			{
				if ( value == this.Tokusei015 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[014] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei015 );
			}
		}
		public string Tokusei016	// 特性習得条件016
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[015] ); }
			set
			{
				if ( value == this.Tokusei016 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[015] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei016 );
			}
		}
		public string Tokusei017	// 特性習得条件017
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[016] ); }
			set
			{
				if ( value == this.Tokusei017 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[016] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei017 );
			}
		}
		public string Tokusei018	// 特性習得条件018
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[017] ); }
			set
			{
				if ( value == this.Tokusei018 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[017] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei018 );
			}
		}
		public string Tokusei019	// 特性習得条件019
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[018] ); }
			set
			{
				if ( value == this.Tokusei019 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[018] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei019 );
			}
		}
		public string Tokusei020	// 特性習得条件020
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[019] ); }
			set
			{
				if ( value == this.Tokusei020 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[019] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei020 );
			}
		}
		public string Tokusei021	// 特性習得条件021
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[020] ); }
			set
			{
				if ( value == this.Tokusei021 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[020] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei021 );
			}
		}
		public string Tokusei022	// 特性習得条件022
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[021] ); }
			set
			{
				if ( value == this.Tokusei022 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[021] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei022 );
			}
		}
		public string Tokusei023	// 特性習得条件023
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[022] ); }
			set
			{
				if ( value == this.Tokusei023 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[022] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei023 );
			}
		}
		public string Tokusei024	// 特性習得条件024
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[023] ); }
			set
			{
				if ( value == this.Tokusei024 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[023] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei024 );
			}
		}
		public string Tokusei025	// 特性習得条件025
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[024] ); }
			set
			{
				if ( value == this.Tokusei025 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[024] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei025 );
			}
		}
		public string Tokusei026	// 特性習得条件026
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[025] ); }
			set
			{
				if ( value == this.Tokusei026 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[025] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei026 );
			}
		}
		public string Tokusei027	// 特性習得条件027
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[026] ); }
			set
			{
				if ( value == this.Tokusei027 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[026] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei027 );
			}
		}
		public string Tokusei028	// 特性習得条件028
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[027] ); }
			set
			{
				if ( value == this.Tokusei028 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[027] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei028 );
			}
		}
		public string Tokusei029	// 特性習得条件029
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[028] ); }
			set
			{
				if ( value == this.Tokusei029 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[028] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei029 );
			}
		}
		public string Tokusei030	// 特性習得条件030
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[029] ); }
			set
			{
				if ( value == this.Tokusei030 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[029] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei030 );
			}
		}
		public string Tokusei031	// 特性習得条件031
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[030] ); }
			set
			{
				if ( value == this.Tokusei031 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[030] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei031 );
			}
		}
		public string Tokusei032	// 特性習得条件032
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[031] ); }
			set
			{
				if ( value == this.Tokusei032 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[031] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei032 );
			}
		}
		public string Tokusei033	// 特性習得条件033
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[032] ); }
			set
			{
				if ( value == this.Tokusei033 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[032] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei033 );
			}
		}
		public string Tokusei034	// 特性習得条件034
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[033] ); }
			set
			{
				if ( value == this.Tokusei034 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[033] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei034 );
			}
		}
		public string Tokusei035	// 特性習得条件035
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[034] ); }
			set
			{
				if ( value == this.Tokusei035 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[034] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei035 );
			}
		}
		public string Tokusei036	// 特性習得条件036
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[035] ); }
			set
			{
				if ( value == this.Tokusei036 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[035] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei036 );
			}
		}
		public string Tokusei037	// 特性習得条件037
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[036] ); }
			set
			{
				if ( value == this.Tokusei037 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[036] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei037 );
			}
		}
		public string Tokusei038	// 特性習得条件038
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[037] ); }
			set
			{
				if ( value == this.Tokusei038 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[037] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei038 );
			}
		}
		public string Tokusei039	// 特性習得条件039
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[038] ); }
			set
			{
				if ( value == this.Tokusei039 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[038] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei039 );
			}
		}
		public string Tokusei040	// 特性習得条件040
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[039] ); }
			set
			{
				if ( value == this.Tokusei040 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[039] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei040 );
			}
		}
		public string Tokusei041	// 特性習得条件041
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[040] ); }
			set
			{
				if ( value == this.Tokusei041 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[040] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei041 );
			}
		}
		public string Tokusei042	// 特性習得条件042
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[041] ); }
			set
			{
				if ( value == this.Tokusei042 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[041] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei042 );
			}
		}
		public string Tokusei043	// 特性習得条件043
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[042] ); }
			set
			{
				if ( value == this.Tokusei043 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[042] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei043 );
			}
		}
		public string Tokusei044	// 特性習得条件044
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[043] ); }
			set
			{
				if ( value == this.Tokusei044 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[043] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei044 );
			}
		}
		public string Tokusei045	// 特性習得条件045
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[044] ); }
			set
			{
				if ( value == this.Tokusei045 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[044] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei045 );
			}
		}
		public string Tokusei046	// 特性習得条件046
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[045] ); }
			set
			{
				if ( value == this.Tokusei046 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[045] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei046 );
			}
		}
		public string Tokusei047	// 特性習得条件047
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[046] ); }
			set
			{
				if ( value == this.Tokusei047 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[046] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei047 );
			}
		}
		public string Tokusei048	// 特性習得条件048
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[047] ); }
			set
			{
				if ( value == this.Tokusei048 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[047] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei048 );
			}
		}
		public string Tokusei049	// 特性習得条件049
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[048] ); }
			set
			{
				if ( value == this.Tokusei049 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[048] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei049 );
			}
		}
		public string Tokusei050	// 特性習得条件050
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[049] ); }
			set
			{
				if ( value == this.Tokusei050 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[049] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei050 );
			}
		}
		public string Tokusei051	// 特性習得条件051
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[050] ); }
			set
			{
				if ( value == this.Tokusei051 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[050] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei051 );
			}
		}
		public string Tokusei052	// 特性習得条件052
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[051] ); }
			set
			{
				if ( value == this.Tokusei052 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[051] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei052 );
			}
		}
		public string Tokusei053	// 特性習得条件053
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[052] ); }
			set
			{
				if ( value == this.Tokusei053 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[052] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei053 );
			}
		}
		public string Tokusei054	// 特性習得条件054
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[053] ); }
			set
			{
				if ( value == this.Tokusei054 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[053] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei054 );
			}
		}
		public string Tokusei055	// 特性習得条件055
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[054] ); }
			set
			{
				if ( value == this.Tokusei055 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[054] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei055 );
			}
		}
		public string Tokusei056	// 特性習得条件056
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[055] ); }
			set
			{
				if ( value == this.Tokusei056 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[055] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei056 );
			}
		}
		public string Tokusei057	// 特性習得条件057
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[056] ); }
			set
			{
				if ( value == this.Tokusei057 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[056] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei057 );
			}
		}
		public string Tokusei058	// 特性習得条件058
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[057] ); }
			set
			{
				if ( value == this.Tokusei058 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[057] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei058 );
			}
		}
		public string Tokusei059	// 特性習得条件059
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[058] ); }
			set
			{
				if ( value == this.Tokusei059 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[058] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei059 );
			}
		}
		public string Tokusei060	// 特性習得条件060
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[059] ); }
			set
			{
				if ( value == this.Tokusei060 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[059] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei060 );
			}
		}
		public string Tokusei061	// 特性習得条件061
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[060] ); }
			set
			{
				if ( value == this.Tokusei061 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[060] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei061 );
			}
		}
		public string Tokusei062	// 特性習得条件062
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[061] ); }
			set
			{
				if ( value == this.Tokusei062 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[061] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei062 );
			}
		}
		public string Tokusei063	// 特性習得条件063
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[062] ); }
			set
			{
				if ( value == this.Tokusei063 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[062] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei063 );
			}
		}
		public string Tokusei064	// 特性習得条件064
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[063] ); }
			set
			{
				if ( value == this.Tokusei064 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[063] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei064 );
			}
		}
		public string Tokusei065	// 特性習得条件065
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[064] ); }
			set
			{
				if ( value == this.Tokusei065 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[064] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei065 );
			}
		}
		public string Tokusei066	// 特性習得条件066
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[065] ); }
			set
			{
				if ( value == this.Tokusei066 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[065] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei066 );
			}
		}
		public string Tokusei067	// 特性習得条件067
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[066] ); }
			set
			{
				if ( value == this.Tokusei067 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[066] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei067 );
			}
		}
		public string Tokusei068	// 特性習得条件068
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[067] ); }
			set
			{
				if ( value == this.Tokusei068 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[067] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei068 );
			}
		}
		public string Tokusei069	// 特性習得条件069
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[068] ); }
			set
			{
				if ( value == this.Tokusei069 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[068] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei069 );
			}
		}
		public string Tokusei070	// 特性習得条件070
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[069] ); }
			set
			{
				if ( value == this.Tokusei070 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[069] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei070 );
			}
		}
		public string Tokusei071	// 特性習得条件071
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[070] ); }
			set
			{
				if ( value == this.Tokusei071 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[070] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei071 );
			}
		}
		public string Tokusei072	// 特性習得条件072
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[071] ); }
			set
			{
				if ( value == this.Tokusei072 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[071] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei072 );
			}
		}
		public string Tokusei073	// 特性習得条件073
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[072] ); }
			set
			{
				if ( value == this.Tokusei073 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[072] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei073 );
			}
		}
		public string Tokusei074	// 特性習得条件074
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[073] ); }
			set
			{
				if ( value == this.Tokusei074 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[073] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei074 );
			}
		}
		public string Tokusei075	// 特性習得条件075
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[074] ); }
			set
			{
				if ( value == this.Tokusei075 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[074] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei075 );
			}
		}
		public string Tokusei076	// 特性習得条件076
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[075] ); }
			set
			{
				if ( value == this.Tokusei076 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[075] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei076 );
			}
		}
		public string Tokusei077	// 特性習得条件077
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[076] ); }
			set
			{
				if ( value == this.Tokusei077 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[076] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei077 );
			}
		}
		public string Tokusei078	// 特性習得条件078
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[077] ); }
			set
			{
				if ( value == this.Tokusei078 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[077] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei078 );
			}
		}
		public string Tokusei079	// 特性習得条件079
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[078] ); }
			set
			{
				if ( value == this.Tokusei079 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[078] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei079 );
			}
		}
		public string Tokusei080	// 特性習得条件080
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[079] ); }
			set
			{
				if ( value == this.Tokusei080 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[079] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei080 );
			}
		}
		public string Tokusei081	// 特性習得条件081
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[080] ); }
			set
			{
				if ( value == this.Tokusei081 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[080] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei081 );
			}
		}
		public string Tokusei082	// 特性習得条件082
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[081] ); }
			set
			{
				if ( value == this.Tokusei082 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[081] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei082 );
			}
		}
		public string Tokusei083	// 特性習得条件083
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[082] ); }
			set
			{
				if ( value == this.Tokusei083 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[082] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei083 );
			}
		}
		public string Tokusei084	// 特性習得条件084
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[083] ); }
			set
			{
				if ( value == this.Tokusei084 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[083] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei084 );
			}
		}
		public string Tokusei085	// 特性習得条件085
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[084] ); }
			set
			{
				if ( value == this.Tokusei085 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[084] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei085 );
			}
		}
		public string Tokusei086	// 特性習得条件086
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[085] ); }
			set
			{
				if ( value == this.Tokusei086 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[085] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei086 );
			}
		}
		public string Tokusei087	// 特性習得条件087
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[086] ); }
			set
			{
				if ( value == this.Tokusei087 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[086] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei087 );
			}
		}
		public string Tokusei088	// 特性習得条件088
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[087] ); }
			set
			{
				if ( value == this.Tokusei088 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[087] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei088 );
			}
		}
		public string Tokusei089	// 特性習得条件089
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[088] ); }
			set
			{
				if ( value == this.Tokusei089 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[088] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei089 );
			}
		}
		public string Tokusei090	// 特性習得条件090
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[089] ); }
			set
			{
				if ( value == this.Tokusei090 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[089] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei090 );
			}
		}
		public string Tokusei091	// 特性習得条件091
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[090] ); }
			set
			{
				if ( value == this.Tokusei091 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[090] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei091 );
			}
		}
		public string Tokusei092	// 特性習得条件092
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[091] ); }
			set
			{
				if ( value == this.Tokusei092 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[091] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei092 );
			}
		}
		public string Tokusei093	// 特性習得条件093
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[092] ); }
			set
			{
				if ( value == this.Tokusei093 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[092] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei093 );
			}
		}
		public string Tokusei094	// 特性習得条件094
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[093] ); }
			set
			{
				if ( value == this.Tokusei094 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[093] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei094 );
			}
		}
		public string Tokusei095	// 特性習得条件095
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[094] ); }
			set
			{
				if ( value == this.Tokusei095 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[094] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei095 );
			}
		}
		public string Tokusei096	// 特性習得条件096
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[095] ); }
			set
			{
				if ( value == this.Tokusei096 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[095] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei096 );
			}
		}
		public string Tokusei097	// 特性習得条件097
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[096] ); }
			set
			{
				if ( value == this.Tokusei097 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[096] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei097 );
			}
		}
		public string Tokusei098	// 特性習得条件098
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[097] ); }
			set
			{
				if ( value == this.Tokusei098 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[097] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei098 );
			}
		}
		public string Tokusei099	// 特性習得条件099
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[098] ); }
			set
			{
				if ( value == this.Tokusei099 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[098] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei099 );
			}
		}
		public string Tokusei100	// 特性習得条件100
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[099] ); }
			set
			{
				if ( value == this.Tokusei100 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[099] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei100 );
			}
		}
		public string Tokusei101	// 特性習得条件101
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[100] ); }
			set
			{
				if ( value == this.Tokusei101 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[100] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei101 );
			}
		}
		public string Tokusei102	// 特性習得条件102
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[101] ); }
			set
			{
				if ( value == this.Tokusei102 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[101] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei102 );
			}
		}
		public string Tokusei103	// 特性習得条件103
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[102] ); }
			set
			{
				if ( value == this.Tokusei103 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[102] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei103 );
			}
		}
		public string Tokusei104	// 特性習得条件104
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[103] ); }
			set
			{
				if ( value == this.Tokusei104 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[103] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei104 );
			}
		}
		public string Tokusei105	// 特性習得条件105
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[104] ); }
			set
			{
				if ( value == this.Tokusei105 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[104] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei105 );
			}
		}
		public string Tokusei106	// 特性習得条件106
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[105] ); }
			set
			{
				if ( value == this.Tokusei106 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[105] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei106 );
			}
		}
		public string Tokusei107	// 特性習得条件107
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[106] ); }
			set
			{
				if ( value == this.Tokusei107 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[106] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei107 );
			}
		}
		public string Tokusei108	// 特性習得条件108
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[107] ); }
			set
			{
				if ( value == this.Tokusei108 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[107] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei108 );
			}
		}
		public string Tokusei109	// 特性習得条件109
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[108] ); }
			set
			{
				if ( value == this.Tokusei109 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[108] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei109 );
			}
		}
		public string Tokusei110	// 特性習得条件110
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[109] ); }
			set
			{
				if ( value == this.Tokusei110 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[109] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei110 );
			}
		}
		public string Tokusei111	// 特性習得条件111
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[110] ); }
			set
			{
				if ( value == this.Tokusei111 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[110] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei111 );
			}
		}
		public string Tokusei112	// 特性習得条件112
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[111] ); }
			set
			{
				if ( value == this.Tokusei112 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[111] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei112 );
			}
		}
		public string Tokusei113	// 特性習得条件113
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[112] ); }
			set
			{
				if ( value == this.Tokusei113 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[112] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei113 );
			}
		}
		public string Tokusei114	// 特性習得条件114
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[113] ); }
			set
			{
				if ( value == this.Tokusei114 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[113] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei114 );
			}
		}
		public string Tokusei115	// 特性習得条件115
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[114] ); }
			set
			{
				if ( value == this.Tokusei115 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[114] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei115 );
			}
		}
		public string Tokusei116	// 特性習得条件116
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[115] ); }
			set
			{
				if ( value == this.Tokusei116 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[115] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei116 );
			}
		}
		public string Tokusei117	// 特性習得条件117
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[116] ); }
			set
			{
				if ( value == this.Tokusei117 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[116] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei117 );
			}
		}
		public string Tokusei118	// 特性習得条件118
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[117] ); }
			set
			{
				if ( value == this.Tokusei118 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[117] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei118 );
			}
		}
		public string Tokusei119	// 特性習得条件119
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[118] ); }
			set
			{
				if ( value == this.Tokusei119 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[118] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei119 );
			}
		}
		public string Tokusei120	// 特性習得条件120
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[119] ); }
			set
			{
				if ( value == this.Tokusei120 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[119] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei120 );
			}
		}
		public string Tokusei121	// 特性習得条件121
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[120] ); }
			set
			{
				if ( value == this.Tokusei121 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[120] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei121 );
			}
		}
		public string Tokusei122	// 特性習得条件122
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[121] ); }
			set
			{
				if ( value == this.Tokusei122 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[121] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei122 );
			}
		}
		public string Tokusei123	// 特性習得条件123
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[122] ); }
			set
			{
				if ( value == this.Tokusei123 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[122] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei123 );
			}
		}
		public string Tokusei124	// 特性習得条件124
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[123] ); }
			set
			{
				if ( value == this.Tokusei124 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[123] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei124 );
			}
		}
		public string Tokusei125	// 特性習得条件125
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[124] ); }
			set
			{
				if ( value == this.Tokusei125 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[124] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei125 );
			}
		}
		public string Tokusei126	// 特性習得条件126
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[125] ); }
			set
			{
				if ( value == this.Tokusei126 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[125] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei126 );
			}
		}
		public string Tokusei127	// 特性習得条件127
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[126] ); }
			set
			{
				if ( value == this.Tokusei127 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[126] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei127 );
			}
		}
		public string Tokusei128	// 特性習得条件128
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[127] ); }
			set
			{
				if ( value == this.Tokusei128 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[127] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei128 );
			}
		}
		public string Tokusei129	// 特性習得条件129
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[128] ); }
			set
			{
				if ( value == this.Tokusei129 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[128] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei129 );
			}
		}
		public string Tokusei130	// 特性習得条件130
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[129] ); }
			set
			{
				if ( value == this.Tokusei130 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[129] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei130 );
			}
		}
		public string Tokusei131	// 特性習得条件131
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[130] ); }
			set
			{
				if ( value == this.Tokusei131 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[130] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei131 );
			}
		}
		public string Tokusei132	// 特性習得条件132
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[131] ); }
			set
			{
				if ( value == this.Tokusei132 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[131] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei132 );
			}
		}
		public string Tokusei133	// 特性習得条件133
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[132] ); }
			set
			{
				if ( value == this.Tokusei133 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[132] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei133 );
			}
		}
		public string Tokusei134	// 特性習得条件134
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[133] ); }
			set
			{
				if ( value == this.Tokusei134 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[133] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei134 );
			}
		}
		public string Tokusei135	// 特性習得条件135
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[134] ); }
			set
			{
				if ( value == this.Tokusei135 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[134] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei135 );
			}
		}
		public string Tokusei136	// 特性習得条件136
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[135] ); }
			set
			{
				if ( value == this.Tokusei136 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[135] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei136 );
			}
		}
		public string Tokusei137	// 特性習得条件137
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[136] ); }
			set
			{
				if ( value == this.Tokusei137 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[136] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei137 );
			}
		}
		public string Tokusei138	// 特性習得条件138
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[137] ); }
			set
			{
				if ( value == this.Tokusei138 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[137] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei138 );
			}
		}
		public string Tokusei139	// 特性習得条件139
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[138] ); }
			set
			{
				if ( value == this.Tokusei139 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[138] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei139 );
			}
		}
		public string Tokusei140	// 特性習得条件140
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[139] ); }
			set
			{
				if ( value == this.Tokusei140 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[139] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei140 );
			}
		}
		public string Tokusei141	// 特性習得条件141
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[140] ); }
			set
			{
				if ( value == this.Tokusei141 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[140] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei141 );
			}
		}
		public string Tokusei142	// 特性習得条件142
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[141] ); }
			set
			{
				if ( value == this.Tokusei142 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[141] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei142 );
			}
		}
		public string Tokusei143	// 特性習得条件143
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[142] ); }
			set
			{
				if ( value == this.Tokusei143 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[142] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei143 );
			}
		}
		public string Tokusei144	// 特性習得条件144
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[143] ); }
			set
			{
				if ( value == this.Tokusei144 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[143] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei144 );
			}
		}
		public string Tokusei145	// 特性習得条件145
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[144] ); }
			set
			{
				if ( value == this.Tokusei145 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[144] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei145 );
			}
		}
		public string Tokusei146	// 特性習得条件146
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[145] ); }
			set
			{
				if ( value == this.Tokusei146 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[145] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei146 );
			}
		}
		public string Tokusei147	// 特性習得条件147
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[146] ); }
			set
			{
				if ( value == this.Tokusei147 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[146] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei147 );
			}
		}
		public string Tokusei148	// 特性習得条件148
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[147] ); }
			set
			{
				if ( value == this.Tokusei148 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[147] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei148 );
			}
		}
		public string Tokusei149	// 特性習得条件149
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[148] ); }
			set
			{
				if ( value == this.Tokusei149 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[148] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei149 );
			}
		}
		public string Tokusei150	// 特性習得条件150
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[149] ); }
			set
			{
				if ( value == this.Tokusei150 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[149] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei150 );
			}
		}
		public string Tokusei151	// 特性習得条件151
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[150] ); }
			set
			{
				if ( value == this.Tokusei151 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[150] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei151 );
			}
		}
		public string Tokusei152	// 特性習得条件152
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[151] ); }
			set
			{
				if ( value == this.Tokusei152 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[151] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei152 );
			}
		}
		public string Tokusei153	// 特性習得条件153
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[152] ); }
			set
			{
				if ( value == this.Tokusei153 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[152] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei153 );
			}
		}
		public string Tokusei154	// 特性習得条件154
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[153] ); }
			set
			{
				if ( value == this.Tokusei154 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[153] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei154 );
			}
		}
		public string Tokusei155	// 特性習得条件155
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[154] ); }
			set
			{
				if ( value == this.Tokusei155 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[154] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei155 );
			}
		}
		public string Tokusei156	// 特性習得条件156
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[155] ); }
			set
			{
				if ( value == this.Tokusei156 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[155] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei156 );
			}
		}
		public string Tokusei157	// 特性習得条件157
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[156] ); }
			set
			{
				if ( value == this.Tokusei157 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[156] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei157 );
			}
		}
		public string Tokusei158	// 特性習得条件158
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[157] ); }
			set
			{
				if ( value == this.Tokusei158 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[157] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei158 );
			}
		}
		public string Tokusei159	// 特性習得条件159
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[158] ); }
			set
			{
				if ( value == this.Tokusei159 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[158] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei159 );
			}
		}
		public string Tokusei160	// 特性習得条件160
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[159] ); }
			set
			{
				if ( value == this.Tokusei160 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[159] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei160 );
			}
		}
		public string Tokusei161	// 特性習得条件161
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[160] ); }
			set
			{
				if ( value == this.Tokusei161 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[160] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei161 );
			}
		}
		public string Tokusei162	// 特性習得条件162
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[161] ); }
			set
			{
				if ( value == this.Tokusei162 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[161] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei162 );
			}
		}
		public string Tokusei163	// 特性習得条件163
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[162] ); }
			set
			{
				if ( value == this.Tokusei163 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[162] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei163 );
			}
		}
		public string Tokusei164	// 特性習得条件164
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[163] ); }
			set
			{
				if ( value == this.Tokusei164 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[163] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei164 );
			}
		}
		public string Tokusei165	// 特性習得条件165
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[164] ); }
			set
			{
				if ( value == this.Tokusei165 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[164] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei165 );
			}
		}
		public string Tokusei166	// 特性習得条件166
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[165] ); }
			set
			{
				if ( value == this.Tokusei166 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[165] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei166 );
			}
		}
		public string Tokusei167	// 特性習得条件167
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[166] ); }
			set
			{
				if ( value == this.Tokusei167 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[166] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei167 );
			}
		}
		public string Tokusei168	// 特性習得条件168
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[167] ); }
			set
			{
				if ( value == this.Tokusei168 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[167] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei168 );
			}
		}
		public string Tokusei169	// 特性習得条件169
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[168] ); }
			set
			{
				if ( value == this.Tokusei169 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[168] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei169 );
			}
		}
		public string Tokusei170	// 特性習得条件170
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[169] ); }
			set
			{
				if ( value == this.Tokusei170 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[169] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei170 );
			}
		}
		public string Tokusei171	// 特性習得条件171
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[170] ); }
			set
			{
				if ( value == this.Tokusei171 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[170] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei171 );
			}
		}
		public string Tokusei172	// 特性習得条件172
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[171] ); }
			set
			{
				if ( value == this.Tokusei172 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[171] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei172 );
			}
		}
		public string Tokusei173	// 特性習得条件173
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[172] ); }
			set
			{
				if ( value == this.Tokusei173 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[172] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei173 );
			}
		}
		public string Tokusei174	// 特性習得条件174
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[173] ); }
			set
			{
				if ( value == this.Tokusei174 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[173] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei174 );
			}
		}
		public string Tokusei175	// 特性習得条件175
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[174] ); }
			set
			{
				if ( value == this.Tokusei175 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[174] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei175 );
			}
		}
		public string Tokusei176	// 特性習得条件176
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[175] ); }
			set
			{
				if ( value == this.Tokusei176 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[175] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei176 );
			}
		}
		public string Tokusei177	// 特性習得条件177
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[176] ); }
			set
			{
				if ( value == this.Tokusei177 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[176] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei177 );
			}
		}
		public string Tokusei178	// 特性習得条件178
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[177] ); }
			set
			{
				if ( value == this.Tokusei178 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[177] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei178 );
			}
		}
		public string Tokusei179	// 特性習得条件179
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[178] ); }
			set
			{
				if ( value == this.Tokusei179 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[178] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei179 );
			}
		}
		public string Tokusei180	// 特性習得条件180
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[179] ); }
			set
			{
				if ( value == this.Tokusei180 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[179] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei180 );
			}
		}
		public string Tokusei181	// 特性習得条件181
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[180] ); }
			set
			{
				if ( value == this.Tokusei181 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[180] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei181 );
			}
		}
		public string Tokusei182	// 特性習得条件182
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[181] ); }
			set
			{
				if ( value == this.Tokusei182 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[181] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei182 );
			}
		}
		public string Tokusei183	// 特性習得条件183
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[182] ); }
			set
			{
				if ( value == this.Tokusei183 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[182] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei183 );
			}
		}
		public string Tokusei184	// 特性習得条件184
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[183] ); }
			set
			{
				if ( value == this.Tokusei184 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[183] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei184 );
			}
		}
		public string Tokusei185	// 特性習得条件185
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[184] ); }
			set
			{
				if ( value == this.Tokusei185 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[184] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei185 );
			}
		}
		public string Tokusei186	// 特性習得条件186
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[185] ); }
			set
			{
				if ( value == this.Tokusei186 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[185] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei186 );
			}
		}
		public string Tokusei187	// 特性習得条件187
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[186] ); }
			set
			{
				if ( value == this.Tokusei187 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[186] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei187 );
			}
		}
		public string Tokusei188	// 特性習得条件188
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[187] ); }
			set
			{
				if ( value == this.Tokusei188 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[187] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei188 );
			}
		}
		public string Tokusei189	// 特性習得条件189
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[188] ); }
			set
			{
				if ( value == this.Tokusei189 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[188] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei189 );
			}
		}
		public string Tokusei190	// 特性習得条件190
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[189] ); }
			set
			{
				if ( value == this.Tokusei190 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[189] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei190 );
			}
		}
		public string Tokusei191	// 特性習得条件191
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[190] ); }
			set
			{
				if ( value == this.Tokusei191 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[190] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei191 );
			}
		}
		public string Tokusei192	// 特性習得条件192
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[191] ); }
			set
			{
				if ( value == this.Tokusei192 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[191] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei192 );
			}
		}
		public string Tokusei193	// 特性習得条件193
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[192] ); }
			set
			{
				if ( value == this.Tokusei193 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[192] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei193 );
			}
		}
		public string Tokusei194	// 特性習得条件194
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[193] ); }
			set
			{
				if ( value == this.Tokusei194 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[193] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei194 );
			}
		}
		public string Tokusei195	// 特性習得条件195
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[194] ); }
			set
			{
				if ( value == this.Tokusei195 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[194] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei195 );
			}
		}
		public string Tokusei196	// 特性習得条件196
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[195] ); }
			set
			{
				if ( value == this.Tokusei196 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[195] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei196 );
			}
		}
		public string Tokusei197	// 特性習得条件197
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[196] ); }
			set
			{
				if ( value == this.Tokusei197 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[196] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei197 );
			}
		}
		public string Tokusei198	// 特性習得条件198
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[197] ); }
			set
			{
				if ( value == this.Tokusei198 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[197] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei198 );
			}
		}
		public string Tokusei199	// 特性習得条件199
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[198] ); }
			set
			{
				if ( value == this.Tokusei199 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[198] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei199 );
			}
		}
		public string Tokusei200	// 特性習得条件200
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[199] ); }
			set
			{
				if ( value == this.Tokusei200 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[199] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei200 );
			}
		}
		public string Tokusei201	// 特性習得条件201
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[200] ); }
			set
			{
				if ( value == this.Tokusei201 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[200] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei201 );
			}
		}
		public string Tokusei202	// 特性習得条件202
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[201] ); }
			set
			{
				if ( value == this.Tokusei202 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[201] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei202 );
			}
		}
		public string Tokusei203	// 特性習得条件203
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[202] ); }
			set
			{
				if ( value == this.Tokusei203 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[202] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei203 );
			}
		}
		public string Tokusei204	// 特性習得条件204
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[203] ); }
			set
			{
				if ( value == this.Tokusei204 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[203] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei204 );
			}
		}
		public string Tokusei205	// 特性習得条件205
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[204] ); }
			set
			{
				if ( value == this.Tokusei205 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[204] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei205 );
			}
		}
		public string Tokusei206	// 特性習得条件206
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[205] ); }
			set
			{
				if ( value == this.Tokusei206 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[205] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei206 );
			}
		}
		public string Tokusei207	// 特性習得条件207
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[206] ); }
			set
			{
				if ( value == this.Tokusei207 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[206] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei207 );
			}
		}
		public string Tokusei208	// 特性習得条件208
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[207] ); }
			set
			{
				if ( value == this.Tokusei208 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[207] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei208 );
			}
		}
		public string Tokusei209	// 特性習得条件209
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[208] ); }
			set
			{
				if ( value == this.Tokusei209 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[208] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei209 );
			}
		}
		public string Tokusei210	// 特性習得条件210
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[209] ); }
			set
			{
				if ( value == this.Tokusei210 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[209] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei210 );
			}
		}
		public string Tokusei211	// 特性習得条件211
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[210] ); }
			set
			{
				if ( value == this.Tokusei211 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[210] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei211 );
			}
		}
		public string Tokusei212	// 特性習得条件212
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[211] ); }
			set
			{
				if ( value == this.Tokusei212 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[211] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei212 );
			}
		}
		public string Tokusei213	// 特性習得条件213
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[212] ); }
			set
			{
				if ( value == this.Tokusei213 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[212] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei213 );
			}
		}
		public string Tokusei214	// 特性習得条件214
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[213] ); }
			set
			{
				if ( value == this.Tokusei214 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[213] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei214 );
			}
		}
		public string Tokusei215	// 特性習得条件215
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[214] ); }
			set
			{
				if ( value == this.Tokusei215 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[214] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei215 );
			}
		}
		public string Tokusei216	// 特性習得条件216
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[215] ); }
			set
			{
				if ( value == this.Tokusei216 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[215] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei216 );
			}
		}
		public string Tokusei217	// 特性習得条件217
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[216] ); }
			set
			{
				if ( value == this.Tokusei217 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[216] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei217 );
			}
		}
		public string Tokusei218	// 特性習得条件218
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[217] ); }
			set
			{
				if ( value == this.Tokusei218 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[217] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei218 );
			}
		}
		public string Tokusei219	// 特性習得条件219
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[218] ); }
			set
			{
				if ( value == this.Tokusei219 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[218] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei219 );
			}
		}
		public string Tokusei220	// 特性習得条件220
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[219] ); }
			set
			{
				if ( value == this.Tokusei220 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[219] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei220 );
			}
		}
		public string Tokusei221	// 特性習得条件221
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[220] ); }
			set
			{
				if ( value == this.Tokusei221 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[220] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei221 );
			}
		}
		public string Tokusei222	// 特性習得条件222
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[221] ); }
			set
			{
				if ( value == this.Tokusei222 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[221] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei222 );
			}
		}
		public string Tokusei223	// 特性習得条件223
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[222] ); }
			set
			{
				if ( value == this.Tokusei223 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[222] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei223 );
			}
		}
		public string Tokusei224	// 特性習得条件224
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[223] ); }
			set
			{
				if ( value == this.Tokusei224 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[223] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei224 );
			}
		}
		public string Tokusei225	// 特性習得条件225
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[224] ); }
			set
			{
				if ( value == this.Tokusei225 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[224] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei225 );
			}
		}
		public string Tokusei226	// 特性習得条件226
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[225] ); }
			set
			{
				if ( value == this.Tokusei226 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[225] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei226 );
			}
		}
		public string Tokusei227	// 特性習得条件227
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[226] ); }
			set
			{
				if ( value == this.Tokusei227 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[226] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei227 );
			}
		}
		public string Tokusei228	// 特性習得条件228
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[227] ); }
			set
			{
				if ( value == this.Tokusei228 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[227] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei228 );
			}
		}
		public string Tokusei229	// 特性習得条件229
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[228] ); }
			set
			{
				if ( value == this.Tokusei229 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[228] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei229 );
			}
		}
		public string Tokusei230	// 特性習得条件230
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[229] ); }
			set
			{
				if ( value == this.Tokusei230 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[229] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei230 );
			}
		}
		public string Tokusei231	// 特性習得条件231
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[230] ); }
			set
			{
				if ( value == this.Tokusei231 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[230] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei231 );
			}
		}
		public string Tokusei232	// 特性習得条件232
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[231] ); }
			set
			{
				if ( value == this.Tokusei232 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[231] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei232 );
			}
		}
		public string Tokusei233	// 特性習得条件233
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[232] ); }
			set
			{
				if ( value == this.Tokusei233 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[232] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei233 );
			}
		}
		public string Tokusei234	// 特性習得条件234
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[233] ); }
			set
			{
				if ( value == this.Tokusei234 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[233] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei234 );
			}
		}
		public string Tokusei235	// 特性習得条件235
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[234] ); }
			set
			{
				if ( value == this.Tokusei235 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[234] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei235 );
			}
		}
		public string Tokusei236	// 特性習得条件236
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[235] ); }
			set
			{
				if ( value == this.Tokusei236 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[235] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei236 );
			}
		}
		public string Tokusei237	// 特性習得条件237
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[236] ); }
			set
			{
				if ( value == this.Tokusei237 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[236] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei237 );
			}
		}
		public string Tokusei238	// 特性習得条件238
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[237] ); }
			set
			{
				if ( value == this.Tokusei238 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[237] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei238 );
			}
		}
		public string Tokusei239	// 特性習得条件239
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[238] ); }
			set
			{
				if ( value == this.Tokusei239 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[238] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei239 );
			}
		}
		public string Tokusei240	// 特性習得条件240
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[239] ); }
			set
			{
				if ( value == this.Tokusei240 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[239] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei240 );
			}
		}
		public string Tokusei241	// 特性習得条件241
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[240] ); }
			set
			{
				if ( value == this.Tokusei241 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[240] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei241 );
			}
		}
		public string Tokusei242	// 特性習得条件242
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[241] ); }
			set
			{
				if ( value == this.Tokusei242 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[241] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei242 );
			}
		}
		public string Tokusei243	// 特性習得条件243
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[242] ); }
			set
			{
				if ( value == this.Tokusei243 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[242] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei243 );
			}
		}
		public string Tokusei244	// 特性習得条件244
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[243] ); }
			set
			{
				if ( value == this.Tokusei244 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[243] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei244 );
			}
		}
		public string Tokusei245	// 特性習得条件245
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[244] ); }
			set
			{
				if ( value == this.Tokusei245 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[244] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei245 );
			}
		}
		public string Tokusei246	// 特性習得条件246
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[245] ); }
			set
			{
				if ( value == this.Tokusei246 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[245] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei246 );
			}
		}
		public string Tokusei247	// 特性習得条件247
		{
			get { return this.N14pkb.TokuseiSyuutokuJoukenlist.GetNameByID( this.Data.TokuseiSyuutokuJoukenIDList[246] ); }
			set
			{
				if ( value == this.Tokusei247 ) { return; }
				var list = this.Data.TokuseiSyuutokuJoukenIDList;
				list[246] = (sbyte)this.N14pkb.TokuseiSyuutokuJoukenlist.GetIDByName( value );
				this.Data.TokuseiSyuutokuJoukenIDList = list;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tokusei247 );
			}
		}
		public int SortID			// ソート用？の数値が入っている
		{
			get { return this.Data.SortID; }
			set
			{
				if ( value == this.SortID ) { return; }
				this.Data.SortID = (ushort)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SortID );
			}
		}


		/// <summary>コンストラクタ 成長型</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Seichougata( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Seichougatatable[id];
		}

		/// <summary>成長型名リストを更新する</summary>
		private void UpdateNamelist()
		{
			var list = this.N14pkb.Seichougatalist.Namelist;
			if ( list[this.ID] == this.Name ) { return; }

			list[this.ID] = this.Name;

			// ビュー更新フラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.武将].NeedsRefresh = true;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			byte[] bytes = this.Data.GetRecord();
			return bytes;
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			var record = (byte[])buff.Clone();
			// 先頭4バイトの MagicNumber はゲーム起動毎に変わるため、現在の値を使用する
			BitConverter.GetBytes( this.Data.MagicNumber ).CopyTo( record, 0x00 );

			this.Data.SetRecord( record );
			this.Write();

			this.UpdateNamelist();

			// ビュー更新フラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.成長型].NeedsRefresh = true;
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Seichougatatable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Seichougatalist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:成長型:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
