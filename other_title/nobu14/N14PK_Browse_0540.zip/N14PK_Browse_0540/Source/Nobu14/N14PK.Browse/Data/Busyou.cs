﻿// Busyou.cs

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;
using N14PKBrowse.Enums;
using N14PKBrowse.List;

namespace N14PKBrowse.Data
{
	/// <summary>武将ビューで使用するデータクラス</summary>
	public class Busyou : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の武将データ</summary>
		public BusyouData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }

		public int ID						// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address					// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex			// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}
		public string Name					// 名前(姓+名) ※表示用
		{
			get { return this.Data.Sei + this.Data.Mei; }
			set { throw new NotSupportedException(); }
		}
		public string Sei					// 姓
		{
			get { return this.Data.Sei; }
			set
			{
				if ( value == this.Sei ) { return; }
				this.Data.Sei = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Sei );
				this.UpdateNamelist();
			}
		}
		public string Mei					// 名
		{
			get { return this.Data.Mei; }
			set
			{
				if ( value == this.Mei ) { return; }
				this.Data.Mei = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Mei );
				this.UpdateNamelist();
			}
		}
		public string Yomi					// 読み(姓読み+名読み) ※表示用
		{
			get { return this.Data.SeiYomi + this.Data.MeiYomi; }
		}
		public string SeiYomi				// 姓読み
		{
			get { return this.Data.SeiYomi; }
			set
			{
				if ( value == this.SeiYomi ) { return; }
				this.Data.SeiYomi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SeiYomi );
			}
		}
		public string MeiYomi				// 名読み
		{
			get { return this.Data.MeiYomi; }
			set
			{
				if ( value == this.MeiYomi ) { return; }
				this.Data.MeiYomi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.MeiYomi );
			}
		}
		public string Mei2					// 名2(Meiに通称が設定されている場合は本名、Meiが本名の場合はデータなし)
		{
			get { return this.Data.Mei2; }
			set
			{
				if ( value == this.Mei2 ) { return; }
				this.Data.Mei2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Mei2 );
			}
		}
		public string MeiYomi2				// 名2読み(Meiに通称が設定されている場合は本名、Meiが本名の場合はデータなし)
		{
			get { return this.Data.Mei2Yomi; }
			set
			{
				if ( value == this.MeiYomi2 ) { return; }
				this.Data.Mei2Yomi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.MeiYomi2 );
			}
		}
		public PointerlistType2 ShinaiList	// 親愛武将リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrShinaiList ); }
		}
		public PointerlistType2 KenoList	// 嫌悪武将リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrKenoList ); }
		}
		public UInt32 PtrSenpou				// 戦法
		{
			get
			{
				var data = PointerlistType2.Create( this.N14pkb, this.Data.PtrSenpouList );
				if ( data != null && data.Count != 0 )
				{
					return data.GetFirstPtrTargetData();
				}
				return 0;
			}

			set
			{
				var data = PointerlistType2.Create( this.N14pkb, this.Data.PtrSenpouList );
				if ( data != null && data.Count != 0 )
				{
					data.WriteTargetDataAddress( value, 0 );
				}
				this.PropertyChanged.Raise( () => this.PtrSenpou );
			}
		}
		public PointerlistType2 SenpouList	// 戦法リスト 複数所持した場合のゲーム内での挙動をそのうち確認
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrSenpouList ); }
		}
		public UInt32 PtrKahou				// 家宝ポインタ
		{
			get { return this.Data.PtrKahou; }
			set
			{
				if ( value == this.PtrKahou ) { return; }
				Funcs.SetKahou( this.N14pkb, this, value );
				this.Data.PtrKahou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrKahou );
			}
		}
		public string Chichi				// 父
		{
			get { return this.N14pkb.Busyoulist.GetNameByAddress( this.PtrChichi ); }
			set
			{
				if ( value == this.Chichi ) { return; }
				this.PtrChichi = this.N14pkb.Busyoulist.GetAddressByName( value );
			}
		}
		public string Youfu					// 養父
		{
			get { return this.N14pkb.Busyoulist.GetNameByAddress( this.PtrYoufu ); }
			set
			{
				if ( value == this.Youfu ) { return; }
				this.PtrYoufu = this.N14pkb.Busyoulist.GetAddressByName( value );
			}
		}
		public string Haigusya				// 配偶者
		{
			get { return this.N14pkb.Busyoulist.GetNameByAddress( this.PtrHaigusya ); }
			set
			{
				if ( value == this.Haigusya ) { return; }
				this.PtrHaigusya = this.N14pkb.Busyoulist.GetAddressByName( value );
			}
		}
		public UInt32 PtrChichi				// 父
		{
			get { return this.Data.PtrChichi; }
			set
			{
				if ( value == this.PtrChichi ) { return; }
				this.Data.PtrChichi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrChichi );
				this.PropertyChanged.Raise( () => this.Chichi );
				this.N14pkb.View.Flags[(int)TabKind.武将].NeedsRefresh = true;
			}
		}
		public UInt32 PtrYoufu				// 養父
		{
			get { return this.Data.PtrYoufu; }
			set
			{
				if ( value == this.PtrYoufu ) { return; }
				this.Data.PtrYoufu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrYoufu );
				this.PropertyChanged.Raise( () => this.Youfu );
				this.N14pkb.View.Flags[(int)TabKind.武将].NeedsRefresh = true;
			}
		}
		public UInt32 PtrHaigusya			// 配偶者
		{
			get { return this.Data.PtrHaigusya; }
			set
			{
				if ( value == this.PtrHaigusya ) { return; }

				Funcs.SetHaigusya( this.N14pkb, this, value );
				this.Data.PtrHaigusya = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrHaigusya );
				this.PropertyChanged.Raise( () => this.Haigusya );
				this.PropertyChanged.Raise( () => this.IsIchimon );
			}
		}
		public UInt32 PtrKuni				// 国ポインタ 普通に城にいる武将でもゼロの場合がある！？
		{
			get { return this.Data.PtrKuni; }
			set
			{
				if ( value == this.PtrKuni ) { return; }
				this.Data.PtrKuni = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrKuni );
			}
		}
		public string Seiryokuname			// 勢力ポインタ 値が入ってるのは謹慎中武将、または捕虜の滅亡勢力当主(ともに軍団ポインタは0)だけ？
		{
			get { return this.N14pkb.Seiryokulist.GetNameByAddress( this.Data.PtrSeiryoku ); }
		}
		public string Syozai				// 所在 所在タイプにより参照しているデータが異なる
		{
			get
			{
				switch ( (DataAddressKind)this.Data.SyozaiType )
				{
					case DataAddressKind.任務:
						return "任務中";

					case DataAddressKind.部隊:
						return this.N14pkb.Butailist.GetNameByAddress( this.PtrSyozai );

					default:
						return string.Empty;
				}
			}
		}
		public short KetsuzokuID			// 血族ID
		{
			get { return this.Data.KetsuzokuID; }
			set
			{
				if ( value == this.KetsuzokuID ) { return; }
				this.Data.KetsuzokuID = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KetsuzokuID );
			}
		}
		public ushort KaoguraID1			// 顔グラID1
		{
			get { return this.Data.KaoguraID1; }
			set
			{
				if ( value == this.KaoguraID1 ) { return; }
				this.Data.KaoguraID1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KaoguraID1 );
			}
		}
		public ushort KaoguraID2			// 顔グラID2
		{
			get { return this.Data.KaoguraID2; }
			set
			{
				if ( value == this.KaoguraID2 ) { return; }
				this.Data.KaoguraID2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KaoguraID2 );
			}
		}
		public ushort YearSei				// 生年
		{
			get { return this.Data.YearSei; }
			set
			{
				if ( value == this.YearSei ) { return; }
				this.Data.YearSei = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.YearSei );
				this.PropertyChanged.Raise( () => this.Nenrei );
			}
		}
		public ushort YearToujou			// 登場年
		{
			get { return this.Data.YearToujou; }
			set
			{
				if ( value == this.YearToujou ) { return; }
				this.Data.YearToujou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.YearToujou );
			}
		}
		public ushort YearBotsu				// 没年
		{
			get { return this.Data.YearBotsu; }
			set
			{
				if ( value == this.YearBotsu ) { return; }
				this.Data.YearBotsu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.YearBotsu );
				this.PropertyChanged.Raise( () => this.Yomei );
			}
		}
		public byte h0D8					//
		{
			get { return this.Data.h0D8; }
			set
			{
				if ( value == this.h0D8 ) { return; }
				this.Data.h0D8 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0D8 );
			}
		}
		public byte h0D9					// 相性？
		{
			get { return this.Data.h0D9; }
			set
			{
				if ( value == this.h0D9 ) { return; }
				this.Data.h0D9 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0D9 );
			}
		}
		public string Souzou				// 創造(0~:保守、40~:中道、70~:創造)
		{
			get
			{
				var souzou = this.Data.Souzou;
				if ( souzou >= 0 && souzou < 40 )
				{
					return "保守(" + souzou.ToString().PadLeft( 2 ) + ")";
				}
				else if ( souzou >= 40 && souzou < 70 )
				{
					return "中道(" + souzou.ToString().PadLeft( 2 ) + ")";
				}
				else if ( souzou >= 70 && souzou <= 100 )
				{
					return "創造(" + souzou.ToString().PadLeft( 2 ) + ")";
				}

				return souzou.ToString();
			}
			set
			{
				sbyte output;
				if ( !sbyte.TryParse( value, out output ) )
				{
					this.PropertyChanged.Raise( () => this.Souzou );	// 表示値を元に戻す
					return;
				}
				else if ( (int)output == this.Data.Tousotsu )
				{
					this.PropertyChanged.Raise( () => this.Souzou );	// 表示値を元に戻す
					return;
				}
				else if ( output < 0 )
				{
					this.PropertyChanged.Raise( () => this.Souzou );	// 表示値を元に戻す
					return;
				}
				this.Data.Souzou = (byte)output;
				this.Write();
				this.PropertyChanged.Raise( () => this.Souzou );
			}
		}
		public string Tousotsu				// 統率
		{
			get
			{
				return Funcs.GetNouryokuAndExp( this.Data.Tousotsu, this.TousotsuExp );
			}
			set
			{
				sbyte output;
				if ( !sbyte.TryParse( value, out output ) )
				{
					this.PropertyChanged.Raise( () => this.Tousotsu );	// 表示値を元に戻す
					return;
				}
				else if ( (int)output == this.Data.Tousotsu )
				{
					this.PropertyChanged.Raise( () => this.Tousotsu );	// 表示値を元に戻す
					return;
				}
				else if ( output < 0 )
				{
					this.PropertyChanged.Raise( () => this.Tousotsu );	// 表示値を元に戻す
					return;
				}
				this.Data.Tousotsu = (byte)output;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tousotsu );
			}
		}
		public string Buyuu					// 武勇
		{
			get
			{
				return Funcs.GetNouryokuAndExp( this.Data.Buyuu, this.BuyuuExp );
			}
			set
			{
				sbyte output;
				if ( !sbyte.TryParse( value, out output ) )
				{
					this.PropertyChanged.Raise( () => this.Buyuu );	// 表示値を元に戻す
					return;
				}
				else if ( (int)output == this.Data.Buyuu )
				{
					this.PropertyChanged.Raise( () => this.Buyuu );	// 表示値を元に戻す
					return;
				}
				else if ( output < 0 )
				{
					this.PropertyChanged.Raise( () => this.Buyuu );	// 表示値を元に戻す
					return;
				}
				this.Data.Buyuu = (byte)output;
				this.Write();
				this.PropertyChanged.Raise( () => this.Buyuu );
			}
		}
		public string Chiryaku				// 知略
		{
			get
			{
				return Funcs.GetNouryokuAndExp( this.Data.Chiryaku, this.ChiryakuExp );
			}
			set
			{
				sbyte output;
				if ( !sbyte.TryParse( value, out output ) )
				{
					this.PropertyChanged.Raise( () => this.Chiryaku );	// 表示値を元に戻す
					return;
				}
				else if ( (int)output == this.Data.Chiryaku )
				{
					this.PropertyChanged.Raise( () => this.Chiryaku );	// 表示値を元に戻す
					return;
				}
				else if ( output < 0 )
				{
					this.PropertyChanged.Raise( () => this.Chiryaku );	// 表示値を元に戻す
					return;
				}
				this.Data.Chiryaku = (byte)output;
				this.Write();
				this.PropertyChanged.Raise( () => this.Chiryaku );
			}
		}
		public string Seiji					// 政治
		{
			get
			{
				return Funcs.GetNouryokuAndExp( this.Data.Seiji, this.SeijiExp );
			}
			set
			{
				sbyte output;
				if ( !sbyte.TryParse( value, out output ) )
				{
					this.PropertyChanged.Raise( () => this.Seiji );	// 表示値を元に戻す
					return;
				}
				else if ( (int)output == this.Data.Seiji )
				{
					this.PropertyChanged.Raise( () => this.Seiji );	// 表示値を元に戻す
					return;
				}
				else if ( output < 0 )
				{
					this.PropertyChanged.Raise( () => this.Seiji );	// 表示値を元に戻す
					return;
				}
				this.Data.Seiji = (byte)output;
				this.Write();
				this.PropertyChanged.Raise( () => this.Seiji );
			}
		}

		/// <summary>統率偏差値</summary>
		public int TousotsuStdScore
		{ get { return (int)( 50 + 10 * ( ( ( this.Data.Tousotsu + (int)( this.TousotsuExp / 100 ) ) - BusyouList.TousotsuAvg ) / BusyouList.TousotsuStdDev ) ); } }

		/// <summary>武勇偏差値</summary>
		public int BuyuuStdScore
		{ get { return (int)( 50 + 10 * ( ( ( this.Data.Buyuu + (int)( this.BuyuuExp / 100 ) ) - BusyouList.BuyuuAvg ) / BusyouList.BuyuuStdDev ) ); } }

		/// <summary>知略偏差値</summary>
		public int ChiryakuStdScore
		{ get { return (int)( 50 + 10 * ( ( ( this.Data.Chiryaku + (int)( this.ChiryakuExp / 100 ) ) - BusyouList.ChiryakuAvg ) / BusyouList.ChiryakuStdDev ) ); } }

		/// <summary>政治偏差値</summary>
		public int SeijiStdScore
		{ get { return (int)( 50 + 10 * ( ( ( this.Data.Seiji + (int)( this.SeijiExp / 100 ) ) - BusyouList.SeijiAvg ) / BusyouList.SeijiStdDev ) ); } }

		public byte Hanshin					// 叛心 自勢力の武将には使われない？
		{
			get { return this.Data.Hanshin; }
			set
			{
				if ( value == this.Hanshin ) { return; }
				this.Data.Hanshin = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Hanshin );
			}
		}
		public bool[] TokuseiFlags			// 特性(特性1つにつき1ビット = 256データ ※特性データ数は247(確認時PKver 1.0.0.1)なので未使用部分がある)
		{
			// 配列の要素にアクセスするたびに get される
			// 要素を変更する場合は、別途配列の参照またはコピーに対して変更し配列自体を set する
			get { return this.Data.TokuseiFlags; }
			set
			{
				if ( value == this.TokuseiFlags ) { return; }
				this.Data.TokuseiFlags = value;
				this.Write();
				this.PropertyChanged.Raise( () => TokuseiFlags );
				this.PropertyChanged.Raise( () => Tokuseisuu );
			}
		}
		public int Tokuseisuu				// 特性数
		{
			get
			{
				var cnt = 0;
				foreach ( var d in this.Data.TokuseiFlags )
				{
					if ( d ) { cnt++; }
				}
				return cnt;
			}
		}
		public UInt32 PtrToujouKuni			// 国2 登場国
		{
			get { return this.Data.PtrToujouKuni; }
			set
			{
				if ( value == this.PtrToujouKuni ) { return; }
				this.Data.PtrToujouKuni = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrToujouKuni );
			}
		}
		public string Haha					// 母
		{
			get { return this.N14pkb.Busyoulist.GetNameByAddress( this.Data.PtrHaha ); }
			set
			{
				if ( value == this.Haha ) { return; }
				this.Data.PtrHaha = this.N14pkb.Busyoulist.GetAddressByName( value );
				this.Write();
				this.PropertyChanged.Raise( () => this.Haha );
			}
		}
		public ushort TousotsuExp			// 統率経験(100毎に能力 +1)
		{
			get { return this.Data.TousotsuExp; }
			set
			{
				if ( value == this.TousotsuExp ) { return; }
				this.Data.TousotsuExp = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.TousotsuExp );
				this.PropertyChanged.Raise( () => this.Tousotsu );
			}
		}
		public ushort BuyuuExp				// 武勇経験(100毎に能力 +1)
		{
			get { return this.Data.BuyuuExp; }
			set
			{
				if ( value == this.BuyuuExp ) { return; }
				this.Data.BuyuuExp = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.BuyuuExp );
				this.PropertyChanged.Raise( () => this.Buyuu );
			}
		}
		public ushort ChiryakuExp			// 知略経験(100毎に能力 +1)
		{
			get { return this.Data.ChiryakuExp; }
			set
			{
				if ( value == this.ChiryakuExp ) { return; }
				this.Data.ChiryakuExp = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ChiryakuExp );
				this.PropertyChanged.Raise( () => this.Chiryaku );
			}
		}
		public ushort SeijiExp				// 政治経験(100毎に能力 +1)
		{
			get { return this.Data.SeijiExp; }
			set
			{
				if ( value == this.SeijiExp ) { return; }
				this.Data.SeijiExp = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SeijiExp );
				this.PropertyChanged.Raise( () => this.Seiji );
			}
		}
		public ushort DateYearShikan		// 仕官年
		{
			get { return this.Data.DateYearShikan; }
			set
			{
				if ( value == this.DateYearShikan ) { return; }
				this.Data.DateYearShikan = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.DateYearShikan );
				this.PropertyChanged.Raise( () => this.Shikan );
			}
		}
		public sbyte[] ChuuseiHoseiList		// 忠誠補正配列 ※使用されているのは26バイトで、残り6バイトは0固定？
		{
			// 配列の要素にアクセスするたびに get される
			// 要素を変更する場合は、別途配列の参照またはコピーに対して変更し配列自体を set する
			get { return this.Data.ChuuseiHoseiList; }
			set
			{
				if ( value == this.ChuuseiHoseiList ) { return; }
				this.Data.ChuuseiHoseiList = value;
				this.Write();
				this.PropertyChanged.Raise( () => ChuuseiHoseiList );
			}
		}
		public int ChuuseiHoseiGoukei		// 忠誠補正合計
		{
			get
			{
				var ret = 0;
				foreach ( var d in this.Data.ChuuseiHoseiList )
				{
					ret += d;
				}
				return ret;
			}
		}
		public int MibunID					// 身分 -1:？、0:生前、1:成人前、(2:未発見)、3:浪人、4:捕虜、(5:人質)、6:姫、7:通常(大名/家臣/一門/隠居)、8:死亡/非登場
		{
			get { return this.Data.MibunID; }
			set
			{
				if ( value == this.MibunID ) { return; }
				this.Data.MibunID = (sbyte)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.MibunID );
			}
		}
		public byte UmajirushiID			// 馬印ID
		{
			get { return this.Data.UmajirushiID; }
			set
			{
				if ( value == this.UmajirushiID ) { return; }
				this.Data.UmajirushiID = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.UmajirushiID );
			}
		}
		public byte HataID					// 武将固有の旗ID
		{
			get { return this.Data.HataID; }
			set
			{
				if ( value == this.HataID ) { return; }
				this.Data.HataID = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HataID );
			}
		}
		public int SeichougataID			// 成長型
		{
			get { return this.Data.SeichougataID; }
			set
			{
				if ( value == this.SeichougataID ) { return; }
				this.Data.SeichougataID = (byte)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SeichougataID );
			}
		}
		public UInt32 PtrSyozai				// 所在ポインタ
		{
			get { return this.Data.PtrSyozai; }
			set
			{
				if ( value == this.PtrSyozai ) { return; }
				this.Data.PtrSyozai = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrSyozai );
				this.PropertyChanged.Raise( () => this.Syozai );
				this.PropertyChanged.Raise( () => this.PtrKyoten );
			}
		}

		public bool IsInkyo					// 160~163h bit00 隠居フラグ 1:隠居
		{
			get { return this.Data.IsInkyo; }
			set
			{
				if ( value == this.IsInkyo ) { return; }
				this.Data.IsInkyo = value;

				if ( value.Equals( true )
					&& ( this.ChuuseiHoseiList[(int)ChuuseihoseiKind.隠居] == 0 )
					)
				{
					Funcs.SetChuuseihosei( this, (int)ChuuseihoseiKind.隠居, 5 );
				}
				else if ( value.Equals( false )
					&& ( this.ChuuseiHoseiList[(int)ChuuseihoseiKind.隠居] != 0 )
					)
				{
					Funcs.SetChuuseihosei( this, (int)ChuuseihoseiKind.隠居, 0 );
				}

				this.Write();
				this.PropertyChanged.Raise( () => this.IsInkyo );
			}
		}
		public bool IsJosei					// 160~163h bit01 女性フラグ 1:女
		{
			get { return this.Data.IsJosei; }
			set
			{
				if ( value == this.IsJosei ) { return; }
				this.Data.IsJosei = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.IsJosei );
			}
		}
		public bool IsByoushi				// 160~163h bit02 病死フラグ 1:病死
		{
			get { return this.Data.IsByoushi; }
			set
			{
				if ( value == this.IsByoushi ) { return; }
				this.Data.IsByoushi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.IsByoushi );
			}
		}
		public int ShinkouID				// 160~163h bit05~06(2ビット) 信仰 0:なし、1:仏教、2:一向宗、3:基督教
		{
			get { return (int)this.Data.ShinkouID; }
			set
			{
				if ( value == this.ShinkouID ) { return; }
				this.Data.ShinkouID = (uint)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ShinkouID );
			}
		}
		public uint SyutsujiID				// 160~163h bit07~09(3ビット) 出自 0:武士、1:高家、2:僧侶、3:商人、4:海賊、5:忍者、6:剣豪、7:庶民
		{
			get { return this.Data.SyutsujiID; }
			set
			{
				if ( value == this.SyutsujiID ) { return; }
				this.Data.SyutsujiID = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SyutsujiID );
			}
		}
		public int SyoubyouID				// 160~163h bit12~13(2ビット) 傷病状態 0:健康、1:負傷、2:病気
		{
			get { return(int)this.Data.SyoubyouID; }
			set
			{
				if ( value == this.SyoubyouID ) { return; }
				this.Data.SyoubyouID = (uint)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SyoubyouID );
			}
		}
		public int KoeTypeID				// 160~163h bit14~18(5ビット) 声タイプ
		{
			get { return (int)this.Data.KoeTypeID; }
			set
			{
				if ( value == this.KoeTypeID ) { return; }
				this.Data.KoeTypeID = (uint)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KoeTypeID );
			}
		}
		public int KakuID					// 160~163h bit19~20(2ビット) 武将の格付け 0:C、1:B、2:A、3:S
		{
			get { return (int)this.Data.KakuID; }
			set
			{
				if ( value == this.KakuID ) { return; }
				this.Data.KakuID = (uint)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KakuID );
			}
		}
		public int ShidouID					// 160~163h bit29~31(3ビット) 士道ID 0:名、1:家、2:才、3:利、4:義、5:創造、6:道、7:志
		{
			get { return (int)this.Data.ShidouID; }
			set
			{
				if ( value == this.ShidouID ) { return; }
				this.Data.ShidouID = (uint)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ShidouID );
			}
		}
		public uint HitsuyouChuusei			// 164~167h bit00~03(4ビット) 必要忠誠
		{
			get { return this.Data.HitsuyouChuusei; }
			set
			{
				if ( value == this.HitsuyouChuusei ) { return; }
				this.Data.HitsuyouChuusei = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HitsuyouChuusei );
			}
		}
		public bool IsLLKao					// 164~167h bit17 顔グラLLフラグ
		{
			get { return this.Data.IsLLKao; }
			set
			{
				if ( value == this.IsLLKao ) { return; }
				this.Data.IsLLKao = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.IsLLKao );
			}
		}

		public UInt32 PtrNinmubusyouSyozokuKyoten		// 任務中武将の所属拠点ポインタ
		{
			get
			{
				// 所在タイプが任務中の場合、任務データを読み込んで所属拠点を取得する
				// 暇な時データ構造を調べる
				if ( this.Data.SyozaiType != (int)DataAddressKind.任務 ) { return 0; }

				// とりあえず以下の手順で取得
				// 所在ポインタ(任務ポインタ)参照先はデータ長 0x10 のポインタデータ？
				var buff = this.N14pkb.N14pk.ReadMemory( this.Data.PtrSyozai, 0x10 );
				// ポインタデータの 0Ch から4バイトをさらにポインタとして、0x24バイト読み込む(これが任務データ？)
				var address = BitConverter.ToUInt32( buff, 0x0C );
				buff = this.N14pkb.N14pk.ReadMemory( address, 0x24 );
				// 20h から4バイトが拠点ポインタ(だと思う)
				return BitConverter.ToUInt32( buff, 0x20 );
			}
		}
		public UInt32 PtrKyoten							// 所属拠点ポインタ 出陣中などは所在＝拠点ではないので、所属拠点を調べてセットしておく
		{
			get
			{
				if ( this.Data.PtrSyozai == 0 ) { return 0; }

				switch ( (DataAddressKind)this.Data.SyozaiType )
				{
					case DataAddressKind.城:
					case DataAddressKind.国人:
						return this.Data.PtrSyozai;

					case DataAddressKind.任務:
						return this.PtrNinmubusyouSyozokuKyoten;

					case DataAddressKind.部隊:
						return this.N14pkb.Butailist[this.Data.PtrSyozai].Data.PtrKyoten;

					default:
						return 0;
				}
			}
			set
			{
				if ( value == this.PtrKyoten ) { return; }
				Funcs.SetBusyouIdouData( this.N14pkb, this.Address, value, BusyouIdouKind.城 );
				if ( !Funcs.CheckBusyouIdou( this.N14pkb, this.Address ) )
				{
					this.PropertyChanged.Raise( () => this.PtrKyoten );
					return;
				}
				Funcs.BusyouIdou( this.N14pkb, this.Address );
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrKyoten );
				this.PropertyChanged.Raise( () => this.PtrGundan );
			}
		}
		public bool IsHime								// 勢力の姫リストに自身がいるかどうか
		{
			get
			{
				if ( this.Seiryoku == null ) { return false; }
				return ( 0 < this.Seiryoku.CntHimeList ) ? this.Seiryoku.HimeList.IsContainTargetDataAddress( this.Address ) : false;
			}
		}
		public bool IsJousyu							// 城主フラグ
		{
			get { return ( this.Shiro != null ) ? this.Shiro.Data.PtrJousyu == this.Address : false; }
			set
			{
				if ( value.Equals( this.IsJousyu ) ) { return; }

				if ( value.Equals( true ) )
				{
					// 城主ON
					// 軍団未所属と身分「通常」以外は×
					if ( this.Gundan == null || this.MibunID != (int)MibunKind.通常 ) { return; }

					var oldJousyu = this.N14pkb.Busyoulist[this.Shiro.PtrJousyu];
					if ( oldJousyu != null )
					{
						// 旧城主の城主フラグOFF
						oldJousyu.IsJousyu = false;
					}
					// 新城主セット
					this.Shiro.PtrJousyu = this.Address;
					if ( !this.IsTousyu )
					{
						// 当主でなければ忠誠補正 "城主" をセット
						Funcs.SetChuuseihosei( this, (int)ChuuseihoseiKind.城主, 4 );	// 4 がデフォルトか？
					}
				}
				else
				{
					// 城主OFF
					if ( this.Shiro.PtrJousyu == this.Address )
					{
						this.Shiro.PtrJousyu = 0;
					}
					// 城主忠誠補正クリア処理
					Funcs.SetChuuseihosei( this, (int)ChuuseihoseiKind.城主, 0 );
				}

				this.PropertyChanged.Raise( () => this.IsJousyu );
			}
		}
		public bool IsBugyou							// 奉行フラグ
		{
			get { return ( this.Shiro != null ) ? this.Shiro.Data.PtrBugyou == this.Address : false; }
			set
			{
				if ( value.Equals( this.IsBugyou ) ) { return; }

				if ( value.Equals( true ) )
				{
					// 奉行ON
					// 軍団未所属と身分「通常」以外は×
					if ( this.Gundan == null || this.MibunID != (int)MibunKind.通常 ) { return; }

					var oldBugyou = this.N14pkb.Busyoulist[this.Shiro.PtrBugyou];
					if ( oldBugyou != null )
					{
						// 旧奉行の奉行フラグOFF
						oldBugyou.IsBugyou = false;
					}
					// 新奉行セット
					this.Shiro.PtrBugyou = this.Address;
				}
				else
				{
					// 奉行OFF
					if ( this.Shiro.PtrBugyou == this.Address )
					{
						this.Shiro.PtrBugyou = 0;
					}
				}
				this.PropertyChanged.Raise( () => this.IsBugyou );
			}
		}
		public bool IsTousyu							// 当主フラグ
		{
			get { return ( this.Seiryoku != null ) ? this.Seiryoku.PtrTousyu == this.Address : false; }
			set
			{
				if ( value.Equals( this.IsTousyu ) ) { return; }
				if ( this.Seiryoku == null ) { return; }

				if ( value.Equals( true ) )
				{
					// 当主ON
					Funcs.ChangeTousyu( this.N14pkb, this.Address );
				}
				else
				{
					// 当主OFF
					if ( this.Seiryoku.PtrTousyu == this.Address )
					{
						this.Seiryoku.PtrTousyu = 0;
					}
				}
				this.PropertyChanged.Raise( () => this.IsTousyu );
			}
		}
		public bool IsGundanchou						// 軍団長フラグ
		{
			get { return ( this.Gundan != null ) ? this.Gundan.PtrGundanchou == this.Address : false; }
			set
			{
				if ( value.Equals( this.IsGundanchou ) ) { return; }
				if ( this.Gundan == null ) { return; }

				if ( value.Equals( true ) )
				{
					// 軍団長ON

					// 旧軍団長
					var oldGundanchou = this.N14pkb.Busyoulist[this.Gundan.PtrGundanchou];
					if ( oldGundanchou.IsTousyu )
					{
						// 旧軍団長が当主なら当主変更処理
						this.IsTousyu = true;
						return;
					}

					// 旧軍団長の軍団長フラグOFF
					oldGundanchou.IsGundanchou = false;

					// 軍団の新軍団長セット
					this.Gundan.PtrGundanchou = this.Address;

					if ( this.MibunID == (int)MibunKind.成人前
						|| this.MibunID == (int)MibunKind.姫
						)
					{
						var shiro = oldGundanchou.Shiro;

						switch ( (MibunKind)this.MibunID )
						{
							case MibunKind.成人前:
								// 成人前武将の軍団長(当主)化
								// ポインタデータ移動 成人前 → 行動可能武将
								Funcs.MovePointerData( this.N14pkb, this.Address, this.Seiryoku.SeijinmaeList, shiro.KoudoukanouList );
								this.Seiryoku.CntSeijinmaeList = this.Seiryoku.SeijinmaeList.Count;
								shiro.CntKoudoukanouList = shiro.KoudoukanouList.Count;
								break;

							case MibunKind.姫:
								// 姫の軍団長(当主)化
								// ポインタデータ移動 姫 → 行動可能武将
								Funcs.MovePointerData( this.N14pkb, this.Address, this.Seiryoku.HimeList, shiro.KoudoukanouList );
								this.Seiryoku.CntHimeList = this.Seiryoku.HimeList.Count;
								shiro.CntKoudoukanouList = shiro.KoudoukanouList.Count;
								break;

							default:
								break;
						}
						this.MibunID = (int)MibunKind.通常;
						this.PtrSyozai = shiro.Address;
						this.Data.SyozaiType = (int)DataAddressKind.城;
					}

					if ( !this.IsTousyu )
					{
						// 当主でなければ忠誠補正をセット
						Funcs.SetChuuseihosei( this, (int)ChuuseihoseiKind.軍団長, 2 );	// なんとなく 2 でいいかな
						Funcs.SetChuuseihosei( this, (int)ChuuseihoseiKind.対軍団長, 0 );
					}

				}
				else
				{
					// 軍団長OFF
					if ( this.Gundan.PtrGundanchou == this.Address )
					{
						this.Gundan.PtrGundanchou = 0;
					}
					Funcs.SetChuuseihosei( this, (int)ChuuseihoseiKind.軍団長, 0 );
				}

				this.PropertyChanged.Raise( () => this.IsGundanchou );
			}
		}
		public bool IsIchimon							// 一門フラグ
		{
			get
			{
				return Funcs.IsIchimon( this.N14pkb, this, this.Seiryoku );
			}
			set { }
		}
		public string UnknownDate			// 不明年月
		{
			get
			{
				var str = string.Empty;
				if ( this.Data.DateYearUnknown != 0 )
				{
					str += this.Data.DateYearUnknown;
					if ( this.Data.DateMonthUnknown != 0 )
					{
						str += "/" + this.Data.DateMonthUnknown.ToString( "D2" );
					}
				}
				return str;
			}
		}
		public int Nenrei					// 年齢
		{
			get
			{
				return this.N14pkb.N14pk.TransactionDateTime.Year - this.YearSei + 1;
			}
			set
			{
				if ( this.Nenrei == value ) { return; }

				if ( value <= 0 )
				{
					this.PropertyChanged.Raise( () => this.Nenrei );
					return;
				}
				this.YearSei = (ushort)( this.N14pkb.N14pk.TransactionDateTime.Year - value + 1 );
			}
		}
		public int Yomei					// 余命
		{
			get
			{
				return this.YearBotsu - this.N14pkb.N14pk.TransactionDateTime.Year;
			}
			set
			{
				if ( this.Yomei == value ) { return; }

				this.YearBotsu = (ushort)( this.N14pkb.N14pk.TransactionDateTime.Year + value );
			}
		}
		public int Shikan					// 仕官年数
		{
			get
			{
				if ( this.DateYearShikan == 0 )
				{
					return 0;
				}
				return this.N14pkb.N14pk.TransactionDateTime.Year - this.DateYearShikan + 1;
			}
			set
			{
				if ( this.Shikan == value )
				{
					return;
				}
				else if ( value <= 0 )
				{
					this.PropertyChanged.Raise( () => this.Shikan );
					return;
				}

				this.DateYearShikan = (ushort)( this.N14pkb.N14pk.TransactionDateTime.Year - value + 1 );
			}
		}

		public string MibunSyousai			// 身分詳細
		{
			get { return Helper.武将身分詳細[this.MibunSyousaiID]; }
		}
		public int MibunSyousaiID			// 身分詳細
		{
			get
			{
				switch ( (MibunKind)this.MibunID )
				{
					case MibunKind.なし:
						return (int)MibunSyousaiKind.なし;
					case MibunKind.成人前:
						return (int)MibunSyousaiKind.成人前;
					case MibunKind.生前:
						return (int)MibunSyousaiKind.生前;
					case MibunKind.他:
						if ( this.Data.PtrSeiryoku != 0 )
						{
							return (int)MibunSyousaiKind.謹慎中;
						}
						else
						{
							return (int)MibunSyousaiKind.他;
						}
					case MibunKind.姫:
						return (int)MibunSyousaiKind.姫;
					case MibunKind.浪人:
						return (int)MibunSyousaiKind.浪人;
					case MibunKind.捕虜:
						if ( this.IsHime )
							return (int)MibunSyousaiKind.捕虜姫;
						else
							return (int)MibunSyousaiKind.捕虜;
					case MibunKind.通常:
						if ( this.IsTousyu )
						{
							return (int)MibunSyousaiKind.当主;
						}
						else if ( this.IsGundanchou )
						{
							if ( this.Gundan.IsInin )
							{
								if ( this.IsHime )
									return (int)MibunSyousaiKind.軍団長姫;
								else
									return (int)MibunSyousaiKind.軍団長;
							}
							else
							{
								if ( this.IsHime )
									return (int)MibunSyousaiKind.軍団長直轄外姫;
								else
									return (int)MibunSyousaiKind.軍団長直轄外;
							}
						}
						else if (
							( this.Data.SyozaiType == (int)DataAddressKind.国人 )
							|| ( this.Seiryoku == null )
							)
						{
							return (int)MibunSyousaiKind.国人衆;
						}
						else
						{
							if ( this.IsHime )
								return (int)MibunSyousaiKind.家臣姫;
							else
								return (int)MibunSyousaiKind.家臣;
						}
					default:
						return -1;
				}
			}
		}

		/// <summary>所属している城(捕虜の場合は捕縛勢力の城)</summary>
		public Shiro Shiro
		{
			get { return this.N14pkb.Shirolist[this.PtrKyoten]; }
		}

		/// <summary>所属している城ポインタ(捕虜の場合は捕縛勢力の城)</summary>
		public uint PtrShiro
		{
			get { return ( this.Shiro != null ) ? this.Shiro.Address : 0; }
		}

		/// <summary>所属している軍団</summary>
		public Gundan Gundan
		{
			get { return this.N14pkb.Gundanlist[this.PtrGundan]; }
		}

		/// <summary>所属している軍団ポインタ</summary>
		public UInt32 PtrGundan
		{
			get { return this.Data.PtrGundan; }
			set
			{
				if ( value == this.PtrGundan ) { return; }
				Funcs.SetBusyouIdouData( this.N14pkb, this.Address, value, BusyouIdouKind.軍団 );
				if ( !Funcs.CheckBusyouIdou( this.N14pkb, this.Address ) )
				{
					this.PropertyChanged.Raise( () => this.PtrGundan );
					return;
				}
				Funcs.BusyouIdou( this.N14pkb, this.Address );
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrGundan );
			}
		}

		/// <summary>所属している勢力</summary>
		public Seiryoku Seiryoku
		{
			get { return ( this.Gundan != null ) ? this.Gundan.Seiryoku : null; }
		}

		/// <summary>所属している勢力ポインタ</summary>
		public uint PtrSeiryoku
		{
			get { return ( this.Gundan != null ) ? this.Gundan.Data.PtrSeiryoku : 0; }
		}

		/// <summary>所在している城が所属している軍団</summary>
		public Gundan ShiroGundan
		{
			get { return ( this.Shiro != null ) ? this.Shiro.Gundan : null; }
		}

		/// <summary>自身の所在している城が所属している勢力</summary>
		public Seiryoku ShiroSeiryoku
		{
			get { return ( this.ShiroGundan != null ) ? this.ShiroGundan.Seiryoku : null; }
		}

		/// <summary>所属変更に使用する城</summary>
		public Shiro ToShiro
		{
			get { return this.N14pkb.Shirolist[this.ToPtrShiro]; }
		}

		/// <summary>所属変更に使用する城ポインタ</summary>
		public uint ToPtrShiro { get; set; }

		/// <summary>所属変更に使用する軍団</summary>
		public Gundan ToGundan
		{
			get { return this.N14pkb.Gundanlist[this.ToPtrGundan]; }
		}

		/// <summary>所属変更に使用する軍団ポインタ</summary>
		public UInt32 ToPtrGundan { set; get; }

		/// <summary>所属変更に使用する勢力</summary>
		public Seiryoku ToSeiryoku
		{
			get { return ( this.ToGundan != null ) ? this.ToGundan.Seiryoku : null; }
		}

		/// <summary>所属変更に使用する勢力ポインタ</summary>
		public uint ToPtrSeiryoku
		{
			get { return ( this.ToGundan != null ) ? this.ToGundan.Data.PtrSeiryoku : 0; }
		}

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Busyou( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Busyoutable[id];
		}

		/// <summary>武将名リストを更新する</summary>
		private void UpdateNamelist()
		{
			this.N14pkb.Busyoulist.SetNamelist();

			// 武将名を参照して名前リストを作成している勢力＆当主名リストをリセット(当主の場合)
			if ( this.IsTousyu )
			{
				this.Seiryoku.Name = this.Sei + "家";
				this.Seiryoku.Yomi = this.SeiYomi;
				this.Seiryoku.UpdateNamelist();
			}
			// 武将名を参照して名前リストを作成している軍団名リストをリセット(軍団長の場合)
			if ( this.IsGundanchou )
			{
				this.Gundan.UpdateNamelist();
			}

			// 武将名を参照しているビューのリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.武将].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.城].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.勢力].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.軍団].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.部隊].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.建物].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.家宝].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.国人衆].NeedsRefresh = true;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			throw new NotSupportedException();
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			throw new NotSupportedException();
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Busyoutable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Busyoulist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:武将:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
