﻿// TokuseiSyuutokuJoukenw.cs

using System;
using System.ComponentModel;
using System.Text;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>特性習得条件ビューで使用するデータクラス</summary>
	public class TokuseiSyuutokuJouken : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の特性習得条件データ</summary>
		public TokuseiSyuutokuJoukenData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID				// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address			// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex	// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}
		public string Name			// 条件能力と数値を名前化したもの
		{
			get { return this.MakeName(); }
			set { throw new NotSupportedException(); }
		}
		public byte Tousotsu		// 統率
		{
			get { return this.Data.Tousotsu; }
			set
			{
				if ( value == this.Tousotsu ) { return; }
				this.Data.Tousotsu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tousotsu );
				this.UpdateNamelist();
			}
		}
		public byte Buyuu			// 武勇
		{
			get { return this.Data.Buyuu; }
			set
			{
				if ( value == this.Buyuu ) { return; }
				this.Data.Buyuu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Buyuu );
				this.UpdateNamelist();
			}
		}
		public byte Chiryaku		// 知略
		{
			get { return this.Data.Chiryaku; }
			set
			{
				if ( value == this.Chiryaku ) { return; }
				this.Data.Chiryaku = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Chiryaku );
				this.UpdateNamelist();
			}
		}
		public byte Seiji			// 政治
		{
			get { return this.Data.Seiji; }
			set
			{
				if ( value == this.Seiji ) { return; }
				this.Data.Seiji = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Seiji );
				this.UpdateNamelist();
			}
		}
		public bool IsJosei			// 女性フラグ
		{
			get { return ( this.Data.Seibetsu == 0 ) ? false : true; }
			set
			{
				if ( value == this.IsJosei ) { return; }
				this.Data.Seibetsu = (byte)( value ? 1 : 0 );
				this.Write();
				this.PropertyChanged.Raise( () => this.IsJosei );
				this.UpdateNamelist();
			}
		}
		public byte B1_9			// 0固定 未使用？
		{
			get { return this.Data.B1_9; }
			set
			{
				if ( value == this.B1_9 ) { return; }
				this.Data.B1_9 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.B1_9 );
			}
		}
		public byte B1_A			// 0固定 未使用？
		{
			get { return this.Data.B1_A; }
			set
			{
				if ( value == this.B1_A ) { return; }
				this.Data.B1_A = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.B1_A );
			}
		}
		public byte B1_B			// 0固定 未使用？
		{
			get { return this.Data.B1_B; }
			set
			{
				if ( value == this.B1_B ) { return; }
				this.Data.B1_B = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.B1_B );
			}
		}


		/// <summary>コンストラクタ 特性習得条件</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public TokuseiSyuutokuJouken( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.TokuseiSyuutokuJoukentable[id];
		}

		/// <summary>特性習得条件名を作って返す</summary>
		private string MakeName()
		{
			var sb = new StringBuilder( 32 );
			var data = new []
			{
				new { Name = "統", Value = this.Tousotsu },
				new { Name = "武", Value = this.Buyuu },
				new { Name = "知", Value = this.Chiryaku },
				new { Name = "政", Value = this.Seiji }
			};
			var valid = new [] { true, true, true, true, };

			for ( var i = 0; i < data.Length; i++ )
			{
				if ( valid[i] && data[i].Value != 0 )
				{
					sb.Append( data[i].Name );
					valid[i] = false;
					var val = data[i].Value;
					for ( var j = 0; j < data.Length; j++ )
					{
						if ( valid[j] && val == data[j].Value )
						{
							sb.Append( data[j].Name );
							valid[j] = false;
						}
					}
					sb.Append( val );
				}
			}

			if ( sb.Length == 0 )
			{
				sb.Append( "初期" );
			}
			else
			{
				sb.Replace( "統武知政", "全種" );
			}

			if ( this.IsJosei )
			{
				sb.Append( "♀" );
			}
			return sb.ToString();
		}

		/// <summary>特性習得条件名リストを更新する</summary>
		private void UpdateNamelist()
		{
			var namelist = this.N14pkb.TokuseiSyuutokuJoukenlist.Namelist;
			if ( namelist[this.ID] == this.Name ) { return; }

			namelist[this.ID] = this.Name;
			this.PropertyChanged.Raise( () => this.Name );

			// 特性習得条件名リストを参照しているビューのリフレッシュフラグ
			//this.N14pkb.View.Flags[(int)Enums.TabKind.習得条件].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.成長型].NeedsRefresh = true;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			return this.Data.GetRecord();
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			// バッファをコピー
			var record = (byte[])buff.Clone();
			// 先頭4バイトの MagicNumber はゲーム起動毎に変わるため、現在の値を使用する
			BitConverter.GetBytes( this.Data.MagicNumber ).CopyTo( record, 0x00 );
			this.Data.SetRecord( record );
			this.Write();

			// 特性習得条件名リスト更新
			this.UpdateNamelist();

			// ビューリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.習得条件].NeedsRefresh = true;
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.TokuseiSyuutokuJoukentable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.TokuseiSyuutokuJoukenlist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:習得条件:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
