﻿// Kaidou.cs

using System;
using System.ComponentModel;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>街道ビューで使用するデータクラス</summary>
	public class Kaidou : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の街道データ</summary>
		public KaidouData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID						// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address					// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex			// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}
		public string Name					// 街道名
		{
			get { return this.N14pkb.Yousyolist.GetNameByAddress( this.Data.PtrYousyo1 ) + "～" + this.N14pkb.Yousyolist.GetNameByAddress( this.Data.PtrYousyo2 ); }
			set { }
		}
		public uint PosX					// X位置？
		{
			get { return this.Data.PosX; }
			set
			{
				if ( value == this.PosX ) { return; }
				this.Data.PosX = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PosX );
			}
		}
		public uint PosY					// Y位置？
		{
			get { return this.Data.PosY; }
			set
			{
				if ( value == this.PosY ) { return; }
				this.Data.PosY = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PosY );
			}
		}
		public uint h14_4					// 街道の長さ？
		{
			get { return this.Data.h14_4; }
			set
			{
				if ( value == this.h14_4 ) { return; }
				this.Data.h14_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h14_4 );
			}
		}
		public uint SeibiLV					// 整備レベル 0:1～4:5
		{
			get { return this.Data.SeibiLV + 1; }
			set
			{
				if ( value == this.SeibiLV ) { return; }
				this.Data.SeibiLV = value - 1;
				this.Write();
				this.PropertyChanged.Raise( () => this.SeibiLV );
			}
		}
		public byte JoutaiFlag				// 状態フラグ？ 0x00,0x01,0x03,0x11 を確認。0x11は街道のポイントとキャプション双方表示されない
		{
			get { return this.Data.JoutaiFlag; }
			set
			{
				if ( value == this.JoutaiFlag ) { return; }
				this.Data.JoutaiFlag = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.JoutaiFlag );
			}
		}
		public int ChikeiID					// 地形
		{
			// 本来は地形テーブルがあるので参照すべきだが、地形テーブルの中身は地形名称文字列だけなので省略
			// 地形タイプIDが 0xCD は未設定(C++ malloc_dbg の初期値か？)
			get { return this.Data.ChikeiID; }
			set
			{
				if ( value == this.ChikeiID ) { return; }
				this.Data.ChikeiID = (byte)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ChikeiID );
			}
		}
		public string Yousyo1Kuni			// 要所1国
		{ get { return this.Yousyo1.Kuni; } }
		public string Yousyo1Kyoten			// 要所1拠点
		{ get { return this.Yousyo1.Kyoten; } }
		public string Yousyo1KyotenSeiryoku	// 要所1拠点勢力
		{ get { return this.Yousyo1.KyotenSeiryoku; } }
		public string Yousyo2Kuni			// 要所2国
		{ get { return this.Yousyo2.Kuni; } }
		public string Yousyo2Kyoten			// 要所2拠点
		{ get { return this.Yousyo2.Kyoten; } }
		public string Yousyo2KyotenSeiryoku	// 要所2拠点勢力
		{ get { return this.Yousyo2.KyotenSeiryoku; } }


		public Yousyo Yousyo1 { get { return this.N14pkb.Yousyolist[this.Data.PtrYousyo1]; } }
		public Yousyo Yousyo2 { get { return this.N14pkb.Yousyolist[this.Data.PtrYousyo2]; } }

		/// <summary>コンストラクタ 街道</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Kaidou( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Kaidoutable[id];
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			throw new NotSupportedException();
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			throw new NotSupportedException();
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Kaidoutable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Kaidoulist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:街道:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
