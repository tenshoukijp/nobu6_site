﻿// Seisaku.cs

using System;
using System.ComponentModel;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>政策ビューで使用するデータクラス</summary>
	public class Seisaku : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の政策データ</summary>
		public SeisakuData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID				// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address			// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex	// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}

		public string Name					// 名称
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Name );
				this.UpdateNamelist();
			}
		}
		public string Yomi					// 読み
		{
			get { return this.Data.Yomi; }
			set
			{
				if ( value == this.Yomi ) { return; }
				this.Data.Yomi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Yomi );
			}
		}
		public string Riten1				// 利点1
		{
			get { return this.Data.Riten1; }
			set
			{
				if ( value == this.Riten1 ) { return; }
				this.Data.Riten1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Riten1 );
			}
		}
		public string Riten2				// 利点2
		{
			get { return this.Data.Riten2; }
			set
			{
				if ( value == this.Riten2 ) { return; }
				this.Data.Riten2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Riten2 );
			}
		}
		public string Ketten1				// 欠点1
		{
			get { return this.Data.Ketten1; }
			set
			{
				if ( value == this.Ketten1 ) { return; }
				this.Data.Ketten1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Ketten1 );
			}
		}
		public string Ketten2				// 欠点2
		{
			get { return this.Data.Ketten2; }
			set
			{
				if ( value == this.Ketten2 ) { return; }
				this.Data.Ketten2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Ketten2 );
			}
		}
		public ushort Hiyou					// 費用
		{
			get { return this.Data.Hiyou; }
			set
			{
				if ( value == this.Hiyou ) { return; }
				this.Data.Hiyou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Hiyou );
			}
		}
		public short Souzouseilowerlimit	// 実施可能創造性下限
		{
			get { return this.Data.Souzouseilowerlimit; }
			set
			{
				if ( value == this.Souzouseilowerlimit ) { return; }
				this.Data.Souzouseilowerlimit = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Souzouseilowerlimit );
			}
		}
		public short SouzouseiUpperlimit	// 実施可能創造性上限
		{
			get { return this.Data.SouzouseiUpperlimit; }
			set
			{
				if ( value == this.SouzouseiUpperlimit ) { return; }
				this.Data.SouzouseiUpperlimit = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SouzouseiUpperlimit );
			}
		}
		public short h102_2					// 102h 2バイト 0固定？
		{
			get { return this.Data.h102_2; }
			set
			{
				if ( value == this.h102_2 ) { return; }
				this.Data.h102_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h102_2 );
			}
		}
		public uint PtrZenteiSeisaku		// 前提政策
		{
			get { return this.Data.PtrZenteiSeisaku; }
			set
			{
				if ( value == this.PtrZenteiSeisaku ) { return; }
				this.Data.PtrZenteiSeisaku = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrZenteiSeisaku );
			}
		}
		public int h108_4					// 108h 4バイト 0固定？
		{
			get { return this.Data.h108_4; }
			set
			{
				if ( value == this.h108_4 ) { return; }
				this.Data.h108_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h108_4 );
			}
		}
		public int SenyouKetsuzokuID		// 専用血族ID
		{
			get { return this.Data.SenyouKetsuzokuID; }
			set
			{
				if ( value == this.SenyouKetsuzokuID ) { return; }
				this.Data.SenyouKetsuzokuID = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SenyouKetsuzokuID );

				if ( value != -1 )
				{
					this.Data.SeisakuTypeID = 1;	// 専用
					this.PropertyChanged.Raise( () => this.SeisakuTypeID );
				}
			}
		}
		public int SeisakuTypeID			// 政策タイプ -1:なし、0:惣無事令、1:専用、2:創造、3:中道、4:保守、5:共通
		{
			get { return this.Data.SeisakuTypeID; }
			set
			{
				if ( value == this.SeisakuTypeID ) { return; }
				this.Data.SeisakuTypeID = (sbyte)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SeisakuTypeID );

				if ( this.Data.SeisakuTypeID != 1 )
				{
					// 専用以外なら血族IDをなしにする
					this.Data.SenyouKetsuzokuID = -1;
					this.PropertyChanged.Raise( () => this.SenyouKetsuzokuID );
				}
			}
		}

		public sbyte h111					// 石高
		{
			get { return this.Data.h111; }
			set
			{
				if ( value == this.h111 ) { return; }
				this.Data.h111 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h111 );
			}
		}
		public sbyte h112					// 商業
		{
			get { return this.Data.h112; }
			set
			{
				if ( value == this.h112 ) { return; }
				this.Data.h112 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h112 );
			}
		}
		public sbyte h113					// 兵舎
		{
			get { return this.Data.h113; }
			set
			{
				if ( value == this.h113 ) { return; }
				this.Data.h113 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h113 );
			}
		}
		public sbyte h114					// 収穫
		{
			get { return this.Data.h114; }
			set
			{
				if ( value == this.h114 ) { return; }
				this.Data.h114 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h114 );
			}
		}
		public sbyte h115					// 収入
		{
			get { return this.Data.h115; }
			set
			{
				if ( value == this.h115 ) { return; }
				this.Data.h115 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h115 );
			}
		}
		public sbyte h116					// 国人兵
		{
			get { return this.Data.h116; }
			set
			{
				if ( value == this.h116 ) { return; }
				this.Data.h116 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h116 );
			}
		}
		public sbyte h117					// 117h 1バイト 0固定？
		{
			get { return this.Data.h117; }
			set
			{
				if ( value == this.h117 ) { return; }
				this.Data.h117 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h117 );
			}
		}
		public sbyte h118					// 懐柔
		{
			get { return this.Data.h118; }
			set
			{
				if ( value == this.h118 ) { return; }
				this.Data.h118 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h118 );
			}
		}
		public sbyte h119					// 敵城包囲時の士気ゲージ減少
		{
			get { return this.Data.h119; }
			set
			{
				if ( value == this.h119 ) { return; }
				this.Data.h119 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h119 );
			}
		}
		public sbyte h11A					// 11Ah 1バイト 0固定？
		{
			get { return this.Data.h11A; }
			set
			{
				if ( value == this.h11A ) { return; }
				this.Data.h11A = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11A );
			}
		}
		public sbyte h11B					// 人口
		{
			get { return this.Data.h11B; }
			set
			{
				if ( value == this.h11B ) { return; }
				this.Data.h11B = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11B );
			}
		}
		public sbyte h11C					// 最大領民兵(*10%)
		{
			get { return this.Data.h11C; }
			set
			{
				if ( value == this.h11C ) { return; }
				this.Data.h11C = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11C );
			}
		}
		public sbyte h11D					// 本城最大常備兵(*10%)
		{
			get { return this.Data.h11D; }
			set
			{
				if ( value == this.h11D ) { return; }
				this.Data.h11D = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11D );
			}
		}
		public sbyte h11E					// 最大民忠
		{
			get { return this.Data.h11E; }
			set
			{
				if ( value == this.h11E ) { return; }
				this.Data.h11E = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11E );
			}
		}
		public sbyte h11F					// 兵舎の石高制限解除(兵農分離)
		{
			get { return this.Data.h11F; }
			set
			{
				if ( value == this.h11F ) { return; }
				this.Data.h11F = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11F );
			}
		}
		public sbyte h120					// 120h 1バイト 0固定？
		{
			get { return this.Data.h120; }
			set
			{
				if ( value == this.h120 ) { return; }
				this.Data.h120 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h120 );
			}
		}
		public sbyte h121					// 取引価格(%)
		{
			get { return this.Data.h121; }
			set
			{
				if ( value == this.h121 ) { return; }
				this.Data.h121 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h121 );
			}
		}
		public sbyte h122					// 商人(堺)
		{
			get { return this.Data.h122; }
			set
			{
				if ( value == this.h122 ) { return; }
				this.Data.h122 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h122 );
			}
		}
		public sbyte h123					// 商人(南蛮)
		{
			get { return this.Data.h123; }
			set
			{
				if ( value == this.h123 ) { return; }
				this.Data.h123 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h123 );
			}
		}
		public sbyte h124					// 一揆発生率
		{
			get { return this.Data.h124; }
			set
			{
				if ( value == this.h124 ) { return; }
				this.Data.h124 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h124 );
			}
		}
		public sbyte h125					// 港収入
		{
			get { return this.Data.h125; }
			set
			{
				if ( value == this.h125 ) { return; }
				this.Data.h125 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h125 );
			}
		}
		public sbyte h126					// 126h 1バイト 0固定？
		{
			get { return this.Data.h126; }
			set
			{
				if ( value == this.h126 ) { return; }
				this.Data.h126 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h126 );
			}
		}
		public sbyte h127					// 127h 1バイト 0固定？
		{
			get { return this.Data.h127; }
			set
			{
				if ( value == this.h127 ) { return; }
				this.Data.h127 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h127 );
			}
		}
		public sbyte h128					// 忠誠補正(能力主義)
		{
			get { return this.Data.h128; }
			set
			{
				if ( value == this.h128 ) { return; }
				this.Data.h128 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h128 );
			}
		}
		public sbyte h129					// 忠誠補正(指出検地)
		{
			get { return this.Data.h129; }
			set
			{
				if ( value == this.h129 ) { return; }
				this.Data.h129 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h129 );
			}
		}
		public sbyte h12A					// 忠誠補正(所領安堵)
		{
			get { return this.Data.h12A; }
			set
			{
				if ( value == this.h12A ) { return; }
				this.Data.h12A = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h12A );
			}
		}
		public sbyte h12B					// 12Bh 1バイト 0固定？
		{
			get { return this.Data.h12B; }
			set
			{
				if ( value == this.h12B ) { return; }
				this.Data.h12B = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h12B );
			}
		}
		public sbyte h12C					// 外交収入(%)
		{
			get { return this.Data.h12C; }
			set
			{
				if ( value == this.h12C ) { return; }
				this.Data.h12C = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h12C );
			}
		}
		public sbyte h12D					// 12Dh 1バイト 0固定？
		{
			get { return this.Data.h12D; }
			set
			{
				if ( value == this.h12D ) { return; }
				this.Data.h12D = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h12D );
			}
		}
		public sbyte h12E					// 12Eh 1バイト 0xFF固定？
		{
			get { return this.Data.h12E; }
			set
			{
				if ( value == this.h12E ) { return; }
				this.Data.h12E = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h12E );
			}
		}
		public sbyte h12F					// 12Fh 1バイト 0xFF固定？
		{
			get { return this.Data.h12F; }
			set
			{
				if ( value == this.h12F ) { return; }
				this.Data.h12F = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h12F );
			}
		}
		public sbyte h130					// 130h 1バイト 0固定？
		{
			get { return this.Data.h130; }
			set
			{
				if ( value == this.h130 ) { return; }
				this.Data.h130 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h130 );
			}
		}
		public sbyte h131					// 外交制限解除(遠交近攻策)
		{
			get { return this.Data.h131; }
			set
			{
				if ( value == this.h131 ) { return; }
				this.Data.h131 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h131 );
			}
		}
		public sbyte h132					// 近工作効果
		{
			get { return this.Data.h132; }
			set
			{
				if ( value == this.h132 ) { return; }
				this.Data.h132 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h132 );
			}
		}
		public sbyte h133					// 遠工作効果
		{
			get { return this.Data.h133; }
			set
			{
				if ( value == this.h133 ) { return; }
				this.Data.h133 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h133 );
			}
		}
		public sbyte h134					// 134h 1バイト 0固定？
		{
			get { return this.Data.h134; }
			set
			{
				if ( value == this.h134 ) { return; }
				this.Data.h134 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h134 );
			}
		}
		public sbyte h135					// 惣無事令
		{
			get { return this.Data.h135; }
			set
			{
				if ( value == this.h135 ) { return; }
				this.Data.h135 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h135 );
			}
		}
		public sbyte h136					// 軍馬鉄砲配備攻撃増
		{
			get { return this.Data.h136; }
			set
			{
				if ( value == this.h136 ) { return; }
				this.Data.h136 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h136 );
			}
		}
		public sbyte h137					// 軍馬鉄砲未配備攻撃減
		{
			get { return this.Data.h137; }
			set
			{
				if ( value == this.h137 ) { return; }
				this.Data.h137 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h137 );
			}
		}
		public sbyte h138					// 軍馬配備攻撃増
		{
			get { return this.Data.h138; }
			set
			{
				if ( value == this.h138 ) { return; }
				this.Data.h138 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h138 );
			}
		}
		public sbyte h139					// 軍馬未配備攻撃減
		{
			get { return this.Data.h139; }
			set
			{
				if ( value == this.h139 ) { return; }
				this.Data.h139 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h139 );
			}
		}
		public sbyte h13A					// 鉄砲配備攻撃増
		{
			get { return this.Data.h13A; }
			set
			{
				if ( value == this.h13A ) { return; }
				this.Data.h13A = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h13A );
			}
		}
		public sbyte h13B					// 鉄砲未配備攻撃減
		{
			get { return this.Data.h13B; }
			set
			{
				if ( value == this.h13B ) { return; }
				this.Data.h13B = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h13B );
			}
		}
		public sbyte h13C					// 13Ch 1バイト 0固定？
		{
			get { return this.Data.h13C; }
			set
			{
				if ( value == this.h13C ) { return; }
				this.Data.h13C = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h13C );
			}
		}
		public sbyte h13D					// 13Dh 1バイト 0固定？
		{
			get { return this.Data.h13D; }
			set
			{
				if ( value == this.h13D ) { return; }
				this.Data.h13D = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h13D );
			}
		}
		public sbyte h13E					// 支城最大常備兵(*10%)
		{
			get { return this.Data.h13E; }
			set
			{
				if ( value == this.h13E ) { return; }
				this.Data.h13E = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h13E );
			}
		}
		public sbyte h13F					// 忠誠補正(創造)
		{
			get { return this.Data.h13F; }
			set
			{
				if ( value == this.h13F ) { return; }
				this.Data.h13F = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h13F );
			}
		}
		public sbyte h140					// 忠誠補正(中道)
		{
			get { return this.Data.h140; }
			set
			{
				if ( value == this.h140 ) { return; }
				this.Data.h140 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h140 );
			}
		}
		public sbyte h141					// 忠誠補正(保守)
		{
			get { return this.Data.h141; }
			set
			{
				if ( value == this.h141 ) { return; }
				this.Data.h141 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h141 );
			}
		}
		public sbyte h142					// 陣効果
		{
			get { return this.Data.h142; }
			set
			{
				if ( value == this.h142 ) { return; }
				this.Data.h142 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h142 );
			}
		}
		public sbyte h143					// 経験補正
		{
			get { return this.Data.h143; }
			set
			{
				if ( value == this.h143 ) { return; }
				this.Data.h143 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h143 );
			}
		}
		public sbyte h144					// 兵糧補給効率
		{
			get { return this.Data.h144; }
			set
			{
				if ( value == this.h144 ) { return; }
				this.Data.h144 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h144 );
			}
		}
		public sbyte h145					// 疲労補正(%)
		{
			get { return this.Data.h145; }
			set
			{
				if ( value == this.h145 ) { return; }
				this.Data.h145 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h145 );
			}
		}
		public sbyte h146					// 146h 1バイト
		{
			get { return this.Data.h146; }
			set
			{
				if ( value == this.h146 ) { return; }
				this.Data.h146 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h146 );
			}
		}
		public sbyte h147					// 147h 1バイト
		{
			get { return this.Data.h147; }
			set
			{
				if ( value == this.h147 ) { return; }
				this.Data.h147 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h147 );
			}
		}
		public sbyte h148					// 行軍影響
		{
			get { return this.Data.h148; }
			set
			{
				if ( value == this.h148 ) { return; }
				this.Data.h148 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h148 );
			}
		}
		public sbyte h149					// 朝廷工作上昇量
		{
			get { return this.Data.h149; }
			set
			{
				if ( value == this.h149 ) { return; }
				this.Data.h149 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h149 );
			}
		}
		public sbyte h14A					// 密談効果上昇量1
		{
			get { return this.Data.h14A; }
			set
			{
				if ( value == this.h14A ) { return; }
				this.Data.h14A = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h14A );
			}
		}
		public sbyte h14B					// 軍団長の軍略効果上昇量
		{
			get { return this.Data.h14B; }
			set
			{
				if ( value == this.h14B ) { return; }
				this.Data.h14B = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h14B );
			}
		}
		public sbyte h14C					// 直轄軍団の統治範囲
		{
			get { return this.Data.h14C; }
			set
			{
				if ( value == this.h14C ) { return; }
				this.Data.h14C = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h14C );
			}
		}
		public sbyte h14D					// 捕縛登用率
		{
			get { return this.Data.h14D; }
			set
			{
				if ( value == this.h14D ) { return; }
				this.Data.h14D = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h14D );
			}
		}
		public sbyte h14E					// 14Eh 1バイト 0固定？
		{
			get { return this.Data.h14E; }
			set
			{
				if ( value == this.h14E ) { return; }
				this.Data.h14E = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h14E );
			}
		}
		public sbyte h14F					// 14Fh 1バイト 0固定？
		{
			get { return this.Data.h14F; }
			set
			{
				if ( value == this.h14F ) { return; }
				this.Data.h14F = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h14F );
			}
		}
		public sbyte h150					// 150h 1バイト
		{
			get { return this.Data.h150; }
			set
			{
				if ( value == this.h150 ) { return; }
				this.Data.h150 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h150 );
			}
		}
		public sbyte h151					// 151h 1バイト
		{
			get { return this.Data.h151; }
			set
			{
				if ( value == this.h151 ) { return; }
				this.Data.h151 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h151 );
			}
		}
		public sbyte h152					// 152h 1バイト
		{
			get { return this.Data.h152; }
			set
			{
				if ( value == this.h152 ) { return; }
				this.Data.h152 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h152 );
			}
		}
		public sbyte h153					// 153h 1バイト 0固定？
		{
			get { return this.Data.h153; }
			set
			{
				if ( value == this.h153 ) { return; }
				this.Data.h153 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h153 );
			}
		}


		/// <summary>コンストラクタ 政策</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Seisaku( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Seisakutable[id];
		}

		/// <summary>政策名リストを更新する</summary>
		private void UpdateNamelist()
		{
			var list = this.N14pkb.Seisakulist.Namelist;
			if ( list[this.Address] == this.Name ) { return; }

			list[this.Address] = this.Name;

			// ビュー更新フラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.政策].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.勢力].NeedsRefresh = true;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			var record = (byte[])this.Data.GetRecord().Clone();

			// 前提政策ポインタをIDに変換して埋め込む
			BitConverter.GetBytes( this.N14pkb.Seisakulist.GetIDByAddress(this.PtrZenteiSeisaku) ).CopyTo( record, 0x104 );

			return record;
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			var record = (byte[])buff.Clone();
			var id = 0;
			// 先頭4バイトの MagicNumber はゲーム起動毎に変わるため、現在の値を使用する
			BitConverter.GetBytes( this.Data.MagicNumber ).CopyTo( record, 0x00 );

			// 前提政策IDをポインタに変換して埋め込む
			id = BitConverter.ToInt32( record, 0x104 );
			BitConverter.GetBytes( this.N14pkb.Seisakulist.GetAddressByID( id ) ).CopyTo( record, 0x104 );

			this.Data.SetRecord( record );
			this.Write();

			// 特性名リストを更新する
			this.UpdateNamelist();

			// ビュー更新フラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.政策].NeedsRefresh = true;
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Seisakutable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Seisakulist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:政策:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
