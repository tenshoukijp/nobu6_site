﻿// Chihou.cs

using System;
using System.ComponentModel;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>地方ビューで使用するデータクラス</summary>
	public class Chihou : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の地方データ</summary>
		public ChihouData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID							// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address						// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex				// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}
		public string Name						// 名称
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Name );
				this.UpdateNamelist();
			}
		}
		public string Yomi						// 読み
		{
			get { return this.Data.Yomi; }
			set
			{
				if ( value == this.Yomi ) { return; }
				this.Data.Yomi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Yomi );
			}
		}
		public PointerlistType2 Chihoulist		// 隣接地方リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrChihouList ); }
		}
		public int CntChihouList				// 隣接地方データ数 6固定(実際に隣接している数ではなく隣接地方リストに含まれるポインタデータ数)
		{
			get { return this.Data.CntChihouList; }
			set
			{
				if ( value == this.CntChihouList ) { return; }
				this.Data.CntChihouList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntChihouList );
			}
		}
		public int h28_4						// 0固定？
		{
			get { return this.Data.h28_4; }
			set
			{
				if ( value == this.h28_4 ) { return; }
				this.Data.h28_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h28_4 );
			}
		}
		public int h2C_4						// 0～2？
		{
			get { return this.Data.h2C_4; }
			set
			{
				if ( value == this.h2C_4 ) { return; }
				this.Data.h2C_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h2C_4 );
			}
		}
		public int h30_4						// 不明
		{
			get { return this.Data.h30_4; }
			set
			{
				if ( value == this.h30_4 ) { return; }
				this.Data.h30_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h30_4 );
			}
		}
		public int h34_4						// 0固定？
		{
			get { return this.Data.h34_4; }
			set
			{
				if ( value == this.h34_4 ) { return; }
				this.Data.h34_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h34_4 );
			}
		}


		/// <summary>コンストラクタ 地方</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Chihou( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Chihoutable[id];
		}

		/// <summary>地方名リストを更新する</summary>
		private void UpdateNamelist()
		{
			var list = this.N14pkb.Chihoulist.Namelist;
			list[this.Address] = this.Name;

			// ビュー更新フラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.地方].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.国].NeedsRefresh = true;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			throw new NotSupportedException();
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			throw new NotSupportedException();
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Chihoutable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Chihoulist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:地方:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
