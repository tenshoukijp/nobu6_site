﻿// Kahou.cs

using System;
using System.ComponentModel;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>家宝ビューで使用するデータクラス</summary>
	public class Kahou : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の家宝データ</summary>
		public KahouData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID					// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address				// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex		// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}

		public string Name				// 名称
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Name );
				this.UpdateNamelist();
			}
		}
		public string Yomi				// 読み
		{
			get { return this.Data.Yomi; }
			set
			{
				if ( value == this.Yomi ) { return; }
				this.Data.Yomi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Yomi );
			}

		}
		public uint PtrHoyuuSeiryoku		// 保有勢力
		{
			get { return this.Data.PtrHoyuuSeiryoku; }
			set
			{
				if ( value == this.PtrHoyuuSeiryoku ) { return; }
				this.Data.PtrHoyuuSeiryoku = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrHoyuuSeiryoku );
			}
		}

		public string HoyuuBusyou		// 保有武将
		{
			get { return this.N14pkb.Busyoulist.GetNameByAddress( this.Data.PtrHoyuuBusyou ); }
			set
			{
				if ( value == this.HoyuuBusyou ) { return; }
				this.PtrHoyuuBusyou = this.N14pkb.Busyoulist.GetAddressByName( value );
			}
		}
		public uint PtrHoyuuBusyou		// 保有武将ポインタ
		{
			get { return this.Data.PtrHoyuuBusyou; }
			set
			{
				if ( value == this.PtrHoyuuBusyou ) { return; }
				Funcs.SetKahou( this.N14pkb, this, value );
				this.Data.PtrHoyuuBusyou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrHoyuuBusyou );
				this.PropertyChanged.Raise( () => this.HoyuuBusyou );
			}
		}
		public uint BunruiID			// 細かい分類？
		{
			get { return this.Data.BunruiID; }
			set
			{
				if ( value == this.BunruiID ) { return; }
				this.Data.BunruiID = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.BunruiID );
			}
		}
		public int ToukyuuID			// 等級
		{
			get { return (int)this.Data.ToukyuuID; }
			set
			{
				if ( value == this.ToukyuuID ) { return; }
				this.Data.ToukyuuID = (uint)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ToukyuuID );
				this.UpdateNamelist();
			}
		}
		public int KahouTypeID			// 家宝タイプ
		{
			get { return (int)this.Data.KahouTypeID; }
			set
			{
				if ( value == this.KahouTypeID ) { return; }
				this.Data.KahouTypeID = (uint)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KahouTypeID );
				this.UpdateNamelist();
			}
		}

		public bool h44_b0				// 44h bit0 登場フラグ？(勢力または個人が所有している(家宝情報に表示される)場合は1？)
		{
			get { return this.Data.h44_b0; }
			set
			{
				if ( value == this.h44_b0 ) { return; }
				this.Data.h44_b0 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h44_b0 );
			}
		}
		public bool h44_b1				// 44h bit1 フラグ 不明
		{
			get { return this.Data.h44_b1; }
			set
			{
				if ( value == this.h44_b1 ) { return; }
				this.Data.h44_b1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h44_b1 );
			}
		}
		public int SanchiID				// 44h bit2~3(2ビット) 生産地 0:日本、1:南蛮、2:明
		{
			get { return (int)this.Data.SanchiID; }
			set
			{
				if ( value == this.SanchiID ) { return; }
				this.Data.SanchiID = (uint)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SanchiID );
			}
		}


		/// <summary>ソートID</summary>
		private int _sortID;
		/// <summary>ソートID</summary>
		public int SortID
		{
			get
			{
				if ( this._sortID == -1 )
				{
					// ソートIDが未セットなら家宝リスト全体に設定する
					this.N14pkb.Kahoulist.SetSortID();
				}
				return this._sortID;
			}
			set
			{
				this._sortID = value;
			}
		}
		/// <summary>コンストラクタ 家宝</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Kahou( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Kahoutable[id];
			this.SortID = -1;
		}

		/// <summary>家宝名リストを更新する</summary>
		private void UpdateNamelist()
		{
			var list = this.N14pkb.Kahoulist.Namelist;
			list[this.Address] = Helper.家宝等級[(int)this.ToukyuuID] + Helper.家宝種類[(int)this.KahouTypeID] + ":" + this.Name;

			// ビューリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.武将].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.勢力].NeedsRefresh = true;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			throw new NotSupportedException();
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			throw new NotSupportedException();
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Kahoutable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Kahoulist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:家宝:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
