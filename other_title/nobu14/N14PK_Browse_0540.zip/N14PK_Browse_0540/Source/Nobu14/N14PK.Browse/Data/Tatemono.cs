﻿// Tatemono.cs

using System;
using System.ComponentModel;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>建物ビューで使用するデータクラス</summary>
	public class Tatemono : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の建物データ</summary>
		public TatemonoData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID					// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address				// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex		// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}
		public string Name				// Name
		{
			get { return this.N14pkb.Shisetsulist.GetNameByAddress( this.Data.PtrShisetsu ); }
			set { throw new NotSupportedException(); }
		}
		public int ShisetsuID			// 施設
		{
			get { return this.N14pkb.Shisetsulist.GetIDByAddress( this.Data.PtrShisetsu ); }
			set
			{
				if ( value == this.ShisetsuID ) { return; }
				this.Data.PtrShisetsu = this.N14pkb.Shisetsulist.GetAddressByID( value );
				this.Write();
				this.PropertyChanged.Raise( () => this.ShisetsuID );
			}
		}
		public uint PosX1				// 何かのX位置
		{
			get { return this.Data.PosX1; }
			set
			{
				if ( value == this.PosX1 ) { return; }
				this.Data.PosX1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PosX1 );
			}
		}
		public uint PosY1				// 何かのY位置
		{
			get { return this.Data.PosY1; }
			set
			{
				if ( value == this.PosY1 ) { return; }
				this.Data.PosY1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PosY1 );
			}
		}
		public ushort PosX2				// キャプション？のX位置
		{
			get { return this.Data.PosX2; }
			set
			{
				if ( value == this.PosX2 ) { return; }
				this.Data.PosX2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PosX2 );
			}
		}
		public ushort PosY2				// キャプション？のY位置
		{
			get { return this.Data.PosY2; }
			set
			{
				if ( value == this.PosY2 ) { return; }
				this.Data.PosY2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PosY2 );
			}
		}
		public uint h14_4				// 0固定？
		{
			get { return this.Data.h14_4; }
			set
			{
				if ( value == this.h14_4 ) { return; }
				this.Data.h14_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h14_4 );
			}
		}
		public string Kuni				// 国
		{
			get
			{
				// PtrKuni に値が入ってない場合(支城建設後に確認すると 0 の場合がある)は、要所リストから当該拠点の国名を取得する
				if ( ( this.Data.PtrKuni == 0 )
					&& ( this.Data.KyotenTypeID == 1 ) // 城
					)
				{
					var yousyo = this.N14pkb.Yousyolist.GetDataByKyotenAddress( this.Data.PtrKyoten );
					return ( yousyo != null ) ? yousyo.Kuni : string.Empty;
				}
				else
				{
					return this.N14pkb.Kunilist.GetNameByAddress( this.Data.PtrKuni );
				}
			}
			set
			{
				if ( value == this.Kuni ) { return; }
				this.Data.PtrKuni = this.N14pkb.Kunilist.GetAddressByName( value );
				this.Write();
				this.PropertyChanged.Raise( () => this.Kuni );
			}
		}
		public short TaikyuuNow			// 現在耐久
		{
			get { return this.Data.TaikyuuNow; }
			set
			{
				if ( value == this.TaikyuuNow ) { return; }
				this.Data.TaikyuuNow = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.TaikyuuNow );
			}
		}
		public ushort h1E_2				// 0固定？
		{
			get { return this.Data.h1E_2; }
			set
			{
				if ( value == this.h1E_2 ) { return; }
				this.Data.h1E_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h1E_2 );
			}
		}
		public sbyte h20				// 0x01 / 0x02 / 0xFF
		{
			get { return this.Data.h20; }
			set
			{
				if ( value == this.h20 ) { return; }
				this.Data.h20 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h20 );
			}
		}
		public byte h21					// 21h 1バイト
		{
			get { return this.Data.h21; }
			set
			{
				if ( value == this.h21 ) { return; }
				this.Data.h21 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h21 );
			}
		}
		public byte h22					// 0固定？
		{
			get { return this.Data.h22; }
			set
			{
				if ( value == this.h22 ) { return; }
				this.Data.h22 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h22 );
			}
		}
		public byte h23					// 0固定？
		{
			get { return this.Data.h23; }
			set
			{
				if ( value == this.h23 ) { return; }
				this.Data.h23 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h23 );
			}
		}
		public string Kyoten			// 拠点(城 / 国人衆)
		{
			get
			{
				switch ( this.Data.KyotenTypeID )
				{
					case 0:	// なし
						return string.Empty;

					case 1:	// 城
						return this.N14pkb.Shirolist.GetNameByAddress( this.Data.PtrKyoten );

					case 3:	// 国人衆
						var name = this.N14pkb.Kokujinlist.GetNameByAddress( this.Data.PtrKyoten );
						// 城名には "*"/"  " が付いているのでそれに合わせる
						return !string.IsNullOrEmpty( name ) ? name.Insert( 0, "  " ) : name;

					default:
						return Funcs.GetNameByAddress( this.N14pkb, this.Data.PtrKyoten );
				}
			}
		}
		public short h2C_2				// 0固定？
		{
			get { return this.Data.h2C_2; }
			set
			{
				if ( value == this.h2C_2 ) { return; }
				this.Data.h2C_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h2C_2 );
			}
		}
		public short h2E_2				// 何かのIDか？ 確認時は0~350(重複あり)が入っていた
		{
			get { return this.Data.h2E_2; }
			set
			{
				if ( value == this.h2E_2 ) { return; }
				this.Data.h2E_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h2E_2 );
			}
		}
		public string Gundanname		// 軍団
		{
			get { return ( this.Gundan != null ) ? this.Gundan.Name : string.Empty; ; }
		}


		// 城
		public Shiro Shiro
		{ get { return this.N14pkb.Shirolist[this.Data.PtrKyoten]; } }
		// 軍団
		public Gundan Gundan
		{ get { return ( this.Shiro != null ) ? this.N14pkb.Gundanlist[this.Shiro.Data.PtrGundan] : null; } }
		// 勢力
		public Seiryoku Seiryoku
		{ get { return ( this.Gundan != null ) ? this.N14pkb.Seiryokulist[this.Gundan.Data.PtrSeiryoku] : null; } }

		/// <summary>コンストラクタ 建物</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Tatemono( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Tatemonotable[id];
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			throw new NotSupportedException();
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			throw new NotSupportedException();
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Tatemonotable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Tatemonolist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>

		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:建物:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
		}
	}
}
