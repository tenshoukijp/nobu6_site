﻿// ViewData.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace N14PKBrowse.Data
{
	public interface IBrowseData
	{
		int ID { get; }
		uint Address { get; }
		string Name { get; set; }
		byte[] GetSaveData();
		void SetSaveData( byte[] buff );
	}
}
