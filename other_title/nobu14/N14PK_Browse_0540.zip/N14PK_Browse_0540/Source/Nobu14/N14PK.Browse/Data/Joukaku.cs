﻿// Joukaku.cs

using System;
using System.ComponentModel;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>城郭ビューで使用するデータクラス</summary>
	public class Joukaku : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の城郭データ</summary>
		public JoukakuData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID								// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address							// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex					// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}

		public string Name							// 名称(シフトJIS nullターミネイト)
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Name );
				this.UpdateNamelist();
			}
		}
		public string Yomi							// 読み(シフトJIS nullターミネイト)
		{
			get { return this.Data.Yomi; }
			set
			{
				if ( value == this.Yomi ) { return; }
				this.Data.Yomi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Yomi );
			}
		}
		public string HelpText1						// ヘルプ1行目(シフトJIS nullターミネイト)
		{
			get { return this.Data.HelpText1; }
			set
			{
				if ( value == this.HelpText1 ) { return; }
				this.Data.HelpText1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HelpText1 );
			}
		}
		public string HelpText2						// ヘルプ2行目(シフトJIS nullターミネイト)
		{
			get { return this.Data.HelpText2; }
			set
			{
				if ( value == this.HelpText2 ) { return; }
				this.Data.HelpText2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HelpText2 );
			}
		}
		public string HelpText3						// ヘルプ3行目(シフトJIS nullターミネイト)
		{
			get { return this.Data.HelpText3; }
			set
			{
				if ( value == this.HelpText3 ) { return; }
				this.Data.HelpText3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HelpText3 );
			}
		}
		public string HelpText4						// ヘルプ4行目 未使用(シフトJIS nullターミネイト)
		{
			get { return this.Data.HelpText4; }
			set
			{
				if ( value == this.HelpText4 ) { return; }
				this.Data.HelpText4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HelpText4 );
			}
		}
		public int JoukakuTypeID					// 城郭タイプID 0:天守、1:城門、2:塀、3:出丸、4:矢倉、5:曲輪、6:施設
		{
			get { return this.Data.JoukakuTypeID; }
			set
			{
				if ( value == this.JoukakuTypeID ) { return; }
				this.Data.JoukakuTypeID = (short)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.JoukakuTypeID );
			}
		}
		public short Taikyuu						// 耐久
		{
			get { return this.Data.Taikyuu; }
			set
			{
				if ( value == this.Taikyuu ) { return; }
				this.Data.Taikyuu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Taikyuu );
			}
		}
		public short h0C8_2							// 0C8h 2バイト
		{
			get { return this.Data.h0C8_2; }
			set
			{
				if ( value == this.h0C8_2 ) { return; }
				this.Data.h0C8_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0C8_2 );
			}
		}
		public short h0CA_2							// 0CAh 2バイト
		{
			get { return this.Data.h0CA_2; }
			set
			{
				if ( value == this.h0CA_2 ) { return; }
				this.Data.h0CA_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0CA_2 );
			}
		}
		public byte Youchi							// 用地
		{
			get { return this.Data.Youchi; }
			set
			{
				if ( value == this.Youchi ) { return; }
				this.Data.Youchi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Youchi );
			}
		}
		public sbyte h0CD							// 0CDh 1バイト
		{
			get { return this.Data.h0CD; }
			set
			{
				if ( value == this.h0CD ) { return; }
				this.Data.h0CD = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0CD );
			}
		}
		public sbyte h0CE							// 0xFF固定？
		{
			get { return this.Data.h0CE; }
			set
			{
				if ( value == this.h0CE ) { return; }
				this.Data.h0CE = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0CE );
			}
		}
		public byte h0CF							// 0固定？
		{
			get { return this.Data.h0CF; }
			set
			{
				if ( value == this.h0CF ) { return; }
				this.Data.h0CF = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0CF );
			}
		}
		public short TaiHoui						// 対包囲
		{
			get { return this.Data.TaiHoui; }
			set
			{
				if ( value == this.TaiHoui ) { return; }
				this.Data.TaiHoui = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.TaiHoui );
			}
		}
		public short TaiKyoukou						// 対強行
		{
			get { return this.Data.TaiKyoukou; }
			set
			{
				if ( value == this.TaiKyoukou ) { return; }
				this.Data.TaiKyoukou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.TaiKyoukou );
			}
		}
		public short h0D4_2							// 0固定？
		{
			get { return this.Data.h0D4_2; }
			set
			{
				if ( value == this.h0D4_2 ) { return; }
				this.Data.h0D4_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0D4_2 );
			}
		}
		public short TaiYakiuchi					// 対焼き討ち
		{
			get { return this.Data.TaiYakiuchi; }
			set
			{
				if ( value == this.TaiYakiuchi ) { return; }
				this.Data.TaiYakiuchi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.TaiYakiuchi );
			}
		}
		public short h0D8_2							// 0固定？
		{
			get { return this.Data.h0D8_2; }
			set
			{
				if ( value == this.h0D8_2 ) { return; }
				this.Data.h0D8_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0D8_2 );
			}
		}
		public short Hokyuuhei						// 補給兵の強さ増加値
		{
			get { return this.Data.Hokyuuhei; }
			set
			{
				if ( value == this.Hokyuuhei ) { return; }
				this.Data.Hokyuuhei = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Hokyuuhei );
			}
		}
		public short Ryouminhei						// 領民兵の強さ増加値
		{
			get { return this.Data.Ryouminhei; }
			set
			{
				if ( value == this.Ryouminhei ) { return; }
				this.Data.Ryouminhei = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Ryouminhei );
			}
		}
		public short Joubihei						// 常備兵増加数
		{
			get { return this.Data.Joubihei; }
			set
			{
				if ( value == this.Joubihei ) { return; }
				this.Data.Joubihei = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Joubihei );
			}
		}
		public short TaiHouibutai					// 包囲している部隊への攻撃 0:×、1:○
		{
			get { return this.Data.TaiHouibutai; }
			set
			{
				if ( value == this.TaiHouibutai ) { return; }
				this.Data.TaiHouibutai = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.TaiHouibutai );
			}
		}
		public short HituyouKokudaka				// 必要石高
		{
			get { return this.Data.HituyouKokudaka; }
			set
			{
				if ( value == this.HituyouKokudaka ) { return; }
				this.Data.HituyouKokudaka = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HituyouKokudaka );
			}
		}
		public short HitsuyouSyougyou				// 必要商業
		{
			get { return this.Data.HitsuyouSyougyou; }
			set
			{
				if ( value == this.HitsuyouSyougyou ) { return; }
				this.Data.HitsuyouSyougyou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HitsuyouSyougyou );
			}
		}
		public short HitsuyouHeisya					// 必要兵舎
		{
			get { return this.Data.HitsuyouHeisya; }
			set
			{
				if ( value == this.HitsuyouHeisya ) { return; }
				this.Data.HitsuyouHeisya = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HitsuyouHeisya );
			}
		}
		public int h0E8_4							// 0xFFFFFFFF固定？
		{
			get { return this.Data.h0E8_4; }
			set
			{
				if ( value == this.h0E8_4 ) { return; }
				this.Data.h0E8_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0E8_4 );
			}
		}
		public int h0EC_4							// 0xFFFFFFFF固定？
		{
			get { return this.Data.h0EC_4; }
			set
			{
				if ( value == this.h0EC_4 ) { return; }
				this.Data.h0EC_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0EC_4 );
			}
		}
		public int h0F0_4							// 0固定？
		{
			get { return this.Data.h0F0_4; }
			set
			{
				if ( value == this.h0F0_4 ) { return; }
				this.Data.h0F0_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0F0_4 );
			}
		}
		public uint PtrJoukaku_0F4					// 城郭(前提？)
		{
			get { return this.N14pkb.Joukakulist.GetAddressByID( this.Data.JoukakuID_0F4 ); }
			set
			{
				if ( value == this.PtrJoukaku_0F4 ) { return; }
				this.Data.JoukakuID_0F4 = this.N14pkb.Joukakulist.GetIDByAddress( value );
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrJoukaku_0F4 );
			}
		}
		public byte h0F8							// 0F8h 1バイト
		{
			get { return this.Data.h0F8; }
			set
			{
				if ( value == this.h0F8 ) { return; }
				this.Data.h0F8 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0F8 );
			}
		}
		public byte h0F9							// 0固定？
		{
			get { return this.Data.h0F9; }
			set
			{
				if ( value == this.h0F9 ) { return; }
				this.Data.h0F9 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0F9 );
			}
		}
		public sbyte h0FA							// 0FAh 1バイト
		{
			get { return this.Data.h0FA; }
			set
			{
				if ( value == this.h0FA ) { return; }
				this.Data.h0FA = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0FA );
			}
		}
		public sbyte SaidaiTamichuuZouka			// 最大民忠増加値
		{
			get { return this.Data.SaidaiTamichuuZouka; }
			set
			{
				if ( value == this.SaidaiTamichuuZouka ) { return; }
				this.Data.SaidaiTamichuuZouka = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SaidaiTamichuuZouka );
			}
		}
		public int JinkouZouka						// 人口増加値
		{
			get { return this.Data.JinkouZouka; }
			set
			{
				if ( value == this.JinkouZouka ) { return; }
				this.Data.JinkouZouka = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.JinkouZouka );
			}
		}
		public int HitsuyouShigenID				// 必要資源(施設)
		{
			get { return this.Data.HitsuyouShigenID; }
			set
			{
				if ( value == this.HitsuyouShigenID ) { return; }
				this.Data.HitsuyouShigenID = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HitsuyouShigenID );
			}
		}
		public int EikyouShisetsuID1				// 影響施設ID(当該施設の数に応じて効果が上昇する)
		{
			get { return this.Data.EikyouShisetsuID1; }
			set
			{
				if ( value == this.EikyouShisetsuID1 ) { return; }
				this.Data.EikyouShisetsuID1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.EikyouShisetsuID1 );
			}
		}
		public int EikyouShisetsuID2				// 影響施設ID(当該施設の数に応じて効果が上昇する)
		{
			get { return this.Data.EikyouShisetsuID2; }
			set
			{
				if ( value == this.EikyouShisetsuID2 ) { return; }
				this.Data.EikyouShisetsuID2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.EikyouShisetsuID2 );
			}
		}
		public int HitsuyouMinatoID				// 必要港(施設)
		{
			get { return this.Data.HitsuyouMinatoID; }
			set
			{
				if ( value == this.HitsuyouMinatoID ) { return; }
				this.Data.HitsuyouMinatoID = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HitsuyouMinatoID );
			}
		}
		public byte SyuukakuZouka					// 収穫増加値
		{
			get { return this.Data.SyuukakuZouka; }
			set
			{
				if ( value == this.SyuukakuZouka ) { return; }
				this.Data.SyuukakuZouka = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SyuukakuZouka );
			}
		}
		public byte SyuunyuuZouka					// 金銭収入増加値
		{
			get { return this.Data.SyuunyuuZouka; }
			set
			{
				if ( value == this.SyuunyuuZouka ) { return; }
				this.Data.SyuunyuuZouka = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SyuunyuuZouka );
			}
		}
		public byte h112							// 0固定？
		{
			get { return this.Data.h112; }
			set
			{
				if ( value == this.h112 ) { return; }
				this.Data.h112 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h112 );
			}
		}
		public byte h113							// 0固定？
		{
			get { return this.Data.h113; }
			set
			{
				if ( value == this.h113 ) { return; }
				this.Data.h113 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h113 );
			}
		}
		public byte HyourousyouhiGensyou			// 腰兵糧消費減少
		{
			get { return this.Data.HyourousyouhiGensyou; }
			set
			{
				if ( value == this.HyourousyouhiGensyou ) { return; }
				this.Data.HyourousyouhiGensyou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HyourousyouhiGensyou );
			}
		}
		public byte SyouheiKaifukusokudoZouka		// 傷兵回復速度上昇値
		{
			get { return this.Data.SyouheiKaifukusokudoZouka; }
			set
			{
				if ( value == this.SyouheiKaifukusokudoZouka ) { return; }
				this.Data.SyouheiKaifukusokudoZouka = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SyouheiKaifukusokudoZouka );
			}
		}
		public byte h116							// 0固定？
		{
			get { return this.Data.h116; }
			set
			{
				if ( value == this.h116 ) { return; }
				this.Data.h116 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h116 );
			}
		}
		public byte h117							// 0固定？
		{
			get { return this.Data.h117; }
			set
			{
				if ( value == this.h117 ) { return; }
				this.Data.h117 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h117 );
			}
		}
		public byte KaisenNouryokuZouka1			// 遠海移動速度・海戦能力上昇(造船所のみ10) 119と同値
		{
			get { return this.Data.KaisenNouryokuZouka1; }
			set
			{
				if ( value == this.KaisenNouryokuZouka1 ) { return; }
				this.Data.KaisenNouryokuZouka1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KaisenNouryokuZouka1 );
			}
		}
		public byte KaisenNouryokuZouka2			// 遠海移動速度・海戦能力上昇(造船所のみ10) 118と同値
		{
			get { return this.Data.KaisenNouryokuZouka2; }
			set
			{
				if ( value == this.KaisenNouryokuZouka2 ) { return; }
				this.Data.KaisenNouryokuZouka2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KaisenNouryokuZouka2 );
			}
		}
		public byte SyozokuButaiKougekiryokuZouka	// 所属部隊攻撃力増加値
		{
			get { return this.Data.SyozokuButaiKougekiryokuZouka; }
			set
			{
				if ( value == this.SyozokuButaiKougekiryokuZouka ) { return; }
				this.Data.SyozokuButaiKougekiryokuZouka = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SyozokuButaiKougekiryokuZouka );
			}
		}
		public byte TaiHobaku						// 対捕縛
		{
			get { return this.Data.TaiHobaku; }
			set
			{
				if ( value == this.TaiHobaku ) { return; }
				this.Data.TaiHobaku = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.TaiHobaku );
			}
		}
		public byte ButaiKyoukaSouzou1				// 創造武将所属部隊強化 11Dと同値
		{
			get { return this.Data.ButaiKyoukaSouzou1; }
			set
			{
				if ( value == this.ButaiKyoukaSouzou1 ) { return; }
				this.Data.ButaiKyoukaSouzou1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ButaiKyoukaSouzou1 );
			}
		}
		public byte ButaiKyoukaSouzou2				// 創造武将所属部隊強化 11Cと同値
		{
			get { return this.Data.ButaiKyoukaSouzou2; }
			set
			{
				if ( value == this.ButaiKyoukaSouzou2 ) { return; }
				this.Data.ButaiKyoukaSouzou2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ButaiKyoukaSouzou2 );
			}
		}
		public byte ButaiKyoukaChuudou1				// 中道武将所属部隊強化 11Fと同値
		{
			get { return this.Data.ButaiKyoukaChuudou1; }
			set
			{
				if ( value == this.ButaiKyoukaChuudou1 ) { return; }
				this.Data.ButaiKyoukaChuudou1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ButaiKyoukaChuudou1 );
			}
		}
		public byte ButaiKyoukaChuudou2				// 中道武将所属部隊強化 11Eと同値
		{
			get { return this.Data.ButaiKyoukaChuudou2; }
			set
			{
				if ( value == this.ButaiKyoukaChuudou2 ) { return; }
				this.Data.ButaiKyoukaChuudou2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ButaiKyoukaChuudou2 );
			}
		}
		public byte ButaiKyoukaHosyu1				// 保守武将所属部隊強化 121と同値
		{
			get { return this.Data.ButaiKyoukaHosyu1; }
			set
			{
				if ( value == this.ButaiKyoukaHosyu1 ) { return; }
				this.Data.ButaiKyoukaHosyu1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ButaiKyoukaHosyu1 );
			}
		}
		public byte ButaiKyoukaHosyu2				// 保守武将所属部隊強化 120と同値
		{
			get { return this.Data.ButaiKyoukaHosyu2; }
			set
			{
				if ( value == this.ButaiKyoukaHosyu2 ) { return; }
				this.Data.ButaiKyoukaHosyu2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ButaiKyoukaHosyu2 );
			}
		}
		public byte GunbaKougekiryokuZouka			// 軍馬配備時の攻撃力上昇値
		{
			get { return this.Data.GunbaKougekiryokuZouka; }
			set
			{
				if ( value == this.GunbaKougekiryokuZouka ) { return; }
				this.Data.GunbaKougekiryokuZouka = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.GunbaKougekiryokuZouka );
			}
		}
		public byte TeppouKougekiryokuZouka			// 鉄砲配備時の攻撃力上昇値
		{
			get { return this.Data.TeppouKougekiryokuZouka; }
			set
			{
				if ( value == this.TeppouKougekiryokuZouka ) { return; }
				this.Data.TeppouKougekiryokuZouka = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.TeppouKougekiryokuZouka );
			}
		}

		// 124h の1バイトはビットフラグぽい
		public bool h124_b0							// bit0 124h
		{
			get { return this.Data.h124_b0; }
			set
			{
				if ( value == h124_b0 ) { return; }
				this.Data.h124_b0 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h124_b0 );
			}
		}
		public bool h124_b1							// bit1 124h
		{
			get { return this.Data.h124_b1; }
			set
			{
				if ( value == h124_b1 ) { return; }
				this.Data.h124_b1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h124_b1 );
			}
		}
		public bool h124_b2							// bit2 124h
		{
			get { return this.Data.h124_b2; }
			set
			{
				if ( value == h124_b2 ) { return; }
				this.Data.h124_b2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h124_b2 );
			}
		}
		public bool h124_b3							// bit3 124h
		{
			get { return this.Data.h124_b3; }
			set
			{
				if ( value == h124_b3 ) { return; }
				this.Data.h124_b3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h124_b3 );
			}
		}
		public bool h124_b4							// bit4 124h
		{
			get { return this.Data.h124_b4; }
			set
			{
				if ( value == h124_b4 ) { return; }
				this.Data.h124_b4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h124_b4 );
			}
		}
		public bool h124_b5							// bit5 124h
		{
			get { return this.Data.h124_b5; }
			set
			{
				if ( value == h124_b5 ) { return; }
				this.Data.h124_b5 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h124_b5 );
			}
		}
		public bool h124_b6							// bit6 124h
		{
			get { return this.Data.h124_b6; }
			set
			{
				if ( value == h124_b6 ) { return; }
				this.Data.h124_b6 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h124_b6 );
			}
		}
		public bool h124_b7							// bit7 124h
		{
			get { return this.Data.h124_b7; }
			set
			{
				if ( value == h124_b7 ) { return; }
				this.Data.h124_b7 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h124_b7 );
			}
		}

		public byte h125							// 125h 1バイト 0固定？
		{
			get { return this.Data.h125; }
			set
			{
				if ( value == this.h125 ) { return; }
				this.Data.h125 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h125 );
			}
		}
		public byte h126							// 126h 1バイト 0固定？
		{
			get { return this.Data.h126; }
			set
			{
				if ( value == this.h126 ) { return; }
				this.Data.h126 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h126 );
			}
		}
		public byte h127							// 127h 1バイト 0固定？
		{
			get { return this.Data.h127; }
			set
			{
				if ( value == this.h127 ) { return; }
				this.Data.h127 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h127 );
			}
		}


		/// <summary>コンストラクタ 城郭</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Joukaku( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Joukakutable[id];
		}

		/// <summary>城郭名リストを更新する</summary>
		private void UpdateNamelist()
		{
			var list = this.N14pkb.Joukakulist.Namelist;
			if ( list[this.Address] == this.Name ) { return; }

			list[this.Address] = this.Name;

			// ビューリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.城].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.城郭].NeedsRefresh = true;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			var record = (byte[])this.Data.GetRecord().Clone();
			return record;
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			var record = (byte[])buff.Clone();
			// 先頭4バイトの MagicNumber はゲーム起動毎に変わるため、現在の値を使用する
			BitConverter.GetBytes( this.Data.MagicNumber ).CopyTo( record, 0x00 );

			this.Data.SetRecord( record );
			this.Write();

			// 城郭名リストを更新する
			this.UpdateNamelist();
			// ビューリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.城郭].NeedsRefresh = true;
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Joukakutable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Joukakulist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:城郭:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
