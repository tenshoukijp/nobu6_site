﻿// Tokusei.cs

using System;
using System.ComponentModel;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>特性ビューで使用するデータクラス</summary>
	public class Tokusei : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の特性データ</summary>
		public TokuseiData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID					// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address				// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex		// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}
		public string Name				// 名称
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Name );
				this.UpdateNamelist();
			}
		}
		public string Yomi				// 読み
		{
			get { return this.Data.Yomi; }
			set
			{
				if ( value == this.Yomi ) { return; }
				this.Data.Yomi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Yomi );
			}
		}
		public string HelpText1			// ヘルプ1
		{
			get { return this.Data.HelpText1; }
			set
			{
				if ( value == this.HelpText1 ) { return; }
				this.Data.HelpText1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HelpText1 );
			}
		}
		public string HelpText2			// ヘルプ2
		{
			get { return this.Data.HelpText2; }
			set
			{
				if ( value == this.HelpText2 ) { return; }
				this.Data.HelpText2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HelpText2 );
			}
		}
		public uint PtrKaiTokusei		// 下位特性
		{
			get { return this.Data.PtrKaiTokusei; }
			set
			{
				if ( value == this.PtrKaiTokusei ) { return; }
				this.Data.PtrKaiTokusei = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrKaiTokusei );
			}
		}
		public uint PtrHanTokusei		// 反特性
		{
			get { return this.Data.PtrHanTokusei; }
			set
			{
				if ( value == this.PtrHanTokusei ) { return; }
				this.Data.PtrHanTokusei = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrHanTokusei );
			}
		}

		public int KakuID				// 格付け 0:E、1:D、2:C、3:B、4:A、5:S
		{
			get { return this.Data.KakuID; }
			set
			{
				if ( value == this.KakuID ) { return; }
				this.Data.KakuID = (sbyte)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KakuID );
			}
		}
		public int KeitouID				// 系統ID 0:統率、1:武勇、2:知略、3:政治、4:内政、5:合戦、6:役職、7:官位、8:？、9:ダミー用 ※8:は使われていない
		{
			get { return this.Data.KeitouID; }
			set
			{
				if ( value == this.KeitouID ) { return; }
				this.Data.KeitouID = (sbyte)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KeitouID );
			}
		}
		public sbyte hAA				// 0固定？
		{
			get { return this.Data.hAA; }
			set
			{
				if ( value == this.hAA ) { return; }
				this.Data.hAA = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hAA );
			}
		}
		public sbyte hAB				// 0固定？
		{
			get { return this.Data.hAB; }
			set
			{
				if ( value == this.hAB ) { return; }
				this.Data.hAB = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hAB );
			}
		}
		public sbyte hAC				// 不明 ダミーデータには1、それ以外は0
		{
			get { return this.Data.hAC; }
			set
			{
				if ( value == this.hAC ) { return; }
				this.Data.hAC = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hAC );
			}
		}
		public sbyte HeisuuJouken		// 兵数条件
		{
			get { return this.Data.HeisuuJouken; }
			set
			{
				if ( value == this.HeisuuJouken ) { return; }
				this.Data.HeisuuJouken = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HeisuuJouken );
			}
		}
		public sbyte Jouken				// 条件
		{
			get { return this.Data.Jouken; }
			set
			{
				if ( value == this.Jouken ) { return; }
				this.Data.Jouken = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Jouken );
			}
		}
		public sbyte Hatsudouritsu		// 発動率
		{
			get { return this.Data.Hatsudouritsu; }
			set
			{
				if ( value == this.Hatsudouritsu ) { return; }
				this.Data.Hatsudouritsu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Hatsudouritsu );
			}
		}
		public sbyte hB0				// 不明
		{
			get { return this.Data.hB0; }
			set
			{
				if ( value == this.hB0 ) { return; }
				this.Data.hB0 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hB0 );
			}
		}
		public sbyte hB1				// 不明
		{
			get { return this.Data.hB1; }
			set
			{
				if ( value == this.hB1 ) { return; }
				this.Data.hB1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hB1 );
			}
		}
		public sbyte Kaii				// 階位
		{
			get { return this.Data.Kaii; }
			set
			{
				if ( value == this.Kaii ) { return; }
				this.Data.Kaii = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kaii );
			}
		}
		public int SortID				// ソートID
		{
			get { return this.Data.SortID; }
			set
			{
				if ( value == this.SortID ) { return; }
				this.Data.SortID = (byte)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SortID );
			}
		}

		public short hB4_2				// 不明
		{
			get { return this.Data.hB4_2; }
			set
			{
				if ( value == this.hB4_2 ) { return; }
				this.Data.hB4_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hB4_2 );
			}
		}
		public short Hyourou			// 腰兵糧
		{
			get { return this.Data.Hyourou; }
			set
			{
				if ( value == this.Hyourou ) { return; }
				this.Data.Hyourou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Hyourou );
			}
		}
		public short Kougeki1			// 攻撃1
		{
			get { return this.Data.Kougeki1; }
			set
			{
				if ( value == this.Kougeki1 ) { return; }
				this.Data.Kougeki1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kougeki1 );
			}
		}
		public short Syubi1				// 守備1
		{
			get { return this.Data.Syubi1; }
			set
			{
				if ( value == this.Syubi1 ) { return; }
				this.Data.Syubi1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Syubi1 );
			}
		}
		public short Kougeki2			// 攻撃2
		{
			get { return this.Data.Kougeki2; }
			set
			{
				if ( value == this.Kougeki2 ) { return; }
				this.Data.Kougeki2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kougeki2 );
			}
		}
		public short Syubi2				// 守備2
		{
			get { return this.Data.Syubi2; }
			set
			{
				if ( value == this.Syubi2 ) { return; }
				this.Data.Syubi2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Syubi2 );
			}
		}
		public short Idou				// 移動速度
		{
			get { return this.Data.Idou; }
			set
			{
				if ( value == this.Idou ) { return; }
				this.Data.Idou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Idou );
			}
		}
		public short Keitaihenkou		// 形態変更
		{
			get { return this.Data.Keitaihenkou; }
			set
			{
				if ( value == this.Keitaihenkou ) { return; }
				this.Data.Keitaihenkou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Keitaihenkou );
			}
		}
		public short Shiki				// 士気ゲージ
		{
			get { return this.Data.Shiki; }
			set
			{
				if ( value == this.Shiki ) { return; }
				this.Data.Shiki = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Shiki );
			}
		}
		public short Jin				// 陣(設営効果)
		{
			get { return this.Data.Jin; }
			set
			{
				if ( value == this.Jin ) { return; }
				this.Data.Jin = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Jin );
			}
		}
		public short Kyougeki			// 挟撃効果
		{
			get { return this.Data.Kyougeki; }
			set
			{
				if ( value == this.Kyougeki ) { return; }
				this.Data.Kyougeki = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kyougeki );
			}
		}
		public short Koudoufuka			// 行動不可
		{
			get { return this.Data.Koudoufuka; }
			set
			{
				if ( value == this.Koudoufuka ) { return; }
				this.Data.Koudoufuka = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Koudoufuka );
			}
		}
		public short Konran				// 混乱
		{
			get { return this.Data.Konran; }
			set
			{
				if ( value == this.Konran ) { return; }
				this.Data.Konran = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Konran );
			}
		}

		public short hCE_2				// 未使用？
		{
			get { return this.Data.hCE_2; }
			set
			{
				if ( value == this.hCE_2 ) { return; }
				this.Data.hCE_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hCE_2 );
			}
		}
		public short hD0_2				// 未使用？
		{
			get { return this.Data.hD0_2; }
			set
			{
				if ( value == this.hD0_2 ) { return; }
				this.Data.hD0_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hD0_2 );
			}
		}
		public short hD2_2				// 未使用？
		{
			get { return this.Data.hD2_2; }
			set
			{
				if ( value == this.hD2_2 ) { return; }
				this.Data.hD2_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hD2_2 );
			}
		}
		public short hD4_2				// 未使用？
		{
			get { return this.Data.hD4_2; }
			set
			{
				if ( value == this.hD4_2 ) { return; }
				this.Data.hD4_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hD4_2 );
			}
		}
		public short hD6_2				// 未使用？
		{
			get { return this.Data.hD6_2; }
			set
			{
				if ( value == this.hD6_2 ) { return; }
				this.Data.hD6_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hD6_2 );
			}
		}
		public short hD8_2				// 未使用？
		{
			get { return this.Data.hD8_2; }
			set
			{
				if ( value == this.hD8_2 ) { return; }
				this.Data.hD8_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hD8_2 );
			}
		}
		public short hDA_2				// 未使用？
		{
			get { return this.Data.hDA_2; }
			set
			{
				if ( value == this.hDA_2 ) { return; }
				this.Data.hDA_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hDA_2 );
			}
		}
		public short hDC_2				// 未使用？
		{
			get { return this.Data.hDC_2; }
			set
			{
				if ( value == this.hDC_2 ) { return; }
				this.Data.hDC_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hDC_2 );
			}
		}
		public short hDE_2				// 未使用？
		{
			get { return this.Data.hDE_2; }
			set
			{
				if ( value == this.hDE_2 ) { return; }
				this.Data.hDE_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hDE_2 );
			}
		}
		public short hE0_2				// 未使用？
		{
			get { return this.Data.hE0_2; }
			set
			{
				if ( value == this.hE0_2 ) { return; }
				this.Data.hE0_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hE0_2 );
			}
		}
		public short hE2_2				// 未使用？
		{
			get { return this.Data.hE2_2; }
			set
			{
				if ( value == this.hE2_2 ) { return; }
				this.Data.hE2_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hE2_2 );
			}
		}
		public short hE4_2				// 未使用？
		{
			get { return this.Data.hE4_2; }
			set
			{
				if ( value == this.hE4_2 ) { return; }
				this.Data.hE4_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hE4_2 );
			}
		}
		public short hE6_2				// 未使用？
		{
			get { return this.Data.hE6_2; }
			set
			{
				if ( value == this.hE6_2 ) { return; }
				this.Data.hE6_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hE6_2 );
			}
		}
		public short hE8_2				// 未使用？
		{
			get { return this.Data.hE8_2; }
			set
			{
				if ( value == this.hE8_2 ) { return; }
				this.Data.hE8_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hE8_2 );
			}
		}
		public short hEA_2				// 未使用？
		{
			get { return this.Data.hEA_2; }
			set
			{
				if ( value == this.hEA_2 ) { return; }
				this.Data.hEA_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hEA_2 );
			}
		}
		public short hEC_2				// 未使用？
		{
			get { return this.Data.hEC_2; }
			set
			{
				if ( value == this.hEC_2 ) { return; }
				this.Data.hEC_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hEC_2 );
			}
		}
		public short hEE_2				// 未使用？
		{
			get { return this.Data.hEE_2; }
			set
			{
				if ( value == this.hEE_2 ) { return; }
				this.Data.hEE_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hEE_2 );
			}
		}
		public short hF0_2				// 未使用？
		{
			get { return this.Data.hF0_2; }
			set
			{
				if ( value == this.hF0_2 ) { return; }
				this.Data.hF0_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hF0_2 );
			}
		}
		public short hF2_2				// 未使用？
		{
			get { return this.Data.hF2_2; }
			set
			{
				if ( value == this.hF2_2 ) { return; }
				this.Data.hF2_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.hF2_2 );
			}
		}


		/// <summary>コンストラクタ 特性</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Tokusei( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Tokuseitable[id];
		}

		/// <summary>特性名リストを更新する</summary>
		private void UpdateNamelist()
		{
			var namelist = this.N14pkb.Tokuseilist.Namelist;

			var oldname = namelist[this.Address];
			if ( namelist[this.Address] == this.Name ) { return; }

			namelist[this.Address] = this.Name;
			// 成長型ビューカラムヘッダ名変更
			var columns = this.N14pkb.MainWindowInterface.DataGrids[(int)Enums.TabKind.成長型].Columns;
			for ( var i = 0; i < columns.Count; i++ )
			{
				if ( (string)( columns[i].Header ) == oldname )
				{
					columns[i].Header = this.Name;
					// ビューリフレッシュフラグ
					this.N14pkb.View.Flags[(int)Enums.TabKind.成長型].NeedsRefresh = true;
					break;
				}
			}

			// ビューリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.特性].NeedsRefresh = true;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			var record = (byte[])this.Data.GetRecord().Clone();

			// 下位特性ポインタ・反特性ポインタをIDに変換して埋め込む
			BitConverter.GetBytes( this.N14pkb.Tokuseilist.GetIDByAddress(this.PtrKaiTokusei) ).CopyTo( record, 0xA0 );
			BitConverter.GetBytes( this.N14pkb.Tokuseilist.GetIDByAddress(this.PtrHanTokusei) ).CopyTo( record, 0xA4 );

			return record;
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			var record = (byte[])buff.Clone();
			var id = 0;
			// 先頭4バイトの MagicNumber はゲーム起動毎に変わるため、現在の値を使用する
			BitConverter.GetBytes( this.Data.MagicNumber ).CopyTo( record, 0x00 );

			// 下位特性ID・反特性IDをポインタに変換して埋め込む
			id = BitConverter.ToInt32( record, 0xA0 );
			BitConverter.GetBytes( this.N14pkb.Tokuseilist.GetAddressByID( id ) ).CopyTo( record, 0xA0 );
			id = BitConverter.ToInt32( record, 0xA4 );
			BitConverter.GetBytes( this.N14pkb.Tokuseilist.GetAddressByID( id ) ).CopyTo( record, 0xA4 );

			this.Data.SetRecord( record );
			this.Write();

			// 特性名リストを更新する
			this.UpdateNamelist();
			// ビューリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.特性].NeedsRefresh = true;
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Tokuseitable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Tokuseilist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:特性:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
