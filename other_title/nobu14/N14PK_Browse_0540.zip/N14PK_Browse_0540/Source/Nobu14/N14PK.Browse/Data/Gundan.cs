﻿// Gundan.cs

using System;
using System.ComponentModel;

using N14PKBrowse.HelperClass;
using N14PKLibrary;
using N14PKLibrary.Data;
using N14PKBrowse.List;

namespace N14PKBrowse.Data
{
	/// <summary>軍団ビューで使用するデータクラス</summary>
	public class Gundan : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の軍団データ</summary>
		public GundanData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID							// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address						// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex				// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}

		public string Name						// 名称
		{
			get { return this.Seiryokuname + ":" + this.Gundanchouname; }
			set { throw new NotSupportedException(); }
		}
		public string Seiryokuname				// 勢力
		{
			get { return this.N14pkb.Seiryokulist.GetNameByAddress( this.Data.PtrSeiryoku ); }
			set
			{
				if ( value == this.Seiryokuname ) { return; }
				this.Data.PtrSeiryoku = this.N14pkb.Seiryokulist.GetAddressByName( value );
				this.Write();
				this.PropertyChanged.Raise( () => this.Seiryokuname );
				this.UpdateNamelist();
			}
		}
		public string Gundanchouname			// 軍団長名
		{
			get { return this.N14pkb.Busyoulist.GetNameByAddress( this.Data.PtrGundanchou ); }
		}
		public uint PtrGundanchou				// 軍団長ポインタ
		{
			get { return this.Data.PtrGundanchou; }
			set
			{
				if ( value == this.PtrGundanchou ) { return; }
				this.Data.PtrGundanchou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrGundanchou );
				this.PropertyChanged.Raise( () => this.Gundanchouname );
				this.UpdateNamelist();
			}
		}
		public uint PtrHoushin					// 方針 設定しても毎月リセットされる
		{
			get { return this.Data.PtrHoushin; }
			set
			{
				if ( value == this.PtrHoushin ) { return; }
				this.Data.PtrHoushin = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrHoushin );
			}
		}
		public int Kinsen						// 金銭
		{
			get { return this.Data.Kinsen; }
			set
			{
				if ( value == this.Kinsen ) { return; }
				this.Data.Kinsen = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Kinsen );
			}
		}
		public int Hyourou						// 兵糧
		{
			get { return this.Data.Hyourou; }
			set
			{
				if ( value == this.Hyourou ) { return; }
				this.Data.Hyourou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Hyourou );
			}
		}
		public int Teppou						// 鉄砲
		{
			get { return this.Data.Teppou; }
			set
			{
				if ( value == this.Teppou ) { return; }
				this.Data.Teppou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Teppou );
			}
		}
		public int Gunba						// 軍馬
		{
			get { return this.Data.Gunba; }
			set
			{
				if ( value == this.Gunba ) { return; }
				this.Data.Gunba = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Gunba );
			}
		}
		public int Rouryoku						// 労力
		{
			get { return this.Data.Rouryoku; }
			set
			{
				if ( value == this.Rouryoku ) { return; }
				this.Data.Rouryoku = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Rouryoku );
			}
		}
		public int h58_4						// 不明値
		{
			get { return this.Data.h58_4; }
			set
			{
				if ( value == this.h58_4 ) { return; }
				this.Data.h58_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h58_4 );
			}
		}
		public string Honkyoname				// 本拠(直轄範囲外軍団とCOM軍団はなし )
		{
			get { return this.N14pkb.Shirolist.GetNameByAddress( this.Data.PtrHonkyo ); }
		}
		public uint PtrHonkyo					// 本拠ポインタ
		{
			get { return this.Data.PtrHonkyo; }
			set
			{
				if ( value == this.PtrHonkyo ) { return; }
				this.Data.PtrHonkyo = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrHonkyo );
				this.PropertyChanged.Raise( () => this.Honkyoname );
			}
		}

		public int CntShihaiShiroList			// カウンタ
		{
			get { return this.Data.CntShihaiShiroList; }
			set
			{
				if ( value == this.CntShihaiShiroList ) { return; }
				this.Data.CntShihaiShiroList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntShihaiShiroList );
			}
		}
		public PointerlistType2 ShihaiShiroList	// 支配城リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrShihaiShiroList, DataKind.城 ); }
		}
		public int CntShiroList1				// カウンタ
		{
			get { return this.Data.CntShiroList1; }
			set
			{
				if ( value == this.CntShiroList1 ) { return; }
				this.Data.CntShiroList1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntShiroList1 );
			}
		}
		public PointerlistType2 ShiroList1		// 城リスト1
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrShiroList1, DataKind.城 ); }
		}
		public int CntShiroList2				// カウンタ
		{
			get { return this.Data.CntShiroList2; }
			set
			{
				if ( value == this.CntShiroList2 ) { return; }
				this.Data.CntShiroList2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntShiroList2 );
			}
		}
		public PointerlistType2 ShiroList2		// 城リスト2
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrShiroList2, DataKind.城 ); }
		}
		/// <summary>軍団長</summary>
		public Busyou Gundanchou
		{
			get { return this.N14pkb.Busyoulist[this.Data.PtrGundanchou]; }
		}

		/// <summary>軍団が所属する勢力</summary>
		public Seiryoku Seiryoku
		{
			get { return this.N14pkb.Seiryokulist[this.Data.PtrSeiryoku]; }
		}

		/// <summary>軍団の本拠</summary>
		public Shiro Honkyo
		{
			get { return this.N14pkb.Shirolist[this.PtrHonkyo]; }
		}

		/// <summary>直轄軍団フラグ</summary>
		public bool IsChokkatsu
		{
			get { return this.PtrGundanchou == this.Seiryoku.PtrTousyu; }
		}

		/// <summary>委任軍団フラグ</summary>
		public bool IsInin
		{
			get
			{
				return ( ( this.PtrGundanchou != this.Seiryoku.PtrTousyu )
						&& ( this.PtrHonkyo != 0 ) );
			}
		}

		/// <summary>配下軍団フラグ(直轄範囲外の非委任軍団)</summary>
		public bool IsHaika
		{
			get
			{
				return ( ( this.PtrGundanchou != this.Seiryoku.PtrTousyu )
						&& ( this.PtrHonkyo == 0 ) );
			}
		}


		// ソートID
		public int SortID
		{
			get
			{
				var seiryoku = this.N14pkb.Seiryokulist[this.Data.PtrSeiryoku];
				var index = ( seiryoku != null ) ? seiryoku.GundanList.GetIndexByTargetDataAddress( this.Data.Address ) : -1;
				return ( index != -1 ) ? seiryoku.SortID + index : -1;
			}
		}


		/// <summary>コンストラクタ 軍団</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Gundan( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Gundantable[id];
		}

		/// <summary>軍団名リストを更新する</summary>
		public void UpdateNamelist()
		{
			var list = this.N14pkb.Gundanlist.Namelist;
			list[this.Address] = this.Name;

			// ビューリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.武将].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.城].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.区画].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.勢力].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.部隊].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.建物].NeedsRefresh = true;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			throw new NotSupportedException();
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			throw new NotSupportedException();
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Gundantable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Gundanlist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:軍団:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
