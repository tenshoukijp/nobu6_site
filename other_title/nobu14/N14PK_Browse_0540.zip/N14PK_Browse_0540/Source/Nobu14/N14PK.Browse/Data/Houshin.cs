﻿// Houshin.cs

using System;
using System.ComponentModel;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>方針ビューで使用するデータクラス</summary>
	public class Houshin : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の方針データ</summary>
		public HoushinData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID				// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address			// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex	// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}

		public string Name			// 名称(シフトJIS nullターミネイト)
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Name );
				this.UpdateNamelist();
			}
		}
		public byte h11			// 11h 1バイト
		{
			get { return this.Data.h11; }
			set
			{
				if ( value == this.h11 ) { return; }
				this.Data.h11 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11 );
			}
		}
		public byte h12			// 12h 1バイト
		{
			get { return this.Data.h12; }
			set
			{
				if ( value == this.h12 ) { return; }
				this.Data.h12 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h12 );
			}
		}
		public byte h13			// 13h 1バイト
		{
			get { return this.Data.h13; }
			set
			{
				if ( value == this.h13 ) { return; }
				this.Data.h13 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h13 );
			}
		}
		public byte h14			// 14h 1バイト
		{
			get { return this.Data.h14; }
			set
			{
				if ( value == this.h14 ) { return; }
				this.Data.h14 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h14 );
			}
		}
		public byte h15			// 15h 1バイト
		{
			get { return this.Data.h15; }
			set
			{
				if ( value == this.h15 ) { return; }
				this.Data.h15 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h15 );
			}
		}
		public byte h16			// 16h 1バイト
		{
			get { return this.Data.h16; }
			set
			{
				if ( value == this.h16 ) { return; }
				this.Data.h16 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h16 );
			}
		}
		public byte h17			// 17h 1バイト
		{
			get { return this.Data.h17; }
			set
			{
				if ( value == this.h17 ) { return; }
				this.Data.h17 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h17 );
			}
		}
		public byte h18			// 18h 1バイト
		{
			get { return this.Data.h18; }
			set
			{
				if ( value == this.h18 ) { return; }
				this.Data.h18 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h18 );
			}
		}
		public byte h19			// 19h 1バイト
		{
			get { return this.Data.h19; }
			set
			{
				if ( value == this.h19 ) { return; }
				this.Data.h19 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h19 );
			}
		}
		public byte h1A			// 1Ah 1バイト
		{
			get { return this.Data.h1A; }
			set
			{
				if ( value == this.h1A ) { return; }
				this.Data.h1A = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h1A );
			}
		}
		public byte h1B			// 1Bh 1バイト
		{
			get { return this.Data.h1B; }
			set
			{
				if ( value == this.h1B ) { return; }
				this.Data.h1B = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h1B );
			}
		}
		public byte h1C			// 1Ch 1バイト
		{
			get { return this.Data.h1C; }
			set
			{
				if ( value == this.h1C ) { return; }
				this.Data.h1C = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h1C );
			}
		}
		public byte h1D			// 1Dh 1バイト
		{
			get { return this.Data.h1D; }
			set
			{
				if ( value == this.h1D ) { return; }
				this.Data.h1D = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h1D );
			}
		}
		public byte h1E			// 1Eh 1バイト
		{
			get { return this.Data.h1E; }
			set
			{
				if ( value == this.h1E ) { return; }
				this.Data.h1E = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h1E );
			}
		}
		public byte h1F			// 1Fh 1バイト
		{
			get { return this.Data.h1F; }
			set
			{
				if ( value == this.h1F ) { return; }
				this.Data.h1F = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h1F );
			}
		}


		/// <summary>コンストラクタ 方針</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Houshin( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Houshintable[id];
		}

		/// <summary>方針名リストを更新する</summary>
		private void UpdateNamelist()
		{
			var list = this.N14pkb.Houshinlist.Namelist;
			if ( list[this.Address] == this.Name ) { return; }

			list[this.Address] = this.Name;
			// ビューリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.軍団].NeedsRefresh = true;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			var record = (byte[])this.Data.GetRecord().Clone();
			return record;
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			var record = (byte[])buff.Clone();
			// 先頭4バイトの MagicNumber はゲーム起動毎に変わるため、現在の値を使用する
			BitConverter.GetBytes( this.Data.MagicNumber ).CopyTo( record, 0x00 );

			this.Data.SetRecord( record );
			this.Write();

			this.UpdateNamelist();

			// ビューリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.方針].NeedsRefresh = true;
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Houshintable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Houshinlist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:方針:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
