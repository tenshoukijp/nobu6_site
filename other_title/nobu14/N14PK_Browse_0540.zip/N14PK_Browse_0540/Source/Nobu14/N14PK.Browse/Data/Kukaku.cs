﻿// Kukaku.cs

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>区画ビューで使用するデータクラス</summary>
	public class Kukaku : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>区画が属する城データ</summary>
		private Shiro _shiro;

		/// <summary>区画が属する城データ</summary>
		public Shiro Shiro { get { return this._shiro; } }

		/// <summary>未加工の区画データ</summary>
		public KukakuData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID				// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address			// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex	// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}

		public string Name			// 名称
		{
			get { return this._shiro.Name + ":" + ( this.Data.KukakuID + 1 ).ToString( "D2" ); }
			set { throw new NotSupportedException(); }
		}
		public string Shironame		// 城名
		{
			get { return this._shiro.Name; }
		}
		public int KukakuID			// 区画ID
		{
			get { return this.Data.KukakuID + 1; }
		}
		public ushort h012_2						// 012h 2バイト
		{
			get { return this.Data.h012_2; }
			set
			{
				if ( value == this.h012_2 ) { return; }
				this.Data.h012_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h012_2 );
			}
		}
		public ushort h014_2						// 014h 2バイト
		{
			get { return this.Data.h014_2; }
			set
			{
				if ( value == this.h014_2 ) { return; }
				this.Data.h014_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h014_2 );
			}
		}
		public ushort h016_2						// 016h 2バイト
		{
			get { return this.Data.h016_2; }
			set
			{
				if ( value == this.h016_2 ) { return; }
				this.Data.h016_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h016_2 );
			}
		}
		public ushort h018_2						// 018h 2バイト
		{
			get { return this.Data.h018_2; }
			set
			{
				if ( value == this.h018_2 ) { return; }
				this.Data.h018_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h018_2 );
			}
		}

		public int ShisetsuID						// 施設
		{
			get { return this.Data.ShisetsuID; }
			set
			{
				if ( value == this.ShisetsuID ) { return; }
				this.Data.ShisetsuID = (sbyte)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ShisetsuID );

				Funcs.CheckKukakuHosei( this.N14pkb, this );
			}
		}
		public int KensetsuchuuShisetsuID			// 建設中施設
		{
			get { return this.Data.KensetsuchuuShisetsuID; }
			set
			{
				if ( value == this.KensetsuchuuShisetsuID ) { return; }
				this.Data.KensetsuchuuShisetsuID = (sbyte)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KensetsuchuuShisetsuID );
			}
		}
		public sbyte h01C							// 01Ch 1バイト
		{
			get { return this.Data.h01C; }
			set
			{
				if ( value == this.h01C ) { return; }
				this.Data.h01C = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h01C );
			}
		}
		public byte h01D							// 01Dh 1バイト
		{
			get { return this.Data.h01D; }
			set
			{
				if ( value == this.h01D ) { return; }
				this.Data.h01D = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h01D );
			}
		}
		public ushort PosX							// キャプション？ X位置
		{
			get { return this.Data.PosX; }
			set
			{
				if ( value == this.PosX ) { return; }
				this.Data.PosX = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PosX );
			}
		}
		public ushort PosY							// キャプション？ Y位置
		{
			get { return this.Data.PosY; }
			set
			{
				if ( value == this.PosY ) { return; }
				this.Data.PosY = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PosY );
			}
		}

		public short KokudakaMax					// 石高最大
		{
			get { return this.Data.KokudakaMax; }
			set
			{
				if ( value == this.KokudakaMax ) { return; }
				var addval = value - this.KokudakaMax;

				this.Data.KokudakaMax = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KokudakaMax );

				this.Shiro.KokudakaMax += (short)addval;
			}
		}
		public short SyougyouMax					// 商業最大
		{
			get { return this.Data.SyougyouMax; }
			set
			{
				if ( value == this.SyougyouMax ) { return; }
				var addval = value - this.SyougyouMax;

				this.Data.SyougyouMax = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SyougyouMax );

				this.Shiro.SyougyouMax += (short)addval;
			}
		}
		public short HeisyaMax						// 兵舎最大
		{
			get { return this.Data.HeisyaMax; }
			set
			{
				if ( value == this.HeisyaMax ) { return; }
				var addval = value - this.HeisyaMax;

				this.Data.HeisyaMax = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HeisyaMax );

				this.Shiro.HeisyaMax += (short)addval;
			}
		}
		public short h130_2							// 130h 2バイト
		{
			get { return this.Data.h130_2; }
			set
			{
				if ( value == this.h130_2 ) { return; }
				this.Data.h130_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h130_2 );
			}
		 }
		public short KukakuBase						// 区画基本値
		{
			get { return this.Data.KukakuBase; }
			set
			{
				if ( value == this.KukakuBase ) { return; }
				this.Data.KukakuBase = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KukakuBase );

				Funcs.CheckKukakuMaxValue( this.N14pkb, this );
			}
		}

		public bool Rinsetsu1						// 134~135h bit0 区画1との隣接フラグ
		{
			get { return this.Data.Rinsetsu1; }
			set
			{
				if ( value == this.Rinsetsu1 ) { return; }
				else if ( this.KukakuID == 1 )
				{
					this.PropertyChanged.Raise( () => this.Rinsetsu1 );
					return;
				}
				this.Data.Rinsetsu1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Rinsetsu1 );
				Funcs.CheckRinsetsuKukaku( this.N14pkb, this, value, 1 );
			}
		}
		public bool Rinsetsu2						// 134~135h bit1 区画2との隣接フラグ
		{
			get { return this.Data.Rinsetsu2; }
			set
			{
				if ( value == this.Rinsetsu2 ) { return; }
				else if ( this.KukakuID == 2 )
				{
					this.PropertyChanged.Raise( () => this.Rinsetsu2 );
					return;
				}
				this.Data.Rinsetsu2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Rinsetsu2 );
				Funcs.CheckRinsetsuKukaku( this.N14pkb, this, value, 2 );
			}
		}
		public bool Rinsetsu3						// 134~135h bit2 区画3との隣接フラグ
		{
			get { return this.Data.Rinsetsu3; }
			set
			{
				if ( value == this.Rinsetsu3 ) { return; }
				else if ( this.KukakuID == 3 )
				{
					this.PropertyChanged.Raise( () => this.Rinsetsu3 );
					return;
				}
				this.Data.Rinsetsu3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Rinsetsu3 );
				Funcs.CheckRinsetsuKukaku( this.N14pkb, this, value, 3 );
			}
		}
		public bool Rinsetsu4						// 134~135h bit3 区画4との隣接フラグ
		{
			get { return this.Data.Rinsetsu4; }
			set
			{
				if ( value == this.Rinsetsu4 ) { return; }
				else if ( this.KukakuID == 4 )
				{
					this.PropertyChanged.Raise( () => this.Rinsetsu4 );
					return;
				}
				this.Data.Rinsetsu4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Rinsetsu4 );
				Funcs.CheckRinsetsuKukaku( this.N14pkb, this, value, 4 );
			}
		}
		public bool Rinsetsu5						// 134~135h bit4 区画5との隣接フラグ
		{
			get { return this.Data.Rinsetsu5; }
			set
			{
				if ( value == this.Rinsetsu5 ) { return; }
				else if ( this.KukakuID == 5 )
				{
					this.PropertyChanged.Raise( () => this.Rinsetsu5 );
					return;
				}
				this.Data.Rinsetsu5 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Rinsetsu5 );
				Funcs.CheckRinsetsuKukaku( this.N14pkb, this, value, 5 );
			}
		}
		public bool Rinsetsu6						// 134~135h bit5 区画6との隣接フラグ
		{
			get { return this.Data.Rinsetsu6; }
			set
			{
				if ( value == this.Rinsetsu6 ) { return; }
				else if ( this.KukakuID == 6 )
				{
					this.PropertyChanged.Raise( () => this.Rinsetsu6 );
					return;
				}
				this.Data.Rinsetsu6 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Rinsetsu6 );
				Funcs.CheckRinsetsuKukaku( this.N14pkb, this, value, 6 );
			}
		}
		public bool Rinsetsu7						// 134~135h bit6 区画7との隣接フラグ
		{
			get { return this.Data.Rinsetsu7; }
			set
			{
				if ( value == this.Rinsetsu7 ) { return; }
				else if ( this.KukakuID == 7 )
				{
					this.PropertyChanged.Raise( () => this.Rinsetsu7 );
					return;
				}
				this.Data.Rinsetsu7 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Rinsetsu7 );
				Funcs.CheckRinsetsuKukaku( this.N14pkb, this, value, 7 );
			}
		}
		public bool Rinsetsu8						// 134~135h bit7 区画8との隣接フラグ
		{
			get { return this.Data.Rinsetsu8; }
			set
			{
				if ( value == this.Rinsetsu8 ) { return; }
				else if ( this.KukakuID == 8 )
				{
					this.PropertyChanged.Raise( () => this.Rinsetsu8 );
					return;
				}
				this.Data.Rinsetsu8 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Rinsetsu8 );
				Funcs.CheckRinsetsuKukaku( this.N14pkb, this, value, 8 );
			}
		}
		public bool Rinsetsu9						// 134~135h bit8 区画9との隣接フラグ
		{
			get { return this.Data.Rinsetsu9; }
			set
			{
				if ( value == this.Rinsetsu9 ) { return; }
				else if ( this.KukakuID == 9 )
				{
					this.PropertyChanged.Raise( () => this.Rinsetsu9 );
					return;
				}
				this.Data.Rinsetsu9 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Rinsetsu9 );
				Funcs.CheckRinsetsuKukaku( this.N14pkb, this, value, 9 );
			}
		}
		public bool Rinsetsu10						// 134~135h bit9 区画10との隣接フラグ
		{
			get { return this.Data.Rinsetsu10; }
			set
			{
				if ( value == this.Rinsetsu10 ) { return; }
				else if ( this.KukakuID == 10 )
				{
					this.PropertyChanged.Raise( () => this.Rinsetsu10 );
					return;
				}
				this.Data.Rinsetsu10 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Rinsetsu10 );
				Funcs.CheckRinsetsuKukaku( this.N14pkb, this, value, 10 );
			}
		}
		//public bool[] Rinsetsulist					// 参照用(要素個別のsetを拾えないので)
		//{
		//	get
		//	{
		//		this.Data.rin
		//		var bools = new bool[10];
		//		bools[0] = this.Rinsetsu1;
		//		bools[1] = this.Rinsetsu2;
		//		bools[2] = this.Rinsetsu3;
		//		bools[3] = this.Rinsetsu4;
		//		bools[4] = this.Rinsetsu5;
		//		bools[5] = this.Rinsetsu6;
		//		bools[6] = this.Rinsetsu7;
		//		bools[7] = this.Rinsetsu8;
		//		bools[8] = this.Rinsetsu9;
		//		bools[9] = this.Rinsetsu10;
		//		return bools;
		//	}
		//}
		public short h136_2							// 136h 2バイト
		{
			get { return this.Data.h136_2; }
			set
			{
				if ( value == this.h136_2 ) { return; }
				this.Data.h136_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h136_2 );
			}
		}

		public short h138_2							// 100になると建設可能になる？
		{
			get { return this.Data.h138_2; }
			set
			{
				if ( value == this.h138_2 ) { return; }
				this.Data.h138_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h138_2 );
			}
		}
		public int ShigenID							// 資源
		{
			get { return this.Data.ShigenID; }
			set
			{
				if ( value == this.ShigenID ) { return; }
				this.Data.ShigenID = (short)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ShigenID );
			}
		}
		public short h13C_2							// 13Ch 2バイト
		{
			get { return this.Data.h13C_2; }
			set
			{
				if ( value == this.h13C_2 ) { return; }
				this.Data.h13C_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h13C_2 );
			}
		}
		public ushort PosX2							// 何かのX位置
		{
			get { return this.Data.PosX2; }
			set
			{
				if ( value == this.PosX2 ) { return; }
				this.Data.PosX2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PosX2 );
			}
		}
		public ushort PosY2							// 何かのY位置
		{
			get { return this.Data.PosY2; }
			set
			{
				if ( value == this.PosY2 ) { return; }
				this.Data.PosY2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PosY2 );
			}
		}
		public short h142_2							// 142h 2バイト
		{
			get { return this.Data.h142_2; }
			set
			{
				if ( value == this.h142_2 ) { return; }
				this.Data.h142_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h142_2 );
			}
		}
		public short h144_2							// 144h 2バイト
		{
			get { return this.Data.h144_2; }
			set
			{
				if ( value == this.h144_2 ) { return; }
				this.Data.h144_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h144_2 );
			}
		}
		public short h146_2							// 146h 2バイト
		{
			get { return this.Data.h146_2; }
			set
			{
				if ( value == this.h146_2 ) { return; }
				this.Data.h146_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h146_2 );
			}
		}
		// 148~14Bh の4バイトは32ビットデータとして使用
		public int KokudakaRankBase					// 148h bit0~4 5ビット 石高ランク基本値 0~17
		{
			get { return this.Data.KokudakaRankBase; }
			set
			{
				if ( value == this.KokudakaRankBase ) { return; }
				this.Data.KokudakaRankBase = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KokudakaRankBase );

				Funcs.CheckKukakuMaxValue( this.N14pkb, this );
			}
		}
		public int SyougyouRankBase					// 148h bit5~9 5ビット 商業ランク基本値 0~17
		{
			get { return this.Data.SyougyouRankBase; }
			set
			{
				if ( value == this.SyougyouRankBase ) { return; }
				this.Data.SyougyouRankBase = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SyougyouRankBase );

				Funcs.CheckKukakuMaxValue( this.N14pkb, this );
			}
		}
		public int HeisyaRankBase					// 148h bit10~14 5ビッ 兵舎ランク基本値 0~17
		{
			get { return this.Data.HeisyaRankBase; }
			set
			{
				if ( value == this.HeisyaRankBase ) { return; }
				this.Data.HeisyaRankBase = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HeisyaRankBase );

				Funcs.CheckKukakuMaxValue( this.N14pkb, this );
			}
		}
		public int KokudakaRankHosei				// 148h bit15~19 5ビット 石高ランク補正値 0~17
		{
			get { return this.Data.KokudakaRankHosei; }
			set
			{
				if ( value == this.KokudakaRankHosei ) { return; }
				this.Data.KokudakaRankHosei = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KokudakaRankHosei );

				Funcs.CheckKukakuMaxValue( this.N14pkb, this );
			}
		}
		public int SyougyouRankHosei				// 148h bit20~24 5ビット 商業ランク補正値 0~17
		{
			get { return this.Data.SyougyouRankHosei; }
			set
			{
				if ( value == this.SyougyouRankHosei ) { return; }
				this.Data.SyougyouRankHosei = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SyougyouRankHosei );

				Funcs.CheckKukakuMaxValue( this.N14pkb, this );
			}
		}
		public int HeisyaRankHosei					// 148h bit25~29 5ビット 兵舎ランク補正値 0~17
		{
			get { return this.Data.HeisyaRankHosei; }
			set
			{
				if ( value == this.HeisyaRankHosei ) { return; }
				this.Data.HeisyaRankHosei = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HeisyaRankHosei );

				Funcs.CheckKukakuMaxValue( this.N14pkb, this );
			}
		}
		public bool h148_b30						// 148h bit30 有効な区画フラグ？
		{
			get { return this.Data.h148_b30; }
			set
			{
				if ( value == this.h148_b30 ) { return; }
				this.Data.h148_b30 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h148_b30 );
			}
		}
		public bool IsKakuchouzumi					// 148h bit31 拡張済みフラグ？
		{
			get { return this.Data.IsKakuchouzumi; }
			set
			{
				if ( value == this.IsKakuchouzumi ) { return; }
				this.Data.IsKakuchouzumi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.IsKakuchouzumi );
			}
		}

		// 軍団名
		public string Gundanname { get { return ( this.Gundan != null ) ? this.Gundan.Name : string.Empty; } }

		// 軍団
		public Gundan Gundan
		{
			get { return this._shiro.Gundan; }
		}
		// 勢力
		public Seiryoku Seiryoku
		{
			get { return this._shiro.Seiryoku; }
		}
		// 国
		public string Kuni { get { return this._shiro.Kuni; } }

		/// <summary>コンストラクタ 区画</summary>
		/// <param name="shiro">区画が属する城データ</param>
		/// <param name="kukakuID">区画ID</param>
		public Kukaku( Shiro Shiro, int kukakuID )
		{
			this._shiro = Shiro;
			this.N14pkb = Shiro.N14pkb;
			this.Data = Shiro.Data.Kukaku[kukakuID];
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			throw new NotSupportedException();
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			throw new NotSupportedException();
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Shirotable.Write( this._shiro.ID, this.Data.GetRecord() );
			this.N14pkb.Shirolist.CommitID = this._shiro.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:区画:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
