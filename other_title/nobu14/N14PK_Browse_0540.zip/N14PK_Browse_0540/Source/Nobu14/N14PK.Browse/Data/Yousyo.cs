﻿// Yousyo.cs

using System;
using System.ComponentModel;

using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>要所ビューで使用するデータクラス</summary>
	public class Yousyo : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の要所データ</summary>
		public YousyoData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID						// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address					// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex			// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}

		public string Name					// 名称
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Name );

				// 要所名を参照している街道タブの更新フラグ
				this.N14pkb.View.Flags[(int)Enums.TabKind.街道].NeedsRefresh = true;
			}
		}
		public string Yomi					// 読み
		{
			get { return this.Data.Yomi; }
			set
			{
				if ( value == this.Yomi ) { return; }
				this.Data.Yomi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Yomi );
			}
		}
		public string Chihou				// 地方
		{
			get { return this.N14pkb.Kunilist[this.Data.PtrKuni].Chihou; }
		}
		public string Kuni					// 国
		{
			get { return this.N14pkb.Kunilist.GetNameByAddress( this.Data.PtrKuni ); }
		}
		public uint PosX					// X位置
		{
			get { return this.Data.PosX; }
			set
			{
				if ( value == this.PosX ) { return; }
				this.Data.PosX = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PosX );
			}
		}
		public uint PosY 					// Y位置
		{
			get { return this.Data.PosY; }
			set
			{
				if ( value == this.PosY ) { return; }
				this.Data.PosY = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PosY );
			}
		}
		public string Kyoten				// 拠点
		{
			get
			{
				var name = Funcs.GetNameByAddress( this.N14pkb, this.Data.PtrKyoten );
				if ( this.Data.KyotenTypeID == (int)DataAddressKind.国人 )
				{
					// 城名は先頭に "*"/"  " が付加されているのでそれに合わせる
					name = "  " + name;
				}
				return name;
			}
		}
		public string KyotenSeiryoku		// 拠点勢力
		{
			get
			{
				return ( this.Shiro != null ) ? Shiro.Seiryoku.Name : string.Empty;
			}
		}
		public uint PtrJinSetsueiSeiryoku	// 陣設営勢力
		{
			get { return this.Data.PtrJinSetsueiSeiryoku; }
			set
			{
				if ( value == this.PtrJinSetsueiSeiryoku ) { return; }
				this.Data.PtrJinSetsueiSeiryoku = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrJinSetsueiSeiryoku );

				if ( this.PtrJinSetsueiSeiryoku == 0 && this.JinLevel != 0 )
				{
					// 陣設営勢力クリア時、陣レベルが設定されていればクリアする
					this.JinLevel = 0;
				}
				else if ( this.PtrJinSetsueiSeiryoku != 0 && this.JinLevel == 0 )
				{
					// 陣設営勢力設定時、陣レベルが0なら陣レベルを最大(2)にする
					this.JinLevel = 2;
				}
			}
		}
		public sbyte JinLevel				// 陣レベル 0:1～2:3
		{
			get { return this.Data.JinLevel; }
			set
			{
				if ( value == this.JinLevel ) { return; }
				this.Data.JinLevel = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.JinLevel );

				if ( this.JinLevel == 0 && this.PtrJinSetsueiSeiryoku != 0 )
				{
					// 陣レベルを0に変更時、陣設営勢力が設定されていればクリアする
					this.PtrJinSetsueiSeiryoku = 0;
				}
				else if ( this.JinLevel != 0 && this.PtrJinSetsueiSeiryoku == 0 )
				{
					// 陣レベルを0以外に変更時、陣設営勢力がないなら選択中勢力を陣設営勢力に設定する
					this.PtrJinSetsueiSeiryoku = this.N14pkb.View.SelectedSeiryokuAddress;
				}
			}
		}

		/// <summary>3Eh 1バイト フラグ系
		/// <para>第2ビットが1の場合、当該要所の城用地サイズに使用するParam値は "COST_N14PK_HONJOU(SHIJOU)_YAMAJIRO_MAX_LV0～3" のいずれか</para>
		/// <para>第2ビットが0の場合、当該要所の城用地サイズに使用するParam値は "COST_N14PK_HONJOU(SHIJOU)_HIRAJIRO_MAX_LV0～3" のいずれか</para></summary>
		public byte h3E
		{
			get { return this.Data.h3E; }
			set
			{
				if ( value == this.h3E ) { return; }
				this.Data.h3E = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h3E );

				// 変更があった場合、城タブの当該データの用地情報を更新する
				// 城データ全体を更新するので若干コストが大きい
				this.N14pkb.View.Flags[(int)Enums.TabKind.城].NeedsRefresh = true;
			}
		}


		public Shiro Shiro
		{
			get { return this.N14pkb.Shirolist[this.Data.PtrKyoten]; }
		}
		public uint PtrSeiryoku
		{
			get { return ( this.Shiro != null && this.Shiro.Gundan != null ) ? this.Shiro.Gundan.Data.PtrSeiryoku : 0; }
		}
		//public Seiryoku Seiryoku
		//{
		//	get { return ( this.Shiro != null ) ? this.Shiro.SyozokuSeiryoku : null; }
		//}
		// ソートID 要所データは全拠点(城・国人衆)が網羅されているので、要所リスト作成時にソートIDを振っておいて拠点ソート時に利用する
		//public int SortID { get; set; }
		private int _sortID;
		public int SortID
		{
			get
			{
				if ( this._sortID == -1 )
				{
					// ソートIDが未セットなら要所リスト全体に設定する
					this.N14pkb.Yousyolist.SetSortID();
				}
				return this._sortID;
			}
			set
			{
				this._sortID = value;
			}
		}

		/// <summary>コンストラクタ 要所</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Yousyo( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Yousyotable[id];
			this.SortID = -1;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			throw new NotSupportedException();
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			throw new NotSupportedException();
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Yousyotable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Yousyolist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:要所:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
