﻿// Shisetsu.cs

using System;
using System.ComponentModel;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>施設ビューで使用するデータクラス</summary>
	public class Shisetsu : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の施設データ</summary>
		public ShisetsuData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }

		public int ID						// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address					// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex			// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}
		public string Name					// 名称
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Name );
				this.UpdateNamelist();
			}
		}
		public string Yomi					// 読み
		{
			get { return this.Data.Yomi; }
			set
			{
				if ( value == this.Yomi ) { return; }
				this.Data.Yomi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Yomi );
			}
		}
		public string HelpText1				// ヘルプ1
		{
			get { return this.Data.HelpText1; }
			set
			{
				if ( value == this.HelpText1 ) { return; }
				this.Data.HelpText1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HelpText1 );
			}
		}
		public string HelpText2				// ヘルプ2
		{
			get { return this.Data.HelpText2; }
			set
			{
				if ( value == this.HelpText2 ) { return; }
				this.Data.HelpText2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HelpText2 );
			}
		}
		public string HelpText3				// ヘルプ3
		{
			get { return this.Data.HelpText3; }
			set
			{
				if ( value == this.HelpText3 ) { return; }
				this.Data.HelpText3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HelpText3 );
			}
		}
		public string HelpText4				// ヘルプ4 未使用
		{
			get { return this.Data.HelpText4; }
			set
			{
				if ( value == this.HelpText4 ) { return; }
				this.Data.HelpText4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HelpText4 );
			}
		}
		public ushort h0D2_2				// 0固定？
		{
			get { return this.Data.h0D2_2; }
			set
			{
				if ( value == this.h0D2_2 ) { return; }
				this.Data.h0D2_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0D2_2 );
			}
		}
		public string Ptr_0D4				// ポインタ
		{
			get { return this.Data.Ptr_0D4.ToString( "X8" ); }
			set
			{
				if ( value == this.Ptr_0D4 ) { return; }
				uint val;
				if ( UInt32.TryParse( value, System.Globalization.NumberStyles.HexNumber, null, out val ) )
				{
					this.Data.Ptr_0D4 = val;
					this.Write();
				}
				this.PropertyChanged.Raise( () => this.Ptr_0D4 );
			}
		}
		public string Ptr_0D8				// ポインタ
		{
			get { return this.Data.Ptr_0D8.ToString( "X8" ); }
			set
			{
				if ( value == this.Ptr_0D8 ) { return; }
				uint val;
				if ( UInt32.TryParse( value, System.Globalization.NumberStyles.HexNumber, null, out val ) )
				{
					this.Data.Ptr_0D8 = val;
					this.Write();
				}
				this.PropertyChanged.Raise( () => this.Ptr_0D8 );
			}
		}
		public string Ptr_0DC				// ポインタ
		{
			get { return this.Data.Ptr_0DC.ToString( "X8" ); }
			set
			{
				if ( value == this.Ptr_0DC ) { return; }
				uint val;
				if ( UInt32.TryParse( value, System.Globalization.NumberStyles.HexNumber, null, out val ) )
				{
					this.Data.Ptr_0DC = val;
					this.Write();
				}
				this.PropertyChanged.Raise( () => this.Ptr_0DC );
			}
		}
		public int h0E0_4					// 0固定？
		{
			get { return this.Data.h0E0_4; }
			set
			{
				if ( value == this.h0E0_4 ) { return; }
				this.Data.h0E0_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0E0_4 );
			}
		}
		public int h0E4_4					// 6固定？
		{
			get { return this.Data.h0E4_4; }
			set
			{
				if ( value == this.h0E4_4 ) { return; }
				this.Data.h0E4_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0E4_4 );
			}
		}
		public int h0E8_4					// h0EC_4 と同値？
		{
			get { return this.Data.h0E8_4; }
			set
			{
				if ( value == this.h0E8_4 ) { return; }
				this.Data.h0E8_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0E8_4 );
			}
		}
		public int h0EC_4					// h0E8_4 と同値？
		{
			get { return this.Data.h0EC_4; }
			set
			{
				if ( value == this.h0EC_4 ) { return; }
				this.Data.h0EC_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0EC_4 );
			}
		}
		public int ShisetsuTypeID			// 施設タイプ 0:城、1:資源、2:内政施設、3:未使用、4:未使用、5:国人衆、6:港・鉱山、7:神社仏閣、8:整備中
		{
			get { return this.Data.ShisetsuTypeID; }
			set
			{
				if ( value == this.ShisetsuTypeID ) { return; }
				this.Data.ShisetsuTypeID = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ShisetsuTypeID );
			}
		}
		public int h0F4_4					// 0F4h 4バイト
		{
			get { return this.Data.h0F4_4; }
			set
			{
				if ( value == this.h0F4_4 ) { return; }
				this.Data.h0F4_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0F4_4 );
			}
		}
		public int h0F8_4					// 0固定？
		{
			get { return this.Data.h0F8_4; }
			set
			{
				if ( value == this.h0F8_4 ) { return; }
				this.Data.h0F8_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0F8_4 );
			}
		}
		public int ZenteiShisetsuID			// 前提施設
		{
			get { return this.N14pkb.Shisetsulist.GetIDByAddress( this.Data.PtrZenteiShisetsu ); }
			set
			{
				if ( value == this.ZenteiShisetsuID ) { return; }
				this.Data.PtrZenteiShisetsu = this.N14pkb.Shisetsulist.GetAddressByID( value );
				this.Write();
				this.PropertyChanged.Raise( () => this.ZenteiShisetsuID );
			}
		}
		public short Taikyuu				// 耐久
		{
			get { return this.Data.Taikyuu; }
			set
			{
				if ( value == this.Taikyuu ) { return; }
				this.Data.Taikyuu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Taikyuu );
			}
		}
		public short Hiyou					// 費用
		{
			get { return this.Data.Hiyou; }
			set
			{
				if ( value == this.Hiyou ) { return; }
				this.Data.Hiyou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Hiyou );
			}
		}
		public short h104_2					// 0固定？
		{
			get { return this.Data.h104_2; }
			set
			{
				if ( value == this.h104_2 ) { return; }
				this.Data.h104_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h104_2 );
			}
		}
		public short h106_2					// 106h 2バイト
		{
			get { return this.Data.h106_2; }
			set
			{
				if ( value == this.h106_2 ) { return; }
				this.Data.h106_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h106_2 );
			}
		}
		public short h108_2					// h111 と同値？
		{
			get { return this.Data.h108_2; }
			set
			{
				if ( value == this.h108_2 ) { return; }
				this.Data.h108_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h108_2 );
			}
		}
		public int HitsuyouShigenID			// 必要資源(施設)
		{
			get { return this.Data.HitsuyouShigenID; }
			set
			{
				if ( value == this.HitsuyouShigenID ) { return; }
				this.Data.HitsuyouShigenID = (short)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HitsuyouShigenID );
			}
		}
		public byte UpRankNougyou			// 農業上昇ランク
		{
			get { return this.Data.UpRankNougyou; }
			set
			{
				if ( value == this.UpRankNougyou ) { return; }
				this.Data.UpRankNougyou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.UpRankNougyou );
			}
		}
		public byte UpRankSyougyou			// 商業上昇ランク
		{
			get { return this.Data.UpRankSyougyou; }
			set
			{
				if ( value == this.UpRankSyougyou ) { return; }
				this.Data.UpRankSyougyou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.UpRankSyougyou );
			}
		}
		public byte UpRankHeisya			// 兵舎上昇ランク
		{
			get { return this.Data.UpRankHeisya; }
			set
			{
				if ( value == this.UpRankHeisya ) { return; }
				this.Data.UpRankHeisya = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.UpRankHeisya );
			}
		}
		public byte Jinkou1					// 人口関連1
		{
			get { return this.Data.Jinkou1; }
			set
			{
				if ( value == this.Jinkou1 ) { return; }
				this.Data.Jinkou1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Jinkou1 );
			}
		}
		public byte h110					// 110h 1バイト
		{
			get { return this.Data.h110; }
			set
			{
				if ( value == this.h110 ) { return; }
				this.Data.h110 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h110 );
			}
		}
		public byte h111					// h108_2 と同値？
		{
			get { return this.Data.h111; }
			set
			{
				if ( value == this.h111 ) { return; }
				this.Data.h111 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h111 );
			}
		}
		public byte UpRankNougyouRinsetsu	// 隣接農業上昇ランク
		{
			get { return this.Data.UpRankNougyouRinsetsu; }
			set
			{
				if ( value == this.UpRankNougyouRinsetsu ) { return; }
				this.Data.UpRankNougyouRinsetsu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.UpRankNougyouRinsetsu );
			}
		}
		public byte UpRankSyougyouRinsetsu	// 隣接商業上昇ランク
		{
			get { return this.Data.UpRankSyougyouRinsetsu; }
			set
			{
				if ( value == this.UpRankSyougyouRinsetsu ) { return; }
				this.Data.UpRankSyougyouRinsetsu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.UpRankSyougyouRinsetsu );
			}
		}
		public byte UpRankHeisyaRinsetsu	// 隣接兵舎上昇ランク
		{
			get { return this.Data.UpRankHeisyaRinsetsu; }
			set
			{
				if ( value == this.UpRankHeisyaRinsetsu ) { return; }
				this.Data.UpRankHeisyaRinsetsu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.UpRankHeisyaRinsetsu );
			}
		}
		public sbyte Souzousei				// 創造性
		{
			get { return this.Data.Souzousei; }
			set
			{
				if ( value == this.Souzousei ) { return; }
				this.Data.Souzousei = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Souzousei );
			}
		}
		public byte h116					// 116h 1バイト
		{
			get { return this.Data.h116; }
			set
			{
				if ( value == this.h116 ) { return; }
				this.Data.h116 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h116 );
			}
		}
		public byte Jinkou2					// 人口関連2
		{
			get { return this.Data.Jinkou2; }
			set
			{
				if ( value == this.Jinkou2 ) { return; }
				this.Data.Jinkou2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Jinkou2 );
			}
		}
		public byte h118					// 118h 1バイト
		{
			get { return this.Data.h118; }
			set
			{
				if ( value == this.h118 ) { return; }
				this.Data.h118 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h118 );
			}
		}
		public byte ShisetsuLV				// 施設レベル
		{
			get { return this.Data.ShisetsuLV; }
			set
			{
				if ( value == this.ShisetsuLV ) { return; }
				this.Data.ShisetsuLV = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ShisetsuLV );
			}
		}
		public byte h11A					// 11Ah 1バイト
		{
			get { return this.Data.h11A; }
			set
			{
				if ( value == this.h11A ) { return; }
				this.Data.h11A = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11A );
			}
		}
		public byte h11B					// 11Bh 1バイト
		{
			get { return this.Data.h11B; }
			set
			{
				if ( value == this.h11B ) { return; }
				this.Data.h11B = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11B );
			}
		}
		public byte h11C					// 11Ch 1バイト
		{
			get { return this.Data.h11C; }
			set
			{
				if ( value == this.h11C ) { return; }
				this.Data.h11C = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11C );
			}
		}
		public sbyte h11D					// 11Dh 1バイト
		{
			get { return this.Data.h11D; }
			set
			{
				if ( value == this.h11D ) { return; }
				this.Data.h11D = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11D );
			}
		}
		// 11Eh の1バイトはビットフラグとして扱う
		public bool h11E_b00				// 11Eh bit0
		{
			get { return this.Data.h11E_b00; }
			set
			{
				if ( value == this.h11E_b00 ) { return; }
				this.Data.h11E_b00 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11E_b00 );
			}
		}
		public bool IsNougyouKukaku			// 11Eh bit1 区画タイプ農業
		{
			get { return this.Data.IsNougyouKukaku; }
			set
			{
				if ( value == this.IsNougyouKukaku ) { return; }
				this.Data.IsNougyouKukaku = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.IsNougyouKukaku );
			}
		}
		public bool IsSyougyouKukaku		// 11Eh bit2 区画タイプ商業
		{
			get { return this.Data.IsSyougyouKukaku; }
			set
			{
				if ( value == this.IsSyougyouKukaku ) { return; }
				this.Data.IsSyougyouKukaku = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.IsSyougyouKukaku );
			}
		}
		public bool IsHeisyaKukaku			// 11Eh bit3 区画タイプ兵舎
		{
			get { return this.Data.IsHeisyaKukaku; }
			set
			{
				if ( value == this.IsHeisyaKukaku ) { return; }
				this.Data.IsHeisyaKukaku = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.IsHeisyaKukaku );
			}
		}
		public bool h11E_b04				// 11Eh bit4
		{
			get { return this.Data.h11E_b04; }
			set
			{
				if ( value == this.h11E_b04 ) { return; }
				this.Data.h11E_b04 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11E_b04 );
			}
		}
		public bool h11E_b05				// 11Eh bit5 収入関連
		{
			get { return this.Data.h11E_b05; }
			set
			{
				if ( value == this.h11E_b05 ) { return; }
				this.Data.h11E_b05 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11E_b05 );
			}
		}
		public bool h11E_b06				// 11Eh bit6 未使用？
		{
			get { return this.Data.h11E_b06; }
			set
			{
				if ( value == this.h11E_b06 ) { return; }
				this.Data.h11E_b06 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11E_b06 );
			}
		}
		public bool h11E_b07				// 11Eh bit7 未使用？
		{
			get { return this.Data.h11E_b07; }
			set
			{
				if ( value == this.h11E_b07 ) { return; }
				this.Data.h11E_b07 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11E_b07 );
			}
		}

		public byte h11F					// ビットフラグ？
		{
			get { return this.Data.h11F; }
			set
			{
				if ( value == this.h11F ) { return; }
				this.Data.h11F = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h11F );
			}
		}


		/// <summary>コンストラクタ 施設</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Shisetsu( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Shisetsutable[id];
		}

		/// <summary>施設名リストを更新する</summary>
		private void UpdateNamelist()
		{
			var namelist = this.N14pkb.Shisetsulist.Namelist;
			if ( namelist[this.ID] == this.Name ) { return; }

			namelist[this.ID] = this.Name;

			// 施設名を参照しているビューのリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.施設].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.城].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.区画].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.建物].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.城郭].NeedsRefresh = true;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			var record = (byte[])this.Data.GetRecord().Clone();

			// 前提施設ポインタをIDに変換して埋め込む
			BitConverter.GetBytes( this.ZenteiShisetsuID ).CopyTo( record, 0x0FC );

			return record;
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			var record = (byte[])buff.Clone();
			var id = 0;
			// 先頭4バイトの MagicNumber はゲーム起動毎に変わるため、現在の値を使用する
			BitConverter.GetBytes( this.Data.MagicNumber ).CopyTo( record, 0x000 );
			// 未解析のポインタ3箇所も現在の値を使用する
			BitConverter.GetBytes( this.Data.Ptr_0D4 ).CopyTo( record, 0x0D4 );
			BitConverter.GetBytes( this.Data.Ptr_0D8 ).CopyTo( record, 0x0D8 );
			BitConverter.GetBytes( this.Data.Ptr_0DC ).CopyTo( record, 0x0DC );

			// 前提施設IDをポインタに変換して埋め込む
			id = BitConverter.ToInt32( record, 0x0FC );
			BitConverter.GetBytes( this.N14pkb.Shisetsulist.GetAddressByID( id ) ).CopyTo( record, 0x0FC );

			this.Data.SetRecord( record );
			this.Write();

			// 施設名リストを更新する
			this.UpdateNamelist();

			//// ビュー更新フラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.施設].NeedsRefresh = true;
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Shisetsutable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Shisetsulist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:施設:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
