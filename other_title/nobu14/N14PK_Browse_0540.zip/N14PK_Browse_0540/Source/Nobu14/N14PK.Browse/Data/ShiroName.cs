﻿// ShiroName.cs

using System;
using System.ComponentModel;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>城名ビューで使用するデータクラス</summary>
	public class ShiroName : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の城名データ</summary>
		public ShiroNameData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID					// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address				// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex		// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}
		public string Name				// 名称
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Name );
				this.SetRefreshFlag();
			}
		}

		public string Yomi				// 読み
		{
			get { return this.Data.Yomi; }
			set
			{
				if ( value == this.Yomi ) { return; }
				this.Data.Yomi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Yomi );
			}
		}


		/// <summary>コンストラクタ 城名</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public ShiroName( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.ShiroNametable[id];
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			var record = (byte[])this.Data.GetRecord().Clone();
			return record;
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			var record = (byte[])buff.Clone();
			// 先頭4バイトの MagicNumber はゲーム起動毎に変わるため、現在の値を使用する
			BitConverter.GetBytes( this.Data.MagicNumber ).CopyTo( record, 0x00 );

			this.Data.SetRecord( record );
			this.Write();

			// ビューリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.城名].NeedsRefresh = true;
			this.SetRefreshFlag();
		}

		/// <summary>データ変更によりリフレッシュが必要なビューのリフレッシュフラグをセット</summary>
		private void SetRefreshFlag()
		{
			this.N14pkb.View.Flags[(int)Enums.TabKind.武将].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.城].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.区画].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.勢力].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.軍団].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.部隊].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.建物].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.要所].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.街道].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.国].NeedsRefresh = true;
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.ShiroNametable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.ShiroNamelist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:城名:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
