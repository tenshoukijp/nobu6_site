﻿// Kuni.cs

using System;
using System.ComponentModel;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>国ビューで使用するデータクラス</summary>
	public class Kuni : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の国データ</summary>
		public KuniData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID							// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address						// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex				// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}
		public string Chihou					// 地方
		{
			get { return this.N14pkb.Chihoulist.GetNameByAddress( this.Data.PtrChihou ); }
		}
		public string Ptr_08					// ポインタ 飛んだ先に国ポインタが2つ入ってる？
		{
			get { return this.Data.Ptr_08.ToString( "X8" ); }
			set
			{
				if ( value == this.Ptr_08 ) { return; }
				uint val;
				if ( UInt32.TryParse( value, System.Globalization.NumberStyles.HexNumber, null, out val ) )
				{
					this.Data.Ptr_08 = val;
					this.Write();
				}
				this.PropertyChanged.Raise( () => this.Ptr_08 );
			}
		}
		public string Ptr_0C					// ポインタ Ptr_10 と同値？
		{
			get { return this.Data.Ptr_0C.ToString( "X8" ); }
			set
			{
				if ( value == this.Ptr_0C ) { return; }
				uint val;
				if ( UInt32.TryParse( value, System.Globalization.NumberStyles.HexNumber, null, out val ) )
				{
					this.Data.Ptr_0C = val;
					this.Write();
				}
				this.PropertyChanged.Raise( () => this.Ptr_0C );
			}
		}
		public string Ptr_10					// ポインタ Ptr_0C と同値？
		{
			get { return this.Data.Ptr_10.ToString( "X8" ); }
			set
			{
				if ( value == this.Ptr_10 ) { return; }
				uint val;
				if ( UInt32.TryParse( value, System.Globalization.NumberStyles.HexNumber, null, out val ) )
				{
					this.Data.Ptr_10 = val;
					this.Write();
				}
				this.PropertyChanged.Raise( () => this.Ptr_10 );
			}
		}
		public int h14_4						// 0固定？
		{
			get { return this.Data.h14_4; }
			set
			{
				if ( value == this.h14_4 ) { return; }
				this.Data.h14_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h14_4 );
			}
		}
		public PointerlistType2 ShiroList		// 城リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrShiroList ); }
		}
		public int CntShiroList					// 城リスト数
		{
			get { return this.Data.CntShiroList; }
			set
			{
				if ( value == this.CntShiroList ) { return; }
				this.Data.CntShiroList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntShiroList );
			}
		}
		public int h20_4						// 0固定？
		{
			get { return this.Data.h20_4; }
			set
			{
				if ( value == this.h20_4 ) { return; }
				this.Data.h20_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h20_4 );
			}
		}
		public string Ptr_24					// ポインタ
		{
			get { return this.Data.Ptr_24.ToString( "X8" ); }
			set
			{
				if ( value == this.Ptr_24 ) { return; }
				uint val;
				if ( UInt32.TryParse( value, System.Globalization.NumberStyles.HexNumber, null, out val ) )
				{
					this.Data.Ptr_24 = val;
					this.Write();
				}
				this.PropertyChanged.Raise( () => this.Ptr_24 );
			}
		}
		public string Ptr_28					// ポインタ Ptr_2C と同値？
		{
			get { return this.Data.Ptr_28.ToString( "X8" ); }
			set
			{
				if ( value == this.Ptr_28 ) { return; }
				uint val;
				if ( UInt32.TryParse( value, System.Globalization.NumberStyles.HexNumber, null, out val ) )
				{
					this.Data.Ptr_28 = val;
					this.Write();
				}
				this.PropertyChanged.Raise( () => this.Ptr_28 );
			}
		}
		public string Ptr_2C					// ポインタ Ptr_28 と同値？
		{
			get { return this.Data.Ptr_2C.ToString( "X8" ); }
			set
			{
				if ( value == this.Ptr_2C ) { return; }
				uint val;
				if ( UInt32.TryParse( value, System.Globalization.NumberStyles.HexNumber, null, out val ) )
				{
					this.Data.Ptr_2C = val;
					this.Write();
				}
				this.PropertyChanged.Raise( () => this.Ptr_2C );
			}
		}
		public int h30_4						// 0固定？
		{
			get { return this.Data.h30_4; }
			set
			{
				if ( value == this.h30_4 ) { return; }
				this.Data.h30_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h30_4 );
			}
		}
		public int h34_4						// 4固定？
		{
			get { return this.Data.h34_4; }
			set
			{
				if ( value == this.h34_4 ) { return; }
				this.Data.h34_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h34_4 );
			}
		}
		public byte h38						// 0固定？
		{
			get { return this.Data.h38; }
			set
			{
				if ( value == this.h38 ) { return; }
				this.Data.h38 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h38 );
			}
		}
		public string Name						// 名称
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Name );
				this.UpdateNamelist();
			}
		}
		public string Yomi						// 読み
		{
			get { return this.Data.Yomi; }
			set
			{
				if ( value == this.Yomi ) { return; }
				this.Data.Yomi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Yomi );
			}
		}
		public sbyte h57						// 0xFF固定？
		{
			get { return this.Data.h57; }
			set
			{
				if ( value == this.h57 ) { return; }
				this.Data.h57 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h57 );
			}
		}
		public PointerlistType2 KuniList1		// 国リスト1
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrKuniList1 ); }
		}
		public int CntKuniList1					// 国リスト1数
		{
			get { return this.Data.CntKuniList1; }
			set
			{
				if ( value == this.CntKuniList1 ) { return; }
				this.Data.CntKuniList1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntKuniList1 );
			}
		}
		public int h60_4						// 0固定？
		{
			get { return this.Data.h60_4; }
			set
			{
				if ( value == this.h60_4 ) { return; }
				this.Data.h60_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h60_4 );
			}
		}
		public PointerlistType2 YousyoList		// 要所リストポインタ(2ポインタタイプ)
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrYousyoList ); }
		}
		public int CntYousyoList				// 要所リスト数
		{
			get { return this.Data.CntYousyoList; }
			set
			{
				if ( value == this.CntYousyoList ) { return; }
				this.Data.CntYousyoList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntYousyoList );
			}
		}
		public int h6C_4						// 0固定？
		{
			get { return this.Data.h6C_4; }
			set
			{
				if ( value == this.h6C_4 ) { return; }
				this.Data.h6C_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h6C_4 );
			}
		}
		public byte h70						// 0x00 または 0x0B(11)？
		{
			get { return this.Data.h70; }
			set
			{
				if ( value == this.h70 ) { return; }
				this.Data.h70 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h70 );
			}
		}
		public byte h71						// 0x00 または 0x0F(15)？
		{
			get { return this.Data.h71; }
			set
			{
				if ( value == this.h71 ) { return; }
				this.Data.h71 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h71 );
			}
		}
		public byte h72						// 0x00 または 0x17(23)？
		{
			get { return this.Data.h72; }
			set
			{
				if ( value == this.h72 ) { return; }
				this.Data.h72 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h72 );
			}
		}
		public byte h73						// 0x00 または 0x17(23)？
		{
			get { return this.Data.h73; }
			set
			{
				if ( value == this.h73 ) { return; }
				this.Data.h73 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h73 );
			}
		}
		public byte h74						// 0x00 または 0x41(65)？
		{
			get { return this.Data.h74; }
			set
			{
				if ( value == this.h74 ) { return; }
				this.Data.h74 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h74 );
			}
		}
		public byte h75						// 0x00 または 0x14(20)？
		{
			get { return this.Data.h75; }
			set
			{
				if ( value == this.h75 ) { return; }
				this.Data.h75 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h75 );
			}
		}
		public byte h76						// 0x00 または 0x1E(30)？
		{
			get { return this.Data.h76; }
			set
			{
				if ( value == this.h76 ) { return; }
				this.Data.h76 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h76 );
			}
		}
		public byte h77						// 0x00 または 0x41(65)？
		{
			get { return this.Data.h77; }
			set
			{
				if ( value == this.h77 ) { return; }
				this.Data.h77 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h77 );
			}
		}
		public byte h78						// 0x00 または 0x46(70)？
		{
			get { return this.Data.h78; }
			set
			{
				if ( value == this.h78 ) { return; }
				this.Data.h78 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h78 );
			}
		}
		public byte h79						// 1固定？
		{
			get { return this.Data.h79; }
			set
			{
				if ( value == this.h79 ) { return; }
				this.Data.h79 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h79 );
			}
		}
		public byte h7A						// 1固定？
		{
			get { return this.Data.h7A; }
			set
			{
				if ( value == this.h7A ) { return; }
				this.Data.h7A = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h7A );
			}
		}
		public byte h7B						// 0固定？
		{
			get { return this.Data.h7B; }
			set
			{
				if ( value == this.h7B ) { return; }
				this.Data.h7B = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h7B );
			}
		}
		public int h7C_4						// 0固定？
		{
			get { return this.Data.h7C_4; }
			set
			{
				if ( value == this.h7C_4 ) { return; }
				this.Data.h7C_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h7C_4 );
			}
		}
		public PointerlistType3 KuniList2		// 国リスト2
		{
			get { return PointerlistType3.Create( this.N14pkb, this.Data.PtrKuniList2 ); }
		}
		public int CntKuniList2					// 国数
		{
			get { return this.Data.CntKuniList2; }
			set
			{
				if ( value == this.CntKuniList2 ) { return; }
				this.Data.CntKuniList2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntKuniList2 );
			}
		}
		public int h88_4						// 0固定？
		{
			get { return this.Data.h88_4; }
			set
			{
				if ( value == this.h88_4 ) { return; }
				this.Data.h88_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h88_4 );
			}
		}


		/// <summary>コンストラクタ 国</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Kuni( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Kunitable[id];
		}

		/// <summary>国名リストを更新する</summary>
		private void UpdateNamelist()
		{
			var list = this.N14pkb.Kunilist.Namelist;
			list[this.Address] = this.Name;

			// ビューリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.武将].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.城].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.区画].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.建物].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.要所].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.街道].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.国].NeedsRefresh = true;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			throw new NotSupportedException();
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			throw new NotSupportedException();
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Kunitable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Kunilist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:国:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
