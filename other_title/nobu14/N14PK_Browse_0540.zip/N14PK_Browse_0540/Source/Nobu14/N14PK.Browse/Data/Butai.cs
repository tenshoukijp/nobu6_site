﻿// Butai.cs

using System;
using System.ComponentModel;

using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>部隊ビューで使用するデータクラス</summary>
	public class Butai : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の部隊データ</summary>
		public ButaiData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID									// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address								// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex						// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}

		public string Name								// 部隊名
		{
			get
			{
				if ( this.CntHenseiList != 0 )
				{
					return this.N14pkb.Busyoulist.GetNameByAddress( this.HenseiList.GetFirstPtrTargetData() ) + "隊";
				}
				return string.Empty;
			}
			set { throw new NotSupportedException(); }
		}

		public string Seiryokuname						// 所属軍団または勢力名(国人衆の場合)
		{
			get
			{
				if ( (DataAddressKind)this.Data.KyotenTypeID == DataAddressKind.国人 )
				{
					return this.Seiryoku.Name;
				}
				return this.N14pkb.Gundanlist.GetNameByAddress( this.Data.PtrGundan );
			}
		}
		public string SyozokuKyoten						// 所属拠点(城 / 国人衆)
		{
			get
			{
				switch ( (DataAddressKind)this.Data.KyotenTypeID )
				{
					case DataAddressKind.城:
						return this.N14pkb.Shirolist.GetNameByAddress( this.Data.PtrKyoten );

					case DataAddressKind.国人:
						var name = this.N14pkb.Kokujinlist.GetNameByAddress( this.Data.PtrKyoten );
						// 城名には "*"/"  " が付いているのでそれに合わせる
						return !string.IsNullOrEmpty( name ) ? name.Insert( 0, "  " ) : name;

					default:
						return Funcs.GetNameByAddress( this.N14pkb, this.Data.PtrKyoten );
				}
			}
		}

		public int CntHenseiList						// カウンタ
		{
			get { return this.Data.CntHenseiList; }
			set
			{
				if ( value == this.CntHenseiList ) { return; }
				this.Data.CntHenseiList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntHenseiList );
			}
		}
		public PointerlistType2 HenseiList				// 編成武将リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrHenseiList ); }
		}

		public int Heisuu								// 兵数
		{
			get { return this.Data.Heisuu; }
			set
			{
				if ( value == this.Heisuu ) { return; }
				this.Data.Heisuu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Heisuu );
			}
		}
		public short HeisuuMax							// 最大兵数
		{
			get { return this.Data.HeisuuMax; }
			set
			{
				if ( value == this.HeisuuMax ) { return; }
				this.Data.HeisuuMax = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HeisuuMax );
			}
		}
		public byte HyourouNissuu						// 兵糧日数
		{
			get { return this.Data.HyourouNissuu; }
			set
			{
				if ( value == this.HyourouNissuu ) { return; }
				this.Data.HyourouNissuu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HyourouNissuu );
			}
		}
		public bool HasGunba							// 軍馬配備フラグ
		{
			get { return this.Data.HasGunba; }
			set
			{
				if ( value == this.HasGunba ) { return; }
				this.Data.HasGunba = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HasGunba );
			}
		}
		public bool HasTeppou							// 鉄砲配備フラグ
		{
			get { return this.Data.HasTeppou; }
			set
			{
				if ( value == this.HasTeppou ) { return; }
				this.Data.HasTeppou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HasTeppou );
			}
		}

		public int h02C_4								// 数値
		{
			get { return this.Data.h02C_4; }
			set
			{
				if ( value == this.h02C_4 ) { return; }
				this.Data.h02C_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h02C_4 );
			}
		}

		public int PosX									// X位置？
		{
			get { return this.Data.PosX; }
			set
			{
				if ( value == this.PosX ) { return; }
				this.Data.PosX = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PosX );
			}
		}
		public int PosY									// Y位置？
		{
			get { return this.Data.PosY; }
			set
			{
				if ( value == this.PosY ) { return; }
				this.Data.PosY = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PosY );
			}
		}
		public int Direction1							// 向き関連？
		{
			get { return this.Data.Direction1; }
			set
			{
				if ( value == this.Direction1 ) { return; }
				this.Data.Direction1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Direction1 );
			}
		}
		public int Direction2							// 向き関連？
		{
			get { return this.Data.Direction2; }
			set
			{
				if ( value == this.Direction2 ) { return; }
				this.Data.Direction2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Direction2 );
			}
		}

		public string Mokuhyou1							// 目標1
		{
			get { return Funcs.GetNameByAddress( this.N14pkb, this.Data.PtrMokuhyou1 ); }
		}
		public string Mokuhyou2							// 目標2
		{
			get { return Funcs.GetNameByAddress( this.N14pkb, this.Data.PtrMokuhyou2 ); }
		}
		public string Mokuhyou3							// 目標3
		{
			get { return Funcs.GetNameByAddress( this.N14pkb, this.Data.PtrMokuhyou3 ); }
		}

		public int CntKousenButaiList					// カウンタ
		{
			get { return this.Data.CntKousenButaiList; }
			set
			{
				if ( value == this.CntKousenButaiList ) { return; }
				this.Data.CntKousenButaiList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntKousenButaiList );
			}
		}
		public PointerlistType2 KousenButaiList			// 交戦部隊リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrKousenButaiList ); }
		}

		public int CntKaisenButaiList					// カウンタ
		{
			get { return this.Data.CntKaisenButaiList; }
			set
			{
				if ( value == this.CntKaisenButaiList ) { return; }
				this.Data.CntKaisenButaiList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntKaisenButaiList );
			}
		}
		public PointerlistType2 KaisenButaiList			// 会戦部隊リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrKaisenButaiList ); }
		}

		public int CntHoryoList							// カウンタ
		{
			get { return this.Data.CntHoryoList; }
			set
			{
				if ( value == this.CntHoryoList ) { return; }
				this.Data.CntHoryoList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntHoryoList );
				this.PropertyChanged.Raise( () => this.HoryoList );
			}
		}
		public PointerlistType2 HoryoList				// 捕虜リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrHoryoList ); }
		}

		public int h074_4								// 数値 ウェイポイントデータ使用数？
		{
			get { return this.Data.h074_4; }
			set
			{
				if ( value == this.h074_4 ) { return; }
				this.Data.h074_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h074_4 );
			}
		}
		public string Mokuhyou_WP1						// WP1目標
		{
			get { return Funcs.GetNameByAddress( this.N14pkb, this.Data.PtrMokuhyou_WP1 ); }
		}
		public string Mokuhyou_WP2						// WP2目標
		{
			get { return Funcs.GetNameByAddress( this.N14pkb, this.Data.PtrMokuhyou_WP2 ); }
		}
		public string Mokuhyou_WP3						// WP3目標
		{
			get { return Funcs.GetNameByAddress( this.N14pkb, this.Data.PtrMokuhyou_WP3 ); }
		}
		public string Mokuhyou_WP4						// WP4目標
		{
			get { return Funcs.GetNameByAddress( this.N14pkb, this.Data.PtrMokuhyou_WP4 ); }
			set
			{
				//if ( value == this.Mokuhyou_WP4 ) { return; }
				//this.Data.PtrMokuhyou_WP4 = value;
				//this.Write();
				//this.PropertyChanged.Raise( () => this.Mokuhyou_WP4 );
			}
		}
		public string Mokuhyou_WP5						// WP5目標
		{
			get { return Funcs.GetNameByAddress( this.N14pkb, this.Data.PtrMokuhyou_WP5 ); }
		}
		public string Mokuhyou_WP6						// WP6目標
		{
			get { return Funcs.GetNameByAddress( this.N14pkb, this.Data.PtrMokuhyou_WP6 ); }
		}
		public string Mokuhyou_WP7						// WP7目標
		{
			get { return Funcs.GetNameByAddress( this.N14pkb, this.Data.PtrMokuhyou_WP7 ); }
		}
		public string Mokuhyou_WP8						// WP8目標
		{
			get { return Funcs.GetNameByAddress( this.N14pkb, this.Data.PtrMokuhyou_WP8 ); }
		}

		public uint PtrGundan							// 軍団ポインタ
		{
			get { return this.Data.PtrGundan; }
			set
			{
				if ( value == this.PtrGundan ) { return; }
				this.Data.PtrGundan = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrGundan );
			}
		}

		// 城
		public Shiro Shiro
		{ get { return this.N14pkb.Shirolist[this.Data.PtrKyoten]; } }
		// 軍団
		public Gundan Gundan
		{ get { return this.N14pkb.Gundanlist[this.Data.PtrGundan]; } }
		// 勢力
		public Seiryoku Seiryoku
		{ 
			get
			{
				if ( (DataAddressKind)this.Data.KyotenTypeID == DataAddressKind.国人 )
				{
					return this.N14pkb.Kokujinlist[this.Data.PtrKyoten].SaikoushijiSeiryoku;
				}
				return ( this.Gundan != null ) ? this.N14pkb.Seiryokulist[this.Gundan.Data.PtrSeiryoku] : null;
			}
		}
		// ソートID
		public int SortID
		{
			get
			{
				if ( (DataAddressKind)this.Data.KyotenTypeID == DataAddressKind.国人 )
				{
					return this.Seiryoku.SortID;
				}
				return this.N14pkb.Gundanlist.GetSortIDByAddress( this.Data.PtrGundan );
			}
		}

		/// <summary>コンストラクタ 部隊</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Butai( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Butaitable[id];
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			throw new NotSupportedException();
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			throw new NotSupportedException();
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Butaitable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Butailist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:部隊:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
