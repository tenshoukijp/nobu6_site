﻿// Seiryoku.cs

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;
namespace N14PKBrowse.Data
{
	/// <summary>勢力ビューで使用するデータクラス</summary>
	public class Seiryoku : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の勢力データ</summary>
		public SeiryokuData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID				// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address			// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex	// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}

		public string Name							// 名
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Name );
				this.UpdateNamelist();
			}
		}
		public string Yomi							// 読み
		{
			get { return this.Data.Yomi; }
			set
			{
				if ( value == this.Yomi ) { return; }
				this.Data.Yomi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Yomi );
			}
		}

		public uint PtrKoyuuSeisaku					// 固有政策 勢力の血族IDと政策の血族IDを合わせる必要がある
		{
			get { return this.Data.PtrKoyuuSeisaku; }
			set
			{
				if ( value == this.PtrKoyuuSeisaku ) { return; }
				this.Data.PtrKoyuuSeisaku = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrKoyuuSeisaku );
			}
		}

		public int CntGundanList					// カウンタ
		{
			get { return this.Data.CntGundanList; }
			set
			{
				if ( value == this.CntGundanList ) { return; }
				this.Data.CntGundanList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntGundanList );
			}
		}
		public PointerlistType2 GundanList			// 軍団リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrGundanList ); }
		}
		public int CntSeijinmaeList					// カウンタ
		{
			get { return this.Data.CntSeijinmaeList; }
			set
			{
				if ( value == this.CntSeijinmaeList ) { return; }
				this.Data.CntSeijinmaeList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntSeijinmaeList );
				this.PropertyChanged.Raise( () => this.SeijinmaeList );
			}
		}
		public PointerlistType2 SeijinmaeList		// 成人前武将リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrSeijinmaeList ); }
		}
		public int CntList_00EC						// カウンタ
		{
			get { return this.Data.CntList_00EC; }
			set
			{
				if ( value == this.CntList_00EC ) { return; }
				this.Data.CntList_00EC = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntList_00EC );
			}
		}
		public PointerlistType2 List_00EC			// リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrList_00EC ); }
		}
		public int CntList_00F8						// カウンタ
		{
			get { return this.Data.CntList_00F8; }
			set
			{
				if ( value == this.CntList_00F8 ) { return; }
				this.Data.CntList_00F8 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntList_00F8 );
			}
		}
		public PointerlistType2 List_00F8			// リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrList_00F8 ); }
		}
		public int CntHimeList						// カウンタ
		{
			get { return this.Data.CntHimeList; }
			set
			{
				if ( value == this.CntHimeList ) { return; }
				this.Data.CntHimeList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntHimeList );
				this.PropertyChanged.Raise( () => this.HimeList );
			}
		}
		public PointerlistType2 HimeList			// 姫リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrHimeList ); }
		}
		public int CntDoumeiList					// カウンタ
		{
			get { return this.Data.CntDoumeiList; }
			set
			{
				if ( value == this.CntDoumeiList ) { return; }
				this.Data.CntDoumeiList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntDoumeiList );
				this.PropertyChanged.Raise( () => this.DoumeiList );
			}
		}
		public PointerlistType3 DoumeiList			// 同盟勢力リスト
		{
			get { return PointerlistType3.Create( this.N14pkb, this.Data.PtrDoumeiList ); }
		}
		public int CntTeisenList					// カウンタ
		{
			get { return this.Data.CntTeisenList; }
			set
			{
				if ( value == this.CntTeisenList ) { return; }
				this.Data.CntTeisenList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntTeisenList );
			}
		}
		public PointerlistType3 TeisenList			// 停戦勢力リスト
		{
			get { return PointerlistType3.Create( this.N14pkb, this.Data.PtrTeisenList ); }
		}
		public int CntKahouList						// カウンタ
		{
			get { return this.Data.CntKahouList; }
			set
			{
				if ( value == this.CntKahouList ) { return; }
				this.Data.CntKahouList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntKahouList );
				this.PropertyChanged.Raise( () => this.KahouList );
			}
		}
		public PointerlistType2 KahouList			// 家宝リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrKahouList ); }
		}

		public string Tousyuname					// 当主
		{
			get { return this.N14pkb.Busyoulist.GetNameByAddress( this.Data.PtrTousyu ); }
		}
		public uint PtrTousyu						// 当主ポインタ
		{
			get { return this.Data.PtrTousyu; }
			set
			{
				if ( value == this.PtrTousyu ) { return; }
				this.Data.PtrTousyu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrTousyu );
				this.PropertyChanged.Raise( () => this.Tousyuname );

				if ( this.PtrTousyu != 0 )
				{
					var busyou = this.N14pkb.Busyoulist[this.PtrTousyu];
					this.Name = busyou.Sei + "家";
					this.Yomi = busyou.SeiYomi;
					this.UpdateNamelist();
				}
			}
		}

		public int h0140_4							// 0x00 / 0x01 / 0xFF？
		{
			get { return this.Data.h0140_4; }
			set
			{
				if ( value == this.h0140_4 ) { return; }
				this.Data.h0140_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0140_4 );
			}
		}
		public int KamonID							// 家紋ID
		{
			get { return this.Data.KamonID; }
			set
			{
				if ( value == this.KamonID ) { return; }
				this.Data.KamonID = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KamonID );
			}
		}
		public int h0148_4							// 何かのID
		{
			get { return this.Data.h0148_4; }
			set
			{
				if ( value == this.h0148_4 ) { return; }
				this.Data.h0148_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0148_4 );
			}
		}
		public int h014C_4							// 014Ch 4バイト
		{
			get { return this.Data.h014C_4; }
			set
			{
				if ( value == this.h014C_4 ) { return; }
				this.Data.h014C_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h014C_4 );
			}
		}
		public int KetsuzokuID						// 血族ID
		{
			get { return this.Data.KetsuzokuID; }
			set
			{
				if ( value == this.KetsuzokuID ) { return; }
				this.Data.KetsuzokuID = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KetsuzokuID );
			}
		}
		public uint PtrJuuzokuSeiryoku				// 従属先勢力
		{
			get { return this.Data.PtrJuuzokuSeiryoku; }
			set
			{
				if ( value == this.PtrJuuzokuSeiryoku ) { return; }
				this.Data.PtrJuuzokuSeiryoku = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrJuuzokuSeiryoku );
			}
		}

		public int CntSeiryokuList_0520				// カウンタ
		{
			get { return this.Data.CntSeiryokuList_0520; }
			set
			{
				if ( value == this.CntSeiryokuList_0520 ) { return; }
				this.Data.CntSeiryokuList_0520 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntSeiryokuList_0520 );
			}
		}
		public PointerlistType3 SeiryokuList_0520	// 勢力リスト
		{
			get { return PointerlistType3.Create( this.N14pkb, this.Data.PtrSeiryokuList_0520 ); }
		}
		public int CntSeiryokuList_0530				// カウンタ
		{
			get { return this.Data.CntSeiryokuList_0530; }
			set
			{
				if ( value == this.CntSeiryokuList_0530 ) { return; }
				this.Data.CntSeiryokuList_0530 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntSeiryokuList_0530 );
			}
		}
		public PointerlistType3 SeiryokuList_0530 	// 勢力リスト
		{
			get { return PointerlistType3.Create( this.N14pkb, this.Data.PtrSeiryokuList_0530 ); }
		}

		public string SyokiHonkyo					// シナリオ開始時の本拠
		{
			get { return this.N14pkb.Shirolist.GetNameByAddress( this.Data.PtrSyokiHonkyo ); }
			set
			{
				if ( value == this.SyokiHonkyo ) { return; }
				this.Data.PtrSyokiHonkyo = this.N14pkb.Shirolist.GetAddressByName( value );
				this.Write();
				this.PropertyChanged.Raise( () => this.SyokiHonkyo );
			}
		}
		public string SyokiTousyu					// シナリオ開始時の当主
		{
			get { return this.N14pkb.Busyoulist.GetNameByAddress( this.Data.PtrSyokiTousyu ); }
			set
			{
				if ( value == this.SyokiTousyu ) { return; }
				this.Data.PtrSyokiTousyu = this.N14pkb.Busyoulist.GetAddressByName( value );
				this.Write();
				this.PropertyChanged.Raise( () => this.SyokiTousyu );
			}
		}

		public SeiryokuData.GaikouData[] Gaikou		// 外交データ
		{
			get { return this.Data.Gaikou; }
		}

		public int CntSeiryokuList_0ECC				// カウンタ
		{
			get { return this.Data.CntSeiryokuList_0ECC; }
			set
			{
				if ( value == this.CntSeiryokuList_0ECC ) { return; }
				this.Data.CntSeiryokuList_0ECC = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntSeiryokuList_0ECC );
			}
		}
		public PointerlistType3 SeiryokuList_0ECC	// 勢力リスト
		{
			get { return PointerlistType3.Create( this.N14pkb, this.Data.PtrSeiryokuList_0ECC ); }
		}
		public int CntSeiryokuList_0EDC				// カウンタ
		{
			get { return this.Data.CntSeiryokuList_0EDC; }
			set
			{
				if ( value == this.CntSeiryokuList_0EDC ) { return; }
				this.Data.CntSeiryokuList_0EDC = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntSeiryokuList_0EDC );
			}
		}
		public PointerlistType3 SeiryokuList_0EDC	// 勢力リスト
		{
			get { return PointerlistType3.Create( this.N14pkb, this.Data.PtrSeiryokuList_0EDC ); }
		}
		public int CntSeiryokuList_0EEC				// カウンタ
		{
			get { return this.Data.CntSeiryokuList_0EEC; }
			set
			{
				if ( value == this.CntSeiryokuList_0EEC ) { return; }
				this.Data.CntSeiryokuList_0EEC = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntSeiryokuList_0EEC );
			}
		}
		public PointerlistType3 SeiryokuList_0EEC	// 勢力リスト
		{
			get { return PointerlistType3.Create( this.N14pkb, this.Data.PtrSeiryokuList_0EEC ); }
		}

		public string Taido							// 態度
		{
			get { return this.Data.Taido; }
			set
			{
				if ( value == this.Taido ) { return; }
				this.Data.Taido = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Taido );
			}
		}

		public short Shirosuu						// 支配城総数
		{
			get { return this.Data.Shirosuu; }
			set
			{
				if ( value == this.Shirosuu ) { return; }
				this.Data.Shirosuu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Shirosuu );
			}
		}
		public byte h0FEA							// 0FEAh 1バイト
		{
			get { return this.Data.h0FEA; }
			set
			{
				if ( value == this.h0FEA ) { return; }
				this.Data.h0FEA = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0FEA );
			}
		}
		public byte h0FEB							// 本城数？ じゃないっぽい
		{
			get { return this.Data.h0FEB; }
			set
			{
				if ( value == this.h0FEB ) { return; }
				this.Data.h0FEB = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0FEB );
			}
		}

		// 0FEC~10E3 248バイト 伝授用データ
		public sbyte[] DenjuTokuseiArray			// 0FEC~10E2 247バイト 伝授用特性の所持数(官位は0/1のみ、役職は無視される？、左大臣・右大臣・関白も無視される？)
		{
			get { return this.Data.DenjuTokuseiArray; }
			set
			{
				if ( value == this.DenjuTokuseiArray ) { return; }
				this.Data.DenjuTokuseiArray = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.DenjuTokuseiArray );
			}
		}
		public short Souzousei						// 創造性
		{
			get { return this.Data.Souzousei; }
			set
			{
				if ( value == this.Souzousei ) { return; }
				this.Data.Souzousei = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Souzousei );
			}
		}

		public int ChouteiShinyou					// 朝廷信用
		{
			get { return this.Data.ChouteiShinyou; }
			set
			{
				if ( value == this.ChouteiShinyou ) { return; }
				this.Data.ChouteiShinyou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.ChouteiShinyou );
			}
		}
		public int HataID							// 旗ID？
		{
			get { return this.Data.HataID; }
			set
			{
				if ( value == this.HataID ) { return; }
				this.Data.HataID = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HataID );
			}
		}

		// 111Ch はビットフラグ(bit1 のプレイヤー勢力フラグ以外未使用？)
		public bool h111C_b0						// 111Ch bit0 0固定？
		{
			get { return this.Data.h111C_b0; }
			set
			{
				if ( value == this.h111C_b0 ) { return; }
				this.Data.h111C_b0 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h111C_b0 );
			}
		}
		public bool IsPlayer						// 111Ch bit1 プレイヤー勢力 このフラグが立っている勢力は、プレイヤーが部隊の出陣・操作可能。挙動が怪しいので触らない方がいい
		{
			get { return this.Data.IsPlayer; }
			set
			{
				if ( value == this.IsPlayer ) { return; }
				this.Data.IsPlayer = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.IsPlayer );
			}
		}
		public bool h111C_b2						// 111Ch bit2
		{
			get { return this.Data.h111C_b2; }
			set
			{
				if ( value == this.h111C_b2 ) { return; }
				this.Data.h111C_b2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h111C_b2 );
			}
		}
		public bool h111C_b3						// 111Ch bit3 0固定？
		{
			get { return this.Data.h111C_b3; }
			set
			{
				if ( value == this.h111C_b3 ) { return; }
				this.Data.h111C_b3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h111C_b3 );
			}
		}
		public bool h111C_b4						// 111Ch bit4 0固定？
		{
			get { return this.Data.h111C_b4; }
			set
			{
				if ( value == this.h111C_b4 ) { return; }
				this.Data.h111C_b4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h111C_b4 );
			}
		}
		public bool h111C_b5						// 111Ch bit5
		{
			get { return this.Data.h111C_b5; }
			set
			{
				if ( value == this.h111C_b5 ) { return; }
				this.Data.h111C_b5 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h111C_b5 );
			}
		}
		public bool h111C_b6						// 111Ch bit6
		{
			get { return this.Data.h111C_b6; }
			set
			{
				if ( value == this.h111C_b6 ) { return; }
				this.Data.h111C_b6 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h111C_b6 );
			}
		}
		public bool h111C_b7						// 111Ch bit7
		{
			get { return this.Data.h111C_b7; }
			set
			{
				if ( value == this.h111C_b7 ) { return; }
				this.Data.h111C_b7 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h111C_b7 );
			}
		}

		public byte h111D							// 111Dh 1バイト 0x00/0x03
		{
			get { return this.Data.h111D; }
			set
			{
				if ( value == this.h111D ) { return; }
				this.Data.h111D = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h111D );
			}
		}
		public byte h111E							// 111Eh 1バイト 0固定？
		{
			get { return this.Data.h111E; }
			set
			{
				if ( value == this.h111E ) { return; }
				this.Data.h111E = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h111E );
			}
		}
		public byte h111F							// 111Fh 1バイト 0固定？
		{
			get { return this.Data.h111F; }
			set
			{
				if ( value == this.h111F ) { return; }
				this.Data.h111F = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h111F );
			}
		}

		// プレイヤー勢力への信用
		public sbyte Shinyou
		{
			get
			{
				if ( 0 <= this.N14pkb.PlayerSeriyokuID )
				{
					return this.Gaikou[this.N14pkb.PlayerSeriyokuID].Shinyou;
				}
				return -1;
			}
			set
			{
				if ( value == this.Shinyou || this.N14pkb.PlayerSeriyokuID == -1 )
				{
					this.PropertyChanged.Raise( () => this.Shinyou );
					return;
				}
				this.Gaikou[this.N14pkb.PlayerSeriyokuID].Shinyou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Shinyou );
			}
		}
		// 婚姻同盟数 リスト作成時にセット
		public int CntKoninDoumei { get; set; }
		// 婚姻同盟リスト
		public string KoninDoumei
		{
			get
			{
				if ( this.CntKoninDoumei == 0 ) { return string.Empty; }
				var sb = new StringBuilder( 512 );
				for ( var i = 0; i < this.CntKoninDoumei; i++ )
				{
					sb.Append( this.N14pkb.Seiryokulist.GetNameByID( this.KoninDoumeiSeiryokuID[i] ) + "(" );
					sb.Append( this.N14pkb.Busyoulist.GetNameByAddress( this.PtrKoninDoumeiBusyou1[i] ) + "×" );
					sb.Append( this.N14pkb.Busyoulist.GetNameByAddress( this.PtrKoninDoumeiBusyou2[i] ) + "), " );
				}
				return sb.ToString().TrimEnd( new[] { ',', ' ' } );
			}
		}

		// 当主の武将データ
		public Busyou Tousyu
		{
			get { return this.N14pkb.Busyoulist[this.PtrTousyu]; }
		}
		// 当主の血族ID
		public int TousyuKetsuzokuID
		{
			get { return ( this.Tousyu != null ) ? this.Tousyu.KetsuzokuID : -1; }
		}
		// 当主の配偶者
		public Busyou TousyuHaigusya
		{
			get { return ( this.Tousyu != null ) ? this.N14pkb.Busyoulist[this.Tousyu.PtrHaigusya] : null; }
		}
		// 当主の配偶者の血族ID
		public int TousyuHaigusyaKetsuzokuID
		{
			get { return ( this.TousyuHaigusya != null ) ? this.TousyuHaigusya.KetsuzokuID : -1; }
		}
		// 当主の養父
		public Busyou TousyuYoufu
		{
			get { return ( this.Tousyu != null ) ? this.N14pkb.Busyoulist[this.Tousyu.PtrYoufu] : null; }
		}
		// 当主の養父の血族ID
		public int TousyuYoufuKetsuzokuID
		{
			get { return ( this.TousyuYoufu != null ) ? this.TousyuYoufu.KetsuzokuID : -1; }
		}

		// 勢力＆当主名(選択勢力コンボボックス用))
		public string SeiryokuAndTousyuName
		{
			get { return this.Name + ":" + this.Tousyuname; }
		}
		// ソートID シナリオ開始時の本拠を元に北から
		public int SortID
		{
			get
			{
				var sortid = this.N14pkb.Shirolist.GetSortIDByAddress( this.Data.PtrSyokiHonkyo );
				return ( 0 <= sortid ) ? sortid * 10 : -1;
			}
		}
		// 婚姻同盟勢力ID リスト作成時にセット
		public int[] KoninDoumeiSeiryokuID { get; set; }
		// 婚姻同盟相手勢力の対象武将ポインタ リスト作成時にセット
		public uint[] PtrKoninDoumeiBusyou1 { get; set; }
		// 婚姻同盟自勢力の対象武将ポインタ リスト作成時にセット
		public uint[] PtrKoninDoumeiBusyou2 { get; set; }


		/// <summary>コンストラクタ 勢力</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Seiryoku( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Seiryokutable[id];
		}

		/// <summary>勢力名リストを更新する</summary>
		public void UpdateNamelist()
		{
			var namelist = this.N14pkb.Seiryokulist.Namelist;
			namelist[this.Address] = this.Name;

			var seiryokuAndGundanchounamelist = this.N14pkb.Seiryokulist.SeiryokuAndTousyunamelist;
			seiryokuAndGundanchounamelist[this.Address] = this.SeiryokuAndTousyuName;
			//this.N14pkb.View.SeiryokuNamelist[this.Address] = this.SeiryokuAndTousyuName;
			// 選択勢力コンボボックスソースリフレッシュ
			this.N14pkb.MainWindowInterface.ComboSeiryoku.Items.Refresh();
			// コンボボックスに表示中の勢力名を更新するにはどうしたらいいの？ わからないので選択し直すことで対処
			this.N14pkb.MainWindowInterface.ComboSeiryoku.SelectedIndex = -1;
			this.N14pkb.MainWindowInterface.ComboSeiryoku.SelectedValue = this.N14pkb.View.SelectedSeiryokuAddress;

			// 勢力名を参照して名前リストを作成している軍団名リストをリセット
			foreach( var d in this.N14pkb.Gundanlist )
			{
				if ( d.Data.PtrSeiryoku == this.Address )
				{
					d.UpdateNamelist();
				}
			}
			//this.N14pkb.Gundanlist.SetNamelist();

			// 勢力名を参照しているビューのリフレッシュフラグ
			this.N14pkb.View.Flags[(int)Enums.TabKind.勢力].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.軍団].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.家宝].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.国人衆].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.要所].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.街道].NeedsRefresh = true;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			throw new NotSupportedException();
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			throw new NotSupportedException();
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Seiryokutable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Seiryokulist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:勢力:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
