﻿// Shiro.cs

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

using N14PKBrowse.HelperClass;
using N14PKLibrary.Data;
using N14PKLibrary;
namespace N14PKBrowse.Data
{
	/// <summary>城ビューで使用するデータクラス</summary>
	public class Shiro : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の城データ</summary>
		public ShiroData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID										// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address									// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex							// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}

		public string Name									// 名称
		{
			get
			{
				var name = this.N14pkb.ShiroNamelist.GetNameByAddress( this.Data.PtrShiroName );
				if ( !string.IsNullOrEmpty( name ) )
				{
					if ( this.Data.PtrTatemono != 0 )
					{
						var shisetsuid = this.N14pkb.Shisetsulist.GetIDByAddress( this.Tatemono.Data.PtrShisetsu );
						if ( 0 <= shisetsuid && shisetsuid <= 6 )
						{
							// 施設IDが 0～6 なら本城とする
							name = "*" + name;
						}
						else if ( 7 <= shisetsuid && shisetsuid <= 8 )
						{
							// 施設IDが 7,8 なら支城とする
							name = "  " + name;
						}
					}
				}
				return name;
			}
			set { throw new NotSupportedException(); }
		}
		public uint PtrGundan								// 軍団ポインタ
		{
			get { return this.Data.PtrGundan; }
			set
			{
				if ( value == this.PtrGundan ) { return; }

				// 所属軍団変更処理
				if ( !Funcs.CheckSyozokuGundanHenkou( this.N14pkb, this.Address, value ) )
				{
					this.PropertyChanged.Raise( () => this.PtrGundan );
					return;
				}
				Funcs.ChangeKyotenGundan( this.N14pkb, this.Address, value );
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrGundan );
			}
		}
		public uint PtrTatemono								// 建物ポインタ(現在耐久はここから引っ張ってくる)
		{
			get { return this.Data.PtrTatemono; }
			set
			{
				if ( value == this.PtrTatemono ) { return; }
				this.Data.PtrTatemono = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrTatemono );
			}
		}
		public uint Heisuu									// 兵数
		{
			get { return this.Data.Heisuu; }
			set
			{
				if ( value == this.Heisuu ) { return; }
				this.Data.Heisuu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Heisuu );
			}
		}
		public string Jousyuname							// 城主武将
		{
			get { return this.N14pkb.Busyoulist.GetNameByAddress( this.Data.PtrJousyu ); }
		}
		public uint PtrJousyu								// 城主ポインタ
		{
			get { return this.Data.PtrJousyu; }
			set
			{
				if ( value == this.PtrJousyu ) { return; }
				this.Data.PtrJousyu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrJousyu );
				this.PropertyChanged.Raise( () => this.Jousyuname );
			}
		}
		public string Bugyouname							// 奉行武将ポインタ
		{
			get { return this.N14pkb.Busyoulist.GetNameByAddress( this.Data.PtrBugyou ); }
		}
		public uint PtrBugyou								// 奉行ポインタ
		{
			get { return this.Data.PtrBugyou; }
			set
			{
				if ( value == this.PtrBugyou ) { return; }
				this.Data.PtrBugyou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrBugyou );
				this.PropertyChanged.Raise( () => this.Bugyouname );
			}
		}
		public int Jinkou									// 人口
		{
			get { return this.Data.Jinkou; }
			set
			{
				if ( value == this.Jinkou ) { return; }
				this.Data.Jinkou = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Jinkou );
			}
		}
		public short SyougyouNow							// 商業(現在)
		{
			get { return this.Data.SyougyouNow; }
			set
			{
				if ( value == this.SyougyouNow ) { return; }
				this.Data.SyougyouNow = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SyougyouNow );
			}
		}
		public short KokudakaNow							// 石高(現在)
		{
			get { return this.Data.KokudakaNow; }
			set
			{
				if ( value == this.KokudakaNow ) { return; }
				this.Data.KokudakaNow = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KokudakaNow );
			}
		}
		public short HeisyaNow								// 兵舎(現在)
		{
			get { return this.Data.HeisyaNow; }
			set
			{
				if ( value == this.HeisyaNow ) { return; }
				this.Data.HeisyaNow = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HeisyaNow );
			}
		}
		public short SyougyouMax							// 商業(最大)
		{
			get { return this.Data.SyougyouMax; }
			set
			{
				if ( value == this.SyougyouMax ) { return; }
				this.Data.SyougyouMax = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.SyougyouMax );
			}
		}
		public short KokudakaMax							// 石高(最大)
		{
			get { return this.Data.KokudakaMax; }
			set
			{
				if ( value == this.KokudakaMax ) { return; }
				this.Data.KokudakaMax = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KokudakaMax );
			}
		}
		public short HeisyaMax								// 兵舎(最大)
		{
			get { return this.Data.HeisyaMax; }
			set
			{
				if ( value == this.HeisyaMax ) { return; }
				this.Data.HeisyaMax = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HeisyaMax );
			}
		}
		public short TaikyuuMax								// 耐久(最大)
		{
			get { return this.Data.TaikyuuMax; }
			set
			{
				if ( value == this.TaikyuuMax ) { return; }
				this.Data.TaikyuuMax = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.TaikyuuMax );
			}
		}
		public short Shiki									// 城士気
		{
			get { return this.Data.Shiki; }
			set
			{
				if ( value == this.Shiki ) { return; }
				this.Data.Shiki = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Shiki );
			}
		}
		public short h00E8_2								// 00E8h 2バイト
		{
			get { return this.Data.h00E8_2; }
			set
			{
				if ( value == this.h00E8_2 ) { return; }
				this.Data.h00E8_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h00E8_2 );
			}
		}
		public short Tamichuu								// 民忠
		{
			get { return this.Data.Tamichuu; }
			set
			{
				if ( value == this.Tamichuu ) { return; }
				this.Data.Tamichuu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Tamichuu );
			}
		}
		public uint PtrJoukaku1								// 城郭ポインタ 天守
		{
			get { return this.Data.PtrJoukaku1; }
			set
			{
				if ( value == this.PtrJoukaku1 ) { return; }
				this.CheckTaikyuu( this.PtrJoukaku1, value );
				this.Data.PtrJoukaku1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrJoukaku1 );
				this.PropertyChanged.Raise( () => this.YouchiInfo );
			}
		}
		public uint PtrJoukaku2								// 城郭ポインタ 城門
		{
			get { return this.Data.PtrJoukaku2; }
			set
			{
				if ( value == this.PtrJoukaku2 ) { return; }
				this.CheckTaikyuu( this.PtrJoukaku2, value );
				this.Data.PtrJoukaku2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrJoukaku2 );
				this.PropertyChanged.Raise( () => this.YouchiInfo );
			}
		}
		public uint PtrJoukaku3								// 城郭ポインタ 塀
		{
			get { return this.Data.PtrJoukaku3; }
			set
			{
				if ( value == this.PtrJoukaku3 ) { return; }
				this.CheckTaikyuu( this.PtrJoukaku3, value );
				this.Data.PtrJoukaku3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrJoukaku3 );
				this.PropertyChanged.Raise( () => this.YouchiInfo );
			}
		}
		public uint PtrJoukaku4								// 城郭ポインタ 出丸
		{
			get { return this.Data.PtrJoukaku4; }
			set
			{
				if ( value == this.PtrJoukaku4 ) { return; }
				this.CheckTaikyuu( this.PtrJoukaku4, value );
				this.Data.PtrJoukaku4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrJoukaku4 );
				this.PropertyChanged.Raise( () => this.YouchiInfo );
			}
		}
		public uint PtrJoukaku5								// 城郭ポインタ 矢倉
		{
			get { return this.Data.PtrJoukaku5; }
			set
			{
				if ( value == this.PtrJoukaku5 ) { return; }
				this.CheckTaikyuu( this.PtrJoukaku5, value );
				this.Data.PtrJoukaku5 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrJoukaku5 );
				this.PropertyChanged.Raise( () => this.YouchiInfo );
			}
		}
		public uint PtrJoukaku6								// 城郭ポインタ 曲輪
		{
			get { return this.Data.PtrJoukaku6; }
			set
			{
				if ( value == this.PtrJoukaku6 ) { return; }
				this.CheckTaikyuu( this.PtrJoukaku6, value );
				this.Data.PtrJoukaku6 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrJoukaku6 );
				this.PropertyChanged.Raise( () => this.YouchiInfo );
			}
		}
		public uint PtrJoukaku7								// 城郭ポインタ 施設
		{
			get { return this.Data.PtrJoukaku7; }
			set
			{
				if ( value == this.PtrJoukaku7 ) { return; }
				this.CheckTaikyuu( this.PtrJoukaku7, value );
				this.Data.PtrJoukaku7 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrJoukaku7 );
				this.PropertyChanged.Raise( () => this.YouchiInfo );
			}
		}
		public int CntHouiButaiList							// カウンタ
		{ 
			get { return this.Data.CntHouiButaiList; }
			set
			{
				if ( value == this.CntHouiButaiList ) { return; }
				this.Data.CntHouiButaiList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntHouiButaiList );
			}
		}
		public PointerlistType2 HouiButaiList				// 包囲部隊リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrHouiButaiList, DataKind.部隊 ); }
		}
		public uint h002C_4									// 002Ch 4バイト
		{
			get { return this.Data.h002C_4; }
			set
			{
				if ( value == this.h002C_4 ) { return; }
				this.Data.h002C_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h002C_4 );
			}
		}
		public int CntList_0030								// カウンタ
		{
			get { return this.Data.CntList_0030; }
			set
			{
				if ( value == this.CntList_0030 ) { return; }
				this.Data.CntList_0030 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntList_0030 );
			}
		}
		public PointerlistType2 List_0030					// リスト30
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrList_0030 ); }
		}
		public int CntList_0044								// カウンタ
		{
			get { return this.Data.CntList_0044; }
			set
			{
				if ( value == this.CntList_0044 ) { return; }
				this.Data.CntList_0044 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntList_0044 );
			}
		}
		public PointerlistType2 List_0044					// リスト44
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrList_0044 ); }
		}
		public int CntSyutsujinButaiList					// カウンタ
		{
			get { return this.Data.CntSyutsujinButaiList; }
			set
			{
				if ( value == this.CntSyutsujinButaiList ) { return; }
				this.Data.CntSyutsujinButaiList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntSyutsujinButaiList );
			}
		}
		public PointerlistType2 SyutsujinButaiList			// 出陣部隊リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrSyutsujinButaiList, DataKind.部隊 ); }
		}
		public int CntNinmuList								// カウンタ
		{
			get { return this.Data.CntNinmuList; }
			set
			{
				if ( value == this.CntNinmuList ) { return; }
				this.Data.CntNinmuList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntNinmuList );
			}
		}
		public PointerlistType2 NinmuList					// 任務中武将リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrNinmuList ); }
		}
		public int CntList_0068								// カウンタ
		{
			get { return this.Data.CntList_0068; }
			set
			{
				if ( value == this.CntList_0068 ) { return; }
				this.Data.CntList_0068 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntList_0068 );
			}
		}
		public PointerlistType2 List_0068					// リスト68
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrList_0068 ); }
		}
		public int CntKoudoukanouList						// カウンタ
		{
			get { return this.Data.CntKoudoukanouList; }
			set
			{
				if ( value == this.CntKoudoukanouList ) { return; }
				this.Data.CntKoudoukanouList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntKoudoukanouList );
				this.PropertyChanged.Raise( () => this.KoudoukanouList );
			}
		}
		public PointerlistType2 KoudoukanouList				// 行動可能武将リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrKoudoukanouList, DataKind.武将 ); }
		}
		public int CntList_0080								// カウンタ
		{
			get { return this.Data.CntList_0080; }
			set
			{
				if ( value == this.CntList_0080 ) { return; }
				this.Data.CntList_0080 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntList_0080 );
			}
		}
		public PointerlistType2 List_0080					// リスト80
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrList_0080 ); }
		}
		public int CntRouninList							// カウンタ
		{
			get { return this.Data.CntRouninList; }
			set
			{
				if ( value == this.CntRouninList ) { return; }
				this.Data.CntRouninList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntRouninList );
				this.PropertyChanged.Raise( () => this.RouninList );
			}
		}
		public PointerlistType2 RouninList					// 浪人リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrRouninList, DataKind.武将 ); }
		}
		public int CntList_0098								// カウンタ
		{
			get { return this.Data.CntList_0098; }
			set
			{
				if ( value == this.CntList_0098 ) { return; }
				this.Data.CntList_0098 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntList_0098 );
			}
		}
		public PointerlistType2 PtrList_0098				// リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrList_0098 ); }
		}
		public int CntSyuuhenButaiList						// カウンタ
		{
			get { return this.Data.CntSyuuhenButaiList; }
			set
			{
				if ( value == this.CntSyuuhenButaiList ) { return; }
				this.Data.CntSyuuhenButaiList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntSyuuhenButaiList );
			}
		}
		public PointerlistType2 SyuuhenButaiList			// 城周辺の部隊リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrSyuuhenButaiList, DataKind.部隊 ); }
		}
		public int CntTatemonoList							// カウンタ
		{
			get { return this.Data.CntTatemonoList; }
			set
			{
				if ( value == this.CntTatemonoList ) { return; }
				this.Data.CntTatemonoList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntTatemonoList );
			}
		}
		public PointerlistType2 TatemonoList				// 建物リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrTatemonoList, DataKind.建物 ); }
		}
		public uint h0108_4									// 0固定？
		{
			get { return this.Data.h0108_4; }
			set
			{
				if ( value == this.h0108_4 ) { return; }
				this.Data.h0108_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0108_4 );
			}
		}
		public uint h010C_4									// 0固定？
		{
			get { return this.Data.h010C_4; }
			set
			{
				if ( value == this.h010C_4 ) { return; }
				this.Data.h010C_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h010C_4 );
			}
		}
		public uint h0110_4									// 0固定？
		{
			get { return this.Data.h0110_4; }
			set
			{
				if ( value == this.h0110_4 ) { return; }
				this.Data.h0110_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0110_4 );
			}
		}
		public uint h0114_4									// 0固定？
		{
			get { return this.Data.h0114_4; }
			set
			{
				if ( value == this.h0114_4 ) { return; }
				this.Data.h0114_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0114_4 );
			}
		}
		public uint h0118_4									// 0固定？
		{
			get { return this.Data.h0118_4; }
			set
			{
				if ( value == this.h0118_4 ) { return; }
				this.Data.h0118_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0118_4 );
			}
		}
		public uint h011C_4									// 0固定？
		{
			get { return this.Data.h011C_4; }
			set
			{
				if ( value == this.h011C_4 ) { return; }
				this.Data.h011C_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h011C_4 );
			}
		}
		public uint h0120_4									// 0固定？
		{
			get { return this.Data.h0120_4; }
			set
			{
				if ( value == this.h0120_4 ) { return; }
				this.Data.h0120_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0120_4 );
			}
		}
		public uint h0124_4									// 0固定？
		{
			get { return this.Data.h0124_4; }
			set
			{
				if ( value == this.h0124_4 ) { return; }
				this.Data.h0124_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0124_4 );
			}
		}
		public uint h0128_4									// 0固定？
		{
			get { return this.Data.h0128_4; }
			set
			{
				if ( value == this.h0128_4 ) { return; }
				this.Data.h0128_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0128_4 );
			}
		}
		public uint h012C_4									// 0固定？
		{
			get { return this.Data.h012C_4; }
			set
			{
				if ( value == this.h012C_4 ) { return; }
				this.Data.h012C_4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h012C_4 );
			}
		}
		public ushort h0130_2								// 0固定？
		{
			get { return this.Data.h0130_2; }
			set
			{
				if ( value == this.h0130_2 ) { return; }
				this.Data.h0130_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0130_2 );
			}
		}
		public ushort h0132_2								// 0132h 2バイト
		{
			get { return this.Data.h0132_2; }
			set
			{
				if ( value == this.h0132_2 ) { return; }
				this.Data.h0132_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0132_2 );
			}
		}
		public byte h0134									// 0134h 1バイト
		{
			get { return this.Data.h0134; }
			set
			{
				if ( value == this.h0134 ) { return; }
				this.Data.h0134 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0134 );
			}
		}
		public byte h0135									// 0135h 1バイト
		{
			get { return this.Data.h0135; }
			set
			{
				if ( value == this.h0135 ) { return; }
				this.Data.h0135 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0135 );
			}
		}
		public byte h0136									// 0136h 1バイト
		{
			get { return this.Data.h0136; }
			set
			{
				if ( value == this.h0136 ) { return; }
				this.Data.h0136 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0136 );
			}
		}
		public byte h0137									// 0137h 1バイト
		{
			get { return this.Data.h0137; }
			set
			{
				if ( value == this.h0137 ) { return; }
				this.Data.h0137 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0137 );
			}
		}
		public byte h0138									// 0138h 1バイト
		{
			get { return this.Data.h0138; }
			set
			{
				if ( value == this.h0138 ) { return; }
				this.Data.h0138 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0138 );
			}
		}
		public byte h0139									// 0139h 1バイト
		{
			get { return this.Data.h0139; }
			set
			{
				if ( value == this.h0139 ) { return; }
				this.Data.h0139 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0139 );
			}
		}
		public byte h013A									// 013Ah 1バイト
		{
			get { return this.Data.h013A; }
			set
			{
				if ( value == this.h013A ) { return; }
				this.Data.h013A = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h013A );
			}
		}
		public byte h013B									// 013Bh 1バイト 用地関連のフラグ ゲーム内編集機能で全開にすると第7ビットが立つ
		{
			get { return this.Data.h013B; }
			set
			{
				if ( value == this.h013B ) { return; }
				this.Data.h013B = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h013B );
				this.PropertyChanged.Raise( () => this.IsYouchiZenkai );
				this.PropertyChanged.Raise( () => this.YouchiInfo );
			}
		}

		/// <summary>013Bh bit7 用地サイズ全開フラグ ゲーム内編集機能で全開にするとこのフラグが立つ</summary>
		public bool IsYouchiZenkai
		{
			get { return this.Data.IsYouchiZenkai; }
			set
			{
				if ( value == this.IsYouchiZenkai ) { return; }
				this.Data.IsYouchiZenkai = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.IsYouchiZenkai );
				this.PropertyChanged.Raise( () => this.h013B );
				this.PropertyChanged.Raise( () => this.YouchiInfo );
			}
		}
		public ushort h013C_2								// 013Ch 2バイト
		{
			get { return this.Data.h013C_2; }
			set
			{
				if ( value == this.h013C_2 ) { return; }
				this.Data.h013C_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h013C_2 );
			}
		}
		public ushort h013E_2								// 013Eh 2バイト
		{
			get { return this.Data.h013E_2; }
			set
			{
				if ( value == this.h013E_2 ) { return; }
				this.Data.h013E_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h013E_2 );
			}
		}
		public ushort h0140_2								// 0140h 2バイト
		{
			get { return this.Data.h0140_2; }
			set
			{
				if ( value == this.h0140_2 ) { return; }
				this.Data.h0140_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0140_2 );
			}
		}
		public ushort h0142_2								// 0142h 2バイト
		{
			get { return this.Data.h0142_2; }
			set
			{
				if ( value == this.h0142_2 ) { return; }
				this.Data.h0142_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0142_2 );
			}
		}
		public ushort h0144_2								// 0144h 2バイト
		{
			get { return this.Data.h0144_2; }
			set
			{
				if ( value == this.h0144_2 ) { return; }
				this.Data.h0144_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0144_2 );
			}
		}
		public ushort h0146_2								// 0146h 2バイト
		{
			get { return this.Data.h0146_2; }
			set
			{
				if ( value == this.h0146_2 ) { return; }
				this.Data.h0146_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0146_2 );
			}
		}
		public ushort h0148_2								// 0148h 2バイト
		{
			get { return this.Data.h0148_2; }
			set
			{
				if ( value == this.h0148_2 ) { return; }
				this.Data.h0148_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0148_2 );
			}
		}
		public ushort h014A_2								// 014Ah 2バイト
		{
			get { return this.Data.h014A_2; }
			set
			{
				if ( value == this.h014A_2 ) { return; }
				this.Data.h014A_2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h014A_2 );
			}
		}

		// 本城フラグ
		public bool IsHonjou
		{
			get
			{
				if ( this.Name.Contains( "*" ) )
				{
					return true;
				}

				return false;
			}
		}

		// 要所データ
		public Yousyo Yousyo
		{ get { return this.N14pkb.Yousyolist.GetDataByKyotenAddress( this.Address ); } }

		// 要所名
		public string YousyoName
		{ get { return ( this.Yousyo != null ) ? this.Yousyo.Name : string.Empty; } }

		// 最大用地サイズ
		public int YouchiSizeMax
		{
			get
			{
				if ( this.Yousyo == null )
				{
					return -1;
				}

				if ( this.IsYouchiZenkai )
				{
					return 20;
				}

				// 用地サイズに使用しているParamデータを特定し、用地サイズを取得する
				var paramname = string.Empty;
				if ( this.IsHonjou )
				{
					paramname += "COST_N14PK_HONJOU_";
				}
				else
				{
					paramname += "COST_N14PK_SHIJOU_";
				}

				if ( ( this.Yousyo.h3E & Convert.ToByte( "00000100", 2 ) ) != 0 )
				{
					paramname += "YAMAJIRO_";
				}
				else
				{
					paramname += "HIRAJIRO_";
				}

				paramname += "MAX_LV" + this.Data.YouchiLV;
				var param = this.N14pkb.Paramlist[paramname];
				if ( param == null )
				{
					return -1;
				}

				return param.Value / 10;
			}
		}

		// 使用済み用地サイズ
		public int YouchiSizeUsed
		{
			get
			{
				var ptrlist = new uint[] { this.PtrJoukaku1, this.PtrJoukaku2, this.PtrJoukaku3, this.PtrJoukaku4, this.PtrJoukaku5, this.PtrJoukaku6, this.PtrJoukaku7 };
				var youchi = 0;
				foreach ( var ptr in ptrlist )
				{
					var joukaku = this.N14pkb.Joukakulist[ptr];
					if ( joukaku == null )
					{
						continue;
					}
					youchi += joukaku.Youchi;
				}

				return youchi / 10;
			}
		}

		// 用地情報(使用済み/最大用地数)
		public string YouchiInfo
		{
			get { return this.YouchiSizeUsed.ToString().PadLeft( 2 ) + "/" + this.YouchiSizeMax.ToString().PadLeft( 2 ); }
		}

		// 区画リスト
		public Kukaku[] Kukakulist { get; private set; }

		// 拡張済み区画数
		public int KukakuCountKakuchou
		{
			get
			{
				var cnt = 0;
				foreach ( var d in this.Kukakulist )
				{
					if ( d.IsKakuchouzumi )
					{
						cnt++;
					}
				}
				return cnt;
			}
		}

		// 使用可能区画数(拡張可能含む)
		public byte KukakuUsed								// 2E45h 1バイト
		{
			get { return this.Data.KukakuUsed; }
			set
			{
				if ( value == this.KukakuUsed ) { return; }
				this.Data.KukakuUsed = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.KukakuUsed );
			}
		}

		// 区画情報(拡張済み+拡張可/最大区画数)
		public string KukakuInfo
		{
			get
			{
				var str = string.Empty;
				str += this.KukakuCountKakuchou.ToString().PadLeft( 2 );

				var kakuchoukanou = this.Data.KukakuUsed - this.KukakuCountKakuchou;
				if ( 0 < kakuchoukanou )
				{
					str += "+" + kakuchoukanou;
				}
				str += "/" + this.Data.KukakuMax.ToString().PadLeft( 2 );

				return str;
			}
		}

		// 区画内訳
		public string KukakuUchiwake
		{
			get
			{
				switch ( this.Data.KukakuMax )
				{
					case 0:
						return "-";

					case 3:
						return "農1/商1/兵1";

					default:
						var nougyou = 0;
						var syougyou = 0;
						var heisya = 0;
						foreach ( var d in this.Kukakulist )
						{
							if ( d.KokudakaMax != 0 )
							{
								nougyou++;
							}
							else if ( d.SyougyouMax != 0 )
							{
								syougyou++;
							}
							else if ( d.HeisyaMax != 0 )
							{
								heisya++;
							}
						}

						return "農" + nougyou + "/商" + syougyou + "/兵" + heisya;
				}
			}
		}

		// 城主
		public Busyou Jousyu
		{
			get { return this.N14pkb.Busyoulist[this.PtrJousyu]; }
		}

		// 奉行
		public Busyou Bugyou
		{
			get { return this.N14pkb.Busyoulist[this.PtrBugyou]; }
		}

		// 軍団
		public Gundan Gundan
		{
			get { return this.N14pkb.Gundanlist[this.Data.PtrGundan]; }
		}

		// 勢力
		public Seiryoku Seiryoku
		{
			get
			{
				return ( this.Gundan != null ) ? this.N14pkb.Seiryokulist[this.Gundan.Data.PtrSeiryoku] : null;
			}
		}

		// 建物
		private Tatemono Tatemono
		{
			get { return this.N14pkb.Tatemonolist[this.Data.PtrTatemono]; }
		}

		// 城名読み
		public string Yomi
		{
			get { return this.N14pkb.ShiroNamelist.GetYomiByAddress( this.Data.PtrShiroName ); }
		}

		// 現在耐久
		public short TaikyuuNow
		{
			get { return ( this.Tatemono != null ) ? this.Tatemono.TaikyuuNow : (short)( -1 ); }
			set
			{
				if ( value == this.TaikyuuNow ) { return; }
				if ( this.Tatemono != null )
				{
					this.Tatemono.TaikyuuNow = value;
				}
				this.PropertyChanged.Raise( () => this.TaikyuuNow );
			}
		}

		// 国
		public string Kuni
		{
			get { return ( this.Tatemono != null ) ? this.Tatemono.Kuni : string.Empty; }
		}

		// 建物の施設名(城の種類)
		public string Shisetsuname
		{
			get { return ( this.Tatemono != null ) ? this.N14pkb.Shisetsulist.GetNameByID( this.Tatemono.ShisetsuID ) : string.Empty; }
		}

		// 鉱山数
		public int Kouzan
		{
			get
			{
				if ( this.TatemonoList.Count == 0 )
				{
					return 0;
				}
				var cnt = 0;
				foreach ( var d in this.TatemonoList.Items )
				{
					if ( ( this.N14pkb.Tatemonolist[d.PtrTargetData].ShisetsuID == 56 )		// 金山
						|| ( this.N14pkb.Tatemonolist[d.PtrTargetData].ShisetsuID == 57 )	// 銀山
						)
					{
						cnt++;
					}
				}
				return cnt;
			}
		}

		// 港数
		public int Minato
		{
			get
			{
				if ( this.TatemonoList.Count == 0 )
				{
					return 0;
				}
				var cnt = 0;
				foreach ( var d in this.TatemonoList.Items )
				{
					if ( this.N14pkb.Tatemonolist[d.PtrTargetData].ShisetsuID == 53 )		// 港
					{
						cnt++;
					}
				}
				return cnt;
			}
		}

		// 商業港数
		public int Syougyoukou
		{
			get
			{
				if ( this.TatemonoList.Count == 0 )
				{
					return 0;
				}
				var cnt = 0;
				foreach ( var d in this.TatemonoList.Items )
				{
					if ( this.N14pkb.Tatemonolist[d.PtrTargetData].ShisetsuID == 54 )		// 商業港
					{
						cnt++;
					}
				}
				return cnt;
			}
		}

		// 軍港数
		public int Gunkou
		{
			get
			{
				if ( this.TatemonoList.Count == 0 )
				{
					return 0;
				}
				var cnt = 0;
				foreach ( var d in this.TatemonoList.Items )
				{
					if ( this.N14pkb.Tatemonolist[d.PtrTargetData].ShisetsuID == 55 )		// 軍港
					{
						cnt++;
					}
				}
				return cnt;
			}
		}


		// ソートID リスト作成時に要所リストを元にセット
		//public int SortID { get; set; }
		public int SortID
		{
			get { return this.N14pkb.Yousyolist.GetSortIDByKyotenAddress( this.Data.Address ); }
		}

		/// <summary>コンストラクタ 城</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Shiro( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Shirotable[id];
			this.Kukakulist = new Kukaku[this.Data.Kukaku.Length];
			for ( var i = 0; i < this.Data.Kukaku.Length; i++ )
			{
				this.Kukakulist[i] = new Kukaku( this, i );
			}
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			throw new NotSupportedException();
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			throw new NotSupportedException();
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Shirotable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Shirolist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:城:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}


		/// <summary>城郭変更時の耐久チェック(城郭変更に伴う兵数ブーストなどとは異なり、耐久変化は自動処理されない)</summary>
		private void CheckTaikyuu( uint ptrOld, uint ptrNew )
		{
			var oldJoukaku = this.N14pkb.Joukakulist[ptrOld];
			var newJoukaku = this.N14pkb.Joukakulist[ptrNew];
			var sabun = (short)( newJoukaku.Taikyuu - oldJoukaku.Taikyuu );
			if ( sabun != 0 )
			{
				this.TaikyuuMax += sabun;
				if ( 0 < sabun )
				{
					this.TaikyuuNow += sabun;
				}
				if ( this.TaikyuuMax < this.TaikyuuNow )
				{
					this.TaikyuuNow = this.TaikyuuMax;
				}
			}
		}
	}
}
