﻿// Kokujin.cs

using System;
using System.ComponentModel;
using System.Linq;

using N14PKBrowse.HelperClass;
using N14PKLibrary;
using N14PKLibrary.Data;

namespace N14PKBrowse.Data
{
	/// <summary>国人衆ビューで使用するデータクラス</summary>
	public class Kokujin : IBrowseData, INotifyPropertyChanged
	{
		/// <summary>未加工の国人衆データ</summary>
		public KokujinData Data { get; private set; }

		/// <summary>ツール管理</summary>
		public N14PKB N14pkb { get; private set; }


		public int ID							// ID
		{
			get { return this.Data.ID; }
		}
		public uint Address						// アドレス
		{
			get { return this.Data.Address; }
		}
		public string AddressHex				// アドレス(16進表示用)
		{
			get { return this.Data.Address.ToString( "X8" ); }
		}

		public string Name						// 名称
		{
			get { return this.Data.Name; }
			set
			{
				if ( value == this.Name ) { return; }
				this.Data.Name = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Name );
				this.SetRefreshFlag();
			}
		}
		public string Yomi						// 読み
		{
			get { return this.Data.Yomi; }
			set
			{
				if ( value == this.Yomi ) { return; }
				this.Data.Yomi = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Yomi );
			}
		}
		public string Touryou					// 頭領
		{
			get { return this.N14pkb.Busyoulist.GetNameByAddress( this.Data.PtrTouryou ); }
			set
			{
				if ( value == Touryou ) { return; }
				this.Data.PtrTouryou = this.N14pkb.Busyoulist.GetAddressByName( value );
				this.Write();
				this.PropertyChanged.Raise( () => this.Touryou );
			}
		}
		public string TorikomiBusyou			// 取込時に配下となる武将
		{
			get { return this.N14pkb.Busyoulist.GetNameByAddress( this.Data.PtrTorikomiBusyou ); }
			set
			{
				if ( value == this.TorikomiBusyou ) { return; }
				this.Data.PtrTorikomiBusyou = this.N14pkb.Busyoulist.GetAddressByName( value );
				this.Write();
				this.PropertyChanged.Raise( () => this.TorikomiBusyou );
			}
		}

		public int TokunouID					// 特能
		{
			get { return this.Data.TokunouID; }
			set
			{
				if ( value == this.TokunouID ) { return; }
				this.Data.TokunouID = (byte)value;
				this.Write();
				this.PropertyChanged.Raise( () => this.TokunouID );
			}
		}
		public int Heisuu						// 現兵数
		{
			get { return this.Data.Heisuu; }
			set
			{
				if ( value == this.Heisuu ) { return; }
				this.Data.Heisuu = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Heisuu );
			}
		}
		public short HeisuuMax					// 最大兵数
		{
			get { return this.Data.HeisuuMax; }
			set
			{
				if ( value == this.HeisuuMax ) { return; }
				this.Data.HeisuuMax = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.HeisuuMax );
			}
		}

		public string Kuni						// 国
		{
			get { return this.Yousyo.Kuni; }
		}
		public string Yousyoname				// 要所
		{
			get { return this.Yousyo.Name; }
		}
		public uint PtrSyozokuSeiryoku			// 所属勢力
		{
			get { return this.Data.PtrSyozokuSeiryoku; }
			set
			{
				if ( value == this.PtrSyozokuSeiryoku ) { return; }
				this.Data.PtrSyozokuSeiryoku = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrSyozokuSeiryoku );
			}
		}

		// 支持勢力データ 8バイト * 6勢力
		public uint PtrShijiSeiryoku1			// 支持勢力1
		{
			get { return this.Data.PtrShijiSeiryoku1; }
			set
			{
				if ( value == this.PtrShijiSeiryoku1 ) { return; }
				this.Data.PtrShijiSeiryoku1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrShijiSeiryoku1 );
			}
		}
		public byte h0D0						// 0D0h 1バイト
		{
			get { return this.Data.h0D0; }
			set
			{
				if ( value == this.h0D0 ) { return; }
				this.Data.h0D0 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0D0 );
			}
		}
		public sbyte Shijiritsu1				// 支持率1
		{
			get { return this.Data.Shijiritsu1; }
			set
			{
				if ( value == this.Shijiritsu1 ) { return; }
				this.Data.Shijiritsu1 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Shijiritsu1 );
			}
		}

		public uint PtrShijiSeiryoku2			// 支持勢力2
		{
			get { return this.Data.PtrShijiSeiryoku2; }
			set
			{
				if ( value == this.PtrShijiSeiryoku2 ) { return; }
				this.Data.PtrShijiSeiryoku2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrShijiSeiryoku2 );
			}
		}
		public byte h0D8						// 0D8h 1バイト
		{
			get { return this.Data.h0D8; }
			set
			{
				if ( value == this.h0D8 ) { return; }
				this.Data.h0D8 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0D8 );
			}
		}
		public sbyte Shijiritsu2				// 支持率2
		{
			get { return this.Data.Shijiritsu2; }
			set
			{
				if ( value == this.Shijiritsu2 ) { return; }
				this.Data.Shijiritsu2 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Shijiritsu2 );
			}
		}

		public uint PtrShijiSeiryoku3			// 支持勢力3
		{
			get { return this.Data.PtrShijiSeiryoku3; }
			set
			{
				if ( value == this.PtrShijiSeiryoku3 ) { return; }
				this.Data.PtrShijiSeiryoku3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrShijiSeiryoku3 );
			}
		}
		public byte h0E0						// 0E0h 1バイト
		{
			get { return this.Data.h0E0; }
			set
			{
				if ( value == this.h0E0 ) { return; }
				this.Data.h0E0 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0E0 );
			}
		}
		public sbyte Shijiritsu3				// 支持率3
		{
			get { return this.Data.Shijiritsu3; }
			set
			{
				if ( value == this.Shijiritsu3 ) { return; }
				this.Data.Shijiritsu3 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Shijiritsu3 );
			}
		}

		public uint PtrShijiSeiryoku4			// 支持勢力4
		{
			get { return this.Data.PtrShijiSeiryoku4; }
			set
			{
				if ( value == this.PtrShijiSeiryoku4 ) { return; }
				this.Data.PtrShijiSeiryoku4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrShijiSeiryoku4 );
			}
		}
		public byte h0E8						// 0E8h 1バイト
		{
			get { return this.Data.h0E8; }
			set
			{
				if ( value == this.h0E8 ) { return; }
				this.Data.h0E8 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0E8 );
			}
		}
		public sbyte Shijiritsu4				// 支持率4
		{
			get { return this.Data.Shijiritsu4; }
			set
			{
				if ( value == this.Shijiritsu4 ) { return; }
				this.Data.Shijiritsu4 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Shijiritsu4 );
			}
		}

		public uint PtrShijiSeiryoku5			// 支持勢力5
		{
			get { return this.Data.PtrShijiSeiryoku5; }
			set
			{
				if ( value == this.PtrShijiSeiryoku5 ) { return; }
				this.Data.PtrShijiSeiryoku5 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrShijiSeiryoku5 );
			}
		}
		public byte h0F0						// 0F0h 1バイト
		{
			get { return this.Data.h0F0; }
			set
			{
				if ( value == this.h0F0 ) { return; }
				this.Data.h0F0 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0F0 );
			}
		}
		public sbyte Shijiritsu5				// 支持率5
		{
			get { return this.Data.Shijiritsu5; }
			set
			{
				if ( value == this.Shijiritsu5 ) { return; }
				this.Data.Shijiritsu5 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Shijiritsu5 );
			}
		}

		public uint PtrShijiSeiryoku6			// 支持勢力6
		{
			get { return this.Data.PtrShijiSeiryoku6; }
			set
			{
				if ( value == this.PtrShijiSeiryoku6 ) { return; }
				this.Data.PtrShijiSeiryoku6 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.PtrShijiSeiryoku6 );
			}
		}
		public byte h0F8						// 0F8h 1バイト
		{
			get { return this.Data.h0F8; }
			set
			{
				if ( value == this.h0F8 ) { return; }
				this.Data.h0F8 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.h0F8 );
			}
		}
		public sbyte Shijiritsu6				// 支持率6
		{
			get { return this.Data.Shijiritsu6; }
			set
			{
				if ( value == this.Shijiritsu6 ) { return; }
				this.Data.Shijiritsu6 = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.Shijiritsu6 );
			}
		}

		public int CntButaiList					// カウンタ
		{
			get { return this.Data.CntButaiList; }
			set
			{
				if ( value == this.CntButaiList ) { return; }
				this.Data.CntButaiList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntButaiList );
			}
		}
		public PointerlistType2 PtrButaiList	// 部隊リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrButaiList, DataKind.部隊 ); }
		}

		public int CntShiroList					// カウンタ
		{
			get { return this.Data.CntShiroList; }
			set
			{
				if ( value == this.CntShiroList ) { return; }
				this.Data.CntShiroList = value;
				this.Write();
				this.PropertyChanged.Raise( () => this.CntShiroList );
			}
		}
		public PointerlistType2 ShiroList		// 城リスト
		{
			get { return PointerlistType2.Create( this.N14pkb, this.Data.PtrShiroList, 0x10 ); }
		}


		// 最高支持勢力
		public Seiryoku SaikoushijiSeiryoku
		{
			get
			{
				if ( this.Data.PtrSyozokuSeiryoku != 0 )
				{
					return this.N14pkb.Seiryokulist[this.Data.PtrSyozokuSeiryoku];
				}
				uint[] ptrSeiryoku = new[]
				{
					this.Data.PtrShijiSeiryoku1, this.Data.PtrShijiSeiryoku2, this.Data.PtrShijiSeiryoku3,
					this.Data.PtrShijiSeiryoku4, this.Data.PtrShijiSeiryoku5, this.Data.PtrShijiSeiryoku6
				};
				sbyte[] shijiritsu = new[] { this.Shijiritsu1, this.Shijiritsu2, this.Shijiritsu3, this.Shijiritsu4, this.Shijiritsu5, this.Shijiritsu6 };

				var index = Array.FindIndex( shijiritsu, d => d == shijiritsu.Max() );
				return ( index != -1 ) ? this.N14pkb.Seiryokulist[ptrSeiryoku[index]] : null;
			}
		}
		// 要所
		public Yousyo Yousyo
		{
			get { return this.N14pkb.Yousyolist.GetDataByKyotenAddress( this.Data.Address ); }
		}

		/// <summary>コンストラクタ 国人衆</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="id">データID</param>
		public Kokujin( N14PKB n14pkb, int id )
		{
			this.N14pkb = n14pkb;
			this.Data = n14pkb.N14pk.Kokujintable[id];
		}

		/// <summary>国人衆名を参照しているビューのリフレッシュフラグをセット</summary>
		private void SetRefreshFlag()
		{
			this.N14pkb.View.Flags[(int)Enums.TabKind.部隊].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.要所].NeedsRefresh = true;
			this.N14pkb.View.Flags[(int)Enums.TabKind.街道].NeedsRefresh = true;
		}

		/// <summary>データセーブ用のバイト列を返す</summary>
		public byte[] GetSaveData()
		{
			throw new NotSupportedException();
		}

		/// <summary>セーブデータを反映する</summary>
		public void SetSaveData( byte[] buff )
		{
			throw new NotSupportedException();
		}

		/// <summary>メモリ書き込みとコミットするデータID登録
		/// (コミットするまでプロセスメモリには反映しない)</summary>
		private void Write()
		{
			this.N14pkb.N14pk.Kokujintable.Write( this.ID, this.Data.GetRecord() );
			this.N14pkb.Kokujinlist.CommitID = this.ID;
		}

		/// <summary>INotifyPropertyChanged メンバ</summary>
		public event PropertyChangedEventHandler PropertyChanged;

		/// <summary>プロパティ変更時</summary>
		public void OnPropertyChanged( object sender, PropertyChangedEventArgs e )
		{
#if DEBUG
			System.Diagnostics.Debug.WriteLine( "PropertyChanged:国人衆:" + ( sender as IBrowseData ).Name + " Property:" + e.PropertyName );
#endif
		}
	}
}
