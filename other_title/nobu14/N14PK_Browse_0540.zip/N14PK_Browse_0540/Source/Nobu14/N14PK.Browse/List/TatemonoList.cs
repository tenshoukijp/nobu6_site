﻿// TatemonoList.cs

using System;

using N14PKBrowse.Data;
using N14PKBrowse.Enums;

namespace N14PKBrowse.List
{
	/// <summary>建物リスト</summary>
	public class TatemonoList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Tatemono[] _items;

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public TatemonoList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.建物 )
		{
			this._items = base._items as Tatemono[];
			this.FilterCallback = new Predicate<object>( this._filterCallback );
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<Tatemono> GetEnumerator()
		//{
		//	for ( var i = 0; i < this.Count; i++ )
		//	{
		//		yield return Array.Find( this._items, d => d.ID == i );
		//	}
		//}

		/// <summary>インデクサ</summary>
		public new Tatemono this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Tatemono this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 建物名</summary>
		public Tatemono this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}

		public override Predicate<object> FilterCallback { get; set; }
		/// <summary>フィルタ用コールバック</summary>
		private bool _filterCallback( object obj )
		{
			var d = obj as Tatemono;

			if ( d == null )
			{
				return false;
			}

			return ( this._n14pkb.View.CheckSeiryoku( ( d.Seiryoku != null ) ? d.Seiryoku.Address : 0 ) );
		}
	}
}
