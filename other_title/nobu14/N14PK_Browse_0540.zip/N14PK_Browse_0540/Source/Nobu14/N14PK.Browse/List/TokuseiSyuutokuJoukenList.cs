﻿// TokuseiSyuutokuJoukenList.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Data;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;

namespace N14PKBrowse.List
{
	/// <summary>特性習得条件リスト</summary>
	public class TokuseiSyuutokuJoukenList : DataList
	{
		/// <summary>リスト本体</summary>
		private new TokuseiSyuutokuJouken[] _items;

		/// <summary>特性習得条件名リスト</summary>
		private List<string> _namelist;

		/// <summary>特性習得条件名リスト</summary>
		// IDと名前をペアにしたもの(N14PKBrowse.NameList<int>)を使用すると成長型ビューのコンボソースで大量に使用されるため表示時のパフォーマンスが低下する。
		// そのため名前だけのリスト(List<string>)にする。
		// 同一名のデータがある場合は常にリスト前方のデータにヒットする。
		public List<string> Namelist
		{
			get
			{
				if ( this._namelist == null )
				{
					this._namelist = new List<string>();
				}

				return this._namelist;
			}
		}
		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public TokuseiSyuutokuJoukenList(N14PKB n14pkb )
			:base ( n14pkb, TabKind.習得条件 )
		{
			this._items = base._items as TokuseiSyuutokuJouken[];
			this.SetNamelist();
		}

		/// <summary>コンボボックスなどで使用する名称リストセット</summary>
		private void SetNamelist()
		{
			this.Namelist.Clear();
			var array = (TokuseiSyuutokuJouken[])this._items.Clone();
			Array.Sort( array, ( x, y ) => x.ID - y.ID );
			foreach ( var d in array )
			{
				this.Namelist.Add( d.Name );
			}
			this.Namelist.Add( string.Empty );
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<TokuseiSyuutokuJouken> GetEnumerator()
		//{
		//	for ( var i = 0; i < this.Count; i++ )
		//	{
		//		yield return Array.Find( this._items, d => d.ID == i );
		//	}
		//}

		/// <summary>インデクサ</summary>
		public new TokuseiSyuutokuJouken this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}


		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public TokuseiSyuutokuJouken this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 特性習得条件名</summary>
		public TokuseiSyuutokuJouken this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}
	}
}
