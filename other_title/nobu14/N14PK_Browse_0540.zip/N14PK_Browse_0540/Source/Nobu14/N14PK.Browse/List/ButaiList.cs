﻿// ButaiList.cs

using System;

using N14PKBrowse.Data;
using N14PKBrowse.Enums;

namespace N14PKBrowse.List
{
	/// <summary>部隊リスト</summary>
	public class ButaiList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Butai[] _items;

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public ButaiList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.部隊 )
		{
			this._items = base._items as Butai[];
			this.FilterCallback = new Predicate<object>( this._filterCallback );
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<Butai> GetEnumerator()
		//{
		//	for ( var i = 0; i < this.Count; i++ )
		//	{
		//		yield return this._items[i];
		//	}
		//}

		/// <summary>インデクサ</summary>
		public new Butai this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Butai this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 部隊名</summary>
		public Butai this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}

		public override Predicate<object> FilterCallback { get; set; }
		/// <summary>フィルタ用コールバック</summary>
		private bool _filterCallback( object obj )
		{
			var d = obj as Butai;

			if ( d == null )
			{
				return false;
			}

			return ( this._n14pkb.View.CheckSeiryoku( ( d.Seiryoku != null ) ? d.Seiryoku.Address : 0 ) );
		}
	}
}
