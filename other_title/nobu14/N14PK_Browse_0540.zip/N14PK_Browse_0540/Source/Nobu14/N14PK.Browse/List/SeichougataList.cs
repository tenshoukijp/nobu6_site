﻿// SeichougataList.cs

using System;

using N14PKBrowse.Data;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;

namespace N14PKBrowse.List
{
	/// <summary>成長型リスト</summary>
	public class SeichougataList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Seichougata[] _items;

		/// <summary>成長型名リスト ※ソートID順</summary>
		private NameList<int> _namelist;

		/// <summary>成長型名リスト ※ソートID順</summary>
		public NameList<int> Namelist
		{
			get
			{
				if ( this._namelist == null )
				{
					this._namelist = new NameList<int>();
				}
				return this._namelist;
			}
		}
		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public SeichougataList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.成長型 )
		{
			this._items = base._items as Seichougata[];
			Array.Sort( this._items, ( x, y ) => x.SortID - y.SortID );
			this.SetNamelist();
		}

		/// <summary>コンボボックスなどで使用する名称リストセット</summary>
		private void SetNamelist()
		{
			var array = (Seichougata[])this._items.Clone();
			Array.Sort( array, ( x, y ) => x.SortID - y.SortID );

			this.Namelist.Clear();
			foreach ( var d in array )
			{
				if ( !string.IsNullOrEmpty( d.Name ) )
				{
					this.Namelist.Add( d.ID, d.Name );
				}
			}
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<Seichougata> GetEnumerator()
		//{
		//	for ( var i = 0; i < this._items.Length; i++ )
		//	{
		//		yield return Array.Find( this._items, d => d.ID == i );
		//	}
		//}

		/// <summary>インデクサ データID</summary>
		public new Seichougata this[int id]
		{
			get
			{
				return Array.Find( this._items, d => d.ID == id );
			}
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Seichougata this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 成長型名</summary>
		public Seichougata this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}
	}
}
