﻿// ParamList.cs

using System;
using System.Collections;
using System.Collections.Generic;
using N14PKBrowse.Data;
using N14PKLibrary;
using N14PKBrowse.Enums;
using System.IO;
namespace N14PKBrowse.List
{
	/// <summary>Paramリスト</summary>
	public class ParamList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Param[] _items;
		/// <summary>リスト本体</summary>
		public override IBrowseData[] Items
		{
			get { return this._items; }
		}

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public ParamList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.Param )
		{
			if ( n14pkb.N14pk.Paramtable.RecordCount == 0 ) { return; }

			var list = new List<Param>();
			foreach ( var d in n14pkb.N14pk.Paramtable )
			{
				var param = new Param( n14pkb, d.ID );
				param.PropertyChanged += param.OnPropertyChanged;
				list.Add( param );
			}
			this._items = list.ToArray();
		}

		/// <summary>インデクサ</summary>
		public new Param this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Param this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ Param</summary>
		public Param this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}

		/// <summary>リスト内アイテム数</summary>
		public override int Count
		{
			get { return this._items.Length; }
		}

		/// <summary>プロセスメモリにデータを書き込む</summary>
		public override void Commit()
		{
			if ( this.CommitIDList != null )
			{
				this._n14pkb.N14pk.Paramtable.Commit( this.CommitIDList );
				this.CommitIDList = null;
			}
		}

		/// <summary>データセーブ</summary>
		public override void DataSave( BinaryWriter bw, int[] ids )
		{
			bw.Write( sizeof( int ) );
			bw.Write( ids.Length );
			foreach ( var id in ids )
			{
				bw.Write( id );
				bw.Write( this[id].GetSaveData() );
			}
		}

		/// <summary>データロード</summary>
		public override void DataLoad( FileStream fs, int size, int count )
		{
			if ( size != sizeof( int ) )
			{
				// レコードサイズが異なる→データ構造変化により復元不可
				throw new ApplicationException( "データ構造が保存時と異なるため読み込みを中止します。" );
			}

			byte[] idbytes = new byte[sizeof( UInt32 )];	// ID用バッファ
			byte[] buff = new byte[size];	// データ用バッファ
			for ( int i = 0; i < count; i++ )
			{
				// 保存データのID読込
				fs.Read( idbytes, 0, 4 );
				var id = BitConverter.ToInt32( idbytes, 0 );

				// 保存データ読込
				fs.Read( buff, 0, size );

				this[id].SetSaveData( buff );
			}
			this.Commit();
		}
	}
}
