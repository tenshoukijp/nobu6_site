﻿// YousyoList.cs

using System;
using System.Collections;
using System.Collections.Generic;
using N14PKBrowse.Data;
using N14PKLibrary;
using N14PKBrowse.Enums;

namespace N14PKBrowse.List
{
	/// <summary>要所リスト</summary>
	public class YousyoList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Yousyo[] _items;

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public YousyoList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.要所 )
		{
			this._items = base._items as Yousyo[];
			this.FilterCallback = new Predicate<object>( this._filterCallback );
		}

		/// <summary>拠点ソート時に参照するソートIDをセットする</summary>
		public void SetSortID()
		{
			var array = (Yousyo[])this._items.Clone();
			// 要所ID→国ポインタでソート、これで国→本城→支城(国人衆含む) の順になる
			Array.Sort( array, ( x, y ) => ( x.Data.PtrKuni != y.Data.PtrKuni ) ? ( (int)x.Data.PtrKuni - (int)y.Data.PtrKuni ) : ( x.Data.ID - y.Data.ID ) );

			var id = 0;
			foreach ( var d in array )
			{
				this[d.ID].SortID = id++;
			}
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<Yousyo> GetEnumerator()
		//{
		//	for ( var i = 0; i < this.Count; i++ )
		//	{
		//		yield return Array.Find( this._items, d => d.ID == i );
		//	}
		//}

		/// <summary>インデクサ</summary>
		public new Yousyo this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Yousyo this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 要所名</summary>
		public Yousyo this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}

		/// <summary>拠点アドレスからソートIDを取得する</summary>
		/// <param name="address">拠点(城・国人衆)アドレス</param>
		/// <returns>ソートID</returns>
		public int GetSortIDByKyotenAddress( uint address )
		{
			if ( address == 0 ) { return -1; }
			var data = Array.Find( this._items, d => d.Data.PtrKyoten == address );

			return ( data != null ) ? data.SortID : -1;
		}

		/// <summary>拠点アドレスから要所データを取得する</summary>
		/// <param name="address">拠点(城・国人衆)アドレス</param>
		/// <returns>ソートID</returns>
		public Yousyo GetDataByKyotenAddress( uint address )
		{
			if ( address == 0 ) { return null; }
			return Array.Find( this._items, d => d.Data.PtrKyoten == address );
		}

		public override Predicate<object> FilterCallback { get; set; }
		/// <summary>フィルタ用コールバック</summary>
		private bool _filterCallback( object obj )
		{
			var d = obj as Yousyo;

			if ( d == null )
			{
				return false;
			}

			return ( this._n14pkb.View.CheckSeiryoku( ( d.Shiro != null ) ? d.Shiro.Seiryoku.Address : 0 ) );
		}
	}
}
