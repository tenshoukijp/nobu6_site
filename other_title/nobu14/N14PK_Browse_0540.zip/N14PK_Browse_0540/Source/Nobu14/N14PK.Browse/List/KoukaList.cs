﻿// KoukaList.cs

using System;

using N14PKBrowse.Data;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;

namespace N14PKBrowse.List
{
	/// <summary>効果リスト</summary>
	public class KoukaList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Kouka[] _items;

		/// <summary>効果名リスト</summary>
		private NameList<int> _namelist;

		/// <summary>効果名リスト</summary>
		public NameList<int> Namelist
		{
			get
			{
				if ( this._namelist == null )
				{
					this._namelist = new NameList<int>();
				}
				return this._namelist;
			}
		}

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public KoukaList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.効果 )
		{
			this._items = base._items as Kouka[];
					this.SetNamelist();
			//this._namelist = null;
		}

		/// <summary>コンボボックスなどで使用する名称リストセット</summary>
		public void SetNamelist()
		{
			this.Namelist.Clear();
			var array = (Kouka[])this._items.Clone();
			Array.Sort( array, ( x, y ) => x.ID - y.ID );
			foreach ( var d in array )
			{
				if ( !string.IsNullOrEmpty( d.Name ) )
				{
					this.Namelist.Add( d.ID, d.Name );
				}
			}
			// 末尾に空白挿入
			this.Namelist.Add( -1, string.Empty );
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<Kouka> GetEnumerator()
		//{
		//	for ( var i = 0; i < this.Count; i++ )
		//	{
		//		yield return Array.Find( this._items, d => d.ID == i );
		//	}
		//}

		/// <summary>インデクサ</summary>
		public new Kouka this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Kouka this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 効果名</summary>
		public Kouka this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}
	}
}
