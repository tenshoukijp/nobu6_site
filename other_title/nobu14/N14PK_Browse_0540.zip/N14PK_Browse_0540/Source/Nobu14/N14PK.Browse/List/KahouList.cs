﻿// KahouList.cs

using System;

using N14PKBrowse.Data;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;

namespace N14PKBrowse.List
{
	/// <summary>家宝リスト</summary>
	public class KahouList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Kahou[] _items;

		/// <summary>家宝名リスト</summary>
		private NameList<uint> _namelist;

		/// <summary>家宝名リスト</summary>
		public NameList<uint> Namelist
		{
			get
			{
				if ( this._namelist == null )
				{
					this._namelist = new NameList<uint>();
				}
				return this._namelist;
			}
		}

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public KahouList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.家宝 )
		{
			this._items = base._items as Kahou[];
			this.SetSortID();
			Array.Sort( this._items, ( x, y ) => ( x.SortID - y.SortID ) );
			this.SetNamelist();

		}

		/// <summary>ソートIDをセットする</summary>
		public void SetSortID()
		{
			var array = (Kahou[])this._items.Clone();
			// 等級→種類→分類IDでソート
			Array.Sort( array, ( x, y ) => ( x.Data.KahouTypeID != y.Data.KahouTypeID ) ? (int)( x.Data.KahouTypeID - y.Data.KahouTypeID )
				: ( x.Data.ToukyuuID != y.Data.ToukyuuID ) ? -1 * (int)( x.Data.ToukyuuID - y.Data.ToukyuuID )
				: (int)( x.Data.BunruiID - y.Data.BunruiID )
				);

			var id = 0;
			foreach ( var d in array )
			{
				this[d.ID].SortID = id++;
			}
		}

		/// <summary>コンボボックスなどで使用する名称リストセット</summary>
		public void SetNamelist()
		{
			this.Namelist.Clear();
			var array = (Kahou[])this._items.Clone();
			Array.Sort( array, ( x, y ) => x.SortID - y.SortID );
			foreach ( var d in array )
			{
				if ( !string.IsNullOrEmpty( d.Name ) )
				{
					this.Namelist.Add( d.Address, Helper.家宝等級[(int)d.ToukyuuID] + Helper.家宝種類[(int)d.KahouTypeID] + ":" + d.Name );
				}
			}
			// 末尾に空白挿入
			this.Namelist.Add( 0U, string.Empty );
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<Kahou> GetEnumerator()
		//{
		//	for ( var i = 0; i < this.Count; i++ )
		//	{
		//		yield return Array.Find( this._items, d => d.ID == i );
		//	}
		//}

		/// <summary>インデクサ</summary>
		public new Kahou this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Kahou this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 家宝名</summary>
		public Kahou this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}
	}
}
