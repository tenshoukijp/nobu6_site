﻿// SenpouList.cs

using System;

using N14PKBrowse.Data;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;

namespace N14PKBrowse.List
{
	/// <summary>戦法リスト</summary>
	public class SenpouList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Senpou[] _items;

		/// <summary>戦法名リスト</summary>
		private NameList<uint> _namelist;

		/// <summary>名前リスト</summary>
		public NameList<uint> Namelist
		{
			get
			{
				if ( this._namelist == null )
				{
					this._namelist = new NameList<uint>();
				}
				return this._namelist;
			}
		}

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public SenpouList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.戦法 )
		{
			this._items = base._items as Senpou[];
			this.SetNamelist();
		}

		/// <summary>コンボボックスなどで使用する名称リストセット</summary>
		public void SetNamelist()
		{
			this.Namelist.Clear();
			var array = (Senpou[])this._items.Clone();
			Array.Sort( array, ( x, y ) => x.ID - y.ID );
			foreach ( var d in array )
			{
				if ( !string.IsNullOrEmpty( d.Name ) )
				{
					this.Namelist.Add( d.Address, d.Name );
				}
			}
			// 末尾に空白挿入
			this.Namelist.Add( 0U, string.Empty );
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<Senpou> GetEnumerator()
		//{
		//	for ( var i = 0; i < this.Count; i++ )
		//	{
		//		yield return Array.Find( this._items, d => d.ID == i );
		//	}
		//}

		/// <summary>インデクサ</summary>
		public new Senpou this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Senpou this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 戦法名</summary>
		public Senpou this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}
	}
}
