﻿// GundanList.cs

using System;

using N14PKBrowse.Data;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;

namespace N14PKBrowse.List
{
	/// <summary>軍団リスト</summary>
	public class GundanList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Gundan[] _items;

		/// <summary>軍団名リスト</summary>
		private NameList<uint> _namelist;

		/// <summary>軍団名リスト</summary>
		public NameList<uint> Namelist
		{
			get
			{
				if ( this._namelist == null )
				{
					this._namelist = new NameList<uint>();
				}
				return this._namelist;
			}
		}

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public GundanList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.軍団 )
		{
			this._items = base._items as Gundan[];
			this.SetNamelist();
			//this.FilterCallback = new Predicate<object>( this._filterCallback );
		}

		/// <summary>コンボボックスなどで使用する名称リストセット</summary>
		public void SetNamelist()
		{
			this.Namelist.Clear();
			var array = (Gundan[])this._items.Clone();
			Array.Sort( array, ( x, y ) => x.SortID - y.SortID );
			foreach ( var d in array )
			{
				if ( !string.IsNullOrEmpty( d.Name ) )
				{
					this.Namelist.Add( d.Address, d.Name );
				}
			}
			// 末尾に空白挿入
			this.Namelist.Add( 0U, string.Empty );
		}

		/// <summary>アドレスからソートIDを取得</summary>
		public int GetSortIDByAddress( uint address )
		{
			if ( address == 0 ) { return -1; }
			var data = Array.Find( this._items, d => d.Address == address );
			return ( data != null ) ? data.SortID : -1;
		}

		/// <summary>勢力アドレスから直轄軍団アドレスを取得する</summary>
		public uint GetChokkatsuGundanAddressBySeiryokuAddress( uint address )
		{
			if ( address == 0 ) { return 0; }
			var data = Array.Find( this._items, d => ( d.Data.PtrSeiryoku == address ) && d.IsChokkatsu );
			return ( data != null ) ? data.Address : 0;
		}

		/// <summary>イテレータ</summary>
		public new System.Collections.Generic.IEnumerator<Gundan> GetEnumerator()
		{
			for ( var i = 0; i < this.Count; i++ )
			{
				yield return this._items[i];
			}
		}

		/// <summary>インデクサ</summary>
		public new Gundan this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Gundan this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 軍団名</summary>
		public Gundan this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}

		//public override Predicate<object> FilterCallback { get; set; }
		///// <summary>フィルタ用コールバック</summary>
		//private bool _filterCallback( object obj )
		//{
		//	var d = obj as Gundan;

		//	if ( d == null )
		//	{
		//		return false;
		//	}

		//	return ( this._n14pkb.View.CheckSeiryoku( ( d.Seiryoku != null ) ? d.Seiryoku.Address : 0 ) );
		//}
	}
}
