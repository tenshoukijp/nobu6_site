﻿// ShiroNameList.cs

using System;
using System.Collections;
using System.Collections.Generic;
using N14PKBrowse.Data;
using N14PKLibrary;
using N14PKBrowse.Enums;
namespace N14PKBrowse.List
{
	/// <summary>城名リスト</summary>
	public class ShiroNameList : DataList
	{
		/// <summary>リスト本体</summary>
		private new ShiroName[] _items;

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public ShiroNameList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.城名 )
		{
			this._items = base._items as ShiroName[];
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<ShiroName> GetEnumerator()
		//{
		//	for ( var i = 0; i < this.Count; i++ )
		//	{
		//		yield return Array.Find( this._items, d => d.ID == i );
		//	}
		//}

		/// <summary>インデクサ</summary>
		public new ShiroName this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public ShiroName this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 城名</summary>
		public ShiroName this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}

		/// <summary>アドレスから城名読みを取得する</summary>
		public string GetYomiByAddress( uint address )
		{
			if ( address == 0 ) { return string.Empty; }
			var data = this[address];

			return ( data != null ) ? data.Yomi : string.Empty;
		}
	}
}
