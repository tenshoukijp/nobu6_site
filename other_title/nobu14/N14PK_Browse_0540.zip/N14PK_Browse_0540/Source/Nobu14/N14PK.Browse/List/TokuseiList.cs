﻿// TokuseiList.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Data;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;

namespace N14PKBrowse.List
{
	/// <summary>特性リスト</summary>
	public class TokuseiList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Tokusei[] _items;

		/// <summary>特性名リスト ※ソートID昇順</summary>
		private NameList<uint> _namelist;

		/// <summary>特性名リスト ※ソートID昇順</summary>
		public NameList<uint> Namelist
		{
			get
			{
				if ( this._namelist == null )
				{
					this._namelist = new NameList<uint>();
				}
				return this._namelist;
			}
		}
		/// <summary>ヘルプ2リスト ※ソートID昇順</summary>
		private NameList<uint> _helplist;

		/// <summary>ヘルプ2リスト ※ソートID昇順</summary>
		public NameList<uint> Helplist
		{
			get
			{
				if ( this._helplist == null )
				{
					this._helplist = new NameList<uint>();
				}
				return this._helplist;
			}
		}

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public TokuseiList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.特性 )
		{
			this._items = base._items as Tokusei[];
			Array.Sort( this._items, ( x, y ) => x.SortID - y.SortID );
			this.SetNamelist();
			this.SetHelplist();
		}

		/// <summary>コンボボックスなどで使用する名称リストセット</summary>
		private void SetNamelist()
		{
			var array = (Tokusei[])this._items.Clone();
			Array.Sort( array, ( x, y ) => x.SortID - y.SortID );

			this.Namelist.Clear();
			foreach ( var d in array )
			{
				this.Namelist.Add( d.Address, d.Name );
			}
			this.Namelist.Add( 0, string.Empty );
		}
		/// <summary>コンボボックスなどで使用する名称リストセット</summary>
		private void SetHelplist()
		{
			var array = (Tokusei[])this._items.Clone();
			Array.Sort( array, ( x, y ) => x.SortID - y.SortID );

			this.Helplist.Clear();
			foreach ( var d in array )
			{
				this.Helplist.Add( d.Address, d.HelpText2 );
			}
		}

		/// <summary>インデクサ</summary>
		public new Tokusei this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Tokusei this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 特性名</summary>
		public Tokusei this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}

		/// <summary>イテレータ</summary>
		public new IEnumerator<Tokusei> GetEnumerator()
		{
			for ( var i = 0; i < this.Count; i++ )
			{
				yield return this._items[i];
			}
		}

		/// <summary>IDからソートID取得</summary>
		public int GetSortIDByID( int id )
		{
			var data = Array.Find( this._items, d => d.ID == id );
			return ( data != null ) ? data.SortID : -1;
		}

		/// <summary>ソートIDからデータ取得</summary>
		public Tokusei GetDataBySortID( int sortid )
		{
			return Array.Find( this._items, d => d.SortID == sortid );
		}


		/// <summary>ソートIDからID取得</summary>
		internal int GetIDBySortID( int sortid )
		{
			var data = Array.Find( this._items, d => d.SortID == sortid );
			return ( data != null ) ? data.ID : -1;
		}
	}
}
