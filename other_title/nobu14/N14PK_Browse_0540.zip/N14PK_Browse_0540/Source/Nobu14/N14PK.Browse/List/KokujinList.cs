﻿// KokujinList.cs

using System;

using N14PKBrowse.Data;
using N14PKBrowse.Enums;

namespace N14PKBrowse.List
{
	/// <summary>国人衆リスト</summary>
	public class KokujinList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Kokujin[] _items;

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public KokujinList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.国人衆 )
		{
			this._items = base._items as Kokujin[];
			this.FilterCallback = new Predicate<object>( this._filterCallback );
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<Kokujin> GetEnumerator()
		//{
		//	var array = (Kokujin[])this._items.Clone();
		//	Array.Sort( array, ( x, y ) => x.ID - y.ID );
		//	for ( var i = 0; i < this.Count; i++ )
		//	{
		//		yield return array[i];
		//	}
		//}

		/// <summary>インデクサ</summary>
		public new Kokujin this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Kokujin this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 国人衆名</summary>
		public Kokujin this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}

		/// <summary>必要なら所属勢力を変更する(拠点の所属変更時)</summary>
		public void CheckSyozokuSeiryoku( uint ptrShiro, uint ptrSeiryoku )
		{
			if ( ptrShiro == 0 || ptrSeiryoku == 0 ) { return; }

			foreach ( var d in this._items )
			{
				if ( d.ShiroList.IsContainTargetDataAddress( ptrShiro ) )
				{
					// 国人衆の被影響城？ に含まれる
					if ( d.PtrSyozokuSeiryoku != 0 && d.PtrSyozokuSeiryoku != ptrSeiryoku )
					{
						// 所属勢力あり ＆ 自勢力ではない場合、所属勢力をクリア(クリアしないといつまでたっても影響力ゼロで懐柔もできないぽい)
						d.PtrSyozokuSeiryoku = 0;
					}
				}
			}
		}

		public override Predicate<object> FilterCallback { get; set; }
		/// <summary>フィルタ用コールバック</summary>
		private bool _filterCallback( object obj )
		{
			var d = obj as Kokujin;

			if ( d == null )
			{
				return false;
			}

			return ( this._n14pkb.View.CheckSeiryoku( ( d.SaikoushijiSeiryoku != null ) ? d.SaikoushijiSeiryoku.Address : 0 ) );
		}
	}
}
