﻿// KukakuList.cs

using System;
using System.Collections;
using System.Collections.Generic;
using N14PKBrowse.Data;
using N14PKLibrary;
using N14PKBrowse.Enums;

namespace N14PKBrowse.List
{
	/// <summary>区画リスト</summary>
	public class KukakuList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Kukaku[] _items;

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public KukakuList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.区画 )
		{
			this._items = base._items as Kukaku[];
			this.FilterCallback = new Predicate<object>( this._filterCallback );
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<Kukaku> GetEnumerator()
		//{
		//	for ( var i = 0; i < this.Count; i++ )
		//	{
		//		yield return Array.Find( this._items, d => d.ID == i );
		//	}
		//}

		/// <summary>インデクサ</summary>
		public new Kukaku this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Kukaku this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		///// <summary>インデクサ 区画名</summary>
		//public Kukaku this[string name]
		//{
		//	get
		//	{
		//		if ( string.IsNullOrEmpty( name ) ) { return null; }
		//		return Array.Find( this._items, d => d.Name == name );
		//	}
		//}

		public override Predicate<object> FilterCallback { get; set; }
		/// <summary>フィルタ用コールバック 区画</summary>
		private bool _filterCallback( object obj )
		{
			var d = obj as Kukaku;

			if ( d == null )
			{
				return false;
			}

			return ( this._n14pkb.View.CheckSeiryoku( ( d.Seiryoku != null ) ? d.Seiryoku.Address : 0 ) );
		}
	}
}
