﻿// KaidouList.cs

using System;
using System.Collections;
using System.Collections.Generic;
using N14PKBrowse.Data;
using N14PKLibrary;
using N14PKBrowse.Enums;

namespace N14PKBrowse.List
{
	/// <summary>街道リスト</summary>
	public class KaidouList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Kaidou[] _items;

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public KaidouList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.街道 )
		{
			this._items = base._items as Kaidou[];
			this.FilterCallback = new Predicate<object>( this._filterCallback );
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<Kaidou> GetEnumerator()
		//{
		//	for ( var i = 0; i < this.Count; i++ )
		//	{
		//		yield return Array.Find( this._items, d => d.ID == i );
		//	}
		//}

		/// <summary>インデクサ</summary>
		public new Kaidou this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Kaidou this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 街道名</summary>
		public Kaidou this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}

		public override Predicate<object> FilterCallback { get; set; }
		/// <summary>フィルタ用コールバック</summary>
		private bool _filterCallback( object obj )
		{
			var d = obj as Kaidou;

			if ( d == null )
			{
				return false;
			}

			var ptr1 = ( d.Yousyo1.Shiro != null ) ? d.Yousyo1.Shiro.Seiryoku.Address : 0;
			var ptr2 = ( d.Yousyo2.Shiro != null ) ? d.Yousyo2.Shiro.Seiryoku.Address : 0;

			return ( this._n14pkb.View.CheckSeiryoku( ptr1, ptr2 ) );
		}
	}
}
