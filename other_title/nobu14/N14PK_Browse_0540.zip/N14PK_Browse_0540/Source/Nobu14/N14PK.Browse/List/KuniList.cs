﻿// KuniList.cs

using System;

using N14PKBrowse.Data;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;

namespace N14PKBrowse.List
{
	/// <summary>国リスト</summary>
	public class KuniList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Kuni[] _items;

		/// <summary>国名リスト</summary>
		private NameList<uint> _namelist;

		/// <summary>国名リスト</summary>
		public NameList<uint> Namelist
		{
			get
			{
				if ( this._namelist == null )
				{
					this._namelist = new NameList<uint>();
				}
				return this._namelist;
			}
		}

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public KuniList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.国 )
		{
			this._items = base._items as Kuni[];
			//this._namelist = null;
					this.SetNamelist();
		}

		/// <summary>コンボボックスなどで使用する名称リストセット</summary>
		public void SetNamelist()
		{
			this.Namelist.Clear();
			var array = (Kuni[])this._items.Clone();
			Array.Sort( array, ( x, y ) => x.ID - y.ID );
			foreach ( var d in array )
			{
				if ( !string.IsNullOrEmpty( d.Name ) )
				{
					this.Namelist.Add( d.Address, d.Name );
				}
			}
			// 末尾に空白挿入
			this.Namelist.Add( 0U, string.Empty );
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<Kuni> GetEnumerator()
		//{
		//	for ( var i = 0; i < this.Count; i++ )
		//	{
		//		yield return Array.Find( this._items, d => d.ID == i );
		//	}
		//}

		/// <summary>インデクサ</summary>
		public new Kuni this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Kuni this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 国名</summary>
		public Kuni this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}
	}
}
