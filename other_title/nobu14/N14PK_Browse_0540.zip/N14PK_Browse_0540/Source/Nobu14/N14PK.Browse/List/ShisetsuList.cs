﻿// ShisetsuList.cs

using System;
using System.Collections;
using System.Collections.Generic;
using N14PKBrowse.Data;
using N14PKLibrary;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;
namespace N14PKBrowse.List
{
	/// <summary>施設リスト</summary>
	public class ShisetsuList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Shisetsu[] _items;

		/// <summary>施設名リスト</summary>
		private NameList<int> _namelist;

		/// <summary>施設名リスト</summary>
		public NameList<int> Namelist
		{
			get
			{
				if ( this._namelist == null )
				{
					this._namelist = new NameList<int>();
				}
				return this._namelist;
			}
		}
		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public ShisetsuList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.施設 )
		{
			this._items = base._items as Shisetsu[];
			this.SetNamelist();
		}

		/// <summary>コンボボックスなどで使用する名称リストセット</summary>
		private void SetNamelist()
		{
			this.Namelist.Clear();
			var array = (Shisetsu[])this._items.Clone();
			Array.Sort( array, ( x, y ) => x.ID - y.ID );
			foreach ( var d in array )
			{
				this.Namelist.Add( d.ID, d.Name );
			}
			// 空白挿入
			this.Namelist.Add( -1, string.Empty );
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<Shisetsu> GetEnumerator()
		//{
		//	for ( var i = 0; i < this._items.Length; i++ )
		//	{
		//		yield return Array.Find( this._items, d => d.ID == i );
		//	}
		//}

		/// <summary>インデクサ</summary>
		public new Shisetsu this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Shisetsu this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 施設</summary>
		public Shisetsu this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}

		/// <summary>IDから区画タイプ(農業・商業・兵舎)取得 ※区画データで使用する</summary>
		public int GetKukakuTypeByID( int id )
		{
			var data = Array.Find( this._items, d => d.ID == id );
			if ( data != null )
			{
				if ( data.IsNougyouKukaku )
				{
					// 農業施設
					return 0;
				}
				else if ( data.IsSyougyouKukaku )
				{
					// 商業施設
					return 1;
				}
				else if ( data.IsHeisyaKukaku )
				{
					// 兵舎施設
					return 2;
				}
				else
				{
					return -1;
				}
			}
			else
			{
				return -1;
			}
		}
	}
}
