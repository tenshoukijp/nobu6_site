﻿// DataList.cs

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using N14PKBrowse.Data;
using N14PKLibrary;
using N14PKLibrary.Table;
using N14PKBrowse.Enums;

namespace N14PKBrowse.List
{
	/// <summary>データリスト基底クラス</summary>
	public class DataList
	{
		/// <summary>ツール管理</summary>
		protected N14PKB _n14pkb;

		/// <summary>データテーブル</summary>
		protected DataTable _table;

		/// <summary>タブ名</summary>
		private TabKind _tabKind;

		/// <summary>リスト本体</summary>
		protected IBrowseData[] _items;

		/// <summary>リスト本体</summary>
		public virtual IBrowseData[] Items
		{
			get { return this._items; }
		}

		/// <summary>リスト内アイテム数</summary>
		public virtual int Count
		{
			get { return this._items.Length; }
		}

		/// <summary>コミット時にプロセスメモリに書き込むレコードID</summary>
		protected List<int> _comitIDList;

		/// <summary>コミット時にプロセスメモリに書き込むレコードIDリスト</summary>
		public int[] CommitIDList
		{
			get { return ( this._comitIDList != null ) ? this._comitIDList.ToArray() : null; }
			set { this._comitIDList = ( value != null ) ? value.ToList<int>() : null; }
		}

		/// <summary>コミット時にプロセスメモリに書き込むレコードIDを設定</summary>
		public int CommitID
		{
			set
			{
				if ( this._comitIDList == null )
				{
					this._comitIDList = new List<int>();
				}
				if ( !this._comitIDList.Contains( value ) )
				{
					// IDが未登録なら追加
					this._comitIDList.Add( value );
					this._n14pkb.NeedsCommit = true;
				}
			}
		}

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール</param>
		/// <param name="tabKind">データの種類</param>
		public DataList( N14PKB n14pkb, TabKind tabKind )
		{
			this._n14pkb = n14pkb;
			this._tabKind = tabKind;
			this._table = n14pkb.N14pk.GetTable( Helper.GetDataTableIDByTabKind( tabKind ) );

			//this._items = new object[this._table.RecordCount];
			//var list = new List<object>();

			this.SetList();
		}

		/// <summary>データリスト作成</summary>
		private void SetList()
		{
			if ( this._table == null ) { return; }
			var length = this._table.RecordCount;

			switch ( this._tabKind )
			{
				#region データの種類による分岐処理
				case TabKind.武将:
					var busyoulist = new List<Busyou>();
					for ( var i = 0; i < length; i++ )
					{
						var busyou = new Busyou( this._n14pkb, i );
						// データ条件
						if ( busyou.Data.MibunID != -1 )
						{
							busyou.PropertyChanged += busyou.OnPropertyChanged;
							busyoulist.Add( busyou );
						}
					}
					this._items = busyoulist.ToArray();
					break;

				case TabKind.城:
					var shirolist = new List<Shiro>();
					for ( var i = 0; i < length; i++ )
					{
						var shiro = new Shiro( this._n14pkb, i );
						// データ条件
						if ( shiro.Data.PtrGundan != 0 )
						{
							shiro.PropertyChanged += shiro.OnPropertyChanged;
							shirolist.Add( shiro );
						}
					}
					this._items = shirolist.ToArray();
					break;

				case TabKind.区画:
					var kukakulist = new List<Kukaku>();
					foreach ( var d in this._n14pkb.Shirolist )
					{
						for ( var i = 0; i < d.Kukakulist.Length; i++ )
						{
							d.Kukakulist[i].PropertyChanged += d.Kukakulist[i].OnPropertyChanged;
							kukakulist.Add( d.Kukakulist[i] );
						}
					}
					this._items = kukakulist.ToArray();
					break;

				case TabKind.勢力:
					var seiryokulist = new List<Seiryoku>();
					for ( var i = 0; i < length; i++ )
					{
						var seiryoku = new Seiryoku( this._n14pkb, i );
						// データ条件
						if ( seiryoku.Data.PtrTousyu != 0 )
						{
							seiryoku.PropertyChanged += seiryoku.OnPropertyChanged;
							seiryokulist.Add( seiryoku );
							// プレイヤー勢力IDセット
							if ( seiryoku.IsPlayer ) { this._n14pkb.PlayerSeriyokuID = seiryoku.ID; }
						}
					}
					this._items = seiryokulist.ToArray();
					break;

				case TabKind.軍団:
					var gundanlist = new List<Gundan>();
					for ( var i = 0; i < length; i++ )
					{
						var gundan = new Gundan( this._n14pkb, i );
						// データ条件
						if ( gundan.Data.PtrGundanchou != 0 )
						{
							gundan.PropertyChanged += gundan.OnPropertyChanged;
							gundanlist.Add( gundan );
						}
					}
					this._items = gundanlist.ToArray();
					break;

				case TabKind.部隊:
					var butailist = new List<Butai>();
					for ( var i = 0; i < length; i++ )
					{
						var butai = new Butai( this._n14pkb, i );
						// データ条件
						if ( butai.Data.CntHenseiList != 0 )
						{
							butai.PropertyChanged += butai.OnPropertyChanged;
							butailist.Add( butai );
						}
					}
					this._items = butailist.ToArray();
					break;

				case TabKind.建物:
					var tatemonolist = new List<Tatemono>();
					for ( var i = 0; i < length; i++ )
					{
						var tatemono = new Tatemono( this._n14pkb, i );
						//// データ条件
						//if ( true )
						//{
							tatemono.PropertyChanged += tatemono.OnPropertyChanged;
							tatemonolist.Add( tatemono );
						//}
					}
					this._items = tatemonolist.ToArray();
					break;

				case TabKind.家宝:
					var kahoulist = new List<Kahou>();
					for ( var i = 0; i < length; i++ )
					{
						var kahou = new Kahou( this._n14pkb, i );
						kahou.PropertyChanged += kahou.OnPropertyChanged;
						kahoulist.Add( kahou );
					}
					this._items = kahoulist.ToArray();
					break;

				case TabKind.国人衆:
					var kokujinlist = new List<Kokujin>();
					for ( var i = 0; i < length; i++ )
					{
						var kokujin = new Kokujin( this._n14pkb, i );
						// データ条件
						if ( kokujin.Data.PtrTouryou != 0 )
						{
							kokujin.PropertyChanged += kokujin.OnPropertyChanged;
							kokujinlist.Add( kokujin );
						}
					}
					this._items = kokujinlist.ToArray();
					break;

				case TabKind.要所:
					var yousyolist = new List<Yousyo>();
					for ( var i = 0; i < length; i++ )
					{
						var yousyo = new Yousyo( this._n14pkb, i );
						// データ条件
						if ( yousyo.Data.PtrKuni != 0 )
						{
							yousyo.PropertyChanged += yousyo.OnPropertyChanged;
							yousyolist.Add( yousyo );
						}
					}
					this._items = yousyolist.ToArray();
					break;

				case TabKind.街道:
					var kaidoulist = new List<Kaidou>();
					for ( var i = 0; i < length; i++ )
					{
						var kaidou = new Kaidou( this._n14pkb, i );
						// データ条件
						if ( kaidou.Data.PtrYousyo1 != 0 )
						{
							kaidou.PropertyChanged += kaidou.OnPropertyChanged;
							kaidoulist.Add( kaidou );
						}
					}
					this._items = kaidoulist.ToArray();
					break;

				case TabKind.施設:
					var shisetsulist = new List<Shisetsu>();
					for ( var i = 0; i < length; i++ )
					{
						var shisetsu = new Shisetsu( this._n14pkb, i );
						shisetsu.PropertyChanged += shisetsu.OnPropertyChanged;
						shisetsulist.Add( shisetsu );
					}
					this._items = shisetsulist.ToArray();
					break;

				case TabKind.政策:
					var seisakulist = new List<Seisaku>();
					for ( var i = 0; i < length; i++ )
					{
						var seisaku = new Seisaku( this._n14pkb, i );
						seisaku.PropertyChanged += seisaku.OnPropertyChanged;
						seisakulist.Add( seisaku );
					}
					this._items = seisakulist.ToArray();
					break;

				case TabKind.戦法:
					var senpoulist = new List<Senpou>();
					for ( var i = 0; i < length; i++ )
					{
						var senpou = new Senpou( this._n14pkb, i );
						senpou.PropertyChanged += senpou.OnPropertyChanged;
						senpoulist.Add( senpou );
					}
					this._items = senpoulist.ToArray();
					break;

				case TabKind.特性:
					var tokuseilist = new List<Tokusei>();
					for ( var i = 0; i < length; i++ )
					{
						var tokusei = new Tokusei( this._n14pkb, i );
						tokusei.PropertyChanged += tokusei.OnPropertyChanged;
						tokuseilist.Add( tokusei );
					}
					this._items = tokuseilist.ToArray();
					break;

				case TabKind.習得条件:
					var tokuseiSyuutokuJoukenlist = new List<TokuseiSyuutokuJouken>();
					for ( var i = 0; i < length; i++ )
					{
						var tokuseiSyuutokuJouken = new TokuseiSyuutokuJouken( this._n14pkb, i );
						tokuseiSyuutokuJouken.PropertyChanged += tokuseiSyuutokuJouken.OnPropertyChanged;
						tokuseiSyuutokuJoukenlist.Add( tokuseiSyuutokuJouken );
					}
					this._items = tokuseiSyuutokuJoukenlist.ToArray();
					break;

				case TabKind.成長型:
					var seichougatalist = new List<Seichougata>();
					for ( var i = 0; i < length; i++ )
					{
						var seichougata = new Seichougata( this._n14pkb, i );
						seichougata.PropertyChanged += seichougata.OnPropertyChanged;
						seichougatalist.Add( seichougata );
					}
					this._items = seichougatalist.ToArray();
					break;

				case TabKind.地方:
					var chihoulist = new List<Chihou>();
					for ( var i = 0; i < length; i++ )
					{
						var chihou = new Chihou( this._n14pkb, i );
						chihou.PropertyChanged += chihou.OnPropertyChanged;
						chihoulist.Add( chihou );
					}
					this._items = chihoulist.ToArray();
					break;

				case TabKind.国:
					var kunilist = new List<Kuni>();
					for ( var i = 0; i < length; i++ )
					{
						var kuni = new Kuni( this._n14pkb, i );
						kuni.PropertyChanged += kuni.OnPropertyChanged;
						kunilist.Add( kuni );
					}
					this._items = kunilist.ToArray();
					break;

				case TabKind.効果:
					var koukalist = new List<Kouka>();
					for ( var i = 0; i < length; i++ )
					{
						var kouka = new Kouka( this._n14pkb, i );
						kouka.PropertyChanged += kouka.OnPropertyChanged;
						koukalist.Add( kouka );
					}
					this._items = koukalist.ToArray();
					break;

				case TabKind.方針:
					var houshinlist = new List<Houshin>();
					for ( var i = 0; i < length; i++ )
					{
						var houshin = new Houshin( this._n14pkb, i );
						houshin.PropertyChanged += houshin.OnPropertyChanged;
						houshinlist.Add( houshin );
					}
					this._items = houshinlist.ToArray();
					break;

				case TabKind.軍略:
					var gunryakulist = new List<Gunryaku>();
					for ( var i = 0; i < length; i++ )
					{
						var gunryaku = new Gunryaku( this._n14pkb, i );
						gunryaku.PropertyChanged += gunryaku.OnPropertyChanged;
						gunryakulist.Add( gunryaku );
					}
					this._items = gunryakulist.ToArray();
					break;

				case TabKind.城郭:
					var joukakulist = new List<Joukaku>();
					for ( var i = 0; i < length; i++ )
					{
						var joukaku = new Joukaku( this._n14pkb, i );
						joukaku.PropertyChanged += joukaku.OnPropertyChanged;
						joukakulist.Add( joukaku );
					}
					this._items = joukakulist.ToArray();
					break;

				case TabKind.城名:
					var shiroNamelist = new List<ShiroName>();
					for ( var i = 0; i < length; i++ )
					{
						var shiroName = new ShiroName( this._n14pkb, i );
						// データ条件
						if ( !string.IsNullOrEmpty( shiroName.Data.Name ) && shiroName.Data.Name != "0" )
						{
							shiroName.PropertyChanged += shiroName.OnPropertyChanged;
							shiroNamelist.Add( shiroName );
						}
					}
					this._items = shiroNamelist.ToArray();
					break;

				default:
					break;
				#endregion
			}
		}

		/// <summary>インデクサ データID</summary>
		public virtual IBrowseData this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}
	
		/// <summary>イテレータ</summary>
		public virtual IEnumerator GetEnumerator()
		{
			for ( var i = 0; i < this._items.Length; i++ )
			{
				yield return Array.Find( this._items, d => d.ID == i );
			}
		}

		/// <summary>フィルタ用コールバック 派生クラスでそれぞれ実装</summary>
		public virtual Predicate<object> FilterCallback { get; set; }

		/// <summary>名称からIDを取得</summary>
		public int GetIDByName( string name )
		{
			if ( string.IsNullOrEmpty( name ) ) { return -1; }
			var data = Array.Find( this._items, d => d.Name == name );
			return ( data != null ) ? data.ID : -1;
		}

		/// <summary>アドレスからIDを取得</summary>
		public int GetIDByAddress( uint address )
		{
			if ( address == 0 ) { return -1; }
			var data = Array.Find( this._items, d => d.Address == address );
			return ( data != null ) ? data.ID : -1;
		}

		/// <summary>IDから名称を取得</summary>
		public string GetNameByID( int id )
		{
			if ( id == -1 ) { return string.Empty; }
			var data = this[id];
			return ( data != null ) ? data.Name : string.Empty;
		}

		/// <summary>アドレスから名称を取得</summary>
		public string GetNameByAddress( uint address )
		{
			if ( address == 0 ) { return string.Empty; }
			var data = Array.Find( this._items, d => d.Address == address );
			return ( data != null ) ? data.Name : string.Empty;
		}

		/// <summary>名称からアドレスを取得</summary>
		public uint GetAddressByName( string name )
		{
			if ( string.IsNullOrEmpty( name ) ) { return 0; }
			var data = Array.Find( this._items, d => d.Name == name );
			return ( data != null ) ? data.Address : 0;
		}

		/// <summary>IDからアドレスを取得</summary>
		public uint GetAddressByID( int id )
		{
			if ( id == -1 ) { return 0; }
			var data = this[id];
			return ( data != null ) ? data.Address : 0;
		}

		/// <summary>データセーブ</summary>
		public virtual void DataSave( BinaryWriter bw, int[] ids )
		{
			bw.Write( this._table.RecordSize );
			bw.Write( ids.Length );
			foreach ( var id in ids )
			{
				bw.Write( id );
				bw.Write( this[id].GetSaveData() );
			}
		}

		/// <summary>データロード</summary>
		public virtual void DataLoad( FileStream fs, int size, int count )
		{
			if ( this._table.RecordSize != size )
			{
				// レコードサイズが異なる→データ構造変化により復元不可
				throw new ApplicationException( "データ構造が保存時と異なるため読み込みを中止します。" );
			}

			byte[] idbytes = new byte[sizeof( UInt32 )];	// ID用バッファ
			byte[] buff = new byte[size];	// データ用バッファ
			for ( int i = 0; i < count; i++ )
			{
				// 保存データのID読込
				fs.Read( idbytes, 0, 4 );
				var id = BitConverter.ToInt32( idbytes, 0 );

				// 保存データ読込
				fs.Read( buff, 0, size );

				this[id].SetSaveData( buff );
			}
			this.Commit();
		}

		/// <summary>プロセスメモリにデータを書き込む</summary>
		public virtual void Commit()
		{
			if ( this.CommitIDList != null )
			{
				this._n14pkb.NeedsCommit = false;
#if DEBUG
				System.Diagnostics.Debug.WriteLine( "Commit(" + this._tabKind + ")" );
#endif
				this._table.Commit( this.CommitIDList );
				this.CommitIDList = null;
			}
		}
	}
}
