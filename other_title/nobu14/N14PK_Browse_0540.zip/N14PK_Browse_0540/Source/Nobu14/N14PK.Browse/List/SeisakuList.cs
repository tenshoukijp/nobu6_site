﻿// SeisakuList.cs

using System;

using N14PKBrowse.Data;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;

namespace N14PKBrowse.List
{
	/// <summary>政策リスト</summary>
	public class SeisakuList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Seisaku[] _items;

		/// <summary>政策名リスト</summary>
		private NameList<uint> _namelist;

		/// <summary>政策名リスト</summary>
		public NameList<uint> Namelist
		{
			get
			{
				if ( this._namelist == null )
				{
					this._namelist = new NameList<uint>();
				}
				return this._namelist;
			}
		}

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public SeisakuList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.政策 )
		{
			this._items = base._items as Seisaku[];
			this.SetNamelist();
		}

		/// <summary>コンボボックスなどで使用する名称リストセット</summary>
		public void SetNamelist()
		{
			this.Namelist.Clear();
			var array = (Seisaku[])this._items.Clone();
			Array.Sort( array, ( x, y ) => x.ID - y.ID );
			foreach ( var d in array )
			{
				if ( !string.IsNullOrEmpty( d.Name ) )
				{
					this.Namelist.Add( d.Address, d.Name );
				}
			}
			// 末尾に空白挿入
			this.Namelist.Add( 0U, string.Empty );
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<Seisaku> GetEnumerator()
		//{
		//	for ( var i = 0; i < this.Count; i++ )
		//	{
		//		yield return Array.Find( this._items, d => d.ID == i );
		//	}
		//}

		/// <summary>インデクサ</summary>
		public new Seisaku this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Seisaku this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 政策名</summary>
		public Seisaku this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}
	}
}
