﻿// SeiryokuList.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Data;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;

namespace N14PKBrowse.List
{
	/// <summary>勢力リスト</summary>
	public class SeiryokuList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Seiryoku[] _items;

		/// <summary>勢力名リスト</summary>
		private NameList<uint> _namelist;

		/// <summary>勢力名リスト</summary>
		public NameList<uint> Namelist
		{
			get
			{
				if ( this._namelist == null )
				{
					this._namelist = new NameList<uint>();
				}
				return this._namelist;
			}
		}

		/// <summary>勢力＆当主名リスト</summary>
		private NameList<uint> _seiryokuAndTousyunamelist;

		/// <summary>勢力＆当主名リスト</summary>
		public NameList<uint> SeiryokuAndTousyunamelist
		{
			get
			{
				if ( this._seiryokuAndTousyunamelist == null )
				{
					this._seiryokuAndTousyunamelist = new NameList<uint>();
				}
				return this._seiryokuAndTousyunamelist;
			}
		}

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public SeiryokuList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.勢力 )
		{
			this._items = base._items as Seiryoku[];
			//this._namelist = null;
			//this._seiryokuAndTousyunamelist = null;
					this.SetNamelist();
					this.SetSeiryokuAndTousyunamelist();
			//this.SetSortID();
			this.SetKoninDoumeiInfo();
		}

		///// <summary>ソート用のIDをセット</summary>
		//private void SetSortID()
		//{
		//	var array = (Seiryoku[])this._items.Clone();

		//	// 要所リストのソートIDを参照してソート
		//	Array.Sort( array, ( x, y ) =>
		//		this._n14pkb.Shirolist.GetSortIDByAddress( x.Data.PtrSyokiHonkyo ) - this._n14pkb.Shirolist.GetSortIDByAddress( y.Data.PtrSyokiHonkyo ) );

		//	var id = 0;
		//	foreach ( var d in array )
		//	{
		//		// 軍団のソートIDを 勢力ソートID+軍団インデクス にするので *10 する
		//		this[d.ID].SortID = 10 * id++;
		//	}
		//}

		/// <summary>コンボボックスなどで使用する名称リストセット</summary>
		public void SetNamelist()
		{
			this.Namelist.Clear();

			var array = (Seiryoku[])this._items.Clone();

			// ソートIDでソート
			Array.Sort( array, ( x, y ) => x.SortID - y.SortID );

			foreach ( var d in array )
			{
				if ( d.Data.PtrTousyu != 0 )
				{
					this.Namelist.Add( d.Address, d.Name );
				}
			}
			// 末尾に空白挿入
			this.Namelist.Add( 0U, string.Empty );
		}
		/// <summary>コンボボックスなどで使用する名称リストセット</summary>
		public void SetSeiryokuAndTousyunamelist()
		{
			//this._n14pkb.View.SeiryokuNamelist.Clear();

			//var array = (Seiryoku[])this._items.Clone();

			//// ソートIDでソート
			//Array.Sort( array, ( x, y ) => x.SortID - y.SortID );

			//foreach ( var d in array )
			//{
			//	if ( d.Data.PtrTousyu != 0 )
			//	{
			//		this._n14pkb.View.SeiryokuNamelist.Add( d.Address, d.SeiryokuAndTousyuName );
			//	}
			//}
			this.SeiryokuAndTousyunamelist.Clear();

			var array = (Seiryoku[])this._items.Clone();

			// ソートIDでソート
			Array.Sort( array, ( x, y ) => x.SortID - y.SortID );

			foreach ( var d in array )
			{
				if ( d.Data.PtrTousyu != 0 )
				{
					this.SeiryokuAndTousyunamelist.Add( d.Address, d.SeiryokuAndTousyuName );
				}
			}
			//this._n14pkb.View.SeiryokuNamelist = this.SeiryokuAndTousyunamelist;
		}

		/// <summary>婚姻同盟に関する情報をセット</summary>
		private void SetKoninDoumeiInfo()
		{
			foreach ( var seiryoku in this._items )
			{
				var listSeiryokuID = new List<int>();
				var listPtrBusyou1 = new List<uint>();
				var listPtrBusyou2 = new List<uint>();
				foreach( var gaikou in seiryoku.Data.Gaikou )
				{
					if ( gaikou.PtrKoninBusyou != 0 )
					{
						seiryoku.CntKoninDoumei++;
						listSeiryokuID.Add( gaikou.ID );
						listPtrBusyou1.Add( gaikou.PtrKoninBusyou );
						listPtrBusyou2.Add( this[gaikou.ID].Data.Gaikou[seiryoku.ID].PtrKoninBusyou );
					}
				}
				seiryoku.KoninDoumeiSeiryokuID = listSeiryokuID.ToArray();
				seiryoku.PtrKoninDoumeiBusyou1 = listPtrBusyou1.ToArray();
				seiryoku.PtrKoninDoumeiBusyou2 = listPtrBusyou2.ToArray();
			}
		}

		/// <summary>アドレスからソートIDを取得</summary>
		public int GetSortIDByAddress( uint address )
		{
			if ( address == 0 ) { return -1; }
			var data = Array.Find( this._items, d => d.Address == address );
			return ( data != null ) ? data.SortID : -1;
		}

		///// <summary>イテレータ</summary>
		//public new IEnumerator<Seiryoku> GetEnumerator()
		//{
		//	for ( var i = 0; i < this.Count; i++ )
		//	{
		//		yield return Array.Find( this._items, d => d.ID == i );
		//	}
		//}

		/// <summary>インデクサ</summary>
		public new Seiryoku this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Seiryoku this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 勢力名</summary>
		public Seiryoku this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}
	}
}
