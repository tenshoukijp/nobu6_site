﻿// BusyouList.cs

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using N14PKBrowse.Data;
using N14PKLibrary;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;

namespace N14PKBrowse.List
{
	/// <summary>武将リスト</summary>
	public class BusyouList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Busyou[] _items;

		/// <summary>武将名リスト ※女性→名前読み順</summary>
		private List<string> _namelist;

		/// <summary>武将名リスト ※女性→名前読み順</summary>
		// アドレスと名前をペアにしたもの(N14PKBrowse.NameList<uint>)を使用したいが
		// 武将名リストをコンボソースに持つビュー表示時のパフォーマンスが著しく低下するため名前だけのリスト(List<string>)にする。
		// 選択された武将名で武将データを取得するため、同一名の武将がいた場合常にリスト前方のデータにヒットする。
		public List<string> Namelist
		{
			get
			{
				if ( this._namelist == null )
				{
					this._namelist = new List<string>();
				}
				return this._namelist;
			}
		}

		// 能力解析用
		public static double TousotsuAvg	{ get; private set; }	// 統率平均値
		public static double BuyuuAvg		{ get; private set; }	// 武勇平均値
		public static double ChiryakuAvg	{ get; private set; }	// 知略平均値
		public static double SeijiAvg		{ get; private set; }	// 政治平均値
		public static double TousotsuStdDev	{ get; private set; }	// 統率標準偏差
		public static double BuyuuStdDev	{ get; private set; }	// 武勇標準偏差
		public static double ChiryakuStdDev	{ get; private set; }	// 知略標準偏差
		public static double SeijiStdDev	{ get; private set; }	// 政治標準偏差

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public BusyouList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.武将 )
		{
			this._items = base._items as Busyou[];
			this.SetNamelist();
			this.SetNouryokuDev();
			this.FilterCallback = new Predicate<object>( this._filterCallback );
		}

		/// <summary>コンボボックスなどで使用する名称リストセット</summary>
		public void SetNamelist()
		{
			this.Namelist.Clear();
			var array = (Busyou[])this._items.Clone();
			// 武将名リスト ※女性→名前読み順
			Array.Sort( array, ( x, y ) => ( x.IsJosei.CompareTo( y.IsJosei ) != 0 ) ? -x.IsJosei.CompareTo( y.IsJosei ) : x.Yomi.CompareTo( y.Yomi ) );
			this.Namelist.Add( string.Empty );	// 空アイテムを先頭に追加
			foreach ( var d in array )
			{
				if ( d.KetsuzokuID != -1 )
				{
					// 血族IDだけを条件にする(武将の性別によってコンボリストの内容を変えるのがしんどそうなので、父設定だろうが母設定だろうが配偶者設定だろうが候補に全武将表示する)
					this.Namelist.Add( d.Name );
				}
			}
			this.Namelist.Add( string.Empty );	// 空アイテムを末尾に追加
		}

		/// <summary>能力解析用の平均値算出・標準偏差</summary>
		public void SetNouryokuDev()
		{
			int cnt = 0;
			foreach ( var d in this._items )
			{
				if ( -1 != d.Data.KetsuzokuID && 0 < d.Data.KaoguraID2 )
				{
					// 血族IDが-1：頭領やダミー、顔グラID2が-1：架空姫、顔グラID2が0：実父用武将
					cnt++;
					BusyouList.TousotsuAvg += d.Data.Tousotsu + (int)( d.Data.TousotsuExp / 100 );
					BusyouList.BuyuuAvg += d.Data.Buyuu + (int)( d.Data.BuyuuExp / 100 );
					BusyouList.ChiryakuAvg += d.Data.Chiryaku + (int)( d.Data.ChiryakuExp / 100 );
					BusyouList.SeijiAvg += d.Data.Seiji + (int)( d.Data.SeijiExp / 100 );
				}
			}
			BusyouList.TousotsuAvg /= cnt;
			BusyouList.BuyuuAvg /= cnt;
			BusyouList.ChiryakuAvg /= cnt;
			BusyouList.SeijiAvg /= cnt;

			// 能力解析用の標準偏差を算出
			foreach ( var d in this._items )
			{
				if ( -1 != d.Data.KetsuzokuID && 0 < d.Data.KaoguraID2 )
				{
					// 血族IDが-1：頭領やダミー、顔グラID2が-1：架空姫、顔グラID2が0：実父用武将
					BusyouList.TousotsuStdDev += Math.Pow( BusyouList.TousotsuAvg - d.Data.Tousotsu, 2 );
					BusyouList.BuyuuStdDev += Math.Pow( BusyouList.BuyuuAvg - d.Data.Buyuu, 2 );
					BusyouList.ChiryakuStdDev += Math.Pow( BusyouList.ChiryakuAvg - d.Data.Chiryaku, 2 );
					BusyouList.SeijiStdDev += Math.Pow( BusyouList.SeijiAvg - d.Data.Seiji, 2 );
				}
			}
			BusyouList.TousotsuStdDev = Math.Pow( BusyouList.TousotsuStdDev / cnt, 0.5 );
			BusyouList.BuyuuStdDev = Math.Pow( BusyouList.BuyuuStdDev / cnt, 0.5 );
			BusyouList.ChiryakuStdDev = Math.Pow( BusyouList.ChiryakuStdDev / cnt, 0.5 );
			BusyouList.SeijiStdDev = Math.Pow( BusyouList.SeijiStdDev / cnt, 0.5 );
		}

		/// <summary>イテレータ</summary>
		public new IEnumerator<Busyou> GetEnumerator()
		{
			for ( var i = 0; i < this.Count; i++ )
			{
				yield return this._items[i];
			}
		}

		/// <summary>インデクサ データID</summary>
		public new Busyou this[int id]
		{
			get
			{
				return Array.Find( this._items, d => d.ID == id );
			}
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Busyou this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		/// <summary>インデクサ 武将名</summary>
		public Busyou this[string name]
		{
			get
			{
				if ( string.IsNullOrEmpty( name ) ) { return null; }
				return Array.Find( this._items, d => d.Name == name );
			}
		}

		public override Predicate<object> FilterCallback { get; set; }
		/// <summary>フィルタ用コールバック</summary>
		private bool _filterCallback( object obj )
		{
			var d = obj as Busyou;

			if ( d == null ) { return false; }

			if ( d.Data.MibunID == -1 ) { return false; }

			//uint ptr1 = ( d.Seiryoku != null ) ? d.Seiryoku.Address : d.Data.PtrSeiryoku;
			uint ptr1 = ( d.Data.PtrSeiryoku != 0 ) ? d.Data.PtrSeiryoku : ( d.Seiryoku != null ) ? d.Seiryoku.Address : 0;
			uint ptr2 = ( d.ShiroSeiryoku != null ) ? d.ShiroSeiryoku.Address : 0;

			var flag = false;

			if ( ( ptr1 != ptr2 ) && ( ptr2 != 0 ) )
				flag = this._n14pkb.View.CheckSeiryoku( ptr1, ptr2 );
			else
				flag = this._n14pkb.View.CheckSeiryoku( ptr1 );

			return ( this._n14pkb.View.CheckMibun( d ) && flag );
		}
	}
}
