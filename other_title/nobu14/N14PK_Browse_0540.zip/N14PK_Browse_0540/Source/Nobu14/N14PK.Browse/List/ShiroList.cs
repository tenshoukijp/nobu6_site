﻿// ShiroList.cs

using System;
using System.Collections;
using System.Collections.Generic;
using N14PKBrowse.Data;
using N14PKLibrary;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;
namespace N14PKBrowse.List
{
	/// <summary>城リスト</summary>
	public class ShiroList : DataList
	{
		/// <summary>リスト本体</summary>
		private new Shiro[] _items;

		/// <summary>城名リスト</summary>
		private NameList<uint> _namelist;

		/// <summary>城名リスト</summary>
		public NameList<uint> Namelist
		{
			get
			{
				if ( this._namelist == null )
				{
					this._namelist = new NameList<uint>();
				}
				return this._namelist;
			}
		}

		/// <summary>コンストラクタ</summary>
		/// <param name="n14pkb">ツール管理</param>
		/// <param name="dataKind">データの種類</param>
		public ShiroList( N14PKB n14pkb )
			:base ( n14pkb, TabKind.城 )
		{
			this._items = base._items as Shiro[];
			this.SetNamelist();
			this.FilterCallback = new Predicate<object>( this._filterCallback );
		}

		/// <summary>コンボボックスなどで使用する名称リストセット</summary>
		private void SetNamelist()
		{
			this.Namelist.Clear();
			var array = (Shiro[])this._items.Clone();
			Array.Sort( array, ( x, y ) => x.SortID - y.SortID );
			foreach ( var d in array )
			{
				if ( !string.IsNullOrEmpty( d.Name ) )
				{
					this.Namelist.Add( d.Address, d.Name );
				}
			}
			// 末尾に空白挿入
			this.Namelist.Add( 0U, string.Empty );
		}

		/// <summary>アドレスからソートIDを取得</summary>
		public int GetSortIDByAddress( uint address )
		{
			if ( address == 0 ) { return -1; }
			var data = Array.Find( this._items, d => d.Address == address );
			return ( data != null ) ? data.SortID : -1;
		}

		/// <summary>イテレータ</summary>
		public new IEnumerator<Shiro> GetEnumerator()
		{
			for ( var i = 0; i < this.Count; i++ )
			{
				yield return this._items[i];
			}
		}

		/// <summary>インデクサ</summary>
		public new Shiro this[int id]
		{
			get { return Array.Find( this._items, d => d.ID == id ); }
		}

		/// <summary>インデクサ アドレス ※必ず uint で渡す(int だとデータIDによる検索になる)</summary>
		public Shiro this[uint address]
		{
			get
			{
				if ( address == 0 ) { return null; }
				return Array.Find( this._items, d => d.Address == address );
			}
		}

		public override Predicate<object> FilterCallback { get; set; }
		/// <summary>フィルタ用コールバック</summary>
		private bool _filterCallback( object obj )
		{
			var d = obj as Shiro;

			if ( d == null )
			{
				return false;
			}

			return ( this._n14pkb.View.CheckSeiryoku( ( d.Seiryoku != null ) ? d.Seiryoku.Address : 0 ) );
		}
	}
}
