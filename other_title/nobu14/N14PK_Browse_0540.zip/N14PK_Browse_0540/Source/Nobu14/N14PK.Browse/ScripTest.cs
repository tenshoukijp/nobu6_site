﻿#if DEBUG
using System;
using N14PKLibrary;
using N14PKLibrary.Data;

namespace N14PKBrowse
{
	/// <summary>スクリプトテスト用クラス</summary>
	public class ScriptTest
	{
		public static void Function( N14PK n14pk, int id, ShiroData shiro )
		{
		}
	}
}
#endif