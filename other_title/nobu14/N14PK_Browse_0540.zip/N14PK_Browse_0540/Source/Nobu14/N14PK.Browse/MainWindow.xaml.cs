﻿#define SORT_MERGE
//#define SORT_CUSTOM
//#define SORT_DESCRIPTIONS

using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;

using N14PKBrowse.Column;
using N14PKBrowse.Data;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;
using N14PKBrowse.Sort;

namespace N14PKBrowse
{
	/// <summary>
	/// MainWindow.xaml の相互作用ロジック
	/// </summary>
	public partial class MainWindow : Window, IMainWindow
	{
		// コントロール
		public RadioButton[] RadioSeiryoku { get; set; }
		public RadioButton[] RadioMibun { get; set; }
		public DataGrid[] DataGrids { get; set; }
		public ComboBox ComboSeiryoku { get { return this.comboSeiryoku; } }

		private DispatcherTimer dispatcherTimer;
		private N14PKB _n14pkb;
		private N14PKBView _view;
		private Setting.ProgramSetting _settingData;
		public Setting.ProgramSetting SettingData { get { return this._settingData; } }
		private int _gridIndex;	
		public int SelectedTabIndex	// 選択タブ
		{
			get { return this._gridIndex; }
		}
		public int TabCount			// タブ数
		{
			get { return this.DataGrids.Length; }
		}

		private bool _hasException = false;	// 例外発生フラグ

		public MainWindow()
		{
			InitializeComponent();
			/////////////////////////////////////////////////////////////////////////////////////////////////////
#if DEBUG
			#region デバッグ時に使用するテストボタン
			this.testButton1.Visibility = System.Windows.Visibility.Visible;
			this.testButton1.IsEnabled = true;
			this.testButton1.Click += this.testButton1_Click;
			this.testButton2.Visibility = System.Windows.Visibility.Visible;
			this.testButton2.IsEnabled = true;
			this.testButton2.Click += this.testButton2_Click;
			this.testButton3.Visibility = System.Windows.Visibility.Visible;
			this.testButton3.IsEnabled = true;
			this.testButton3.Click += this.testButton3_Click;
			#endregion
#endif
			this.RadioSeiryoku = (RadioButton[])MyControlArray.GetControlArrayByName( this, "radioSeiryoku" );
			this.RadioMibun = (RadioButton[])MyControlArray.GetControlArrayByName( this, "radioMibun" );
			this.DataGrids = (DataGrid[])MyControlArray.GetControlArrayByName( this, "dataGrid" );
			foreach ( var dg in this.DataGrids )
			{
				dg.Visibility = System.Windows.Visibility.Collapsed;
			}

			// タイマー処理
			dispatcherTimer = new DispatcherTimer( DispatcherPriority.Normal );
			dispatcherTimer.Interval = new TimeSpan( 0, 0, 1 );
			dispatcherTimer.Tick += new EventHandler( dispatcherTimer_Tick );
			dispatcherTimer.Start();

			// Assembly取得
			var asm = System.Reflection.Assembly.GetExecutingAssembly();
			this.Title = asm.GetName().Name + " ver " + asm.GetName().Version;

			// 設定ファイルロード
			this._settingData = Setting.LoadSettingFile();

			// ウィンドウ設定
			this.Top = this._settingData.WinInfo.Top;
			this.Left = this._settingData.WinInfo.Left;
			this.Width = this._settingData.WinInfo.Width;
			this.Height = this._settingData.WinInfo.Height;
			/////////////////////////////////////////////////////////////////////////////////////////////////////
		}

		/// <summary>タイマーチック処理</summary>
		void dispatcherTimer_Tick( object sender, EventArgs e )
		{
			// ステータスバーのメモリ使用量を更新
			this.statusBarItem1.Content = ( GC.GetTotalMemory( false ) / 1024.0 / 1024.0 ).ToString( "F2" ) + " MB";
		}

		/// <summary>強制的にガベージコレクトする</summary>
		private void GCCollect()
		{
			this.statusBarItem1.Content = "GC中...";
			GC.Collect( GC.MaxGeneration, GCCollectionMode.Forced );
			GC.WaitForPendingFinalizers();
			GC.Collect( GC.MaxGeneration, GCCollectionMode.Forced );
		}

		/// <summary>イベントハンドラ メモリ使用量表示部分クリック</summary>
		private void statusBarItem1_MouseDoubleClick( object sender, MouseButtonEventArgs e )
		{
			this.GCCollect();
		}

		/// <summary>イベントハンドラ セルチェンジ</summary>
		private void DataGrid_CurrentCellChanged( object sender, EventArgs e )
		{
			// コミット
			this._n14pkb.Commit();
			// リフレッシュ
			this._view.Refresh( this.SelectedTabIndex );
		}

		/// <summary>列ヘッダセット</summary>
		private void SetColumn( DataGrid grid, ColumnSetting setting )
		{
			if ( setting == null ) { return; }

			// 自動生成しない
			grid.AutoGenerateColumns = false;

			grid.Columns.Clear();

			// 列設定情報を表示インデクス昇順でソートする
			Array.Sort( setting.Items, ( x, y ) => x.DispIndex - y.DispIndex );

			// 文字位置右寄せ用スタイル(右寄せしか処理していない)
			var style = new Style();
			style.Setters.Add( new Setter( TextBlock.TextAlignmentProperty, TextAlignment.Right ) );		// 文字配置
			style.Setters.Add( new Setter( TextBlock.MarginProperty, new Thickness( 0, 0, 2, 0 ) ) );		// マージン
			foreach ( var d in setting.Items )
			{
				// 数値による色分け用スタイル(対象文字列を取り出してトリガー設定)
				var style2 = new Style( typeof( DataGridCell ) );
				string[] strs = null;
				var length = 0;
				if ( d.Str != null )
				{
					strs = d.Str.Split( new Char[] { ',' }, StringSplitOptions.RemoveEmptyEntries );
					length = strs.Length;
				}
				for ( var i = 0; i < length; i++ )
				{
					style2.Triggers.Add( new DataTrigger() { Binding = new Binding( d.Prop ), Value = strs[i] } );
					( style2.Triggers[i] as DataTrigger ).Setters.Add( new Setter( ForegroundProperty, new SolidColorBrush( Color.FromRgb( 0xD0, 0xCC, 0xC8 ) ) ) );
				}

				switch ( d.Col )
				{
					// コンボリスト
					case ColKind.COMBO:
						var combo = new DataGridComboBoxColumn();
						combo.ItemsSource = d.Source;
						if ( ( d.Source is HelperClass.NameList<int> ) || d.Source is HelperClass.NameList<uint> )
						{
							combo.SelectedValuePath = "Key";
							combo.DisplayMemberPath = "Value";
						}
						combo.SelectedValueBinding = new Binding( d.Prop );
						combo.CellStyle = style2;
						grid.Columns.Add( combo );
						break;

					// チェックボックス
					case ColKind.CHECK:
						var check = new DataGridCheckBoxColumn();
						check.Binding = new Binding( d.Prop );
						check.CellStyle = style2;
						grid.Columns.Add( check );
						break;

					// テキスト
					case ColKind.TEXT:
						var text = new DataGridTextColumn();
						text.Binding = new Binding( d.Prop );
						grid.Columns.Add( text );

						if ( d.Ali == Column.Align.R )
						{
							text.ElementStyle = style;
							text.EditingElementStyle = style;
						}
						text.CellStyle = style2;
						break;

					default:
						break;
				}
				// 共通設定
				var index = grid.Columns.Count - 1;
				grid.Columns[index].Header = d.Head;
				grid.Columns[index].Width = ( d.Width != 0 && d.Width != 20 ) ? d.Width : DataGridLength.Auto;
				grid.Columns[index].IsReadOnly = ( d.IsRO ) ? true : false;
				grid.Columns[index].Visibility = ( d.IsHid ) ? Visibility.Collapsed : Visibility.Visible;
			}
			// 行見出し列数
			grid.FrozenColumnCount = setting.FrozenColumnCount;
		}

		/// <summary>列ヘッダコンテキストメニューセット</summary>
		private void SetColumnHeaderContextmenu( DataGrid grid, ColumnSetting setting )
		{
			if ( setting == null ) { return; }

			var contextMenu = new ContextMenu();	// コンテキストメニュー本体
			MenuItem menuItem;						// メニューアイテム

			menuItem = new MenuItem() { Header = "列設定リセット" };
			menuItem.Click += new RoutedEventHandler( this.RestColumnSetting );
			contextMenu.Items.Add( menuItem );
			menuItem = new MenuItem() { Header = "列項目全表示" };
			menuItem.Click += new RoutedEventHandler( this.DisplayAllColumn );
			contextMenu.Items.Add( menuItem );

			// 列設定情報分繰り返す
			for ( int dispIndex = 0; dispIndex < setting.Items.Length; dispIndex++ )
			{
				var item = Array.Find( setting.Items, d => d.DispIndex == dispIndex );
				// ヘッダコンテキストメニューアイテム作成
				menuItem = new MenuItem();					// メニューアイテム
				menuItem.Header = item.Head;				// メニュー名
				if ( !string.IsNullOrEmpty( item.Tip ) )	// ツールチップ
				{
					menuItem.ToolTip = item.Tip;
				}
				menuItem.IsCheckable = true;
				menuItem.IsChecked = item.IsHid ? false : true;
				menuItem.Click += new RoutedEventHandler( MenuItem_Click );
				// 行見出し列は操作不可にする
				if ( dispIndex < grid.FrozenColumnCount )
				{
					menuItem.IsEnabled = false;
					menuItem.IsChecked = false;
				}
				contextMenu.Items.Add( menuItem );

				var style = new Style();
				style.Setters.Add( new Setter( ToolTipService.ToolTipProperty, item.Tip ) );				// ツールチップテキスト
				style.Setters.Add( new Setter( ToolTipService.InitialShowDelayProperty, 0 ) );				// 表示ディレイ(ms)
				style.Setters.Add( new Setter( ToolTipService.ShowDurationProperty, 10000 ) );				// 表示時間(ms)
				style.Setters.Add( new Setter( DataGridColumnHeader.ContextMenuProperty, contextMenu ) );	// コンテキストメニュー
				grid.Columns[item.Index].HeaderStyle = style;
			}
		}

		/// <summary>列設定リセット(列ヘッダコンテキストメニュー)</summary>
		private void RestColumnSetting( object sender, RoutedEventArgs e )
		{
			var index = this.SelectedTabIndex;
			this._n14pkb.ColumnSettings[index].Reset();
			// カラムヘッダ再作成
			this.SetColumn( this.DataGrids[index], this._n14pkb.ColumnSettings[index] );
			this.SetColumnHeaderContextmenu( this.DataGrids[index], this._n14pkb.ColumnSettings[index] );

			if ( this._n14pkb.SortHistories[index].Count != 0 )
			{
				// ソート履歴があればカラムヘッダにソートマーク表示
				var sortdata = this._n14pkb.SortHistories[index][0];
				this.DataGrids[index].Columns[sortdata.Index].SortDirection = sortdata.IsAsc ? ListSortDirection.Ascending : ListSortDirection.Descending;
			}
		}

		/// <summary>列項目全表示(列ヘッダコンテキストメニュー)</summary>
		private void DisplayAllColumn( object sender, RoutedEventArgs e )
		{
			var gridIndex = this.SelectedTabIndex;
			foreach ( var d in this._n14pkb.ColumnSettings[gridIndex] )
			{
				if ( d.IsHid )
				{
					// "非表示"フラグクリア
					d.IsHid = false;
				}
			}
			foreach ( var d in this.DataGrids[gridIndex].Columns )
			{
				if ( d.Visibility != System.Windows.Visibility.Visible )
				{
					d.Visibility = System.Windows.Visibility.Visible;
				}
			}
			// 列ヘッダコンテキストメニュー更新
			this.SetColumnHeaderContextmenu( this.DataGrids[gridIndex], this._n14pkb.ColumnSettings[gridIndex] );
		}

		/// <summary>ヘッダコンテキストメニュークリック(表示項目切り替え)</summary>
		void MenuItem_Click( object sender, RoutedEventArgs e )
		{
			var gridIndex = this.SelectedTabIndex;
			var isHidden = !( sender as MenuItem ).IsChecked;
			var headerName = ( sender as MenuItem ).Header.ToString();
			var data = Array.Find( this._n14pkb.ColumnSettings[gridIndex].Items, d => d.Head == headerName );
			// 列設定情報の不可設定更新
			data.IsHid = isHidden;
			var index = data.Index;
			// 列ヘッダの不可設定更新
			this.DataGrids[gridIndex].Columns[index].Visibility = isHidden ? Visibility.Collapsed : Visibility.Visible;
		}

		/// <summary>イベントハンドラ 列ヘッダ移動完了</summary>
		private void DataGrid_ColumnReordered( object sender, DataGridColumnEventArgs e )
		{
			var gridIndex = this.SelectedTabIndex;
			if ( this._n14pkb.ColumnSettings[gridIndex] == null ) { return; }

			// 列設定情報の表示インデクス更新
			for ( var i = 0; i < DataGrids[gridIndex].Columns.Count; i++ )
			{
				this._n14pkb.ColumnSettings[gridIndex][i].DispIndex = DataGrids[gridIndex].Columns[i].DisplayIndex;
			}
			// 列ヘッダコンテキストメニュー更新
			this.SetColumnHeaderContextmenu( this.DataGrids[gridIndex], this._n14pkb.ColumnSettings[gridIndex] );
		}

		/// <summary>イベントハンドラ ソート</summary>
		private void DataGrid_Sorting( object sender, DataGridSortingEventArgs e )
		{
			// デフォルトソートは遅いしデータの内容によっては意図した並べかえができない。
			// ListCollectionView.SortDescriptions はデフォルトソートよりたいてい遅い。
			// ListCollectionView.CustomSort はそこそこ。だが安定ソート(ぽく)するには複数キーで連続ソートする必要があり遅い。
			// 安定ソートがほしいので自前でマージソートする。ソート自体は速いが結局WPFのグリッドリフレッシュが遅い。
			if ( this._n14pkb.ColumnSettings[this.SelectedTabIndex] == null )
			{
				// 列設定情報がなければデフォルトのソート処理
				return;
			}

			// 必要なデータの取得
			var dataGrid = sender as DataGrid;
			var columnIndex = dataGrid.Columns.IndexOf( e.Column );
			var columnSettingItem = this._n14pkb.ColumnSettings[this.SelectedTabIndex][columnIndex];
			//var propertyName = columnSettingItem.Prop;
			var propertyName = e.Column.SortMemberPath;
			var comparer = this._n14pkb.Comparers[this.SelectedTabIndex];
			var isAsc = ( e.Column.SortDirection == null ) ? columnSettingItem.IsAsc
				: e.Column.SortDirection == ListSortDirection.Ascending ? false
				: true;
			var callback = ( comparer != null ) ? comparer.GetCallback( propertyName ) : null;
			var sortHistory = this._n14pkb.SortHistories[this.SelectedTabIndex];

			if ( ( columnSettingItem.Mode == CompMode.UNKNOWN ) && ( callback == null ) )
			{
				// 比較モードが不明かつコールバックが未設定ならデフォルトソート処理
				return;
			}

			// ソート情報保存
			sortHistory.Save( columnIndex, propertyName, isAsc, columnSettingItem.Mode, callback );
#if DEBUG
			var sw = new System.Diagnostics.Stopwatch();
			sw.Start();
#endif
			e.Handled = this.Sort( this.SelectedTabIndex, sortHistory, SortMode.NORMAL );
#if DEBUG
			sw.Stop();
			System.Diagnostics.Debug.WriteLine( sw.ElapsedMilliseconds + " ms" );
#endif
		}

		/// <summary>ソート</summary>
		private bool Sort( int gridIndex, SortHistory history, SortMode mode )
		{
			if ( history.Count == 0 ) { return false; }
#if DEBUG
			System.Diagnostics.Debug.Write( "Sorting:" );
			var sw = new System.Diagnostics.Stopwatch();
			sw.Start();
#endif
#if SORT_MERGE
			// マージソート
#if DEBUG
			System.Diagnostics.Debug.Write( "MergeSort:" );
			if ( history[0].Callback != null )
				System.Diagnostics.Debug.WriteLine( "use callback" );
			else
				System.Diagnostics.Debug.WriteLine( "" );
#endif
			// ListCollectionView のViewに対して外からソートする方法がわからない
			// 元データそのものをソートする(ListCollectionViewの意味が無い)
			// FormのListView & ListViewItem の方が色々楽な気がする
			Sorter.Sort( this._n14pkb.DataLists[gridIndex].Items, history, mode );
			this._view.ListCollectionViews[gridIndex].Refresh();
			var index = this._n14pkb.ColumnSettings[gridIndex][history[0].PropertyName].Index;
			this.DataGrids[gridIndex].Columns[index].SortDirection = history[0].IsAsc ? ListSortDirection.Ascending : ListSortDirection.Descending;
			return true;
#elif SORT_CUSTOM
			// ListCollectionView.CustomSort
			if ( this._vm.Comparers[gridIndex].SetCallback( history[0].PropertyName, history[0].IsAsc ) )
			{
#if DEBUG
				System.Diagnostics.Debug.WriteLine( "CustomSort: use callback" );
#endif
				this._vm.ListCollectionViews[gridIndex].CustomSort = this._vm.Comparers[gridIndex];
				this.DataGrids[gridIndex].Columns[history[0].Index].SortDirection = history[0].IsAsc ? ListSortDirection.Ascending : ListSortDirection.Descending;
				return true;
			} else { return false; }
#elif SORT_DESCRIPTIONS
			// ListCollectionView.SortDescriptions
			if ( !string.IsNullOrEmpty( history[0].PropertyName ) )
			{
#if DEBUG
				System.Diagnostics.Debug.WriteLine( "SortDescription:" );
#endif
				this._vm.ListCollectionViews[gridIndex].SortDescriptions.Clear();
				this._vm.ListCollectionViews[gridIndex].SortDescriptions.Add( new SortDescription( history[0].PropertyName, ( history[0].IsAsc ? ListSortDirection.Ascending : ListSortDirection.Descending ) ) );
				this.DataGrids[gridIndex].Columns[history[0].Index].SortDirection = history[0].IsAsc ? ListSortDirection.Ascending : ListSortDirection.Descending;
				return true;
			} else { return false; }
#endif
		}

		/// <summary>イベントハンドラ タブ変更</summary>
		private void tabControl_SelectionChanged( object sender, SelectionChangedEventArgs e )
		{
			if ( ( e.OriginalSource as TabControl ) == null )
			{
				// 子コントロールのルーティングでも呼ばれるので TabControl 以外はスルー
				return;
			}
			var tc = sender as TabControl;
			// 選択タブインデクス保存
			this._gridIndex = tc.SelectedIndex;

			// コントロール設定
			this.SetControls( tc.SelectedIndex );

			System.Diagnostics.Debug.WriteLine( "tabControl_SelectionChanged: " + tc.SelectedIndex );

			if ( this._view == null )
			{
				return;
			}

			// ソート
			if ( this._view.Flags[this.SelectedTabIndex].IsFirst )
			{
				this._view.Flags[this.SelectedTabIndex].IsFirst = false;
				this.Sort( this.SelectedTabIndex, this._n14pkb.SortHistories[this.SelectedTabIndex], SortMode.FIRST );
			}
			// フィルタ処理
			this._view.Filtering( this.SelectedTabIndex );
			// リフレッシュ
			this._view.Refresh( this.SelectedTabIndex );
		}

		/// <summary>イベントハンドラ データ取得ボタン押下</summary>
		private void button_Click( object sender, RoutedEventArgs e )
		{
			this.GetData();
		}

		/// <summary>データ取得処理</summary>
		public void GetData()
		{
			try
			{
				if ( this._n14pkb == null )
				{
					// ビューモデル
					this._n14pkb = new N14PKB( this as IMainWindow );
					this._view = this._n14pkb.View;
					this.DataContext = this._view;
				}
				else
				{
					// 列設定情報収集
					this.SetColInfo();

					// データ再読み込み
					this._n14pkb.ReloadDataLists();
					this._view.ResetListCollectionViews();
					// 勢力名セット
					this._n14pkb.View.SeiryokuNamelist = this._n14pkb.Seiryokulist.SeiryokuAndTousyunamelist;
				}

				// DataGridセット
				for ( var i = 0; i < this.DataGrids.Length; i++ )
				{
					this.DataGrids[i].Visibility = System.Windows.Visibility.Collapsed;
					if ( this._view.ListCollectionViews[i] != null )
					{
						this.DataGrids[i].Visibility = System.Windows.Visibility.Visible;
						this.DataGrids[i].ItemsSource = this._view.ListCollectionViews[i];
						this.DataGrids[i].ContextMenu = ( this._n14pkb.CMenus[i] != null ) ? this._n14pkb.CMenus[i].CMenu : null;
					}

					// 列設定
					this.SetColumn( this.DataGrids[i], this._n14pkb.ColumnSettings[i] );
					this.SetColumnHeaderContextmenu( this.DataGrids[i], this._n14pkb.ColumnSettings[i] );
				}

				// ソート
				if ( this._view.Flags[this.SelectedTabIndex].IsFirst )
				{
					this._view.Flags[this.SelectedTabIndex].IsFirst = false;
					this.Sort( this.SelectedTabIndex, this._n14pkb.SortHistories[this.SelectedTabIndex], SortMode.FIRST );
				}

				// フィルタ処理
				this._view.Filtering( this.SelectedTabIndex );
				// GC
				this.GCCollect();
			}
			catch ( Exception ex )
			{
				var message = ex.Message;// + Environment.NewLine + "StackTrace:\n" + ex.StackTrace;
				System.Windows.MessageBox.Show( message, "エラー", MessageBoxButton.OK, MessageBoxImage.Error );
				this._hasException = true;
				//throw;
			}
		}

		/// <summary>イベントハンドラ ウィンドウクローズ</summary>
		private void Window_Closing( object sender, CancelEventArgs e )
		{
			if ( !this._hasException && this._n14pkb != null )
			{
				// プログラム設定情報収集
				// 列設定情報収集
				this.SetColInfo();
				this._settingData.Misc = new Setting.Miscellany() { MyVersion = this._n14pkb.MyVersion, GameVersion = this._n14pkb.GameVersion };
			}
			this._settingData.WinInfo = this.ToSetting();

			// プログラム設定情報保存
			Setting.SaveSettingFile( this._settingData );
		}

		/// <summary>列設定情報収集</summary>
		private void SetColInfo()
		{
			if ( this._settingData.TabNames == null )
			{
				this._settingData.TabNames = new Enums.TabKind[this.TabCount];
				this._settingData.ColInfo = new Setting.ColumnInformation[this.TabCount][];
			}

			for ( var i = 0; i < this._n14pkb.ColumnSettings.Length; i++ )
			{
				this._settingData.TabNames[i] = (Enums.TabKind)i;
				if ( this._n14pkb.ColumnSettings[i] != null )
				{
					for ( var c = 0; c < this.DataGrids[i].Columns.Count; c++ )
					{
						this._n14pkb.ColumnSettings[i][c].Width = (int)Math.Ceiling( this.DataGrids[i].Columns[c].ActualWidth );
					}
					this._settingData.ColInfo[i] = this._n14pkb.ColumnSettings[i].ToSetting();
				}
			}
		}

		/// <summary>設定保存用のウィンドウ情報を返す</summary>
		private Setting.WindowInformation ToSetting()
		{
			return new Setting.WindowInformation()
			{
				Top = (int)this.Top,
				Left = (int)this.Left,
				Width = (int)this.Width,
				Height = (int)this.Height
			};
		}

		/// <summary>イベントハンドラ コンテキストメニューオープン</summary>
		private void DataGrid_ContextMenuOpening( object sender, ContextMenuEventArgs e )
		{
			if ( this.DataGrids[this.SelectedTabIndex].SelectedItems.Count != 0 )
			{
				this._n14pkb.CMenus[this.SelectedTabIndex].ContextMenuOpening();
			}
		}

		/// <summary>イベントハンドラ セル編集前移行</summary>
		private void DataGrid_BeginningEdit( object sender, DataGridBeginningEditEventArgs e )
		{
			try
			{
				if ( !Funcs.CheckDate( this._n14pkb.N14pk ) )
				{
#if DEBUG
					System.Diagnostics.Debug.WriteLine( "編集キャンセル" );
#endif
					e.Cancel = true;
					return;
				}
			}
			catch ( Exception ex )
			{
				var message = ex.Message;
				System.Windows.MessageBox.Show( message, "エラー", MessageBoxButton.OK, MessageBoxImage.Error );
				e.Cancel = true;
				return;
			}

			// 編集キャンセルの挙動設定
			#region 武将タブ
			if ( this.SelectedTabIndex == (int)TabKind.武将 )
			{
				var d = e.Row.Item as Data.Busyou;	// 選択中データ

				if ( (string)e.Column.Header == "軍団" )
				{
					// 所属軍団編集
					if ( d.MibunID == (int)MibunKind.なし
						|| d.MibunID == (int)MibunKind.生前
						|| d.MibunID == (int)MibunKind.他
						|| ( d.MibunID == (int)MibunKind.姫 && ( d.PtrGundan == 0 || d.PtrHaigusya != 0 ) )
						|| ( d.Data.SyozaiType != (int)DataAddressKind.城 && d.MibunID != (int)MibunKind.姫 && d.MibunID != (int)MibunKind.捕虜 )
						)
					{
						e.Cancel = true;
						return;
					}
				}
				if ( (string)e.Column.Header == "城" )
				{
					// 所属拠点編集
					if ( d.MibunID == (int)MibunKind.なし
						|| d.MibunID == (int)MibunKind.他
						|| d.MibunID == (int)MibunKind.姫
						|| ( d.Data.SyozaiType != (int)DataAddressKind.城 && d.MibunID != (int)MibunKind.捕虜 )
						)
					{
						e.Cancel = true;
						return;
					}
				}
			}
			#endregion

			#region 城タブ
			if ( this.SelectedTabIndex == (int)TabKind.城 )
			{
				var d = e.Row.Item as Data.Shiro;	// 選択中データ
				if ( (string)e.Column.Header == "軍団" )
				{
					// 任務中武将がいる
					if ( 0 < d.CntNinmuList )
					{
						e.Cancel = true;
						return;
					}
				}
			}
			#endregion
		}

		/// <summary>タブインデクスによりコントロールの表示設定を切り替える</summary>
		private void SetControls( int tabindex )
		{
			// コンボボックス勢力選択
			if ( tabindex == (int)TabKind.武将
				|| tabindex == (int)TabKind.城
				|| tabindex == (int)TabKind.区画
				//|| tabindex == (int)TabKind.軍団
				|| tabindex == (int)TabKind.建物
				|| tabindex == (int)TabKind.部隊
				|| tabindex == (int)TabKind.国人衆
				|| tabindex == (int)TabKind.要所
				|| tabindex == (int)TabKind.街道
				)
			{
				this.ComboSeiryoku.IsEnabled = true;
				this.ComboSeiryoku.Foreground = System.Windows.Media.Brushes.Black;
			}
			else
			{
				this.ComboSeiryoku.IsEnabled = false;
				this.ComboSeiryoku.Foreground = System.Windows.Media.Brushes.LightGray;
			}

			// ラジオボタン勢力
			if ( tabindex == (int)TabKind.武将
				|| tabindex == (int)TabKind.城
				|| tabindex == (int)TabKind.区画
				//|| tabindex == (int)TabKind.軍団
				|| tabindex == (int)TabKind.建物
				|| tabindex == (int)TabKind.部隊
				|| tabindex == (int)TabKind.国人衆
				|| tabindex == (int)TabKind.要所
				|| tabindex == (int)TabKind.街道
				)
			{
				foreach ( var d in this.RadioSeiryoku )
				{
					d.IsEnabled = true;
					d.Foreground = System.Windows.Media.Brushes.Black;
				}
			}
			else
			{
				foreach ( var d in this.RadioSeiryoku )
				{
					d.IsEnabled = false;
					d.Foreground = System.Windows.Media.Brushes.LightGray;
				}
			}

			// ラジオボタン身分
			if ( tabindex == (int)TabKind.武将 )
			{
				foreach ( var d in this.RadioMibun )
				{
					d.IsEnabled = true;
					d.Foreground = System.Windows.Media.Brushes.Black;
				}
			}
			else
			{
				foreach ( var d in this.RadioMibun )
				{
					d.IsEnabled = false;
					d.Foreground = System.Windows.Media.Brushes.LightGray;
				}
			}
		}

#if DEBUG
		/// <summary>イベントハンドラ テストボタン1クリック</summary>
		private void testButton1_Click( object sender, RoutedEventArgs e )
		{
			// スクリプトテスト
			var tabIndex = this._n14pkb.MainWindowInterface.SelectedTabIndex;
			var grid = this._n14pkb.MainWindowInterface.DataGrids[tabIndex];
			if ( grid.SelectedItems.Count == 0 ) { return; }

			// 選択中のデータ
			foreach ( var d in grid.SelectedItems )
			{
				var data = ( d as Shiro ).Data;

				// スクリプト
				ScriptTest.Function( this._n14pkb.N14pk, data.ID, data );
			}
		}

		/// <summary>イベントハンドラ テストボタン2クリック</summary>
		private void testButton2_Click( object sender, RoutedEventArgs e )
		{
		}

		/// <summary>イベントハンドラ テストボタン3クリック</summary>
		private void testButton3_Click( object sender, RoutedEventArgs e )
		{
		}
#endif
	}
}
