﻿// IMainWindow.cs

using System.Windows.Controls;

namespace N14PKBrowse
{
	/// <summary>メインウィンドウ操作用インターフェイス</summary>
	public interface IMainWindow
	{
		int TabCount { get; }
		int SelectedTabIndex { get; }
		DataGrid[] DataGrids { get; }
		ComboBox ComboSeiryoku { get; }
		Setting.ProgramSetting SettingData { get; }
		void GetData();
	}
}
