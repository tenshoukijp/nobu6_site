﻿// BusyouColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;
using N14PKBrowse.List;

namespace N14PKBrowse.Column
{
	/// <summary>武将ビューの列設定情報</summary>
	public class BusyouColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 4; } }

		/// <summary>コンストラクタ</summary>
		public BusyouColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",					Head = "ID",				Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "PtrGundan",				Head = "軍団",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Gundanlist.Namelist },
				new ColumnSettingItem { Prop = "Name",					Head = "名前",				Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "PtrKyoten",				Head = "城",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Shirolist.Namelist },
				new ColumnSettingItem { Prop = "Sei",					Head = "姓",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Mei",					Head = "名",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yomi",					Head = "読み",				Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "SeiYomi",				Head = "姓読み",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "MeiYomi",				Head = "名読み",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Mei2",					Head = "名2",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.STR, Tip = "名に通称が設定されている場合は本名、名が本名の場合はデータなし" },
				new ColumnSettingItem { Prop = "MeiYomi2",				Head = "名2読み",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.STR, Tip = "名に通称が設定されている場合は本名、名が本名の場合はデータなし" },
				new ColumnSettingItem { Prop = "Syozai",				Head = "所在",				Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				//
				//new ColumnSettingItem { Prop = "IsTousyu",				Head = "当主",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				//new ColumnSettingItem { Prop = "IsGundanchou",			Head = "軍団長",			Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				//
				new ColumnSettingItem { Prop = "KetsuzokuID",			Head = "血族",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Str = "-1" },
				new ColumnSettingItem { Prop = "IsIchimon",				Head = "一門",				Ali = Align.L, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Chichi",				Head = "実父",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR, Col = ColKind.COMBO, Source = this._n14pkb.Busyoulist.Namelist },
				new ColumnSettingItem { Prop = "Youfu",					Head = "養父",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR, Col = ColKind.COMBO, Source = this._n14pkb.Busyoulist.Namelist },
				new ColumnSettingItem { Prop = "Haigusya",				Head = "配偶者",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR, Col = ColKind.COMBO, Source = this._n14pkb.Busyoulist.Namelist },
				new ColumnSettingItem { Prop = "Haha",					Head = "母",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "ShinaiList",			Head = "親愛武将リスト",	Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST, Tip = "親愛武将リスト" },
				new ColumnSettingItem { Prop = "KenoList",				Head = "嫌悪武将リスト",	Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST, Tip = "嫌悪武将リスト" },
				new ColumnSettingItem { Prop = "PtrKahou",				Head = "家宝",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Kahoulist.Namelist },
				new ColumnSettingItem { Prop = "MibunSyousai",			Head = "身分詳細",			Ali = Align.L, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.STR, Str = "なし" },
				new ColumnSettingItem { Prop = "MibunID",				Head = "身分",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.武将身分, Tip = "変更はできるが身分IDを変えているだけでデータの整合性は一切取っていない" },
				new ColumnSettingItem { Prop = "IsJousyu",				Head = "城主",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "IsBugyou",				Head = "奉行",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "IsInkyo",				Head = "隠居",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "IsJosei",				Head = "女性",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "SyoubyouID",			Head = "傷病",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.武将傷病 },
				new ColumnSettingItem { Prop = "Nenrei",				Head = "年齢"	,			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "Yomei",					Head = "余命"	,			Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "Shikan",				Head = "仕官"	,			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "仕官年数" },
				new ColumnSettingItem { Prop = "YearSei",				Head = "生年",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "YearToujou",			Head = "登年"	,			Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "YearBotsu",				Head = "没年",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "DateYearShikan",		Head = "仕年",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "仕官した年" },
				new ColumnSettingItem { Prop = "UnknownDate",			Head = "不明年月",			Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.STR, Str = "0" },
				new ColumnSettingItem { Prop = "KakuID",				Head = "格",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.武将格 },
				new ColumnSettingItem { Prop = "Tousotsu",				Head = "統率",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.STR, Str = "0", Tip = "カッコ内は経験値による増分 ※入力した値は基本値に反映" },
				new ColumnSettingItem { Prop = "Buyuu",					Head = "武勇",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.STR, Str = "0", Tip = "カッコ内は経験値による増分 ※入力した値は基本値に反映" },
				new ColumnSettingItem { Prop = "Chiryaku",				Head = "知略",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.STR, Str = "0", Tip = "カッコ内は経験値による増分 ※入力した値は基本値に反映" },
				new ColumnSettingItem { Prop = "Seiji",					Head = "政治",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.STR, Str = "0", Tip = "カッコ内は経験値による増分 ※入力した値は基本値に反映" },
				new ColumnSettingItem { Prop = "TousotsuExp",			Head = "統率EXP",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM, Str = "0", Tip = "100毎に能力 +1" },
				new ColumnSettingItem { Prop = "BuyuuExp",				Head = "武勇EXP",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM, Str = "0", Tip = "100毎に能力 +1" },
				new ColumnSettingItem { Prop = "ChiryakuExp",			Head = "知略EXP",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM, Str = "0", Tip = "100毎に能力 +1" },
				new ColumnSettingItem { Prop = "SeijiExp",				Head = "政治EXP",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM, Str = "0", Tip = "100毎に能力 +1" },
				new ColumnSettingItem { Prop = "PtrSenpou",				Head = "戦法",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Senpoulist.Namelist },
				new ColumnSettingItem { Prop = "Tokuseisuu",			Head = "特性",				Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "特性数" },
				new ColumnSettingItem { Prop = "SeichougataID",			Head = "成長型",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Seichougatalist.Namelist },
				new ColumnSettingItem { Prop = "Souzou",				Head = "主義(創造)",		Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.STR, Str = "保守( 0)", Tip = "入力した値は創造性に反映" },
				new ColumnSettingItem { Prop = "ChuuseiHoseiGoukei",	Head = "忠計"	,			Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.NUM, Tip = "忠誠補正合計" },
				new ColumnSettingItem { Prop = "HitsuyouChuusei",		Head = "必忠",				Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "必要忠誠" },
				new ColumnSettingItem { Prop = "Hanshin",				Head = "叛心",				Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "自勢力の武将は値が変化しない？" },
				new ColumnSettingItem { Prop = "PtrToujouKuni",			Head = "登場国",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Kunilist.Namelist },
				new ColumnSettingItem { Prop = "PtrKuni",				Head = "国1",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Kunilist.Namelist, Tip = "用途不明" },
				new ColumnSettingItem { Prop = "h0D8",				Head = "D8",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM, Str = "255", Tip = "不明" },
				new ColumnSettingItem { Prop = "h0D9",				Head = "D9",				Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM, Tip = "相性？" },
				new ColumnSettingItem { Prop = "UmajirushiID",			Head = "馬印",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "馬印ID" },
				new ColumnSettingItem { Prop = "HataID",				Head = "旗",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "旗ID" },
				new ColumnSettingItem { Prop = "IsByoushi",				Head = "病死",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "ShinkouID",				Head = "信仰",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.武将信仰 },
				new ColumnSettingItem { Prop = "SyutsujiID",			Head = "出自",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.武将出自 },
				new ColumnSettingItem { Prop = "KoeTypeID",				Head = "声ID",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.武将声タイプ },
				new ColumnSettingItem { Prop = "ShidouID",				Head = "士道",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.武将士道 },
				new ColumnSettingItem { Prop = "KaoguraID1",			Head = "顔ID1",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "KaoguraID2",			Head = "顔ID2",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "IsLLKao",				Head = "LL顔",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.FLAG, Col = ColKind.CHECK, Tip = "顔グラバストアップフラグ" },
				new ColumnSettingItem { Prop = "AddressHex",			Head = "アドレス",			Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
