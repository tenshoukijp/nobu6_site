﻿// KahouColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>家宝ビューの列設定情報</summary>
	public class KahouColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 2; } }

		/// <summary>コンストラクタ</summary>
		public KahouColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",				Head = "ID",		Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.NUM },

				new ColumnSettingItem { Prop = "Name",				Head = "名称",		Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yomi",				Head = "読み",		Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "PtrHoyuuSeiryoku",	Head = "保有勢力",	Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Seiryokulist.Namelist },
				new ColumnSettingItem { Prop = "HoyuuBusyou",		Head = "保有武将",	Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR, Col = ColKind.COMBO, Source = this._n14pkb.Busyoulist.Namelist },
				new ColumnSettingItem { Prop = "BunruiID",			Head = "分類",		Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1 },
				new ColumnSettingItem { Prop = "ToukyuuID",			Head = "等級",		Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = Helper.家宝等級 },
				new ColumnSettingItem { Prop = "KahouTypeID",		Head = "種類",		Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.家宝種類 },
				new ColumnSettingItem { Prop = "h44_b0",			Head = "b0-44",		Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "勢力または個人が所有している(家宝情報に表示される)場合は1？\n0で再販売されるかは未確認", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h44_b1",			Head = "b1-44",		Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "イベント関連フラグ？", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "SanchiID",			Head = "産地",		Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.家宝産地 },

				new ColumnSettingItem { Prop = "AddressHex",		Head = "アドレス",	Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
