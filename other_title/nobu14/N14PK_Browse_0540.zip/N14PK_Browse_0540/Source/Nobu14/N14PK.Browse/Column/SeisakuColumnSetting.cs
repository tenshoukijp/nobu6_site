﻿// SeisakuColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>政策ビューの列設定情報</summary>
	public class SeisakuColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 2; } }

		/// <summary>コンストラクタ</summary>
		public SeisakuColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",					Head = "ID",			Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "Name",					Head = "名称",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yomi",					Head = "読み",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Riten1",				Head = "利点1",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Riten2",				Head = "利点2",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Ketten1",				Head = "欠点1",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Ketten2",				Head = "欠点2",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Hiyou",					Head = "費用",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "Souzouseilowerlimit",	Head = "創造下",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "実施可能な創造性の下限" },
				new ColumnSettingItem { Prop = "SouzouseiUpperlimit",	Head = "創造上",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "実施可能な創造性の上限" },
				new ColumnSettingItem { Prop = "h102_2",				Head = "102",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "PtrZenteiSeisaku",		Head = "前提政策",		Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Seisakulist.Namelist },
				new ColumnSettingItem { Prop = "h108_4",				Head = "dw108",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "SenyouKetsuzokuID",		Head = "血族ID",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM1, Str = "-1", Tip = "専用血族ID" },
				new ColumnSettingItem { Prop = "SeisakuTypeID",			Head = "タイプ",		Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.政策タイプ },

				new ColumnSettingItem { Prop = "h111",				Head = "石高",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h112",				Head = "商業",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h113",				Head = "兵舎",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h114",				Head = "収穫",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h115",				Head = "収入",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h116",				Head = "国人兵",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h117",				Head = "117",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h118",				Head = "懐柔",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h119",				Head = "包囲士気",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "敵城包囲時の士気ゲージ減少" },
				new ColumnSettingItem { Prop = "h11A",				Head = "11A",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h11B",				Head = "人口",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h11C",				Head = "領民兵",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "最大領民兵(*10%)" },
				new ColumnSettingItem { Prop = "h11D",				Head = "本城常備兵",	Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "本城最大常備兵(*10%)" },
				new ColumnSettingItem { Prop = "h11E",				Head = "民忠",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "最大民忠" },
				new ColumnSettingItem { Prop = "h11F",				Head = "兵農分離",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "政策『兵農分離』に 1 が入っているが他の政策に設定しても効果が出ない？" },
				new ColumnSettingItem { Prop = "h120",				Head = "120",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h121",				Head = "取引価格",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "取引価格(%)" },
				new ColumnSettingItem { Prop = "h122",				Head = "商人(堺)",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h123",				Head = "商人(南蛮)",	Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h124",				Head = "一揆",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "一揆発生率" },
				new ColumnSettingItem { Prop = "h125",				Head = "港収入",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h126",				Head = "126",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h127",				Head = "127",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h128",				Head = "忠補(能主)",	Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "忠誠補正(能力主義)" },
				new ColumnSettingItem { Prop = "h129",				Head = "忠補(指検)",	Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "忠誠補正(指出検地)" },
				new ColumnSettingItem { Prop = "h12A",				Head = "忠補(所安)",	Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "忠誠補正(所領安堵)" },
				new ColumnSettingItem { Prop = "h12B",				Head = "12B",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h12C",				Head = "外交収入",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "外交収入(%)" },
				new ColumnSettingItem { Prop = "h12D",				Head = "12D",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h12E",				Head = "12E",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0,-1", Tip = "0xFF固定？" },
				new ColumnSettingItem { Prop = "h12F",				Head = "12F",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0,-1", Tip = "0xFF固定？" },
				new ColumnSettingItem { Prop = "h130",				Head = "130",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h131",				Head = "遠交近攻策",	Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "外交制限解除(遠交近攻策)" },
				new ColumnSettingItem { Prop = "h132",				Head = "近工",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "近工作効果" },
				new ColumnSettingItem { Prop = "h133",				Head = "遠工",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "遠工作効果" },
				new ColumnSettingItem { Prop = "h134",				Head = "134",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h135",				Head = "惣無事令",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h136",				Head = "馬鉄配備",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "軍馬・鉄砲配備時の攻撃増" },
				new ColumnSettingItem { Prop = "h137",				Head = "馬鉄未配",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "軍馬・鉄砲未配備時の攻撃減" },
				new ColumnSettingItem { Prop = "h138",				Head = "軍馬配備",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "軍馬配備時の攻撃増" },
				new ColumnSettingItem { Prop = "h139",				Head = "軍馬未配",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "軍馬未配備時の攻撃減" },
				new ColumnSettingItem { Prop = "h13A",				Head = "鉄砲配備",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "鉄砲配備時の攻撃増" },
				new ColumnSettingItem { Prop = "h13B",				Head = "鉄砲未配",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "鉄砲未配備時の攻撃減" },
				new ColumnSettingItem { Prop = "h13C",				Head = "13C",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h13D",				Head = "13D",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h13E",				Head = "支城常備兵",	Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "支城最大常備兵(*10%)" },
				new ColumnSettingItem { Prop = "h13F",				Head = "忠補(創造)",	Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "忠誠補正(創造)" },
				new ColumnSettingItem { Prop = "h140",				Head = "忠補(中道)",	Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "忠誠補正(中道)" },
				new ColumnSettingItem { Prop = "h141",				Head = "忠補(保守)",	Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "忠誠補正(保守)" },
				new ColumnSettingItem { Prop = "h142",				Head = "陣効果",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h143",				Head = "経験補正",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h144",				Head = "兵糧補給効率",	Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h145",				Head = "疲労補正",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "疲労補正(%)" },
				new ColumnSettingItem { Prop = "h146",				Head = "146",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h147",				Head = "147",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h148",				Head = "行軍影響",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h149",				Head = "朝廷工作",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "朝廷工作上昇量" },
				new ColumnSettingItem { Prop = "h14A",				Head = "密談効果",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "密談効果上昇量" },
				new ColumnSettingItem { Prop = "h14B",				Head = "軍略効果",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "軍団長の軍略効果上昇量" },
				new ColumnSettingItem { Prop = "h14C",				Head = "直轄範囲",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "直轄軍団の統治範囲" },
				new ColumnSettingItem { Prop = "h14D",				Head = "登用",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "捕虜登用率" },
				new ColumnSettingItem { Prop = "h14E",				Head = "14E",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h14F",				Head = "14F",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h150",				Head = "150",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h151",				Head = "151",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h152",				Head = "152",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h153",				Head = "153",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },

				new ColumnSettingItem { Prop = "AddressHex",			Head = "アドレス",		Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
