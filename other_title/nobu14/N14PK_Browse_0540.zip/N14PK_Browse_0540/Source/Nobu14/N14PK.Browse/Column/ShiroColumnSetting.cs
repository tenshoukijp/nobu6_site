﻿// ShiroColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;
using N14PKBrowse.List;

namespace N14PKBrowse.Column
{
	/// <summary>城ビューの列設定情報</summary>
	public class ShiroColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 4; } }

		/// <summary>コンストラクタ</summary>
		public ShiroColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",							Head = "ID",					Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "Shisetsuname",					Head = "タイプ",				Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "PtrGundan",						Head = "軍団",					Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Gundanlist.Namelist },
				new ColumnSettingItem { Prop = "Name",							Head = "名称",					Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yomi",							Head = "読み",					Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Heisuu",						Head = "兵数",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Jinkou",						Head = "人口",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Tamichuu",						Head = "民忠",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Shiki",							Head = "士気",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "TaikyuuNow",					Head = "耐久",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM1, Str = "-1", Tip = "耐久現在値" },
				new ColumnSettingItem { Prop = "TaikyuuMax",					Head = "耐大",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM1, Str = "-1", Tip = "耐久最大値" },
				new ColumnSettingItem { Prop = "Jousyuname",					Head = "城主",					Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Bugyouname",					Head = "奉行",					Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "KukakuInfo",					Head = "区画",					Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.STR, Str = " 0/ 0", Tip = "拡張済(+拡張可)/最大区画数" },
				new ColumnSettingItem { Prop = "KukakuUchiwake",				Head = "区画内訳",				Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR, Str = "-" },
				new ColumnSettingItem { Prop = "KokudakaNow",					Head = "石高",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "石高現在値" },
				new ColumnSettingItem { Prop = "KokudakaMax",					Head = "石大",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "石高最大値 区画の合計値表示用？" },
				new ColumnSettingItem { Prop = "SyougyouNow",					Head = "商業",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "商業現在値" },
				new ColumnSettingItem { Prop = "SyougyouMax",					Head = "商大",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "商業最大値 区画の合計値表示用？" },
				new ColumnSettingItem { Prop = "HeisyaNow",						Head = "兵舎",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "兵舎現在値" },
				new ColumnSettingItem { Prop = "HeisyaMax",						Head = "兵大",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "兵舎最大値 区画の合計値表示用？" },
				new ColumnSettingItem { Prop = "h00E8_2",						Head = "wE8",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "YouchiInfo",					Head = "用地",					Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.STR, Str = " 0/ 0", Tip = "使用済/用地" },
				new ColumnSettingItem { Prop = "IsYouchiZenkai",				Head = "全開",					Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Col = ColKind.CHECK, Tip = "用地を全開(20)にする" },
				new ColumnSettingItem { Prop = "PtrJoukaku1",					Head = "天守",					Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Tip = "城郭：天守", Col = ColKind.COMBO, Source = this._n14pkb.Joukakulist.Namelist },
				new ColumnSettingItem { Prop = "PtrJoukaku2",					Head = "城門",					Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Tip = "城郭：城門", Col = ColKind.COMBO, Source = this._n14pkb.Joukakulist.Namelist },
				new ColumnSettingItem { Prop = "PtrJoukaku3",					Head = "塀",					Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Tip = "城郭：塀", Col = ColKind.COMBO, Source = this._n14pkb.Joukakulist.Namelist },
				new ColumnSettingItem { Prop = "PtrJoukaku4",					Head = "出丸",					Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Tip = "城郭：出丸", Col = ColKind.COMBO, Source = this._n14pkb.Joukakulist.Namelist },
				new ColumnSettingItem { Prop = "PtrJoukaku5",					Head = "矢倉",					Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Tip = "城郭：矢倉", Col = ColKind.COMBO, Source = this._n14pkb.Joukakulist.Namelist },
				new ColumnSettingItem { Prop = "PtrJoukaku6",					Head = "曲輪",					Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Tip = "城郭：曲輪", Col = ColKind.COMBO, Source = this._n14pkb.Joukakulist.Namelist },
				new ColumnSettingItem { Prop = "PtrJoukaku7",					Head = "施設",					Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Tip = "城郭：施設", Col = ColKind.COMBO, Source = this._n14pkb.Joukakulist.Namelist },
				new ColumnSettingItem { Prop = "CntHouiButaiList",				Head = "包囲",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "包囲している部隊数" },
				new ColumnSettingItem { Prop = "HouiButaiList",					Head = "包囲部隊リスト",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "h002C_4",						Head = "dw2C",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "CntSyutsujinButaiList",			Head = "出陣",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "出陣中部隊数" },
				new ColumnSettingItem { Prop = "SyutsujinButaiList",			Head = "出陣部隊リスト",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntNinmuList",					Head = "任務",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "不明" },
				new ColumnSettingItem { Prop = "NinmuList",						Head = "任務リスト",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntKoudoukanouList",			Head = "行動可",				Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "KoudoukanouList",				Head = "行動可能武将リスト",	Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntRouninList",					Head = "浪人",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "RouninList",					Head = "浪人リスト",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntSyuuhenButaiList",			Head = "周辺",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "城周辺部隊数" },
				new ColumnSettingItem { Prop = "SyuuhenButaiList",				Head = "周辺部隊リスト",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST, Tip = "城周辺の部隊リスト" },
				new ColumnSettingItem { Prop = "Kouzan",						Head = "鉱山",					Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "表示のみ" },
				new ColumnSettingItem { Prop = "Minato",						Head = "港",					Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "表示のみ" },
				new ColumnSettingItem { Prop = "Syougyoukou",					Head = "商港",					Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "表示のみ" },
				new ColumnSettingItem { Prop = "Gunkou",						Head = "軍港",					Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "表示のみ" },
				new ColumnSettingItem { Prop = "CntTatemonoList",				Head = "建物",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "拠点に属している建物数" },
				new ColumnSettingItem { Prop = "TatemonoList",					Head = "建物リスト",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "h0108_4",						Head = "dw108",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h010C_4",						Head = "dw10C",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0110_4",						Head = "dw110",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0114_4",						Head = "dw114",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0118_4",						Head = "dw118",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h011C_4",						Head = "dw11C",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0120_4",						Head = "dw120",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0124_4",						Head = "dw124",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0128_4",						Head = "dw128",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h012C_4",						Head = "dw12C",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0130_2",						Head = "w130",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0132_2",						Head = "w132",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0134",						Head = "134",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0135",						Head = "135",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0136",						Head = "136",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0137",						Head = "137",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0138",						Head = "138",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0139",						Head = "139",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h013A",						Head = "13A",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h013B",						Head = "13B",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "用地関連(ゲーム内編集機能で全開にすると第7ビットが立つ)" },
				new ColumnSettingItem { Prop = "h013C_2",						Head = "w13C",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h013E_2",						Head = "w13E",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0140_2",						Head = "w140",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0142_2",						Head = "w142",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0144_2",						Head = "w144",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0146_2",						Head = "w146",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0148_2",						Head = "w148",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h014A_2",						Head = "w14A",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "CntList_0030",					Head = "List30",				Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "List_0030",						Head = "List30リスト",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntList_0044",					Head = "List44",				Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "List_0044",						Head = "List44リスト",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntList_0068",					Head = "List66",				Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "List_0068",						Head = "List66リスト",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntList_0080",					Head = "List80",				Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "List_0080",						Head = "List80リスト",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntList_0098",					Head = "List98",				Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "PtrList_0098",					Head = "List98リスト",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.PLIST },
				//new ColumnSettingItem { Prop = "YousyoName",					Head = "要所",					Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.STR },

				new ColumnSettingItem { Prop = "AddressHex",			Head = "アドレス",	Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
