﻿// KokujinColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>国人衆ビューの列設定情報</summary>
	public class KokujinColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 2; } }

		/// <summary>コンストラクタ</summary>
		public KokujinColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",					Head = "ID",			Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.NUM },

				new ColumnSettingItem { Prop = "Name",					Head = "名称",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yomi",					Head = "読み",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Touryou",				Head = "頭領",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "TorikomiBusyou",		Head = "取込武将",		Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR, Col = ColKind.COMBO, Source = this._n14pkb.Busyoulist.Namelist },
				new ColumnSettingItem { Prop = "TokunouID",				Head = "特能",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.国人衆特能 },
				new ColumnSettingItem { Prop = "Heisuu",				Head = "現兵数",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "HeisuuMax",				Head = "最大兵",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "Kuni",					Head = "国",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yousyoname",			Head = "要所",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "PtrSyozokuSeiryoku",	Head = "所属",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Seiryokulist.Namelist },

				new ColumnSettingItem { Prop = "PtrShijiSeiryoku1",		Head = "勢力1",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Seiryokulist.Namelist },
				new ColumnSettingItem { Prop = "Shijiritsu1",			Head = "%1",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0D0",				Head = "D0",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "PtrShijiSeiryoku2",		Head = "勢力2",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Seiryokulist.Namelist },
				new ColumnSettingItem { Prop = "Shijiritsu2",			Head = "%2",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0D8",				Head = "D8",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "PtrShijiSeiryoku3",		Head = "勢力3",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Seiryokulist.Namelist },
				new ColumnSettingItem { Prop = "Shijiritsu3",			Head = "%3",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0E0",				Head = "E0",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "PtrShijiSeiryoku4",		Head = "勢力4",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Seiryokulist.Namelist },
				new ColumnSettingItem { Prop = "Shijiritsu4",			Head = "%4",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0E8",				Head = "E8",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "PtrShijiSeiryoku5",		Head = "勢力5",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Seiryokulist.Namelist },
				new ColumnSettingItem { Prop = "Shijiritsu5",			Head = "%5",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0F0",				Head = "F0",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "PtrShijiSeiryoku6",		Head = "勢力6",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Seiryokulist.Namelist },
				new ColumnSettingItem { Prop = "Shijiritsu6",			Head = "%6",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0F8",				Head = "F8",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },

				new ColumnSettingItem { Prop = "CntButaiList",			Head = "部隊",			Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "PtrButaiList",			Head = "部隊リスト",	Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntShiroList",			Head = "城",			Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "ShiroList",				Head = "城リスト",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST, Tip = "カッコ内の数値の意味は不明(リストの意味も不明)" },

				new ColumnSettingItem { Prop = "AddressHex",			Head = "アドレス",		Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
