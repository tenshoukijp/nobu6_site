﻿// TatemonoColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>建物ビューの列設定情報</summary>
	public class TatemonoColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 4; } }

		/// <summary>コンストラクタ</summary>
		public TatemonoColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",			Head = "ID",		Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.NUM },

				new ColumnSettingItem { Prop = "Gundanname",	Head = "所属",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Kuni",			Head = "国",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Kyoten",		Head = "拠点",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "ShisetsuID",	Head = "施設",		Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Shisetsulist.Namelist },
				new ColumnSettingItem { Prop = "PosX1",			Head = "PosX1",		Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "何かのX位置" },
				new ColumnSettingItem { Prop = "PosY1",			Head = "PosY1",		Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "何かのY位置" },
				new ColumnSettingItem { Prop = "PosX2",			Head = "PosX2",		Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "キャプション？のX位置" },
				new ColumnSettingItem { Prop = "PosY2",			Head = "PosY2",		Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "キャプション？のY位置" },
				new ColumnSettingItem { Prop = "h14_4",			Head = "dw14",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "TaikyuuNow",	Head = "現耐久",	Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "h1E_2",			Head = "1E",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h20",			Head = "20",		Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Str = "0,-1", Tip = "0x01/0x02/0xFF" },
				new ColumnSettingItem { Prop = "h21",			Head = "21",		Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "h22",			Head = "22",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h23",			Head = "23",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h2C_2",			Head = "w2C",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h2E_2",			Head = "w2E",		Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Str = "-1", Tip = "何かのID(重複あり)か？" },

				new ColumnSettingItem { Prop = "AddressHex",	Head = "アドレス",	Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
