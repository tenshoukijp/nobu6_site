﻿// KaidouColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>街道ビューの列設定情報</summary>
	public class KaidouColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 2; } }

		/// <summary>コンストラクタ</summary>
		public KaidouColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",					Head = "ID",		Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.NUM },

				new ColumnSettingItem { Prop = "Name",					Head = "街道名",	Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "PosX",					Head = "PosX",		Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "PosY",					Head = "PosY",		Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "h14_4",					Head = "街道長",	Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM, Str = "0", Tip = "街道の長さっぽいが何に影響するのか不明" },
				new ColumnSettingItem { Prop = "SeibiLV",				Head = "整備LV",	Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0,1", Tip = "1~5" },
				new ColumnSettingItem { Prop = "JoutaiFlag",			Head = "状態",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "0x00/0x01/0x03/0x11 を確認。0x11は街道のポイントとキャプション双方表示されない" },
				new ColumnSettingItem { Prop = "ChikeiID",				Head = "地形",		Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.街道地形タイプ },
				new ColumnSettingItem { Prop = "Yousyo1Kuni",			Head = "国1",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yousyo1Kyoten",			Head = "拠点1",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yousyo1KyotenSeiryoku",	Head = "勢力1",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yousyo2Kuni",			Head = "国2",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yousyo2Kyoten",			Head = "拠点2",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yousyo2KyotenSeiryoku",	Head = "勢力2",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },

				new ColumnSettingItem { Prop = "AddressHex",			Head = "アドレス",	Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
