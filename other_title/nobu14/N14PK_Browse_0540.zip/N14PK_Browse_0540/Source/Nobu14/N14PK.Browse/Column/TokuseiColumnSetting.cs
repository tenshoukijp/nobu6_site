﻿// TokuseiColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>特性ビューの列設定情報</summary>
	public class TokuseiColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 2; } }

		/// <summary>コンストラクタ</summary>
		public TokuseiColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",			Head = "ID",			Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "Name",			Head = "名称",			Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yomi",			Head = "読み",			Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR, IsHid = true },
				new ColumnSettingItem { Prop = "HelpText1",		Head = "ヘルプ1",		Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR, IsHid = true },
				new ColumnSettingItem { Prop = "HelpText2",		Head = "ヘルプ2",		Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "PtrKaiTokusei",	Head = "下位特性",		Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Tokuseilist.Namelist },
				new ColumnSettingItem { Prop = "PtrHanTokusei",	Head = "反特性",		Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Tokuseilist.Namelist },
				new ColumnSettingItem { Prop = "KakuID",		Head = "格",			Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.特性格 },
				new ColumnSettingItem { Prop = "KeitouID",		Head = "系統",			Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.特性系統 },
				new ColumnSettingItem { Prop = "hAA",			Head = "AA",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "hAB",			Head = "AB",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "hAC",			Head = "AC",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "HeisuuJouken",	Head = "兵数条件",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM1, Str = "0,-1" },
				new ColumnSettingItem { Prop = "Jouken",		Head = "条件",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM1, Str = "-1" },
				new ColumnSettingItem { Prop = "Hatsudouritsu",	Head = "発動率",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM1, Str = "-1" },
				new ColumnSettingItem { Prop = "hB0",			Head = "B0",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM1, Str = "-1" },
				new ColumnSettingItem { Prop = "hB1",			Head = "B1",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM1, Str = "-1" },
				new ColumnSettingItem { Prop = "Kaii",			Head = "階位",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM1, Str = "-1" },
				new ColumnSettingItem { Prop = "SortID",		Head = "ソートID",		Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "hB4_2",			Head = "wB4",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "Hyourou",		Head = "腰兵糧",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "Kougeki1",		Head = "攻撃1",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "Syubi1",		Head = "守備1",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "Kougeki2",		Head = "攻撃2",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "Syubi2",		Head = "守備2",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "Idou",			Head = "移動速度",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "Keitaihenkou",	Head = "形態変更",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "Shiki",			Head = "士気ゲージ",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "Jin",			Head = "設営効果",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "Kyougeki",		Head = "挟撃効果",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "Koudoufuka",	Head = "行動不可",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "Konran",		Head = "混乱",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "hCE_2",			Head = "wCE",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hD2_2",			Head = "wD2",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hD4_2",			Head = "wD4",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hD6_2",			Head = "wD6",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hD8_2",			Head = "wD8",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hDA_2",			Head = "wDA",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hDC_2",			Head = "wDC",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hDE_2",			Head = "wDE",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hE0_2",			Head = "wE0",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hE2_2",			Head = "wE2",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hE4_2",			Head = "wE4",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hE6_2",			Head = "wE6",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hE8_2",			Head = "wE8",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hEA_2",			Head = "wEA",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hEC_2",			Head = "wEC",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hEE_2",			Head = "wEE",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hF0_2",			Head = "wF0",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "hF2_2",			Head = "wF2",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true,	Tip = "未使用？", Str = "0,-1" },
				new ColumnSettingItem { Prop = "AddressHex",	Head = "アドレス",		Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
