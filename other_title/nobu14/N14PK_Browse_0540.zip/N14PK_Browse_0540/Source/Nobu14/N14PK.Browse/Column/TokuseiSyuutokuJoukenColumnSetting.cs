﻿// TokuseiSyuutokuJoukenColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>特性習得条件ビューの列設定情報</summary>
	public class TokuseiSyuutokuJoukenColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 2; } }

		/// <summary>コンストラクタ</summary>
		public TokuseiSyuutokuJoukenColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",			Head = "ID",		Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "Name",			Head = "名称",		Ali = Align.L, IsAsc = true,  IsRO = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Tousotsu",		Head = "統率",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "Buyuu",			Head = "武勇",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "Chiryaku",		Head = "知略",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "Seiji",			Head = "政治",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "IsJosei",		Head = "女性",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "B1_9",			Head = "B1_9",		Ali = Align.R, IsAsc = true,  IsRO = false, Mode = CompMode.NUM0, IsHid = true,	Tip = "未使用？", Str = "0" },
				new ColumnSettingItem { Prop = "B1_A",			Head = "B1_A",		Ali = Align.R, IsAsc = true,  IsRO = false, Mode = CompMode.NUM0, IsHid = true,	Tip = "未使用？", Str = "0" },
				new ColumnSettingItem { Prop = "B1_B",			Head = "B1_B",		Ali = Align.R, IsAsc = true,  IsRO = false, Mode = CompMode.NUM0, IsHid = true,	Tip = "未使用？", Str = "0" },
				new ColumnSettingItem { Prop = "AddressHex",	Head = "アドレス",	Ali = Align.R, IsAsc = true,  IsRO = false, Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
