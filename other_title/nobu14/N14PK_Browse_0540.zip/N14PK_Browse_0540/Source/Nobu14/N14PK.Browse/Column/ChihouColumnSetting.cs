﻿// ChihouColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>地方ビューの列設定情報</summary>
	public class ChihouColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 2; } }

		/// <summary>コンストラクタ</summary>
		public ChihouColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",			Head = "ID",				Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "Name",			Head = "名称",				Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yomi",			Head = "読み",				Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "CntChihouList",	Head = "隣接地方",			Ali = Align.R, IsAsc = false, IsRO = true,  Mode = CompMode.NUM0, Str = "0", Tip = "実際に隣接している数ではなく隣接地方リストに含まれるデータ数", IsHid = true },
				new ColumnSettingItem { Prop = "Chihoulist",	Head = "隣接地方リスト",	Ali = Align.L, IsAsc = true,  IsRO = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "h28_4",			Head = "dw28",				Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h2C_4",			Head = "dw2C",				Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0,-1", Tip = "0～2？" },
				new ColumnSettingItem { Prop = "h30_4",			Head = "dw30",				Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h34_4",			Head = "dw34",				Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "AddressHex",	Head = "アドレス",			Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
