﻿// KukakuColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>区画ビューの列設定情報</summary>
	public class KukakuColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 7; } }

		/// <summary>コンストラクタ</summary>
		public KukakuColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",						Head = "ID",		Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "Gundanname",				Head = "所属",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Kuni",						Head = "国",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Shironame",					Head = "城名",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "KukakuID",					Head = "区画",		Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "ShisetsuID",				Head = "施設",		Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Shisetsulist.Namelist },
				new ColumnSettingItem { Prop = "ShigenID",					Head = "資源",		Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Shisetsulist.Namelist },
				new ColumnSettingItem { Prop = "KensetsuchuuShisetsuID",	Head = "建設中",	Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Shisetsulist.Namelist },
				new ColumnSettingItem { Prop = "h012_2",					Head = "w12",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h014_2",					Head = "w14",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h016_2",					Head = "w16",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h018_2",					Head = "w18",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h01C",					Head = "1C",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM1, Str = "-1" },
				new ColumnSettingItem { Prop = "h01D",					Head = "1D",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "PosX",						Head = "PosX1",		Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "PosY",						Head = "PosY1",		Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "KokudakaMax",				Head = "石MAX",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "石高最大値" },
				new ColumnSettingItem { Prop = "SyougyouMax",				Head = "商MAX",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "商業最大値" },
				new ColumnSettingItem { Prop = "HeisyaMax",					Head = "兵MAX",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "兵舎最大値" },
				new ColumnSettingItem { Prop = "h130_2",					Head = "w130",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "KukakuBase",				Head = "区画基本",	Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "区画のポテンシャル？" },
				new ColumnSettingItem { Prop = "Rinsetsu1",					Head = "接1",		Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "区画1との隣接フラグ", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Rinsetsu2",					Head = "接2",		Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "区画2との隣接フラグ", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Rinsetsu3",					Head = "接3",		Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "区画3との隣接フラグ", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Rinsetsu4",					Head = "接4",		Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "区画4との隣接フラグ", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Rinsetsu5",					Head = "接5",		Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "区画5との隣接フラグ", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Rinsetsu6",					Head = "接6",		Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "区画6との隣接フラグ", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Rinsetsu7",					Head = "接7",		Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "区画7との隣接フラグ", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Rinsetsu8",					Head = "接8",		Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "区画8との隣接フラグ", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Rinsetsu9",					Head = "接9",		Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "区画9との隣接フラグ", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Rinsetsu10",				Head = "接10",		Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "区画10との隣接フラグ", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h136_2",					Head = "w136",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h138_2",					Head = "w138",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "100になると建設可能になる？" },
				new ColumnSettingItem { Prop = "h13C_2",					Head = "w13C",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "PosX2",						Head = "PosX2",		Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "PosY2",						Head = "PosY2",		Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h142_2",					Head = "w142",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h144_2",					Head = "w144",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h146_2",					Head = "w146",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "KokudakaRankBase",			Head = "石基R",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "石高ランク基本値" },
				new ColumnSettingItem { Prop = "SyougyouRankBase",			Head = "商基R",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "商業ランク基本値" },
				new ColumnSettingItem { Prop = "HeisyaRankBase",			Head = "兵基R",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "兵舎ランク基本値" },
				new ColumnSettingItem { Prop = "KokudakaRankHosei",			Head = "石補R",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "石高ランク補正値" },
				new ColumnSettingItem { Prop = "SyougyouRankHosei",			Head = "商補R",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "商業ランク補正値" },
				new ColumnSettingItem { Prop = "HeisyaRankHosei",			Head = "兵補R",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "兵舎ランク補正値" },
				new ColumnSettingItem { Prop = "h148_b30",					Head = "b30-148",	Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "148h bit30", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "IsKakuchouzumi",			Head = "b31-148",	Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "148h bit31 拡張済みフラグ？", Col = ColKind.CHECK },

				new ColumnSettingItem { Prop = "AddressHex",				Head = "アドレス",	Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
