﻿// ShiroNameColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>施設ビューの列設定情報</summary>
	public class ShisetsuColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 2; } }

		/// <summary>コンストラクタ</summary>
		public ShisetsuColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",						Head = "ID",		Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "Name",						Head = "名称",		Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yomi",						Head = "読み",		Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR, IsHid = true },
				new ColumnSettingItem { Prop = "HelpText1",					Head = "ヘルプ1",	Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR, IsHid = true },
				new ColumnSettingItem { Prop = "HelpText2",					Head = "ヘルプ2",	Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR, IsHid = true },
				new ColumnSettingItem { Prop = "HelpText3",					Head = "ヘルプ3",	Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR, IsHid = true },
				new ColumnSettingItem { Prop = "HelpText4",					Head = "ヘルプ4",	Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR, IsHid = true, Tip = "未使用" },
				new ColumnSettingItem { Prop = "h0D2_2",					Head = "wD2",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "Ptr_0D4",					Head = "ptrD4",		Ali = Align.L, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX, IsHid = true },
				new ColumnSettingItem { Prop = "Ptr_0D8",					Head = "ptrD8",		Ali = Align.L, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX, IsHid = true, Tip = "ptrDCと同値？" },
				new ColumnSettingItem { Prop = "Ptr_0DC",					Head = "ptrDC",		Ali = Align.L, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX, IsHid = true, Tip = "ptrD8と同値？" },
				new ColumnSettingItem { Prop = "h0E0_4",					Head = "dwE0",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h0E4_4",					Head = "dwE4",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true, Tip = "6固定？" },
				new ColumnSettingItem { Prop = "h0E8_4",					Head = "dwE8",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0,-1", Tip = "dwECと同値？" },
				new ColumnSettingItem { Prop = "h0EC_4",					Head = "dwEC",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0,-1", Tip = "dwE8と同値？" },
				new ColumnSettingItem { Prop = "ShisetsuTypeID",			Head = "タイプ",	Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.施設タイプ },
				new ColumnSettingItem { Prop = "h0F4_4",					Head = "dwF4",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "-1" },
				new ColumnSettingItem { Prop = "h0F8_4",					Head = "dwF8",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, IsHid = true, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "ZenteiShisetsuID",			Head = "前提施設",	Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Shisetsulist.Namelist },
				new ColumnSettingItem { Prop = "Taikyuu",					Head = "耐久",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "Hiyou",						Head = "費用",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "h104_2",					Head = "w104",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, IsHid = true, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h106_2",					Head = "w106",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "h108_2",					Head = "w108",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1", Tip = "111と同値？" },
				new ColumnSettingItem { Prop = "HitsuyouShigenID",			Head = "必要資源",	Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Shisetsulist.Namelist },
				new ColumnSettingItem { Prop = "UpRankNougyou",				Head = "農UP",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "農業上昇ランク" },
				new ColumnSettingItem { Prop = "UpRankSyougyou",			Head = "商UP",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "商業上昇ランク" },
				new ColumnSettingItem { Prop = "UpRankHeisya",				Head = "兵UP",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "兵舎上昇ランク" },
				new ColumnSettingItem { Prop = "Jinkou1",					Head = "人口1",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "人口に関するデータ" },
				new ColumnSettingItem { Prop = "h110",					Head = "110",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h111",					Head = "111",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "w108と同値？" },
				new ColumnSettingItem { Prop = "UpRankNougyouRinsetsu",		Head = "接農UP",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "隣接農業上昇ランク" },
				new ColumnSettingItem { Prop = "UpRankSyougyouRinsetsu",	Head = "接商UP",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "隣接商業上昇ランク" },
				new ColumnSettingItem { Prop = "UpRankHeisyaRinsetsu",		Head = "接兵UP",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "隣接兵舎上昇ランク" },
				new ColumnSettingItem { Prop = "Souzousei",					Head = "創造性",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0,-1" },
				new ColumnSettingItem { Prop = "h116",					Head = "116",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "Jinkou2",					Head = "人口2",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "人口に関するデータ" },
				new ColumnSettingItem { Prop = "h118",					Head = "118",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "ShisetsuLV",				Head = "施設LV",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h11A",					Head = "11A",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h11B",					Head = "11B",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h11C",					Head = "11C",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h11D",					Head = "11D",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, IsHid = true, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h11E_b00",					Head = "b0-11E",	Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "IsNougyouKukaku",			Head = "農",		Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, Col = ColKind.CHECK, Tip = "区画タイプ" },
				new ColumnSettingItem { Prop = "IsSyougyouKukaku",			Head = "商",		Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, Col = ColKind.CHECK, Tip = "区画タイプ" },
				new ColumnSettingItem { Prop = "IsHeisyaKukaku",			Head = "兵",		Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, Col = ColKind.CHECK, Tip = "区画タイプ" },
				new ColumnSettingItem { Prop = "h11E_b04",					Head = "b4-11E",	Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, IsHid = true, Col = ColKind.CHECK, Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h11E_b05",					Head = "収入",		Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, Col = ColKind.CHECK, Tip = "収入に関するフラグ？" },
				new ColumnSettingItem { Prop = "h11E_b06",					Head = "b6-11E",	Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, IsHid = true, Col = ColKind.CHECK, Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h11E_b07",					Head = "b7-11E",	Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, IsHid = true, Col = ColKind.CHECK, Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h11F",					Head = "11F",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0", Tip = "ビットフラグ？" },
				new ColumnSettingItem { Prop = "AddressHex",				Head = "アドレス",	Ali = Align.L, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX },
				#endregion
			};
		}
	}
}
