﻿// KuniColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>国ビューの列設定情報</summary>
	public class KuniColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 2; } }

		/// <summary>コンストラクタ</summary>
		public KuniColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",			Head = "ID",			Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "Name",			Head = "名称",			Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yomi",			Head = "読み",			Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Chihou",		Head = "地方",			Ali = Align.L, IsAsc = true,  IsRO = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Ptr_08",		Head = "ptr08",			Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX, IsHid = true },
				new ColumnSettingItem { Prop = "Ptr_0C",		Head = "ptr0C",			Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX, Tip = "ptr10と同値？", IsHid = true },
				new ColumnSettingItem { Prop = "Ptr_10",		Head = "ptr10",			Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX, Tip = "ptr0Cと同値？", IsHid = true },
				new ColumnSettingItem { Prop = "h14_4",			Head = "dw14",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "CntShiroList",	Head = "城",			Ali = Align.R, IsAsc = false, IsRO = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "ShiroList",		Head = "城リスト",		Ali = Align.L, IsAsc = true,  IsRO = true,  Mode = CompMode.PLIST, IsHid = true },
				new ColumnSettingItem { Prop = "h20_4",			Head = "dw20",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "Ptr_24",		Head = "ptr24",			Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX, IsHid = true },
				new ColumnSettingItem { Prop = "Ptr_28",		Head = "ptr28",			Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX, Tip = "ptr2Cと同値？", IsHid = true },
				new ColumnSettingItem { Prop = "Ptr_2C",		Head = "ptr2C",			Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX, Tip = "ptr28と同値？", IsHid = true },
				new ColumnSettingItem { Prop = "h30_4",			Head = "dw30",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "h34_4",			Head = "dw34",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "4固定？", IsHid = true },
				new ColumnSettingItem { Prop = "h38",			Head = "38",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "h57",			Head = "57",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM1, Str = "-1", Tip = "0xFF固定？", IsHid = true },
				new ColumnSettingItem { Prop = "CntKuniList1",	Head = "隣接国",		Ali = Align.R, IsAsc = false, IsRO = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "KuniList1",		Head = "隣接国リスト",	Ali = Align.L, IsAsc = true,  IsRO = true,  Mode = CompMode.PLIST, IsHid = true },
				new ColumnSettingItem { Prop = "h60_4",			Head = "dw60",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "CntYousyoList",	Head = "要所",			Ali = Align.R, IsAsc = false, IsRO = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "YousyoList",	Head = "要所リスト",	Ali = Align.L, IsAsc = true,  IsRO = true,  Mode = CompMode.PLIST, IsHid = true },
				new ColumnSettingItem { Prop = "h6C_4",			Head = "dw6C",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "h70",			Head = "70",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0", Tip = "0/11？" },
				new ColumnSettingItem { Prop = "h71",			Head = "71",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0", Tip = "0/15？" },
				new ColumnSettingItem { Prop = "h72",			Head = "72",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0", Tip = "0/23？" },
				new ColumnSettingItem { Prop = "h73",			Head = "73",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0", Tip = "0/23？" },
				new ColumnSettingItem { Prop = "h74",			Head = "74",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0", Tip = "0/65？" },
				new ColumnSettingItem { Prop = "h75",			Head = "75",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0", Tip = "0/20？" },
				new ColumnSettingItem { Prop = "h76",			Head = "76",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0", Tip = "0/30？" },
				new ColumnSettingItem { Prop = "h77",			Head = "77",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0", Tip = "0/65？" },
				new ColumnSettingItem { Prop = "h78",			Head = "78",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0", Tip = "0/70？" },
				new ColumnSettingItem { Prop = "h79",			Head = "79",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0", Tip = "1固定？", IsHid = true },
				new ColumnSettingItem { Prop = "h7A",			Head = "7A",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0", Tip = "1固定？", IsHid = true },
				new ColumnSettingItem { Prop = "h7B",			Head = "7B",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "h7C_4",			Head = "7C",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "CntKuniList2",	Head = "国2",			Ali = Align.R, IsAsc = false, IsRO = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "KuniList2",		Head = "国リスト2",		Ali = Align.L, IsAsc = true,  IsRO = true,  Mode = CompMode.PLIST, Tip = "カッコ内の数値の意味は不明", IsHid = true },
				new ColumnSettingItem { Prop = "h88_4",			Head = "dw88",			Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "AddressHex",	Head = "アドレス",		Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
