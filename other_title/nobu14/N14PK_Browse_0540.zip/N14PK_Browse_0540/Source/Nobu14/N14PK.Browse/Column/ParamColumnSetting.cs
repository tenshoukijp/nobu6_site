﻿// ShiroNameColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>Paramビューの列設定情報</summary>
	public class ParamColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 2; } }

		/// <summary>コンストラクタ</summary>
		public ParamColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",			Head = "ID",		Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "Name",			Head = "名称",		Ali = Align.L, IsAsc = true,  IsRO = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "DefaultValue",	Head = "初期値",	Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Value",			Head = "現在値",	Ali = Align.R, IsAsc = true,  IsRO = false, Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "IsNotDefault",	Head = "≠初期値",	Ali = Align.L, IsAsc = false, IsRO = true,  Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "AddressHex",	Head = "アドレス",	Ali = Align.R, IsAsc = true,  IsRO = true,	Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
