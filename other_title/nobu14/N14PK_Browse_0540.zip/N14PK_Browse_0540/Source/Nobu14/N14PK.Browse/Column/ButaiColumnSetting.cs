﻿// ButaiColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>部隊ビューの列設定情報</summary>
	public class ButaiColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 3; } }

		/// <summary>コンストラクタ</summary>
		public ButaiColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",					Head = "ID",				Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.NUM },

				new ColumnSettingItem { Prop = "Seiryokuname",			Head = "勢力",				Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Name",					Head = "部隊名",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "SyozokuKyoten",			Head = "拠点",				Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Heisuu",				Head = "兵数",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "HeisuuMax",				Head = "最大兵",			Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "HyourouNissuu",			Head = "兵糧",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "HasGunba",				Head = "軍馬",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "HasTeppou",				Head = "鉄砲",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "CntHenseiList",			Head = "編成",				Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "HenseiList",			Head = "編成武将リスト",	Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "h02C_4",				Head = "dw2C",				Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "PosX",					Head = "PosX",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "PosY",					Head = "PosY",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "Direction1",			Head = "Dir1",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "部隊の方向に関するデータ" },
				new ColumnSettingItem { Prop = "Direction2",			Head = "Dir2",				Ali = Align.R, IsAsc = true,  IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "部隊の方向に関するデータ" },
				new ColumnSettingItem { Prop = "Mokuhyou1",				Head = "目標1",				Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Mokuhyou2",				Head = "目標2",				Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Mokuhyou3",				Head = "目標3",				Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "CntHoryoList",			Head = "捕虜",				Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "HoryoList",				Head = "捕虜リスト",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntKousenButaiList",	Head = "交戦",				Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "KousenButaiList",		Head = "交戦部隊リスト",	Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntKaisenButaiList",	Head = "会戦",				Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "KaisenButaiList",		Head = "会戦部隊リスト",	Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "h074_4",				Head = "WP数",				Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "ウェイポイントデータ使用数？" },
				new ColumnSettingItem { Prop = "Mokuhyou_WP1",			Head = "WP1目標",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.STR, Tip = "ウェイポイント1目標" },
				new ColumnSettingItem { Prop = "Mokuhyou_WP2",			Head = "WP2目標",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.STR, Tip = "ウェイポイント2目標" },
				new ColumnSettingItem { Prop = "Mokuhyou_WP3",			Head = "WP3目標",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.STR, Tip = "ウェイポイント3目標" },
				new ColumnSettingItem { Prop = "Mokuhyou_WP4",			Head = "WP4目標",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.STR, Tip = "ウェイポイント4目標" },
				new ColumnSettingItem { Prop = "Mokuhyou_WP5",			Head = "WP5目標",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.STR, Tip = "ウェイポイント5目標" },
				new ColumnSettingItem { Prop = "Mokuhyou_WP6",			Head = "WP6目標",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.STR, Tip = "ウェイポイント6目標" },
				new ColumnSettingItem { Prop = "Mokuhyou_WP7",			Head = "WP7目標",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.STR, Tip = "ウェイポイント7目標" },
				new ColumnSettingItem { Prop = "Mokuhyou_WP8",			Head = "WP8目標",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.STR, Tip = "ウェイポイント8目標" },

				new ColumnSettingItem { Prop = "AddressHex",			Head = "アドレス",			Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
