﻿// GundanColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>軍団ビューの列設定情報</summary>
	public class GundanColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 3; } }

		/// <summary>コンストラクタ</summary>
		public GundanColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",					Head = "ID",			Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.NUM },

				new ColumnSettingItem { Prop = "Seiryokuname",			Head = "勢力",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Gundanchouname",		Head = "軍団長",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "PtrHoushin",			Head = "方針",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Tip = "設定しても毎月リセットされる", Col = ColKind.COMBO, Source = this._n14pkb.Houshinlist.Namelist },
				new ColumnSettingItem { Prop = "Kinsen",				Head = "金銭",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Hyourou",				Head = "兵糧",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Teppou",				Head = "鉄砲",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Gunba",					Head = "軍馬",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Rouryoku",				Head = "労力",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "h58_4",					Head = "dw58",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Honkyoname",			Head = "本拠",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR, Tip = "直轄範囲外軍団とCOM軍団はなし" },
				new ColumnSettingItem { Prop = "CntShihaiShiroList",	Head = "支配城",		Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "ShihaiShiroList",		Head = "支配城リスト",	Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntShiroList1",			Head = "城数1",			Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "用途不明" },
				new ColumnSettingItem { Prop = "ShiroList1",			Head = "城リスト1",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST, Tip = "用途不明" },
				new ColumnSettingItem { Prop = "CntShiroList2",			Head = "城数2",			Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "用途不明" },
				new ColumnSettingItem { Prop = "ShiroList2",			Head = "城リスト2",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST, Tip = "用途不明" },

				new ColumnSettingItem { Prop = "AddressHex",			Head = "アドレス",		Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
