﻿// HoushinColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>方針ビューの列設定情報</summary>
	public class HoushinColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 2; } }

		/// <summary>コンストラクタ</summary>
		public HoushinColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",			Head = "ID",		Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "Name",			Head = "名称",		Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "h11",			Head = "11",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h12",			Head = "12",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h13",			Head = "13",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h14",			Head = "14",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h15",			Head = "15",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h16",			Head = "16",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h17",			Head = "17",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h18",			Head = "18",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h19",			Head = "19",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h1A",			Head = "1A",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h1B",			Head = "1B",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h1C",			Head = "1C",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h1D",			Head = "1D",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h1E",			Head = "1E",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h1F",			Head = "1F",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "AddressHex",	Head = "アドレス",	Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
