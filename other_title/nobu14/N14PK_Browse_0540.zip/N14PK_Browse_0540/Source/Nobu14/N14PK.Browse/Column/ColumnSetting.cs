﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace N14PKBrowse.Column
{
	/// <summary>列設定情報基底クラス</summary>
	public class ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public virtual int FrozenColumnCount { get; set; }

		/// <summary>ツール管理 カラム設定のコンボソース参照に使用する</summary>
		protected N14PKB _n14pkb;

		/// <summary>列設定情報</summary>
		protected ColumnSettingItem[] _items;
		/// <summary>列設定</summary>
		public ColumnSettingItem[] Items
		{
			get { return this._items; }
		}

		/// <summary>コンストラクタ</summary>
		public ColumnSetting( N14PKB n14pkb )
		{
			this._n14pkb = n14pkb;
			this.SetItems();
			this.Reset();
		}

		/// <summary>インデクサ</summary>
		public ColumnSettingItem this[int index]
		{
			get { return Array.Find( this.Items, d => d.Index == index ); }
		}

		/// <summary>インデクサ</summary>
		public ColumnSettingItem this[string propertyname]
		{
			get { return Array.Find( this.Items, d => d.Prop == propertyname ); }
		}

		/// <summary>イテレータ</summary>
		/// <returns>カラム設定情報</returns>
		public IEnumerator<ColumnSettingItem> GetEnumerator()
		{
			for ( var i = 0; i < this.Items.Length; i++ )
			{
				yield return this[i];
			}
		}

		/// <summary>列設定情報配列をセットする</summary>
		public virtual void SetItems()
		{
			throw new NotSupportedException();
		}

		/// <summary>列設定情報をリセットする</summary>
		public void Reset()
		{
			this._items = null;
			this.SetItems();
			// 列ID、表示インデクスの初期値設定
			for ( var i = 0; i < this.Items.Length; i++ )
			{
				this.Items[i].Index = i;
				this.Items[i].DispIndex = i;
			}
		}

		/// <summary>列設定情報を設定保存用フォーマットにする</summary>
		public Setting.ColumnInformation[] ToSetting()
		{
			var list = new List<Setting.ColumnInformation>();
			foreach ( var d in this.Items )
			{
				list.Add( new Setting.ColumnInformation() { PropertyName = d.Prop, Width = d.Width, DisplayIndex = d.DispIndex, IsHidden = d.IsHid } );
			}
			return list.ToArray();
		}

		/// <summary>保存された設定を列設定情報へ反映する</summary>
		public void FromSetting( Setting.ColumnInformation[] setting )
		{
			if ( setting == null )
			{
				return;
			}

			foreach ( var d in setting )
			{
				var item = Array.Find( this.Items, i => i.Prop == d.PropertyName );
				if ( item != null )
				{
					item.Width = d.Width;
					item.IsHid = d.IsHidden;
					item.DispIndex = d.DisplayIndex;
					// 表示インデクス順に列作成することになるのでインデクスも変更する
					item.Index = d.DisplayIndex;
				}
			}
			// 列作成時のために表示インデクスでソートする
			Array.Sort( this.Items, ( x, y ) => x.DispIndex - y.DispIndex );
			// ツールバージョンアップ等で項目の増減があった場合の表示インデクス抜け対策に値を振り直す
			for ( var i = 0; i < this.Items.Length; i++ )
			{
				this.Items[i].Index = i;
				this.Items[i].DispIndex = i;
			}
		}
	}
}
