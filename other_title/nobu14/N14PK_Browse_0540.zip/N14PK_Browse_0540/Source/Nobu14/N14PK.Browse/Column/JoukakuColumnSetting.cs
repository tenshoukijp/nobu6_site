﻿// JoukakuColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>城郭ビューの列設定情報</summary>
	public class JoukakuColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 2; } }

		/// <summary>コンストラクタ</summary>
		public JoukakuColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",							Head = "ID",		Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "Name",							Head = "名称",		Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yomi",							Head = "読み",		Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "HelpText1",						Head = "ヘルプ1",	Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR, IsHid = true },
				new ColumnSettingItem { Prop = "HelpText2",						Head = "ヘルプ2",	Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR, IsHid = true },
				new ColumnSettingItem { Prop = "HelpText3",						Head = "ヘルプ3",	Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR, IsHid = true },
				new ColumnSettingItem { Prop = "HelpText4",						Head = "ヘルプ4",	Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR, Tip = "未使用", IsHid = true },
				new ColumnSettingItem { Prop = "JoukakuTypeID",					Head = "タイプ",	Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.城郭タイプ },
				new ColumnSettingItem { Prop = "Taikyuu",						Head = "耐久",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0C8_2",						Head = "wC8",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0CA_2",						Head = "wCA",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "Youchi",						Head = "用地",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0CD",						Head = "CD",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM1, Str = "-1" },
				new ColumnSettingItem { Prop = "h0CE",						Head = "CE",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM1, Str = "-1", Tip = "0xFF固定？", IsHid = true },
				new ColumnSettingItem { Prop = "h0CF",						Head = "CF",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "TaiHoui",						Head = "対包囲",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "TaiKyoukou",					Head = "対強行",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0D4_2",						Head = "wD4",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "TaiYakiuchi",					Head = "対焼討",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0D8_2",						Head = "wD8",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "Hokyuuhei",						Head = "補給兵",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "補給兵の強さ上昇値" },
				new ColumnSettingItem { Prop = "Ryouminhei",					Head = "領民兵",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "領民兵増加値" },
				new ColumnSettingItem { Prop = "Joubihei",						Head = "常備兵",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "常備兵増加値" },
				new ColumnSettingItem { Prop = "TaiHouibutai",					Head = "対包囲",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "包囲部隊への攻撃可否 0:×、1:○" },
				new ColumnSettingItem { Prop = "HituyouKokudaka",				Head = "要石高",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "HitsuyouSyougyou",				Head = "要商業",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "HitsuyouHeisya",				Head = "要兵舎",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "h0E8_4",						Head = "dwE8",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM1, Str = "-1", Tip = "0xFFFFFFFF固定？", IsHid = true },
				new ColumnSettingItem { Prop = "h0EC_4",						Head = "dwEC",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM1, Str = "-1", Tip = "0xFFFFFFFF固定？", IsHid = true },
				new ColumnSettingItem { Prop = "h0F0_4",						Head = "dwF0",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "PtrJoukaku_0F4",				Head = "城郭",		Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.NUM0, Col = ColKind.COMBO, Source = this._n14pkb.Joukakulist.Namelist },
				new ColumnSettingItem { Prop = "h0F8",						Head = "F8",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "定期収入関連？" },
				new ColumnSettingItem { Prop = "h0F9",						Head = "F9",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "h0FA",						Head = "FA",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM1, Str = "-1", Tip = "定期収入関連？" },
				new ColumnSettingItem { Prop = "SaidaiTamichuuZouka",			Head = "民忠",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "最大民忠増加値" },
				new ColumnSettingItem { Prop = "JinkouZouka",					Head = "人口増",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "HitsuyouShigenID",				Head = "要資源",	Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Shisetsulist.Namelist },
				new ColumnSettingItem { Prop = "EikyouShisetsuID1",				Head = "影響施設1",	Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Shisetsulist.Namelist, Tip = "当該施設の数に応じて効果が上昇する" },
				new ColumnSettingItem { Prop = "EikyouShisetsuID2",				Head = "影響施設2",	Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Shisetsulist.Namelist, Tip = "当該施設の数に応じて効果が上昇する" },
				new ColumnSettingItem { Prop = "HitsuyouMinatoID",				Head = "要港",		Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Shisetsulist.Namelist },
				new ColumnSettingItem { Prop = "SyuukakuZouka",					Head = "収穫",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "収穫増加値" },
				new ColumnSettingItem { Prop = "SyuunyuuZouka",					Head = "収入",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "金銭収入増加値" },
				new ColumnSettingItem { Prop = "h112",						Head = "112",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "h113",						Head = "113",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "HyourousyouhiGensyou",			Head = "腰兵糧",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "腰兵糧消費量減少" },
				new ColumnSettingItem { Prop = "SyouheiKaifukusokudoZouka",		Head = "傷兵回復",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "傷兵回復速度上昇値" },
				new ColumnSettingItem { Prop = "h116",						Head = "116",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "h117",						Head = "117",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "KaisenNouryokuZouka1",			Head = "海戦1",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "遠海移動速度・海戦能力上昇(造船所のみ10) 119と同値" },
				new ColumnSettingItem { Prop = "KaisenNouryokuZouka2",			Head = "海戦2",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "遠海移動速度・海戦能力上昇(造船所のみ10) 118と同値" },
				new ColumnSettingItem { Prop = "SyozokuButaiKougekiryokuZouka",	Head = "部隊攻",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "所属部隊攻撃力増加値" },
				new ColumnSettingItem { Prop = "TaiHobaku",						Head = "対捕縛",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "捕縛されにくくなる" },
				new ColumnSettingItem { Prop = "ButaiKyoukaSouzou1",			Head = "創造攻1",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "創造武将所属部隊強化 11Dと同値" },
				new ColumnSettingItem { Prop = "ButaiKyoukaSouzou2",			Head = "創造攻2",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "創造武将所属部隊強化 11Cと同値" },
				new ColumnSettingItem { Prop = "ButaiKyoukaChuudou1",			Head = "中道攻1",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "中道武将所属部隊強化 11Fと同値" },
				new ColumnSettingItem { Prop = "ButaiKyoukaChuudou2",			Head = "中道攻2",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "中道武将所属部隊強化 11Eと同値" },
				new ColumnSettingItem { Prop = "ButaiKyoukaHosyu1",				Head = "保守攻1",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "保守武将所属部隊強化 121と同値" },
				new ColumnSettingItem { Prop = "ButaiKyoukaHosyu2",				Head = "保守攻2",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "保守武将所属部隊強化 120と同値" },
				new ColumnSettingItem { Prop = "GunbaKougekiryokuZouka",		Head = "騎馬攻",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "騎馬配備時の攻撃力上昇値" },
				new ColumnSettingItem { Prop = "TeppouKougekiryokuZouka",		Head = "鉄砲攻",	Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "鉄砲配備時の攻撃力上昇値" },
				new ColumnSettingItem { Prop = "h124_b0",						Head = "b0-124",	Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h124_b1",						Head = "b1-124",	Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h124_b2",						Head = "b2-124",	Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h124_b3",						Head = "b3-124",	Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h124_b4",						Head = "b4-124",	Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h124_b5",						Head = "b5-124",	Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h124_b6",						Head = "b6-124",	Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h124_b7",						Head = "b7-124",	Ali = Align.L, IsAsc = false, IsRO = false, Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h125",						Head = "125",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "h126",						Head = "126",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "h127",						Head = "127",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM0, Str = "0", Tip = "0固定？", IsHid = true },
				new ColumnSettingItem { Prop = "AddressHex",					Head = "アドレス",	Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
