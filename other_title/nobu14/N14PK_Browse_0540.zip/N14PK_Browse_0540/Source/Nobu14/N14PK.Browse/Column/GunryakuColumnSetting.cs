﻿// GunryakuColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>軍略ビューの列設定情報</summary>
	public class GunryakuColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 2; } }

		/// <summary>コンストラクタ</summary>
		public GunryakuColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",			Head = "ID",			Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "Name",			Head = "名称",			Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Help",			Head = "ヘルプ",		Ali = Align.L, IsAsc = true,  IsRO = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "KoukaTypeID",	Head = "効果タイプ",	Ali = Align.R, IsAsc = true, IsRO = true, Mode = CompMode.NUM0, Str = "0", Tip = "政策効果と対応している？" },
				new ColumnSettingItem { Prop = "KoukaValue",	Head = "効果値",		Ali = Align.R, IsAsc = false, IsRO = false, Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "AddressHex",	Head = "アドレス",		Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
