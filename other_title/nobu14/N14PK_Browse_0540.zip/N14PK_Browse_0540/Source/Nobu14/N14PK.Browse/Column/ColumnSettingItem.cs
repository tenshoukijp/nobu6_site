﻿// ColSetInfo.cs

using System.Collections;
using System.ComponentModel;
using System.Windows;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>カラムヘッダの種類</summary>
	public enum ColKind
	{
		TEXT,	// DataGridTextColumn
		COMBO,	// DataGridComboBoxColumn
		CHECK	// DataGridCheckBoxColumn
	}

	/// <summary>テキストの配置</summary>
	public enum Align
	{
		R,	// Right
		L,	// Left
		//C	// Center
	}

	/// <summary>カラムヘッダ設定情報</summary>
	public class ColumnSettingItem
	{
		/// <summary>バインドするプロパティ名</summary>
		public string Prop		{ get; set; }

		/// <summary>ヘッダ名</summary>
		public string Head		{ get; set; }

		/// <summary>デフォルト列幅 (省略可、デフォルトは自動設定)</summary>
		public int Width		{ get; set; }

		/// <summary>文字配置 (省略可、デフォルトは左)</summary>
		public Align Ali		{ get; set; }

		/// <summary>デフォルトソート方向(順) (省略可、デフォルトは降順)</summary>
		public bool IsAsc		{ get; set; }

		/// <summary>編集禁止 (省略可、デフォルトは編集可)</summary>
		public bool IsRO		{ get; set; }

		/// <summary>カラムタイプ</summary>
		public ColKind Col		{ get; set; }

		/// <summary>比較モード</summary>
		public CompMode Mode	{ get; set; }

		/// <summary>不可視 (省略可、デフォルトは可視)</summary>
		public bool IsHid		{ get; set; }

		/// <summary>コンボリストソース (オプション)</summary>
		public IEnumerable Source	{ get; set; }

		/// <summary>ヘッダツールチップ (オプション)</summary>
		public string Tip		{ get; set; }

		/// <summary>色付けする文字 (オプション) カンマ(,)で区切る</summary>
		public string Str		{ get; set; }

		/// <summary>インデクス</summary>
		public int Index		{ get; set; }

		/// <summary>表示インデクス</summary>
		public int DispIndex	{ get; set; }
	}
}
