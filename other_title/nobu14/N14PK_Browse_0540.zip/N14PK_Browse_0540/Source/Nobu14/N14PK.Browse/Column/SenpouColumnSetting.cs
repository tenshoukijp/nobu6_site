﻿// SenpouColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>戦法ビューの列設定情報</summary>
	public class SenpouColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 2; } }

		/// <summary>コンストラクタ</summary>
		public SenpouColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",				Head = "ID",			Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "Name",				Head = "戦法名",		Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yomi",				Head = "読み",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "HelpText",			Head = "ヘルプ",		Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "h47",				Head = "47",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "KeitouID",			Head = "系統",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = Helper.戦法系統 },
				new ColumnSettingItem { Prop = "h49",				Head = "49",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "koukaHanni",		Head = "範囲",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "円の中心位置？ 15以上フリーズ、強化系は12、妨害系は13で全範囲？" },
				new ColumnSettingItem { Prop = "Koukasuu",			Head = "効果数？",		Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "SaihaiOrTokuseiID",	Head = "采配/特性ID",	Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "h4E_2",				Head = "w4E",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Kouka1ID",			Head = "効果1",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Koukalist.Namelist },
				new ColumnSettingItem { Prop = "Kouka1Value1",		Head = "時間1",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Kouka1Value2",		Head = "対象1",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Tip = "0:自分、1:自中心、2:敵" },
				new ColumnSettingItem { Prop = "Kouka1Value3",		Head = "％1",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "効果割合(最大250%)" },
				new ColumnSettingItem { Prop = "Kouka2ID",			Head = "効果2",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Koukalist.Namelist },
				new ColumnSettingItem { Prop = "Kouka2Value1",		Head = "時間2",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Kouka2Value2",		Head = "対象2",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Tip = "0:自分、1:自中心、2:敵" },
				new ColumnSettingItem { Prop = "Kouka2Value3",		Head = "％2",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "効果割合(最大250%)" },
				new ColumnSettingItem { Prop = "Kouka3ID",			Head = "効果3",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Koukalist.Namelist },
				new ColumnSettingItem { Prop = "Kouka3Value1",		Head = "時間3",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Kouka3Value2",		Head = "対象3",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Tip = "0:自分、1:自中心、2:敵" },
				new ColumnSettingItem { Prop = "Kouka3Value3",		Head = "％3",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "効果割合(最大250%)" },
				new ColumnSettingItem { Prop = "Kouka4ID",			Head = "効果4",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Koukalist.Namelist },
				new ColumnSettingItem { Prop = "Kouka4Value1",		Head = "時間4",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Kouka4Value2",		Head = "対象4",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Tip = "0:自分、1:自中心、2:敵" },
				new ColumnSettingItem { Prop = "Kouka4Value3",		Head = "％4",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "効果割合(最大250%)" },
				new ColumnSettingItem { Prop = "Kouka5ID",			Head = "効果5",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Koukalist.Namelist },
				new ColumnSettingItem { Prop = "Kouka5Value1",		Head = "時間5",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Kouka5Value2",		Head = "対象5",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Tip = "0:自分、1:自中心、2:敵" },
				new ColumnSettingItem { Prop = "Kouka5Value3",		Head = "％5",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "効果割合(最大250%)" },
				new ColumnSettingItem { Prop = "Kouka6ID",			Head = "効果6",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Koukalist.Namelist },
				new ColumnSettingItem { Prop = "Kouka6Value1",		Head = "時間6",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Kouka6Value2",		Head = "対象6",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Tip = "0:自分、1:自中心、2:敵" },
				new ColumnSettingItem { Prop = "Kouka6Value3",		Head = "％6",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "効果割合(最大250%)" },
				new ColumnSettingItem { Prop = "Kouka7ID",			Head = "効果7",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Koukalist.Namelist },
				new ColumnSettingItem { Prop = "Kouka7Value1",		Head = "時間7",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Kouka7Value2",		Head = "対象7",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Tip = "0:自分、1:自中心、2:敵" },
				new ColumnSettingItem { Prop = "Kouka7Value3",		Head = "％7",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "効果割合(最大250%)" },
				new ColumnSettingItem { Prop = "Kouka8ID",			Head = "効果8",			Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM1, Col = ColKind.COMBO, Source = this._n14pkb.Koukalist.Namelist },
				new ColumnSettingItem { Prop = "Kouka8Value1",		Head = "時間8",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0" },
				new ColumnSettingItem { Prop = "Kouka8Value2",		Head = "対象8",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Tip = "0:自分、1:自中心、2:敵" },
				new ColumnSettingItem { Prop = "Kouka8Value3",		Head = "％8",			Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM, Str = "0", Tip = "効果割合(最大250%)" },
				new ColumnSettingItem { Prop = "Kouka01",			Head = this._n14pkb.Koukalist.Namelist[00],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit00", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka02",			Head = this._n14pkb.Koukalist.Namelist[01],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit01", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka03",			Head = this._n14pkb.Koukalist.Namelist[02],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit02", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka04",			Head = this._n14pkb.Koukalist.Namelist[03],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit03", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka05",			Head = this._n14pkb.Koukalist.Namelist[04],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit04", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka06",			Head = this._n14pkb.Koukalist.Namelist[05],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit05", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka07",			Head = this._n14pkb.Koukalist.Namelist[06],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit06", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka08",			Head = this._n14pkb.Koukalist.Namelist[07],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit07", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka09",			Head = this._n14pkb.Koukalist.Namelist[08],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit08", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka10",			Head = this._n14pkb.Koukalist.Namelist[09],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit09", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka11",			Head = this._n14pkb.Koukalist.Namelist[10],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit10", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka12",			Head = this._n14pkb.Koukalist.Namelist[11],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit11", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka13",			Head = this._n14pkb.Koukalist.Namelist[12],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit12", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka14",			Head = this._n14pkb.Koukalist.Namelist[13],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit13", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka15",			Head = this._n14pkb.Koukalist.Namelist[14],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit14", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka16",			Head = this._n14pkb.Koukalist.Namelist[15],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit15", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka17",			Head = this._n14pkb.Koukalist.Namelist[16],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit16", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka18",			Head = this._n14pkb.Koukalist.Namelist[17],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit17", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka19",			Head = this._n14pkb.Koukalist.Namelist[18],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit18", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka20",			Head = this._n14pkb.Koukalist.Namelist[19],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit19", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka21",			Head = this._n14pkb.Koukalist.Namelist[20],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit20", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka22",			Head = this._n14pkb.Koukalist.Namelist[21],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit21", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka23",			Head = this._n14pkb.Koukalist.Namelist[22],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit22", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka24",			Head = this._n14pkb.Koukalist.Namelist[23],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit23", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka25",			Head = this._n14pkb.Koukalist.Namelist[24],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit24", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka26",			Head = this._n14pkb.Koukalist.Namelist[25],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit25", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka27",			Head = this._n14pkb.Koukalist.Namelist[26],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit26", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka28",			Head = this._n14pkb.Koukalist.Namelist[27],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit27", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka29",			Head = this._n14pkb.Koukalist.Namelist[28],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit28", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka30",			Head = this._n14pkb.Koukalist.Namelist[29],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit29", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka31",			Head = this._n14pkb.Koukalist.Namelist[30],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit30", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "Kouka32",			Head = this._n14pkb.Koukalist.Namelist[31],	Ali = Align.L, IsAsc = false,  IsRO = false, IsHid = false, Mode = CompMode.FLAG, Tip = "90h bit31", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "AddressHex",		Head = "アドレス",	Ali = Align.R, IsAsc = true,  IsRO = true,  Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
