﻿// SeiryokuColumnSetting.cs

using System;
using System.Collections.Generic;

using N14PKBrowse.Sort;

namespace N14PKBrowse.Column
{
	/// <summary>勢力ビューの列設定情報</summary>
	public class SeiryokuColumnSetting : ColumnSetting
	{
		/// <summary>行ヘッダ列数</summary>
		public override int FrozenColumnCount { get { return 2; } }

		/// <summary>コンストラクタ</summary>
		public SeiryokuColumnSetting( N14PKB n14pkb )
			: base( n14pkb )
		{ }

		/// <summary>列設定情報配列をセットする</summary>
		public override void SetItems()
		{
			this._items = new ColumnSettingItem[]
			{
				#region 設定情報
				new ColumnSettingItem { Prop = "ID",					Head = "ID",					Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.NUM },
				new ColumnSettingItem { Prop = "Name",					Head = "勢力",					Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Yomi",					Head = "読み",					Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "Tousyuname",			Head = "当主",					Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "PtrKoyuuSeisaku",		Head = "固有政策",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Tip = "勢力の血族IDと政策の血族IDを合わせる必要がある", Col = ColKind.COMBO, Source = this._n14pkb.Seisakulist.Namelist },
				new ColumnSettingItem { Prop = "Shinyou",				Head = "信用",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0,-1", Tip = "プレイヤー勢力に対する信用" },
				new ColumnSettingItem { Prop = "ChouteiShinyou",		Head = "朝廷",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "朝廷信用" },
				new ColumnSettingItem { Prop = "Souzousei",				Head = "創造性",				Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "Shirosuu",				Head = "城数",					Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "支配城総数" },
				new ColumnSettingItem { Prop = "h0FEA",					Head = "FEA",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h0FEB",					Head = "FEB",					Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "本城数？ じゃないっぽい" },
				new ColumnSettingItem { Prop = "h0140_4",				Head = "dw140",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM1, Str = "-1", Tip = "0x00/0x01/0xFF" },
				new ColumnSettingItem { Prop = "KamonID",				Head = "家紋",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM1, Str = "-1", Tip = "家紋ID" },
				new ColumnSettingItem { Prop = "h0148_4",				Head = "dw148",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM1, Str = "-1", Tip = "何かのID？" },
				new ColumnSettingItem { Prop = "HataID",				Head = "旗",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "旗ID" },
				new ColumnSettingItem { Prop = "h014C_4",				Head = "dw14C",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "何かのID？" },
				new ColumnSettingItem { Prop = "KetsuzokuID",			Head = "血族",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = false, Mode = CompMode.NUM1, Str = "-1", Tip = "血族ID" },
				new ColumnSettingItem { Prop = "PtrJuuzokuSeiryoku",	Head = "従属先",				Ali = Align.L, IsAsc = true,  IsRO = false, IsHid = false, Mode = CompMode.NUM0, Tip = "従属先勢力", Col = ColKind.COMBO, Source = this._n14pkb.Seiryokulist.Namelist },
				new ColumnSettingItem { Prop = "CntGundanList",			Head = "軍団",					Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "GundanList",			Head = "軍団リスト",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntSeijinmaeList",		Head = "成人前",				Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "SeijinmaeList",			Head = "成人前武将リスト",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntHimeList",			Head = "姫",					Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "HimeList",				Head = "姫リスト",				Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntKoninDoumei",		Head = "婚同",					Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "KoninDoumei",			Head = "婚姻同盟リスト",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "CntDoumeiList",			Head = "同盟",					Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0", Tip = "婚姻同盟を除く" },
				new ColumnSettingItem { Prop = "DoumeiList",			Head = "同盟リスト",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST, Tip = "婚姻同盟を除く カッコ内の数値は月数" },
				new ColumnSettingItem { Prop = "CntTeisenList",			Head = "停戦",					Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "TeisenList",			Head = "停戦リスト",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST, Tip = "カッコ内の数値は月数" },
				new ColumnSettingItem { Prop = "CntKahouList",			Head = "家宝",					Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = false, Mode = CompMode.NUM0, Str = "0" },
				new ColumnSettingItem { Prop = "KahouList",				Head = "家宝リスト",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST },
				new ColumnSettingItem { Prop = "CntList_00EC",			Head = "ListEC",				Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "用途不明" },
				new ColumnSettingItem { Prop = "List_00EC",				Head = "ListECリスト",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST, Tip = "用途不明" },
				new ColumnSettingItem { Prop = "CntList_00F8",			Head = "ListF8",				Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "用途不明" },
				new ColumnSettingItem { Prop = "List_00F8",				Head = "ListF8リスト",			Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST, Tip = "用途不明" },
				new ColumnSettingItem { Prop = "CntSeiryokuList_0520",	Head = "勢力List520",			Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "用途不明" },
				new ColumnSettingItem { Prop = "SeiryokuList_0520",		Head = "勢力List520リスト",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST, Tip = "用途不明 カッコ内の数値の意味は不明" },
				new ColumnSettingItem { Prop = "CntSeiryokuList_0530",	Head = "勢力List530",			Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "用途不明" },
				new ColumnSettingItem { Prop = "SeiryokuList_0530 ",	Head = "勢力List530リスト",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST, Tip = "用途不明 カッコ内の数値の意味は不明" },
				new ColumnSettingItem { Prop = "CntSeiryokuList_0ECC",	Head = "勢力ListECC",			Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "用途不明" },
				new ColumnSettingItem { Prop = "SeiryokuList_0ECC",		Head = "勢力ListECCリスト",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST, Tip = "用途不明 カッコ内の数値の意味は不明" },
				new ColumnSettingItem { Prop = "CntSeiryokuList_0EDC",	Head = "勢力ListEDC",			Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "用途不明" },
				new ColumnSettingItem { Prop = "SeiryokuList_0EDC",		Head = "勢力ListEDCリスト",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST, Tip = "用途不明 カッコ内の数値の意味は不明" },
				new ColumnSettingItem { Prop = "CntSeiryokuList_0EEC",	Head = "勢力ListEEC",			Ali = Align.R, IsAsc = false, IsRO = true,  IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "用途不明" },
				new ColumnSettingItem { Prop = "SeiryokuList_0EEC",		Head = "勢力ListEECリスト",		Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.PLIST, Tip = "用途不明 カッコ内の数値の意味は不明" },
				new ColumnSettingItem { Prop = "Taido",					Head = "態度",					Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "SyokiHonkyo",			Head = "初期本拠",				Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "SyokiTousyu",			Head = "初期当主",				Ali = Align.L, IsAsc = true,  IsRO = true,  IsHid = true,  Mode = CompMode.STR },
				new ColumnSettingItem { Prop = "h111C_b0",				Head = "b0-111C",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.FLAG, Tip = "0固定？", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "IsPlayer",				Head = "Player",				Ali = Align.L, IsAsc = false, IsRO = true,  IsHid = true,  Mode = CompMode.FLAG, Tip = "このフラグが立っている勢力は、プレイヤーが部隊の出陣・操作可能。挙動が怪しいので変更不可", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h111C_b2",				Head = "b2-111C",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h111C_b3",				Head = "b3-111C",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.FLAG, Tip = "0固定？", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h111C_b4",				Head = "b4-111C",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.FLAG, Tip = "0固定？", Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h111C_b5",				Head = "b5-111C",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h111C_b6",				Head = "b6-111C",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h111C_b7",				Head = "b7-111C",				Ali = Align.L, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.FLAG, Col = ColKind.CHECK },
				new ColumnSettingItem { Prop = "h111D",				Head = "111D",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0x00/0x03" },
				new ColumnSettingItem { Prop = "h111E",				Head = "111E",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "h111F",				Head = "111F",					Ali = Align.R, IsAsc = false, IsRO = false, IsHid = true,  Mode = CompMode.NUM0, Str = "0", Tip = "0固定？" },
				new ColumnSettingItem { Prop = "AddressHex",			Head = "アドレス",				Ali = Align.R, IsAsc = true,  IsRO = true,  IsHid = false, Mode = CompMode.HEX }
				#endregion
			};
		}
	}
}
