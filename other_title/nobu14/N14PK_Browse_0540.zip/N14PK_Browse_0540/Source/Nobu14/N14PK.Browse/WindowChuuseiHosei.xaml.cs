﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

using N14PKBrowse.Data;
using N14PKBrowse.Enums;
using N14PKBrowse.HelperClass;

namespace N14PKBrowse
{
	/// <summary>
	/// WindowChuuseiHosei.xaml の相互作用ロジック
	/// </summary>
	public partial class WindowChuuseiHosei : Window
	{
		private TextBox[] TextBoxArray	{ get; set; }	// コントロールの配列
		private Label[] LabelArray		{ get; set; }	// コントロールの配列
		public N14PKB N14pkb			{ get; set; }	// ツール管理
		public Busyou Busyou			{ get; set; }	// 選択中の武将データ
		private sbyte UndoValue			{ get; set; }	// 編集前の値

		public WindowChuuseiHosei()
		{
			InitializeComponent();
		}

		private void Window_Loaded( object sender, RoutedEventArgs e )
		{
			// コントロール配列を作成
			this.TextBoxArray = (TextBox[])MyControlArray.GetControlArrayByName( this, "TextBox" );
			this.LabelArray = (Label[])MyControlArray.GetControlArrayByName( this, "Label" );

			// テクストボックス＆ラベル設定
			for ( int i = 0; i < this.TextBoxArray.Length; i++ )	// 最後の一つは必要忠誠値用
			{
				if ( i < this.TextBoxArray.Length - 1 )
				{
					this.LabelArray[i].Content = ( (ChuuseihoseiKind)i ).ToString();	// ラベルテキスト
					if ( (ChuuseihoseiKind)i == ChuuseihoseiKind.日和見 )
					{
						ToolTipService.SetInitialShowDelay( LabelArray[i], 0 );							// ツールチップ表示ディレイ
						this.LabelArray[i].ToolTip = "\"日和見\"は入力値とゲーム内で値が異なる(詳細不明)";		// ツールチップテキスト
					}

					this.TextBoxArray[i].Text = this.Busyou.ChuuseiHoseiList[i].ToString();	// 補正値
				}
				else
				{
					this.TextBoxArray[i].Text = this.Busyou.HitsuyouChuusei.ToString();			// 必要忠誠値
				}

				this.TextBoxArray[i].KeyDown += new KeyEventHandler( TextBox_KeyDown );								// イベントデリゲート エンターチェック
				this.TextBoxArray[i].LostFocus += new RoutedEventHandler( TextBox_LostFocus );						// イベントデリゲート フォーカス移動チェック※このタイミングで書き込み
				this.TextBoxArray[i].GotFocus += new RoutedEventHandler( TextBox_GotFocus );						// イベントデリゲート フォーカスチェック(テキスト全選択)
				this.TextBoxArray[i].PreviewMouseDown += new MouseButtonEventHandler( TextBox_PreviewMouseDown );	// イベントデリゲート マウスダウン(テキスト全選択)

				if ( i < this.Busyou.ChuuseiHoseiList.Length )
				{
					if ( 0 < this.Busyou.ChuuseiHoseiList[i] )
					{
						this.TextBoxArray[i].Foreground = System.Windows.Media.Brushes.Blue;					// 文字色
					}
					else if ( 0 == this.Busyou.ChuuseiHoseiList[i] )
					{
						this.TextBoxArray[i].Foreground = System.Windows.Media.Brushes.Black;				// 文字色
					}
					else
					{
						this.TextBoxArray[i].Foreground = System.Windows.Media.Brushes.Red;				// 文字色
					}
				}
			}
			this.UpdateStatusBar();
		}

		// ステータスバー更新
		private void UpdateStatusBar()
		{
			var goukei = this.Busyou.ChuuseiHoseiGoukei;
			bool isOver = false;
			if ( goukei < -10 )
			{
				goukei = -10;
				isOver = true;
			}
			else if ( 10 < goukei )
			{
				goukei = 10;
				isOver = true;
			}
			this.StatusBarItem1.Content = this.Busyou.Sei + this.Busyou.Mei
				+ " 補正合計:" + goukei.ToString( "+#0;-#0;#0" ) + ( ( isOver ) ? "(" + this.Busyou.ChuuseiHoseiGoukei.ToString( "+#0;-#0;#0" ) + ")" : string.Empty )
				+ ", 必要忠誠:" + this.Busyou.HitsuyouChuusei.ToString();
		}

		// 閉じるボタン
		private void ButtonClose_Click( object sender, RoutedEventArgs e )
		{
			this.Close();
		}

		// キー入力判定(フォーカス移動や入力キャンセル)
		private void TextBox_KeyDown( object sender, KeyEventArgs e )
		{
			if ( e.Key == Key.Return )
			{
				FocusNavigationDirection focusDirection = FocusNavigationDirection.Next;
				TraversalRequest request = new TraversalRequest( focusDirection );
				UIElement elementWithFocus = Keyboard.FocusedElement as UIElement;

				if ( elementWithFocus != null )
				{
					elementWithFocus.MoveFocus( request );
				}
			}

			if ( e.Key == Key.Escape )
			{
				var tb = ( sender as TextBox );
				if ( null == tb )
				{
					return;
				}
				tb.Text = this.UndoValue.ToString();
				tb.SelectAll();
			}
		}

		// フォーカスを失ったタイミングでデータのチェック＆書き込み
		private void TextBox_LostFocus( object sender, RoutedEventArgs e )
		{
			var tb = ( sender as TextBox );

			if ( null == tb )
			{
				return;
			}

			// テキストボックスのインデクスを取得する
			int index = -1;
			for ( int i = 0; i < this.TextBoxArray.Length; i++ )
			{
				if ( this.TextBoxArray[i].Equals( sender ) )
				{
					index = i;
					break;
				}
			}

			this.WriteData( tb, index );

			// テキストボックス表示更新
			if ( index < this.TextBoxArray.Length - 1 )
			{
				tb.Text = this.Busyou.ChuuseiHoseiList[index].ToString();
				if ( 0 < this.Busyou.ChuuseiHoseiList[index] )
				{
					this.TextBoxArray[index].Foreground = System.Windows.Media.Brushes.Blue;					// 文字色
				}
				else if ( 0 == this.Busyou.ChuuseiHoseiList[index] )
				{
					this.TextBoxArray[index].Foreground = System.Windows.Media.Brushes.Black;				// 文字色
				}
				else
				{
					this.TextBoxArray[index].Foreground = System.Windows.Media.Brushes.Red;				// 文字色
				}
			}
			else
			{
				tb.Text = this.Busyou.HitsuyouChuusei.ToString();			// 必要忠誠値
			}

			// ステータスバー更新
			this.UpdateStatusBar();

		}

		private void WriteData( TextBox tb, int index )
		{
			long num;
			if ( !long.TryParse( tb.Text, out num ) )
			{
				// 入力されたテキストが数値変換できない場合
				return;
			}

			if ( index < this.TextBoxArray.Length - 1 )
			{
				// 編集箇所が忠誠補正値

				if ( num < -128 )
				{
					num = -128;
				}
				else if ( 127 < num )
				{
					num = 127;
				}

				// BusyouData.ChuuseiHoseiList のコピーに対して操作し、終了時に戻す
				// ChuuseiHoseiList を直接変更しても参照時にgetプロパティで配列ごと new されるため意味が無い
				var array = this.Busyou.ChuuseiHoseiList;
				array[index] = (sbyte)num;
				this.Busyou.ChuuseiHoseiList = array;
			}
			else
			{
				// 編集箇所が必要忠誠値
				if ( num < 0 )
				{
					num = 0;
				}
				else if ( 15 < num )
				{
					num = 15;
				}
				this.Busyou.HitsuyouChuusei = (uint)num;
			}
			this.N14pkb.Busyoulist.Commit();

		}

		// タブやエンターでフォーカスを得た際にテキストボックス内のテキストを全選択する
		private void TextBox_GotFocus( object sender, RoutedEventArgs e )
		{
			var tb = ( sender as TextBox );

			if ( null == tb )
			{
				return;
			}

			// 編集前の値を保存
			sbyte num;
			if ( SByte.TryParse( tb.Text, out num ) )
			{
				this.UndoValue = num;
			}

			tb.SelectAll();
			e.Handled = true;
		}

		// マウスクリックでフォーカスを得た際にテキストボックス内のテキストを全選択する
		public void TextBox_PreviewMouseDown(object sender, MouseButtonEventArgs e)
		{
			var tb = ( sender as TextBox );

			if ( null == tb )
				return;

			tb.SelectAll();
			tb.Focus();
			e.Handled = true;
		}
	}
}
