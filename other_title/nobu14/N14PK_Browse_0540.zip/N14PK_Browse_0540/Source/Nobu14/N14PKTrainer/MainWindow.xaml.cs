﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls.Primitives;
using N14PKLibrary.HelperClass;
using N14PKLibrary.VersionConfig;

namespace N14PKTrainer
{
	public enum PatchKind
	{
		築城即完了 = 0,	// 築城が即完了する
		築城場所制限,	// 築城時の場所制限解除
		城数制限,		// 築城時の城数制限解除
		プレイ記録,		// 編集を使用してもプレイ記録が残る
		朝廷信用,		// 朝廷信用が減らない
		真田丸			// 真田丸の血族ID制限解除
	}

	/// <summary>
	/// MainWindow.xaml の相互作用ロジック
	/// </summary>
	public partial class MainWindow : Window
	{
		private ToggleButton[] _button;
		private int _patchKindCount = 6;
		private ProcessMemory _pm;
		private Setting.VersionSetting[] _settings;
		private Setting.VersionSetting _setting;

		private byte[][] _nowValue;

		public MainWindow()
		{
			InitializeComponent();
		}

		/// <summary>バージョンチェック</summary>
		private void CheckVersion()
		{
			foreach ( var s in this._settings )
			{
				if ( this._pm.Version.Equals( s.GameVersion ) )
				{
					// 設定ファイル内に当該バージョンの情報がある
					this._setting = s;
					return;
				}
			}

			if ( this._setting == null )
			{
				// 未対応バージョン
				// 設定ファイル内で最も新しいバージョンの情報をセットする
				this._setting = this._settings[this._settings.Length - 1];

				System.Windows.MessageBox.Show(
					"バージョン " + this._pm.Version + " は未対応です。\nボタンがグレーアウトしていない箇所は使用できる可能性があります。",
					System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " " + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version,
					System.Windows.MessageBoxButton.OK,
					System.Windows.MessageBoxImage.Warning
					);
			}
		}

		/// <summary>コントロール初期化</summary>
		private void InitializeControl()
		{
			// 現在値をプロセスメモリから取得する
			this._nowValue = new byte[this._patchKindCount][];
			for ( var i = 0; i < this._setting.PatchInformations.Length; i++ )
			{
				var data = this._setting.PatchInformations[i];
				this._nowValue[(int)data.kind] = this._pm.ReadMemory( this._pm.BaseAddress + data.Offset, (uint)data.DefaultValue.Length );
			}

			// ボタンを初期化する
			for ( var i = 0; i < this._patchKindCount; i++ )
			{
				var bt = this._button[i];
				var data = Array.Find( this._setting.PatchInformations, d => (int)d.kind == i );

				if ( data == null )
				{
					// セッティングにデータがない
					bt.IsEnabled = false;
					continue;
				}

				if ( this._nowValue[i].SequenceEqual( data.DefaultValue ) )
				{
					// 現在値が初期値と等しい
					bt.IsEnabled = true;
					bt.IsChecked = false;
					bt.Foreground = System.Windows.Media.Brushes.Black;

				}
				else if ( this._nowValue[i].SequenceEqual( data.PatchValue ) )
				{
					// 現在値がチート値と等しい
					bt.IsEnabled = true;
					bt.IsChecked = true;
					bt.Foreground = System.Windows.Media.Brushes.Red;
				}
				else
				{
					// 予期しない値
					bt.IsEnabled = false;
				}
			}
		}

		/// <summary>ボタンクリック</summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void toggleButton_Click( object sender, RoutedEventArgs e )
		{
			// ボタンのインデクスを取得する
			var index = -1;
			for ( var i = 0; i < this._button.Length; i++ )
			{
				if ( this._button[i].Equals( sender ) )
				{
					index = i;
					break;
				}
			}
			var bt = this._button[index];

#if DEBUG
			System.Diagnostics.Debug.WriteLine( "ボタン:" + index + " : " + bt.Content + " : " + bt.IsChecked );
#endif
			// プロセス取得
			try
			{
				using ( this._pm = new ProcessMemory( "NOBU14PK" ) )
				{
					this.CheckVersion();
					byte[] buff;

					var data = Array.Find( this._setting.PatchInformations, d => (int)d.kind == index );
					if ( (bool)bt.IsChecked )
					{
						// null は考慮しない
						buff = data.PatchValue;
						bt.Foreground = System.Windows.Media.Brushes.Red;
					}
					else
					{
						buff = data.DefaultValue;
						bt.Foreground = System.Windows.Media.Brushes.Black;
					}

					// プロセスメモリに書き込み
					this._pm.WriteMemory( this._pm.BaseAddress + data.Offset, buff );
				}
			}
			catch ( Exception ex )
			{
				// チェック状態を元に戻す
				bt.IsChecked = !(bool)bt.IsChecked;

				System.Windows.MessageBox.Show(
					ex.Message,
					System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " " + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version,
					System.Windows.MessageBoxButton.OK,
					System.Windows.MessageBoxImage.Error
					);
			}
		}

		private void Window_Closing( object sender, System.ComponentModel.CancelEventArgs e )
		{
			// プログラム設定情報保存
			//Setting.SaveSettingFile( this._settings );
		}

		private void Window_Loaded( object sender, RoutedEventArgs e )
		{

			// 設定ファイルロード
			this._settings = Setting.LoadSettingFile();

			// Assembly取得
			var asm = System.Reflection.Assembly.GetExecutingAssembly();
			this.Title = asm.GetName().Name + " v" + asm.GetName().Version;

			// ボタンを配列化
			this._button = (ToggleButton[])MyControlArray.GetControlArrayByName( this, "toggleButton" );

			// プロセス取得
			try
			{
				using ( this._pm = new ProcessMemory( "NOBU14PK" ) )
				{
					this.CheckVersion();
					this.InitializeControl();
				}
			}
			catch ( Exception ex )
			{
				System.Windows.MessageBox.Show(
					ex.Message,
					System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " " + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version,
					System.Windows.MessageBoxButton.OK,
					System.Windows.MessageBoxImage.Error
					);
				this.Close();
			}
		}
	}
}
