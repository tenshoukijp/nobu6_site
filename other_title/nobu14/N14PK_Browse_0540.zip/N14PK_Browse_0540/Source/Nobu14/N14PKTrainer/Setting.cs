﻿using System;
using System.IO;
using System.Windows;
using System.Xml.Serialization;

namespace N14PKTrainer
{
	/// <summary>ツールの設定情報管理</summary>
	public class Setting
	{
		public class PatchInformationXML
		{
			public PatchKind kind		{ get; set; }
			public string Offset		{ get; set; }
			public string DefaultValue	{ get; set; }
			public string PatchValue	{ get; set; }
		}

		public class VersionSettingXML
		{
			public string GameVersion						{ get; set; }
			public PatchInformationXML[] PatchInformations	{ get; set; }
		}

		public class PatchInformation
		{
			public PatchKind kind		{ get; set; }
			public uint Offset			{ get; set; }
			public byte[] DefaultValue	{ get; set; }
			public byte[] PatchValue	{ get; set; }
		}

		public class VersionSetting
		{
			public string GameVersion					{ get; set; }
			public PatchInformation[] PatchInformations	{ get; set; }
		}

		//public ProgramSetting[] ProgramSettings	{ get; set; }

		/// <summary>設定ファイル名</summary>
		public static readonly string Filename = "N14PK_Trainer.Setting.xml";

		/// <summary>設定をファイルから読み込む</summary>
		public static VersionSetting[] LoadSettingFile()
		{
			var filepath = Environment.CurrentDirectory + @"\" + Filename;
			if ( !File.Exists( filepath ) )
			{
				return Setting.DefaultSettings;
			}

			var serializer = new XmlSerializer( typeof( VersionSettingXML[] ) );

			using ( var fs = new FileStream( filepath, FileMode.Open ) )
			{
				try
				{
					var xml = (VersionSettingXML[])serializer.Deserialize( fs );

					// ソート
					foreach ( var s in xml )
					{
						Array.Sort( s.PatchInformations, ( x, y ) => (int)x.kind - (int)y.kind );
					}
					Array.Sort( xml, ( x, y ) => x.GameVersion.CompareTo( y.GameVersion ) );

					return XMLToSetting( xml );
				}
				catch ( Exception ex )
				{
					var message = Filename + Environment.NewLine
								+ ex.Message + Environment.NewLine
								+ "初期設定で起動します。";

					MessageBox.Show( message, "設定ファイル読み込み", MessageBoxButton.OK, MessageBoxImage.Error );
					return Setting.DefaultSettings;
				}
			}
		}

		private static VersionSetting[] XMLToSetting( VersionSettingXML[] xml )
		{
			var settings = new VersionSetting[xml.Length];

			for ( var i = 0; i < xml.Length; i++ )
			{
				settings[i] = new VersionSetting();
				settings[i].GameVersion = xml[i].GameVersion;
				settings[i].PatchInformations = new PatchInformation[xml[i].PatchInformations.Length];
				for ( var j = 0; j < xml[i].PatchInformations.Length; j++ )
				{
					settings[i].PatchInformations[j] = new PatchInformation();
					settings[i].PatchInformations[j].kind = xml[i].PatchInformations[j].kind;
					settings[i].PatchInformations[j].Offset = Convert.ToUInt32( xml[i].PatchInformations[j].Offset, 16 );

					var hexValuesSplit = xml[i].PatchInformations[j].DefaultValue.Split( ' ' );
					settings[i].PatchInformations[j].DefaultValue = new byte[hexValuesSplit.Length];
					for ( var k = 0; k < hexValuesSplit.Length; k++  )
					{
						settings[i].PatchInformations[j].DefaultValue[k] = Convert.ToByte( hexValuesSplit[k], 16 );
					}
					hexValuesSplit = xml[i].PatchInformations[j].PatchValue.Split( ' ' );
					settings[i].PatchInformations[j].PatchValue = new byte[hexValuesSplit.Length];
					for ( var k = 0; k < hexValuesSplit.Length; k++  )
					{
						settings[i].PatchInformations[j].PatchValue[k] = Convert.ToByte( hexValuesSplit[k], 16 );
					}
				}
			}
			return settings;
		}

		/// <summary>設定をファイルに書き出す</summary>
		/// <param name="functions">出力する設定</param>
		public static void SaveSettingFile( VersionSetting[] setting )
		{
			var serializer = new XmlSerializer( typeof( VersionSettingXML[] ) );
			var filepath = Environment.CurrentDirectory + @"\" + Filename;

			using( var fs = new FileStream( filepath, FileMode.Create ) )
			{
				serializer.Serialize( fs, SettingToXML( setting ) );
			}
		}

		private static VersionSettingXML[] SettingToXML( VersionSetting[] setting )
		{
			var xml = new VersionSettingXML[setting.Length];

			for ( var i = 0; i < setting.Length; i++ )
			{
				xml[i] = new VersionSettingXML();
				xml[i].GameVersion = setting[i].GameVersion;
				xml[i].PatchInformations = new PatchInformationXML[setting[i].PatchInformations.Length];
				for ( var j = 0; j < setting[i].PatchInformations.Length; j++ )
				{
					xml[i].PatchInformations[j] = new PatchInformationXML();
					xml[i].PatchInformations[j].kind = setting[i].PatchInformations[j].kind;
					xml[i].PatchInformations[j].Offset = setting[i].PatchInformations[j].Offset.ToString( "X8" );

					xml[i].PatchInformations[j].DefaultValue = string.Empty;
					for ( var k = 0; k < setting[i].PatchInformations[j].DefaultValue.Length; k++  )
					{
						xml[i].PatchInformations[j].DefaultValue += setting[i].PatchInformations[j].DefaultValue[k].ToString( "X2" );
					}
					xml[i].PatchInformations[j].PatchValue = string.Empty;
					for ( var k = 0; k < setting[i].PatchInformations[j].PatchValue.Length; k++  )
					{
						xml[i].PatchInformations[j].PatchValue += setting[i].PatchInformations[j].PatchValue[k].ToString( "X2" );
					}
				}
			}
			return xml;
		}

		/// <summary>デフォルト設定</summary>
		public static VersionSetting[] DefaultSettings
		{
			get
			{
				var settings = new VersionSetting[]
				{
					new VersionSetting()
					{
						GameVersion = "1.0.4.0",
						PatchInformations = new PatchInformation[]
						{
							new PatchInformation(){ Offset = 0x00092D5D, DefaultValue = new byte[]{ 0x8C }, PatchValue = new byte[]{ 0x8D }, kind = PatchKind.築城即完了 },
							new PatchInformation(){ Offset = 0x000EF2FE, DefaultValue = new byte[]{ 0x3F }, PatchValue = new byte[]{ 0x00 }, kind = PatchKind.築城場所制限 },
							new PatchInformation(){ Offset = 0x0019D057, DefaultValue = new byte[]{ 0x75 }, PatchValue = new byte[]{ 0x00 }, kind = PatchKind.城数制限 },
							new PatchInformation(){ Offset = 0x004EB597, DefaultValue = new byte[]{ 0x77 }, PatchValue = new byte[]{ 0xEB }, kind = PatchKind.プレイ記録 },
							new PatchInformation(){ Offset = 0x00582958, DefaultValue = new byte[]{ 0x11 }, PatchValue = new byte[]{ 0x00 }, kind = PatchKind.朝廷信用 },
							new PatchInformation(){ Offset = 0x00621AC0, DefaultValue = new byte[]{ 0x74 }, PatchValue = new byte[]{ 0xEB }, kind = PatchKind.真田丸 }
						}
					}
				};

				return settings;
			}
		}
	}
}
