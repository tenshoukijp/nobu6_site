using System;
using System.Collections.Generic;

using N14PKLibrary;
using N14PKLibrary.Data;


class N14PKBrowseExtension
 {
	public static void Function( N14PK n14pk, int id, ParamData data )
	{
		var ids = new List<int>();

		foreach ( var p in n14pk.Paramtable )
		{
			if ( p.Name == "N14_GUNDAN_RADIUS" )
			{
				ids.Add( p.ID );
				p.Value = 1000000;
			}

			if ( p.Name == "N14_GUNDAN_RADIUS_2" )
			{
				ids.Add( p.ID );
				p.Value = 1000;
			}

			if ( ids.Count == 2 ) { break; }
		}

		if ( ids.Count != 2 )
		{
			throw new ApplicationException( "�f�[�^��������܂���ł����B" );
		}

		foreach ( var d in ids )
		{
			n14pk.Paramtable.Write( d );
		}
	}
}

