using System;

using N14PKLibrary;
using N14PKLibrary.Data;
using N14PKLibrary.HelperClass;

class N14PKBrowseExtension
{
	public static void Function( N14PK n14pk, int id, ShiroData data )
	{
		var val = 30000;

		// �ő�l
		data.TaikyuuMax = (short)val;
		n14pk.Shirotable.Write( data );

		// �����f�[�^�擾(���ݑϋv�͌����f�[�^��)
		var tatemono = n14pk.Tatemonotable[data.PtrTatemono];

		if ( tatemono != null )
		{
			tatemono.TaikyuuNow = (short)val;
			n14pk.Tatemonotable.Write( tatemono );
		}
	}
}
