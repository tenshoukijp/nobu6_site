using System;

using N14PKLibrary;
using N14PKLibrary.Data;
using N14PKLibrary.HelperClass;

class N14PKBrowseExtension
{
	public static void Function( N14PK n14pk, int id, KaidouData data )
	{
		if ( data.SeibiLV != 0 )
		{
			data.SeibiLV = 0;
		}

		n14pk.Kaidoutable.Write( data );
	}
}
