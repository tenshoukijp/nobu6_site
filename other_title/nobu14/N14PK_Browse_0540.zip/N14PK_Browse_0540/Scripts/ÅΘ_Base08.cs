using System;

using N14PKLibrary;
using N14PKLibrary.Data;
using N14PKLibrary.HelperClass;

class N14PKBrowseExtension
{
	public static void Function( N14PK n14pk, int id, ShiroData data )
	{
		var rank = 8;

		foreach ( var k in data.Kukaku )
		{
			if ( k.KukakuBase != 0 )
			{
				k.KokudakaRankBase = rank;
				k.SyougyouRankBase = rank;
				k.HeisyaRankBase = rank;
			}
			// �␳�����N�v
			var hoseigoukei = 0;

			// ���̍ő�l
			var max = 0;

			// ��S�̂̒l�Ƃ̍���
			var diff = 0;

			if ( k.KokudakaMax != 0 )
			{
				hoseigoukei = k.KokudakaRankBase + k.KokudakaRankHosei;
				max = k.KukakuBase * 3 * ( ( hoseigoukei <= 18 ) ? hoseigoukei + 1 : 18 + 1 );
				diff = max - k.KokudakaMax;
				
				// ���̍ő�l���Z�b�g
				k.KokudakaMax = (short)max;

				// ��̍ő�l�C��
				data.KokudakaMax += (short)diff;
			}
			else if ( k.SyougyouMax != 0  )
			{
				hoseigoukei = k.SyougyouRankBase + k.SyougyouRankHosei;
				max = k.KukakuBase * 3 * ( ( hoseigoukei <= 18 ) ? hoseigoukei + 1 : 18 + 1 );
				diff = max - k.SyougyouMax;
				k.SyougyouMax = (short)max;
				data.SyougyouMax += (short)diff;
			}
			else if ( k.HeisyaMax != 0  )
			{
				hoseigoukei = k.HeisyaRankBase + k.HeisyaRankHosei;
				max = k.KukakuBase * 3 * ( ( hoseigoukei <= 18 ) ? hoseigoukei + 1 : 18 + 1 );
				diff = max - k.HeisyaMax;
				k.HeisyaMax = (short)max;
				data.HeisyaMax += (short)diff;
			}
		}
		n14pk.Shirotable.Write( data );
	}
}
