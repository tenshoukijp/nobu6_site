using System;

using N14PKLibrary;
using N14PKLibrary.Data;
using N14PKLibrary.HelperClass;

class N14PKBrowseExtension
{
	public static void Function( N14PK n14pk, int id, YousyoData data )
	{
		var yousyo = data;

		foreach ( var kaidou in n14pk.Kaidoutable )
		{
			if ( ( ( kaidou.PtrYousyo1 == yousyo.Address ) || ( kaidou.PtrYousyo2 == yousyo.Address ) )
					&& ( 1 < kaidou.JoutaiFlag )
				)
			{
				// �X���̗��[�ǂ��炩���v���ƈ�v �� �������X��

				kaidou.JoutaiFlag &= Convert.ToByte( "00000001", 2 );

				n14pk.Kaidoutable.Write( kaidou );
			}
		}
	}
}
