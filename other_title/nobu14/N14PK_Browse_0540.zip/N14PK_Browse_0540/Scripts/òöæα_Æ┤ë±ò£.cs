using System;

using N14PKLibrary;
using N14PKLibrary.Data;
using N14PKLibrary.HelperClass;

class N14PKBrowseExtension
{
	public static void Function( N14PK n14pk, int id, ButaiData data )
	{
		if ( data.Heisuu < data.HeisuuMax )
		{
			data.Heisuu = data.HeisuuMax;
		}

		if ( data.HyourouNissuu < byte.MaxValue )
		{
			data.HyourouNissuu = byte.MaxValue;
		}

		n14pk.Butaitable.Write( data );
	}
}
