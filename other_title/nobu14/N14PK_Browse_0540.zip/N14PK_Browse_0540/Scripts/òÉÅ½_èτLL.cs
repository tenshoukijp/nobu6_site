using System;

using N14PKLibrary;
using N14PKLibrary.Data;
using N14PKLibrary.HelperClass;

class N14PKBrowseExtension
{
	public static void Function( N14PK n14pk, int id, BusyouData data )
	{
		data.IsLLKao = true;

		n14pk.Busyoutable.Write( data );
	}
}
