using System;

using N14PKLibrary;
using N14PKLibrary.Data;
using N14PKLibrary.HelperClass;

class N14PKBrowseExtension
{
	public static void Function( N14PK n14pk, int id, KaidouData data )
	{
		var n = data.ChikeiID;

		var level = ( n == 0 ) ? 4	// ���n
			: ( n == 1 ) ? 2		// �R
			: ( n == 2 ) ? 4		// ���n(��)
			: ( n == 3 ) ? 4		// �ߊC
			: ( n == 4 ) ? 0		// ���C
			: 0;

		data.SeibiLV = (uint)level;

		n14pk.Kaidoutable.Write( data );
	}
}
