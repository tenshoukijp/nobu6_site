using System;

using N14PKLibrary;
using N14PKLibrary.Data;
using N14PKLibrary.HelperClass;

class N14PKBrowseExtension
{
	public static void Function( N14PK n14pk, int id, ShiroData shiro )
	{
		bool[] isRinsetsu;
		var cnt = 10;

		for ( var kukakuid = 0; kukakuid < cnt; kukakuid++ )
		{
			// ��敪�̃t���O���쐬(����������)
			isRinsetsu = new bool[cnt];
			
			for ( var i = 0; i < cnt; i++ )
			{
				isRinsetsu[i] = ( i != kukakuid );
			}
			
			shiro.Kukaku[kukakuid].IsRinsetsu = isRinsetsu;
		}

		CheckRankHosei( n14pk, shiro );
		n14pk.Shirotable.Write( shiro );
	}

	// ���␳�`�F�b�N
	private static void CheckRankHosei( N14PK n14pk, ShiroData shiro )
	{
		
		for ( int i = 0; i < shiro.Kukaku.Length; i++ )
		{
			// ��搔�J��Ԃ�
			byte kokudakaHosei = 0;
			byte syougyouHosei = 0;
			byte heisyaHosei = 0;
			var shisetsu = ( shiro.Kukaku[i].ShisetsuID != -1 ) ? n14pk.Shisetsutable[shiro.Kukaku[i].ShisetsuID] : null;

			if ( shisetsu != null )
			{
				kokudakaHosei = shisetsu.UpRankNougyou;		// �{�݂̐΍��␳
				syougyouHosei = shisetsu.UpRankSyougyou;	// �{�݂̏��ƕ␳
				heisyaHosei = shisetsu.UpRankHeisya;		// �{�݂̕��ɕ␳
			}

			// �אڋ����`�F�b�N
			for ( int j = 0; j < shiro.Kukaku[i].IsRinsetsu.Length; j++ )
			{
				if ( shiro.Kukaku[i].IsRinsetsu[j] )
				{
					// �אڋ��̎{�݂��擾
					shisetsu = ( shiro.Kukaku[j].ShisetsuID != -1 ) ? n14pk.Shisetsutable[shiro.Kukaku[j].ShisetsuID] : null;
					if ( shisetsu != null)
					{
						kokudakaHosei += shisetsu.UpRankNougyouRinsetsu;	// �אڋ�悩��󂯂�΍��␳
						syougyouHosei += shisetsu.UpRankSyougyouRinsetsu;	// �אڋ�悩��󂯂鏤�ƕ␳
						heisyaHosei += shisetsu.UpRankHeisyaRinsetsu;		// �אڋ�悩��󂯂镺�ɕ␳
					}
				}
			}
			shiro.Kukaku[i].KokudakaRankHosei = kokudakaHosei;
			shiro.Kukaku[i].SyougyouRankHosei = syougyouHosei;
			shiro.Kukaku[i].HeisyaRankHosei = heisyaHosei;

			// �΍��E���ƁE���ɂ̍ő�l���`�F�b�N
			CheckMax( shiro, shiro.Kukaku[i] );
		}
	}

	// �΍��E���ƁE���ɍő�l�`�F�b�N
	private static void CheckMax( ShiroData shiro, KukakuData k )
	{
		// �����N�␳�v
		var hoseigoukei = 0;

		// ���ő�l
		var max = 0;

		// ��S�̂̍ő�l�Ƃ̍���
		var diff = 0;

		if ( k.KokudakaMax != 0 )
		{
			// �_�Ƌ��
			hoseigoukei = k.KokudakaRankBase + k.KokudakaRankHosei;
			max = k.KukakuBase * 3 * ( ( hoseigoukei <= 18 ) ? hoseigoukei + 1 : 18 + 1 );
			diff = max - k.KokudakaMax;
			
			// ���̍ő�l���Z�b�g
			k.KokudakaMax = (short)max;

			// ��S�̂̍ő�l�C��
			shiro.KokudakaMax += (short)diff;
			if ( shiro.KokudakaMax < shiro.KokudakaNow )
				shiro.KokudakaNow = shiro.KokudakaMax;
		}
		else if ( k.SyougyouMax != 0  )
		{
			// ���Ƌ��
			hoseigoukei = k.SyougyouRankBase + k.SyougyouRankHosei;
			max = k.KukakuBase * 3 * ( ( hoseigoukei <= 18 ) ? hoseigoukei + 1 : 18 + 1 );
			diff = max - k.SyougyouMax;
			k.SyougyouMax = (short)max;
			shiro.SyougyouMax += (short)diff;
			if ( shiro.SyougyouMax < shiro.SyougyouNow )
				shiro.SyougyouNow = shiro.SyougyouMax;
		}
		else if ( k.HeisyaMax != 0  )
		{
			// ���ɋ��
			hoseigoukei = k.HeisyaRankBase + k.HeisyaRankHosei;
			max = k.KukakuBase * 3 * ( ( hoseigoukei <= 18 ) ? hoseigoukei + 1 : 18 + 1 );
			diff = max - k.HeisyaMax;
			k.HeisyaMax = (short)max;
			shiro.HeisyaMax += (short)diff;
			if ( shiro.HeisyaMax < shiro.HeisyaNow )
				shiro.HeisyaNow = shiro.HeisyaMax;
		}
	}
}
