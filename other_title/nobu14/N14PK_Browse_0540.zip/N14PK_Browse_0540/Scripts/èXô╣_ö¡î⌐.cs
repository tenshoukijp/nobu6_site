using System;

using N14PKLibrary;
using N14PKLibrary.Data;
using N14PKLibrary.HelperClass;

class N14PKBrowseExtension
{
	public static void Function( N14PK n14pk, int id, KaidouData data )
	{
		data.JoutaiFlag &= Convert.ToByte( "00000001", 2 );

		n14pk.Kaidoutable.Write( data );
	}
}
