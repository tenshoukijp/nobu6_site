using System;

using N14PKLibrary;
using N14PKLibrary.Data;
using N14PKLibrary.HelperClass;

class N14PKBrowseExtension
{
	public static void Function( N14PK n14pk, int id, BusyouData data )
	{
		data.TousotsuExp	= 0;
		data.BuyuuExp		= 0;
		data.ChiryakuExp	= 0;
		data.SeijiExp		= 0;

		n14pk.Busyoutable.Write( data );
		//// 以下3つも同じ
		//n14pk.Busyoutable.Write( id, data.GetRecord() );
		//n14pk.Datatables[(int)DataKind.武将].Write( data );
		//n14pk.Datatables[(int)DataKind.武将].Write( id, data.GetRecord() );
	}
}
